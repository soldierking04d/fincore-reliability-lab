/** 首页与详细索引使用同一份主题定义；子链接直接定位原有章节。 */
export const portfolioTopics = [
  { title: '交易系统与资金正确性', detail: '订单、资金预占、交割与对账；附架构和代码', href: '#system-architecture', links: [['交易链路', '#full-lifecycle'], ['代码与事务', '#implementation'], ['行业案例', '#industry-cases']] },
  { title: '结算性能优化', detail: '资金事务、幂等冲突、租约过期与逐笔验账', href: '#settlement-optimization', links: [['实现与代码', '#settlement-implementation'], ['测试记录', '#settlement-evidence'], ['实施手册', '#settlement-handbook']] },
  { title: '交易、支付与一致性边界', detail: '下单与资金、支付与兑换、故障恢复、对账', href: '#transaction-boundaries', links: [['模块概览', '#transaction-boundaries'], ['逐笔订单', '#order-case'], ['支付与兑换', '#execution-case']] },
  { title: '性能与技术选型', detail: '中间件、热点账户、JVM、低延迟和语言对比', href: '#performance-engineering', links: [['中间件与热点', '#performance-engineering'], ['CPU / GPU', '#low-latency'], ['Java / C++', '#java-cpp-migration']] },
  { title: '运行时安全与漏洞治理', detail: 'PHP 近期漏洞、依赖补丁、请求隔离与发布验收', href: '#runtime-security', links: [['修复步骤', '#runtime-security-remediation'], ['跨语言对照', '#runtime-security-languages'], ['离线核对', '#runtime-security-checker']] },
  { title: '钱包安全与第三方供应链', detail: '事件事实、业务止损、签名意图与恢复门禁', href: '#authority-boundaries', links: [['事实分级', '#authority-facts'], ['防御架构', '#authority-architecture'], ['防御实验', '#authority-lab']] },
  { title: '团队与业务交付', detail: '优先级、运营放量、人员备份与协作方案', href: '#management', links: [['决策场景', '#management-decisions'], ['协作演练', '#management-case']] },
  { title: 'AI 辅助研发', detail: '代码理解、内部需求、缺陷修复与人工验收', href: '#ai', links: [['研发实施', '#ai'], ['历史评测', '#ai-evaluations']] },
  { title: '数字资产与交易所扩展', detail: '合约风险、充值提现、最终性与外围能力实验', href: '#blockchain', links: [['链上可靠性', '#blockchain'], ['交易所九域', '#exchange-coverage']] },
  { title: '运行与监控', detail: '后台实验与教学回放分开，核对业务和系统指标', href: '#demo', links: [['运行演示', '#demo'], ['代表案例', '#profile-cases'], ['详细索引', '#outline']] },
] as const;
