/** 固定只读查询，不接受用户任意 PromQL。数据仅代表 FinCore 应用，不代表整台机器。 */
export const METRICS = {
  cpu: { label: '应用 CPU', unit: '%', query: '100 * process_cpu_usage{job="fincore"}' },
  qps: { label: '业务 HTTP QPS · 1 分钟', unit: 'req/s', query: 'sum(rate(http_server_requests_seconds_count{job="fincore",uri!~"/actuator.*"}[1m]))' },
  heap: { label: 'JVM 已用堆', unit: 'MiB', query: 'sum(jvm_memory_used_bytes{job="fincore",area="heap"}) / 1024 / 1024' },
  db: { label: '活跃数据库连接', unit: '个', query: 'sum(hikaricp_connections_active{job="fincore"})' },
} as const;
export type MetricKey = keyof typeof METRICS;
export type MetricSample = { value: number; sampledAt: number };
export function metricEndpoint(key: MetricKey, hostname: string): string {
  const path = `/prometheus/api/v1/query?query=${encodeURIComponent(metricQuery(key))}`;
  return hostname === '124.223.164.254' ? path : `https://124.223.164.254${path}`;
}
/** 应用最近采集失败或 up 已过期时，不显示 Prometheus 回看窗口中的旧值。 */
export function metricQuery(key: MetricKey): string {
  return `(${METRICS[key].query}) and on() (max(up{job="fincore"}) == 1) and on() (max(timestamp(up{job="fincore"})) > time() - 45)`;
}
/** 过期、空向量、多结果或 NaN 均显示缺数，不能转换成零。 */
export function parseMetric(payload: unknown, now = Date.now()): MetricSample {
  const body = payload as { status?: string; data?: { result?: { value?: unknown[] }[] } } | null;
  const result = body?.data?.result;
  if (body?.status !== 'success' || !Array.isArray(result) || result.length !== 1) throw new Error('未取得唯一监控样本');
  const pair = result[0].value;
  if (!pair || typeof pair[0] !== 'number' || typeof pair[1] !== 'string' || !pair[1].trim()) throw new Error('监控格式异常');
  const value = Number(pair[1]), sampledAt = pair[0] * 1000;
  if (!Number.isFinite(value) || value < 0 || !Number.isFinite(sampledAt)
    || now - sampledAt > 60_000 || sampledAt - now > 30_000) throw new Error('监控样本缺失或过期');
  return { value, sampledAt };
}
