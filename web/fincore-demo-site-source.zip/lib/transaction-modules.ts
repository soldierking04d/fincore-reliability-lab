/** 一个专题只归属一个模块；导航和展示共享映射，防止内容新增后成为孤岛。 */
export const boundaryModules = [
  { id:'orders', title:'下单与资金', question:'成交之后，订单和余额怎样变化？', outcome:'逐笔核对成交、手续费和撤单释放。', path:['委托','撮合','交割','可用余额'], topics:[], cases:['order-case'], scope:'现有 Java 闭环＋5 个数值模型', source:'model.mjs' },
  { id:'execution', title:'支付与兑换', question:'外部结果不确定，怎样避免多付和超退？', outcome:'演示超时、退款预占和部分对冲。', path:['受理','外部尝试','核查结果','履约'], topics:['payment-execution','callback-refund','stablecoin-fx'], cases:['execution-case'], scope:'3 个内存案例；外部渠道未接入', source:'execution-model.mjs' },
  { id:'recovery', title:'故障与恢复', question:'只完成一半，或主节点宕机，如何继续？', outcome:'看清提交决定、水位和旧主隔离。', path:['保留中间态','确认决定','幂等恢复','核验完成'], topics:['cross-shard','commit-protocols','recovery-storage'], cases:['workflow-case','recovery-case'], scope:'5 个内存案例；非真实 XA / HA', source:'recovery-model.mjs' },
  { id:'assurance', title:'对账与交付', question:'怎样证明结果可信，而不是看起来正常？', outcome:'区分在途与缺失，再核对事务和交付证据。', path:['统一切面','发现差异','隔离核查','验证交付'], topics:['reconciliation-cuts','runtime-governance'], cases:['reconciliation-case'], scope:'1 个对账模型＋既有工程专项', source:'execution-model.mjs' },
] as const;

export type BoundaryModuleId = typeof boundaryModules[number]['id'];

/** 纯映射便于回归；畸形或无关 hash 不影响站点其他专题。 */
export function moduleForHash(hash: string): BoundaryModuleId | null {
  let id: string;
  try { id = decodeURIComponent(hash.replace(/^#/,'')); } catch { return null; }
  return boundaryModules.find(module => id === `boundary-module-${module.id}` ||
    (module.cases as readonly string[]).includes(id) ||
    (module.topics as readonly string[]).some(topic => id === `boundary-${topic}`))?.id ?? null;
}
