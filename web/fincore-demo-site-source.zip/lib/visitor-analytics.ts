/** 只上报本站公开章节，不发送查询参数或任意 hash 中可能携带的私密内容。 */
export function visitorPage(hash: string): string {
  return /^#[a-z][a-z0-9-]{0,79}$/.test(hash) ? `/${hash}` : '/';
}

/** 来源仅保留 HTTP(S) 域名及端口，不记录来源路径、凭据或查询参数。 */
export function visitorReferrer(referrer: string): string {
  try {
    const url = new URL(referrer);
    return /^https?:$/.test(url.protocol) && !url.username && !url.password ? url.origin : '';
  } catch {
    return '';
  }
}

/** 仅用于单次事件幂等，不跨页面保存，也不作为访客身份。 */
export function visitorEventId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
