/** 场景是团队工作方法，不是模型实测成绩。代码实验结果另从带源码摘要的报告读取。 */
export const developerAiCases = [
  {
    id: 'understand',
    title: '读懂仓库，定位改动',
    short: '少问人、少翻代码',
    problem:
      '新人接到“账户摘要展示”任务，不知道入口、数据来源和哪些地方不能改。把整个仓库丢给 AI，得到的可能是不存在的调用链。',
    input:
      '只读分析账户摘要查询：给出 HTTP 入口 → 应用服务 → MyBatis SQL 的真实路径、方法名和证据。区分已确认与待确认，不改代码、不连接数据库。',
    steps: [
      '读取仓库地图、已有 AGENTS.md 与相关源文件；不把所有历史资料塞进上下文。',
      '沿方法引用追踪到 SQL，返回文件和符号，不靠目录名猜调用关系。',
      '开发者打开引用核对，再决定改哪里；当前地图不等于运行时调用追踪。',
    ],
    output: '一份可核查的影响分析：入口、调用链、数据来源、候选测试和未知项。',
    benefit:
      '减少寻找入口、重复询问资深同事的时间；把熟悉仓库的方法沉淀给下一位开发者。',
    downside:
      '代码索引或文档过期会让解释自信但错误。要求实际文件证据，模块负责人维护地图；不能把未跑测试写成已验证。',
    measure: '从接单到找对修改点的用时、引用准确率、资深同事被打断次数。',
  },
  {
    id: 'implement',
    title: '按团队规范做小需求',
    short: '少写样板、控制改动',
    problem:
      '内部工单查询要限制分页大小并规范化关键词。AI 写得很快，但容易另造一套风格、扩大修改范围，或把整数越界漏掉。',
    input:
      '实现内部工单查询参数规范化：page 从 0 开始，size 为 1–200，offset 使用 long；null 关键词变空串，去掉首尾 Unicode 空白。仅改隔离练习模块，保留既定测试，不增加依赖。',
    steps: [
      '给 AI 任务单、输入输出合同、允许修改路径和一份本仓库的实现参考。',
      '先确认边界，再生成候选补丁；一次只做这一个小需求，不顺手重构其他模块。',
      '编译、跑独立测试、逐块看差异；负责人检查兼容性，再走原有 PR 与 CI。',
    ],
    output: '可运行 Java 代码、逐行补丁、正常与异常测试、改动范围说明。',
    benefit:
      '把参数处理、重复编码和测试骨架交给 AI，人保留接口合同、取舍与验收。',
    downside:
      '代码量变多不等于产出变多。限制单次任务范围；评审者若无法解释补丁，就不能因为全绿而合并。',
    measure:
      '接单到可评审补丁的总用时，加上 review、返工和工具等待；同时看缺陷率。',
  },
  {
    id: 'repair',
    title: '用失败测试驱动修复',
    short: '先复现，再证明修好',
    problem:
      '分页很大时 offset 变成负数。只贴异常让 AI 猜原因，可能得到“把结果转成 long”的错误补丁：溢出早在 int 乘法时发生。',
    input:
      '用 page=2147483647、size=200 复现分页偏移溢出。不要改测试期望，解释运算发生在哪种类型，再做最小修复；把旧版失败和新版通过的逐项结果交付。',
    steps: [
      '使用合成输入稳定复现；编译失败或环境缺失不能冒充“发现缺陷”。',
      '先提升操作数为 long 再相乘，而不是溢出后才转型；同时保护正常输入行为。',
      '同一组用例分别运行旧版与修复版，保存 actual、expected 与源码摘要；修复结果进入正常人工审查。',
    ],
    output: '红 → 绿的 Java 实际执行报告，以及能解释根因的最小改动。',
    benefit:
      '减少查错和重复运行的时间，让修复依据可以复查，而不是相信 AI 的一句“已修复”。',
    downside:
      'AI 可能改掉断言来“修好”测试。用例合同由人确定，关键期望不与实现共用计算函数，检查漏测和回归。',
    measure:
      '复现耗时、修复总耗时、再次打开率、是否保留正常基线；不按生成测试数量奖励。',
  },
] as const;

export const repositoryTrace = [
  {
    path: 'src/main/java/dev/fincore/web/AccountController.java',
    symbol: 'summary(UUID)',
    detail: 'GET /api/accounts/{id}/ledger-summary：映射 HTTP 请求。',
  },
  {
    path: 'src/main/java/dev/fincore/application/AccountService.java',
    symbol: 'ledgerSummary(UUID)',
    detail: '委托 Mapper，组装余额、账本净额与期望余额。',
  },
  {
    path: 'src/main/java/dev/fincore/infrastructure/persistence/mapper/AccountMapper.java',
    symbol: 'summarizeLedger(UUID)',
    detail:
      'SQL 关联 account 与 ledger_entry，在数据库中汇总，不读全量分录到 JVM。',
  },
] as const;
