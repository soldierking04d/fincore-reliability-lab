export type PerformanceDetailKey =
  | 'virtual-threads'
  | 'matching-lanes'
  | 'kafka-consumers'
  | 'hikari-pool'
  | 'tomcat-admission'
  | 'symbol-lane'
  | 'database-locks'
  | 'outbox-batch'
  | 'overload-429'
  | 'overload-503'
  | 'idempotent-retry'
  | 'uuid-ordering'
  | 'ledger-batch'
  | 'outbox-publish'
  | 'lease-coalescing'
  | 'g1'
  | 'zgc'
  | 'observability'
  | 'load-test';

export type PerformanceDetail = {
  eyebrow: string;
  title: string;
  summary: string;
  configurations: string[];
  flow: string[];
  metrics: string[];
  failure: string;
  verification: string[];
  sourcePath: string;
  sourceLabel: string;
  code: string;
};

const sourceRoot = 'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/';

export const performanceDetails: Record<PerformanceDetailKey, PerformanceDetail> = {
  'virtual-threads': {
    eyebrow: 'WEB · JAVA 21',
    title: '虚拟线程只承接短时阻塞 I/O',
    summary: 'Spring MVC 请求使用 Java 21 虚拟线程，撮合、Kafka Consumer 和定时任务仍使用隔离的平台线程。这样既减少阻塞请求的线程内存，又避免长生命周期任务或 synchronized 代码固定载体线程。',
    configurations: ['spring.threads.virtual.enabled=true', 'JDK 21', 'Kafka / 撮合 / Scheduler 显式平台线程'],
    flow: ['HTTP 请求进入 Tomcat', 'Spring 为请求创建虚拟线程', '写命令进入有界撮合 Lane', '事务与消息传播在隔离资源中执行'],
    metrics: ['jvm.threads.virtual.pinned', 'jvm.threads.virtual.submit.failed', 'http.server.requests', 'fincore.matching.queue.wait'],
    failure: '如果数据库驱动、锁或 native 调用长时间 pin 住载体线程，虚拟线程数量虽高，真实并发仍会下降；因此 pinned 事件必须和延迟一起观察。',
    verification: ['启动服务后读取 /actuator/prometheus', '压测期间查看 pinned 计数是否持续增长', '对比 HTTP P95 与撮合队列等待时间'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/concurrent/ConcurrencyConfiguration.java',
    sourceLabel: 'ConcurrencyConfiguration.java',
    code: `@Bean(destroyMethod = "close")
VirtualThreadMetrics virtualThreadMetrics() {
    // 暴露虚拟线程固定载体和提交失败指标。
    return new VirtualThreadMetrics();
}

// application.yml
spring:
  threads:
    virtual:
      enabled: true`,
  },
  'matching-lanes': {
    eyebrow: 'MATCHING · BOUNDED LANES',
    title: '同交易对串行、跨交易对并行',
    summary: '交易对经过稳定散列后进入 4 个固定 Lane。每个 Lane 只有一个平台线程，普通新单容量 256、撤单保留容量 32；撤单可越过尚未开始的普通积压，但仍与成交共享同一顺序。',
    configurations: ['matching-lanes=4', 'ordinary-capacity=256', 'cancel-reserve=32', 'PriorityCommandQueue + AbortPolicy'],
    flow: ['symbol 计算稳定 hash', '普通/撤单进入独立有界容量', '同一平台线程按 8:1 出队', '队列满时明确拒绝并返回 429'],
    metrics: ['fincore.matching.lane.queue.depth', 'fincore.matching.cancel.lane.queue.depth', 'fincore.matching.queue.rejected', 'fincore.matching.cancel.queue.rejected'],
    failure: '队列饱和时不会使用 CallerRuns，也不会静默丢弃。普通新单不能挤占撤单容量；任何超时仍需先查询权威订单状态。',
    verification: ['对同一 symbol 并发提交请求并核对成交顺序', '压满普通队列后确认新单 429、撤单仍受理', '确认撤单先于普通积压且不会抢占当前事务'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/concurrent/StripedTaskExecutor.java',
    sourceLabel: 'StripedTaskExecutor.java',
    code: `PriorityCommandQueue queue = new PriorityCommandQueue(
    ordinaryCapacity, cancelReserveCapacity, 8);

ThreadPoolExecutor executor = new ThreadPoolExecutor(
    1, 1, 0L, TimeUnit.MILLISECONDS, queue,
    Thread.ofPlatform().name("fincore-matching-" + lane + "-", 0).factory(),
    new ThreadPoolExecutor.AbortPolicy());

// 撤单使用保留容量，但仍由同一 Lane 执行。
executor.execute(new PriorityRunnable(cancelCommand));`,
  },
  'kafka-consumers': {
    eyebrow: 'KAFKA · SETTLEMENT',
    title: '消费者并发数受 CPU 和配置双重约束',
    summary: '结算 Consumer 数量取配置上限与可用 CPU 的较小值。每个 Consumer 使用一个独立平台线程和零容量交接队列，避免无界排队以及 Kafka Consumer 被错误跨线程使用。',
    configurations: ['effectiveConsumers=min(configured, availableProcessors)', 'max.poll.records=50', 'queueCapacity=0'],
    flow: ['Kafka poll 最多取得 50 条记录', '固定 Consumer 线程调用 Listener', 'Inbox 唯一键先去重', '资金事务提交后再确认处理结果'],
    metrics: ['fincore.settlement.consumer.inflight', 'kafka.consumer.fetch.manager.records.lag', 'fincore.settlement.process', 'fincore.inbox.duplicate'],
    failure: '盲目增加消费者会把压力转移到数据库连接池，并可能触发 rebalance 或处理超时；因此线程数不能超过 CPU 和下游预算。',
    verification: ['检查启动日志中的有效并发数', '制造重复消息并确认只产生一次资金效果', '同时观察 Kafka Lag 与 Hikari pending'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/concurrent/ConcurrencyConfiguration.java',
    sourceLabel: 'ConcurrencyConfiguration.java',
    code: `int consumerConcurrency = properties.effectiveSettlementConsumers();
executor.setCorePoolSize(consumerConcurrency);
executor.setMaxPoolSize(consumerConcurrency);
executor.setQueueCapacity(0);
factory.setConcurrency(consumerConcurrency);`,
  },
  'hikari-pool': {
    eyebrow: 'POSTGRESQL · HIKARI',
    title: '连接池就是数据库并发预算',
    summary: '项目默认最多 12 个连接并设置 1.5 秒获取超时；4GB 云演示机为给 PostgreSQL、Kafka 和系统缓存留空间，部署值进一步收紧。请求线程不会驱动连接数无限膨胀。',
    configurations: ['maximum-pool-size=12（项目默认）', 'connection-timeout=1500ms', '云演示机按 4GB 规格收紧'],
    flow: ['事务申请连接', '池内有额度则立即取得', '额度耗尽时最多等待 1.5 秒', '超时返回可识别错误而非无限堆积'],
    metrics: ['hikaricp.connections.active', 'hikaricp.connections.pending', 'hikaricp.connections.timeout', 'jdbc.connections.max'],
    failure: '把连接池调大通常只会增加 PostgreSQL 上下文切换、锁等待和内存占用，不能修复慢 SQL 或热点锁。',
    verification: ['压测时观察 active 是否长期贴顶', 'pending 上升时同时检查 SQL 与锁等待', '确认超时请求没有占住业务线程无限等待'],
    sourcePath: 'src/main/resources/application.yml',
    sourceLabel: 'application.yml',
    code: `spring:
  datasource:
    hikari:
      maximum-pool-size: \${FINCORE_DB_POOL_SIZE:12}
      minimum-idle: \${FINCORE_DB_POOL_SIZE:12}
      connection-timeout: 1500`,
  },
  'tomcat-admission': {
    eyebrow: '01 · ADMISSION',
    title: '先在 HTTP 接入层限制积压',
    summary: 'Tomcat 的最大连接和 accept 队列给整个服务设置第一道硬边界。云演示机采用比项目默认值更保守的配置，防止 4GB 机器被大量空闲 socket 和排队请求挤占。',
    configurations: ['max-connections=4096（项目默认）', 'accept-count=256（项目默认）', '云演示机：512 / 128'],
    flow: ['客户端建立连接', 'Tomcat 检查连接额度', 'accept 队列吸收短时突发', '请求进入业务准入层'],
    metrics: ['tomcat.connections.current', 'tomcat.connections.max', 'tomcat.threads.busy', 'http.server.requests'],
    failure: '连接与队列都满时，新连接会被拒绝或超时；这是有界系统的预期表现，需要由负载均衡和客户端退避吸收。',
    verification: ['逐步提高并发连接数', '观察连接数与 P95 拐点', '确认容量边界外没有内存持续增长'],
    sourcePath: 'src/main/resources/application.yml',
    sourceLabel: 'application.yml',
    code: `server:
  tomcat:
    max-connections: \${FINCORE_TOMCAT_MAX_CONNECTIONS:4096}
    accept-count: \${FINCORE_TOMCAT_ACCEPT_COUNT:256}`,
  },
  'symbol-lane': {
    eyebrow: '02 · LOCAL SERIALIZATION',
    title: '本地 Lane 削平热点锁竞争',
    summary: '同一个交易对在单实例内只保留一个并发写者，减少大量线程同时争抢同一把 PostgreSQL advisory lock；不同交易对仍能并行。',
    configurations: ['4 lanes', '256 queued tasks per lane', 'stable symbol hashing'],
    flow: ['请求携带 symbol', 'MatchingCommandCoordinator 提交 Lane', 'Lane 保序调用 MatchingService', 'CompletableFuture 返回结果'],
    metrics: ['fincore.matching.queue.depth.total', 'fincore.matching.queue.wait', 'fincore.matching.execution', 'fincore.matching.queue.rejected'],
    failure: '单个热点交易对会填满自己的 Lane，但不会让其他 Lane 的交易对一起失去吞吐。',
    verification: ['对一个 symbol 制造热点', '并行请求另一个 symbol', '检查热点 Lane 深度与独立 Lane 吞吐'],
    sourcePath: 'src/main/java/dev/fincore/application/MatchingCommandCoordinator.java',
    sourceLabel: 'MatchingCommandCoordinator.java',
    code: `return matchingTaskExecutor
    .submit(command.symbol(), () -> matchingService.match(command))
    .orTimeout(waitTimeout.toMillis(), TimeUnit.MILLISECONDS);`,
  },
  'database-locks': {
    eyebrow: '03 · CROSS-INSTANCE ORDER',
    title: 'PostgreSQL 是多实例最终串行化边界',
    summary: '本地 Lane 只能约束单个 JVM。真正跨副本的交易对写顺序由事务级 advisory lock 保证，资金账户再按稳定 UUID 顺序逐行 FOR UPDATE。',
    configurations: ['pg_advisory_xact_lock(hash(symbol))', 'SELECT ... FOR UPDATE', '稳定 UUID 锁顺序'],
    flow: ['事务开始', '获取交易对 advisory lock', '读取并锁定可成交订单', '更新订单、写成交与 Outbox 后统一提交'],
    metrics: ['pg_locks', 'pg_stat_activity.wait_event', 'fincore.matching.execution', 'hikaricp.connections.pending'],
    failure: '如果多个路径以不同顺序锁账户，可能形成死锁；项目统一复用 UuidOrder，并把资金更新放在同一事务内。',
    verification: ['启动两个应用副本同时写同一 symbol', '核对成交序列仍唯一且有序', '确认事务回滚时订单和事件一起回滚'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/persistence/mapper/MatchingMapper.java',
    sourceLabel: 'MatchingMapper.java',
    code: `@Select("SELECT pg_advisory_xact_lock(hashtextextended(#{symbol}, 0))")
void lockSymbol(@Param("symbol") String symbol);

// 事务结束时 advisory lock 自动释放。`,
  },
  'outbox-batch': {
    eyebrow: '04 · ASYNC PROPAGATION',
    title: 'Outbox 批量抢占、并发发送、批量回写',
    summary: '业务事务只写 Outbox。Publisher 通过 FOR UPDATE SKIP LOCKED 抢占最多 200 条，异步等待 Kafka ack，再将成功与失败编号分别批量回写。',
    configurations: ['outbox-batch-size=200（项目默认）', '云演示机=100', 'FOR UPDATE SKIP LOCKED'],
    flow: ['业务数据与事件同事务提交', 'Publisher 原子抢占一批事件', 'KafkaTemplate 异步发送', '成功标记 PUBLISHED，失败退避重试'],
    metrics: ['fincore.outbox.ready.backlog', 'fincore.outbox.claimed', 'fincore.outbox.published', 'fincore.outbox.uncertain'],
    failure: 'ack 超时时结果未知，记录不会被误标为成功；超时抢占由恢复任务回收，保证至少一次传播。',
    verification: ['停止 Kafka 后提交业务事务', '确认 Outbox 保持待发送', '恢复 Kafka 后观察积压归零且消费者幂等'],
    sourcePath: 'src/main/java/dev/fincore/messaging/OutboxPublisher.java',
    sourceLabel: 'OutboxPublisher.java',
    code: `List<OutboxEventRow> events = outboxMapper.claimBatch(publisherId, batchSize);
publishClaimed(events);

// 全部发送为异步 Future；完成后再分组批量回写。
CompletableFuture.allOf(futures).get(awaitTimeout.toNanos(), NANOSECONDS);`,
  },
  'overload-429': {
    eyebrow: 'OVERLOAD · 429',
    title: 'Lane 已满：请求明确未入队',
    summary: 'AbortPolicy 在容量耗尽时立即抛出业务化的 ConcurrencyRejectedException，由统一异常处理映射为 429。调用方可保留原幂等键退避重试。',
    configurations: ['普通/撤单双有界容量', 'AbortPolicy', 'HTTP 429 Too Many Requests'],
    flow: ['Lane 队列满', 'execute 抛 RejectedExecutionException', '记录 rejected 指标', '返回带 retryable 语义的 429'],
    metrics: ['fincore.matching.queue.rejected', 'fincore.matching.queue.depth.total', 'http.server.requests{status="429"}'],
    failure: '不会 CallerRuns 让 Web 线程绕过队列，也不会 DiscardPolicy 静默丢单，因此客户端能准确知道请求未被接受。',
    verification: ['将 Lane 和队列容量临时调小', '并发提交直到出现 429', '用同一 clientOrderId 重试并核对只产生一次结果'],
    sourcePath: 'src/main/java/dev/fincore/web/ApiExceptionHandler.java',
    sourceLabel: 'ApiExceptionHandler.java',
    code: `@ExceptionHandler(ConcurrencyRejectedException.class)
ResponseEntity<ApiError> handleRejected(ConcurrencyRejectedException exception) {
    return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
        .body(ApiError.retryable(exception.getMessage()));
}`,
  },
  'overload-503': {
    eyebrow: 'OVERLOAD · 503',
    title: '等待或下游确认超时：结果不可伪装',
    summary: '调用方等待撮合或 Kafka 确认超过预算时返回 503，并带可重试语义。已经进入数据库事务的工作不会被粗暴取消，避免调用方收到失败但后台发生半截状态。',
    configurations: ['明确超时预算', 'HTTP 503 Service Unavailable', 'retryable=true'],
    flow: ['进入有界执行链', '等待超过服务预算', '标记结果未知或可重试', '客户端沿用同一幂等键查询或重试'],
    metrics: ['http.server.requests{status="503"}', 'fincore.matching.queue.wait', 'fincore.outbox.uncertain', 'kafka.producer.request.latency'],
    failure: '超时不等于事务一定失败。服务端必须依赖幂等记录和最终查询来消除“客户端不知道结果”的歧义。',
    verification: ['注入数据库或 Kafka 延迟', '确认接口返回 503 与 retryable', '延迟解除后用同一幂等键核对唯一结果'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/concurrent/ConcurrencyTimeoutException.java',
    sourceLabel: 'ConcurrencyTimeoutException.java',
    code: `throw new ConcurrencyTimeoutException(
    "matching wait timed out; query or retry with the same idempotency key"
);`,
  },
  'idempotent-retry': {
    eyebrow: 'OVERLOAD · IDEMPOTENCY',
    title: '重复请求由业务键和数据库唯一约束兜底',
    summary: 'clientOrderId、messageId、businessKey 和 repair key 分别覆盖订单入口、消息消费、资金事务和修复动作。应用层先识别重复，数据库唯一约束处理最终并发竞争。',
    configurations: ['client_order_id UNIQUE', 'inbox message_id UNIQUE', 'ledger business_key UNIQUE', 'repair idempotency key UNIQUE'],
    flow: ['请求携带稳定业务键', '查询或插入幂等记录', '并发冲突由唯一约束裁决', '返回已存在结果或拒绝载荷篡改'],
    metrics: ['fincore.idempotency.replayed', 'fincore.inbox.duplicate', 'fincore.repair.skipped', 'ledger transaction count'],
    failure: '撮合与盘前入口会校验同键载荷；结算专项已补通用路径的完整经济字段比较与消息关联回归。HTTP 202 仍只是受理，异步消费时的冲突不等于资金完成；公网运行版本以发行记录为准。',
    verification: ['完全相同请求并发重放', '确认响应一致且业务效果一次', '修改金额但复用同一键，确认冲突被拒绝'],
    sourcePath: 'src/main/java/dev/fincore/application/MatchingService.java',
    sourceLabel: 'MatchingService.java',
    code: `// 应用层快速返回已完成结果，数据库唯一键裁决并发首次写入。
IdempotencyRecord existing = repository.find(clientOrderId);
if (existing != null) {
    existing.requireSamePayload(payloadHash);
    return existing.result();
}`,
  },
  'uuid-ordering': {
    eyebrow: 'CPU · LOCK ORDER',
    title: '直接比较 UUID 的 128 位数值',
    summary: '资金事务要稳定排序多个账户锁。比较器直接读取 UUID 的两个 64 位分量并做无符号比较，避免在高频路径创建 UUID 字符串。',
    configurations: ['Long.compareUnsigned', '统一共享 Comparator', '排序后移除重复账户'],
    flow: ['收集相关账户 UUID', '按高 64 位比较', '相同时比较低 64 位', '以唯一顺序逐个 FOR UPDATE'],
    metrics: ['JFR allocation profile', 'transaction duration', 'PostgreSQL deadlocks', 'CPU samples'],
    failure: '不同资金路径若使用不同锁顺序，即使单次事务正确，也可能在并发下形成死锁环。',
    verification: ['JFR 检查 UUID.toString 分配是否离开热点', '高并发反向转账测试', '检查 pg_stat_database.deadlocks'],
    sourcePath: 'src/main/java/dev/fincore/domain/UuidOrder.java',
    sourceLabel: 'UuidOrder.java',
    code: `public static final Comparator<UUID> COMPARATOR = (left, right) -> {
    int high = Long.compareUnsigned(
        left.getMostSignificantBits(), right.getMostSignificantBits());
    return high != 0 ? high : Long.compareUnsigned(
        left.getLeastSignificantBits(), right.getLeastSignificantBits());
};`,
  },
  'ledger-batch': {
    eyebrow: 'CPU · DATABASE ROUND TRIPS',
    title: '整组账本分录一次批量写入',
    summary: '借贷分录先在内存中校验平衡，再通过 MyBatis foreach 生成一条多 values INSERT。它减少 JDBC 往返，同时保持整个账本事务的原子性。',
    configurations: ['MyBatis foreach', 'single INSERT ... VALUES', 'same Spring transaction'],
    flow: ['构造借贷分录', '校验借方合计等于贷方合计', '一次 INSERT 写入整组分录', '同事务更新账户余额'],
    metrics: ['jdbc statement latency', 'ledger transaction duration', 'database round trips', 'JFR allocation profile'],
    failure: '批量写不是跳过校验；任一分录或余额更新失败时，事务头、分录和余额必须整体回滚。',
    verification: ['查看 SQL 日志确认整组分录一次 INSERT', '注入余额不足并确认无半截分录', '对账验证余额和不可变账本一致'],
    sourcePath: 'src/main/java/dev/fincore/infrastructure/persistence/mapper/LedgerMapper.java',
    sourceLabel: 'LedgerMapper.java',
    code: `INSERT INTO ledger_entry(...)
VALUES
<foreach collection="entries" item="entry" separator=",">
  (#{entry.entryId}, #{transactionId}, #{entry.accountId},
   #{entry.direction}, #{entry.amount})
</foreach>`,
  },
  'outbox-publish': {
    eyebrow: 'CPU · NETWORK ROUND TRIPS',
    title: 'Kafka 异步发送与数据库批量状态更新',
    summary: 'Publisher 不逐条阻塞等待 Kafka，而是先创建整批 Future，再统一等待预算。完成后把成功、明确失败和结果未知分开处理。',
    configurations: ['KafkaTemplate async send', 'CompletableFuture.allOf', 'batch status update'],
    flow: ['创建每条事件的发送 Future', '整批并行等待 ack', '聚合成功/失败/未完成集合', '分别批量更新状态'],
    metrics: ['fincore.outbox.publish.batch', 'fincore.outbox.published', 'fincore.outbox.failed', 'fincore.outbox.uncertain'],
    failure: '结果未知的 Future 不会被写成 PUBLISHED；异常抢占恢复稍后再判断和重试，由下游 Inbox 保证重复安全。',
    verification: ['延迟 Kafka ack 触发等待超时', '确认 uncertain 增加而 published 不误增', '恢复后确认积压最终归零'],
    sourcePath: 'src/main/java/dev/fincore/messaging/OutboxPublisher.java',
    sourceLabel: 'OutboxPublisher.java',
    code: `CompletableFuture.allOf(sends.stream()
    .map(PendingSend::future)
    .toArray(CompletableFuture[]::new))
    .get(awaitTimeout.toNanos(), TimeUnit.NANOSECONDS);`,
  },
  'lease-coalescing': {
    eyebrow: 'CPU · STAMPEDE CONTROL',
    title: '64 个并发续期合并成一次数据库操作',
    summary: 'WorkerLeaseManager 使用 ConcurrentHashMap.compute 对同一 shard 的本地续期进行合并。仍在安全窗口内的 Lease 直接复用，只有一个线程真正访问数据库。',
    configurations: ['ConcurrentHashMap.compute', 'per-shard cache', 'renewal safety window'],
    flow: ['多个线程请求同一 shard Lease', 'compute 对该 key 串行', '有效 Lease 直接复用', '仅过期或临界 Lease 调用数据库续期'],
    metrics: ['lease renewal calls', 'database query count', 'worker takeover duration', 'JFR lock profile'],
    failure: '本地合并只是减压，不能替代数据库 Epoch Fencing；进程暂停或旧 Worker 恢复后仍由数据库 epoch 拒绝迟到写入。',
    verification: ['64 线程同时请求同一 shard', '统计数据库续期次数为 1', '模拟旧 Worker 恢复并确认 epoch 拒写'],
    sourcePath: 'src/main/java/dev/fincore/application/WorkerLeaseManager.java',
    sourceLabel: 'WorkerLeaseManager.java',
    code: `ShardLeaseService.Lease current = cache.compute(shardId, (key, existing) -> {
    if (existing != null && existing.isSafeAt(clock.instant())) {
        return existing;
    }
    return shardLeaseService.acquireOrRenew(key, workerId);
});`,
  },
  g1: {
    eyebrow: 'JVM · DEFAULT G1',
    title: '4GB 中小堆的默认生产基线',
    summary: 'G1 是本项目的默认收集器。堆使用容器内存百分比而非固定 Xmx，为线程栈、直接内存、Metaspace、JFR、页缓存和同机依赖保留空间。',
    configurations: ['-XX:+UseG1GC', '-XX:InitialRAMPercentage=25', '-XX:MaxRAMPercentage=65', '-XX:MaxGCPauseMillis=200'],
    flow: ['容器感知可用内存', 'G1 按 region 管理堆', '并发标记回收老年代', 'GC 日志与 JFR 保留诊断证据'],
    metrics: ['jvm.gc.pause', 'jvm.memory.used', 'jvm.memory.live.data.size', 'process.cpu.usage'],
    failure: '频繁 Full GC、live set 接近最大堆或 CPU 长期被 GC 占用时，应该先查分配热点和保留对象，而不是只把堆调大。',
    verification: ['运行固定到达率压测', '比较 p99 GC pause 与业务 P95/P99', '用 JFR 检查 Allocation in new TLAB 和 Old Object Sample'],
    sourcePath: 'config/jvm/g1.options',
    sourceLabel: 'config/jvm/g1.options',
    code: `-XX:+UseG1GC
-XX:InitialRAMPercentage=25
-XX:MaxRAMPercentage=65
-XX:MaxGCPauseMillis=200
-XX:+ParallelRefProcEnabled
-XX:+UseStringDeduplication`,
  },
  zgc: {
    eyebrow: 'JVM · OPTIONAL ZGC',
    title: '低停顿备选必须由真实数据触发',
    summary: 'Generational ZGC 保留和 G1 相同的堆边界、OOM dump、GC 日志及 JFR。它适用于真实数据证明 G1 停顿不达标，同时容器有足够 CPU/内存余量的场景。',
    configurations: ['-XX:+UseZGC', '-XX:+ZGenerational', '-XX:MaxRAMPercentage=65', 'FINCORE_GC=zgc'],
    flow: ['保持相同业务负载和容器规格', '切换 ZGC 运行同一压测', '比较停顿、CPU 与吞吐', '只有整体收益明确才采用'],
    metrics: ['jvm.gc.pause', 'jvm.gc.overhead', 'process.cpu.usage', 'container.memory.working.set'],
    failure: '只比较 GC 停顿会得出错误结论；ZGC 可能以更多 CPU 和并发回收内存换取低停顿，4GB 演示机上尤其要留意余量。',
    verification: ['用同一 k6 脚本分别跑 G1 与 ZGC', '保持请求速率、CPU、内存完全相同', '比较业务 P99、GC p99、吞吐和容器 OOM'],
    sourcePath: 'config/jvm/zgc.options',
    sourceLabel: 'config/jvm/zgc.options',
    code: `-XX:+UseZGC
-XX:+ZGenerational
-XX:InitialRAMPercentage=25
-XX:MaxRAMPercentage=65
-XX:+HeapDumpOnOutOfMemoryError`,
  },
  observability: {
    eyebrow: 'PROMETHEUS · JFR · GRAFANA',
    title: '业务、排队、数据库和 JVM 必须同图观察',
    summary: '单看 CPU 无法判断系统健康。FinCore 将撮合队列、拒绝、Consumer in-flight、Hikari pending、GC pause 和虚拟线程 pinned 与价格、单量、QPS、TPS 及延迟放在同一时间轴。',
    configurations: ['Spring Boot Actuator', 'Micrometer Prometheus', 'Grafana dashboard', 'JFR continuous recording'],
    flow: ['业务路径记录 Counter/Timer/Gauge', 'Prometheus 周期抓取', 'Grafana 按同一时间窗口展示', '异常时下载 JFR 和 GC 日志定位热点'],
    metrics: ['fincore_matching_queue_depth_total', 'fincore_matching_queue_rejected_total', 'hikaricp_connections_pending', 'jvm_gc_pause_seconds_bucket'],
    failure: '吞吐下降可能来自入口拒绝、Lane 排队、连接池等待、Kafka Lag 或 GC。只有把这些层级对齐，才能避免把数据库瓶颈误判成 JVM 问题。',
    verification: ['运行 market-crash-day 场景', '打开公网 Grafana 观察同一时间窗', '按 QPS 峰值追踪队列、连接池、GC 与恢复时间'],
    sourcePath: 'docs/high-concurrency-jvm-tuning.md',
    sourceLabel: 'high-concurrency-jvm-tuning.md',
    code: `# 同一时间窗至少包含四组信号
业务：price / order_rate / match_tps
排队：matching_queue / kafka_lag / outbox_backlog
资源：cpu / heap / hikari_pending
结果：http_status / p95 / reconciliation_diff`,
  },
  'load-test': {
    eyebrow: 'K6 · REPRODUCIBLE LOAD',
    title: '固定到达率压测，不预造漂亮成绩',
    summary: 'mixed-workload.js 同时注入结算、热点撮合和市场查询。脚本固定请求到达率而不是固定线程数，最终结果必须绑定机器规格、配置、Git commit 和原始输出。',
    configurations: ['settlement 150 req/s', 'hot matching 100 req/s', 'market query 100 req/s', 'JSON + Prometheus + GC log + JFR'],
    flow: ['记录环境和 Git commit', '预热服务', '执行固定到达率混合负载', '收集原始指标并运行门槛检查'],
    metrics: ['http_req_duration p95/p99', 'http_reqs', 'dropped_iterations', '业务正确性检查'],
    failure: '如果目标机器 CPU 或带宽不足，dropped_iterations 会暴露未达到目标速率；页面不会把设定的 350 QPS 冒充实测吞吐。',
    verification: ['在目标云主机执行性能脚本', '保存 results JSON、JFR 和 GC 日志', '将结果与机器规格和配置一并归档'],
    sourcePath: 'benchmarks/mixed-workload.js',
    sourceLabel: 'benchmarks/mixed-workload.js',
    code: `export const options = {
  scenarios: {
    settlement: { executor: 'constant-arrival-rate', rate: 150 },
    matching:   { executor: 'constant-arrival-rate', rate: 100 },
    market:     { executor: 'constant-arrival-rate', rate: 100 },
  },
};`,
  },
};

export function performanceSourceUrl(detail: PerformanceDetail) {
  return `${sourceRoot}${detail.sourcePath}`;
}
