/** 运行报告是业务证据；字段不完整时禁止补演示默认值。 */
export type MarketReport = {
  runId: string; finalStatus: 'RECOVERED'; startedAt: string; completedAt: string;
  metrics: Record<string, number>; checks: Record<string, string>;
};
export type LifecycleReport = {
  runId: string; finalStatus: 'PASS'; checks: Record<string, string>;
  startedAt: string; completedAt: string; funds: SpotFundsEvidence;
  data: {
    userId: string; userStatus: string; kycStatus: string; accountAsset: string;
    accountBalance: number; symbol: string; referencePrice: number; quantity: number;
    orderNotional: number; preTradeDecision: string; orderStatus: string;
    tradeCount: number; rejectedReasonCode: string;
  };
};
export type SpotFundsEvidence = {
  tradeId: string; deliveryStatus: 'SETTLED'; baseAsset: string; quoteAsset: string;
  reservedForCancel: number; availableWhileReserved: number; availableAfterCancel: number;
  buyerQuoteBalance: number; buyerBaseBalance: number; sellerBaseBalance: number;
  sellerQuoteBalance: number; pendingDebit: number; reconciledAccounts: number; settledAt: string;
};
export type ExchangeDomainReport = {
  title: string; status: 'PASS'; flow: string; metrics: Record<string, string | number | boolean>;
  checks: string[]; boundary: string;
};
export type ExchangeCoverageReport = {
  runId: string; generatedAt: string; status: 'PASS'; domainCount: 9;
  domains: Record<string, ExchangeDomainReport>; evidenceBoundary: string;
};
export class ScenarioError extends Error {
  readonly state: 'error' | 'unknown';
  constructor(message: string, state: 'error' | 'unknown' = 'unknown') {
    super(message); this.state = state;
  }
}
export const MARKET_CHECKS = ['大行情撮合', '请求重放', '流动性耗尽', '节点接管', '结算重投',
  '同步异常发现', '派生数据修复', '权威事实保护', '最终收敛', '资金账本'];
export const LIFECYCLE_CHECKS = ['用户与 KYC', '账户与风控', '参考行情', '盘前决定',
  '撮合结果', '端到端幂等', '失败关闭', '行情联动', '委托预占', '撤单释放', '双资产交割', '资金对账'];
export const EXCHANGE_DOMAINS = ['marketData', 'orderSemantics', 'fixOms', 'surveillance',
  'apiSecurity', 'fees', 'matchingRecovery', 'derivatives', 'digitalAssets'];

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ScenarioError('报告结构不完整，结果未知');
  return value as Record<string, unknown>;
}
function text(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) throw new ScenarioError('报告缺少必要文字字段，结果未知');
  return value;
}
function number(value: unknown): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) throw new ScenarioError('报告指标缺失或不合法，结果未知');
  return value;
}
function primitive(value: unknown): string | number | boolean {
  if (typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  throw new ScenarioError('报告指标包含不合法的值，结果未知');
}
function checks(value: unknown, required: string[]): Record<string, string> {
  const result = object(value);
  for (const key of required) if (!(key in result)) throw new ScenarioError(`报告缺少检查项：${key}`);
  for (const [key, status] of Object.entries(result)) {
    if (!/^PASS(?:$|[：: ])/.test(text(status))) throw new ScenarioError(`后台检查未通过：${key} — ${text(status)}`, 'error');
  }
  return result as Record<string, string>;
}

export function parseMarketReport(value: unknown): MarketReport {
  const report = object(value), metrics = object(report.metrics);
  if (text(report.finalStatus) !== 'RECOVERED') throw new ScenarioError('后台尚未确认恢复成功', 'error');
  const startedAt = text(report.startedAt), completedAt = text(report.completedAt);
  if (!Number.isFinite(Date.parse(startedAt)) || !Number.isFinite(Date.parse(completedAt))
    || Date.parse(completedAt) < Date.parse(startedAt)) throw new ScenarioError('报告完成时间不合法');
  const requiredMetrics = ['makerOrders', 'concurrentMarketSellers', 'tradeCount', 'uniqueTradeSequences',
    'tradeOutboxEvents', 'settlementCommands', 'duplicateSettlementDeliveries', 'ledgerTransactions',
    'repairedProjections', 'quarantinedProjections', 'matchingElapsedMs', 'observedTradesPerSecond', 'endToEndElapsedMs'];
  const validated = Object.fromEntries(requiredMetrics.map(key => [key, number(metrics[key])]));
  if (validated.tradeCount === 0 || validated.tradeCount !== validated.uniqueTradeSequences)
    throw new ScenarioError('成交唯一性指标不一致', 'error');
  if (object(report.recovery).finalStatus !== 'CLEAN') throw new ScenarioError('最终对账未确认 CLEAN', 'error');
  return { runId: text(report.runId), finalStatus: 'RECOVERED', startedAt, completedAt,
    metrics: validated, checks: checks(report.checks, MARKET_CHECKS) };
}

export function parseLifecycleReport(value: unknown): LifecycleReport {
  const report = object(value), data = object(report.data);
  if (text(report.finalStatus) !== 'PASS') throw new ScenarioError('后台未确认链路实验成功', 'error');
  const validated: Record<string, string | number> = {};
  for (const key of ['userId', 'userStatus', 'kycStatus', 'accountAsset', 'symbol', 'preTradeDecision', 'orderStatus', 'rejectedReasonCode']) validated[key] = text(data[key]);
  for (const key of ['accountBalance', 'referencePrice', 'quantity', 'orderNotional', 'tradeCount']) validated[key] = number(data[key]);
  if (validated.preTradeDecision !== 'APPROVED' || validated.orderStatus !== 'FILLED' || Number(validated.tradeCount) <= 0)
    throw new ScenarioError('盘前或成交结果与成功状态不一致', 'error');
  const evidence = object(report.funds);
  const fields: Record<string, string | number> = {};
  for (const key of ['tradeId', 'deliveryStatus', 'baseAsset', 'quoteAsset', 'settledAt']) fields[key] = text(evidence[key]);
  for (const key of ['reservedForCancel', 'availableWhileReserved', 'availableAfterCancel', 'buyerQuoteBalance',
    'buyerBaseBalance', 'sellerBaseBalance', 'sellerQuoteBalance', 'pendingDebit', 'reconciledAccounts']) fields[key] = number(evidence[key]);
  const funds = fields as SpotFundsEvidence;
  const startedAt = text(report.startedAt), completedAt = text(report.completedAt);
  const start = Date.parse(startedAt), end = Date.parse(completedAt), settled = Date.parse(funds.settledAt);
  if (![start, end, settled].every(Number.isFinite) || start > settled || settled > end)
    throw new ScenarioError('资金报告时间不完整或顺序不正确');
  if (!/^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(funds.tradeId) || funds.deliveryStatus !== 'SETTLED'
    || funds.pendingDebit !== 0 || funds.reconciledAccounts !== 4)
    throw new ScenarioError('资金仍在途或交割证据不完整，不能显示闭环成功', 'error');
  // 此处只验证固定模拟场景报告，前端不承担真实账本计算或金额裁决。
  if (`${funds.baseAsset}-${funds.quoteAsset}` !== validated.symbol || funds.quoteAsset !== validated.accountAsset
    || funds.buyerQuoteBalance !== validated.accountBalance || funds.buyerBaseBalance !== validated.quantity
    || funds.sellerQuoteBalance !== validated.orderNotional
    || funds.buyerQuoteBalance + funds.sellerQuoteBalance !== 1000
    || funds.buyerBaseBalance + funds.sellerBaseBalance !== 10
    || funds.reservedForCancel <= 0
    || funds.availableWhileReserved + funds.reservedForCancel !== funds.availableAfterCancel
    || funds.availableAfterCancel !== funds.buyerQuoteBalance)
    throw new ScenarioError('固定实验的资金变化不一致，请核对后台报告', 'error');
  return { runId: text(report.runId), finalStatus: 'PASS', data: validated as LifecycleReport['data'],
    startedAt, completedAt, funds, checks: checks(report.checks, LIFECYCLE_CHECKS) };
}

/** 九域报告必须逐域验证，不能用 domainCount 或 HTTP 200 代替业务成功。 */
export function parseExchangeCoverageReport(value: unknown): ExchangeCoverageReport {
  const report = object(value);
  if (text(report.status) !== 'PASS') throw new ScenarioError('交易所九域实验未全部通过', 'error');
  if (number(report.domainCount) !== EXCHANGE_DOMAINS.length) throw new ScenarioError('九域报告数量不完整', 'error');
  const generatedAt = text(report.generatedAt);
  if (!Number.isFinite(Date.parse(generatedAt))) throw new ScenarioError('九域报告生成时间不合法');
  const rawDomains = object(report.domains);
  const domains: Record<string, ExchangeDomainReport> = {};
  for (const key of EXCHANGE_DOMAINS) {
    const raw = object(rawDomains[key]);
    if (text(raw.status) !== 'PASS') throw new ScenarioError(`能力域未通过：${key}`, 'error');
    const rawMetrics = object(raw.metrics);
    if (Object.keys(rawMetrics).length === 0) throw new ScenarioError(`能力域缺少指标：${key}`);
    const rawChecks = raw.checks;
    if (!Array.isArray(rawChecks) || rawChecks.length === 0)
      throw new ScenarioError(`能力域缺少业务断言：${key}`);
    domains[key] = {
      title: text(raw.title), status: 'PASS', flow: text(raw.flow),
      metrics: Object.fromEntries(Object.entries(rawMetrics).map(([name, metric]) => [name, primitive(metric)])),
      checks: rawChecks.map(check => text(check)), boundary: text(raw.boundary),
    };
  }
  if (Object.keys(rawDomains).length !== EXCHANGE_DOMAINS.length)
    throw new ScenarioError('九域报告包含无法识别的能力域');
  return { runId: text(report.runId), generatedAt, status: 'PASS', domainCount: 9,
    domains, evidenceBoundary: text(report.evidenceBoundary) };
}

/** 同一份产物支持公网 Nginx 和 Sites 服务端代理，不再修改压缩后的脚本。 */
export function scenarioEndpoint(kind: 'market' | 'lifecycle' | 'exchange', hostname: string): string {
  const endpoint = kind === 'market' ? 'market-crash-day'
    : kind === 'lifecycle' ? 'trading-lifecycle' : 'exchange-coverage';
  if (hostname === '124.223.164.254') return `/lab/scenarios/${endpoint}`;
  // Sites 的 /api 路径受平台访问策略保护，公开访客会收到 403。腾讯云入口仅开放
  // 三个精确路由并校验 Origin，因此公开站直接跨域调用仍保持最小暴露面。
  return `https://124.223.164.254/lab/scenarios/${endpoint}`;
}

/** 超时只意味着客户端未知；请求可能已在后台执行，绝不自动重试写请求。 */
export async function requestReport<T>(url: string, parse: (value: unknown) => T,
  signal: AbortSignal, fetcher: typeof fetch = fetch): Promise<T> {
  const response = await fetcher(url, { method: 'POST', headers: { Accept: 'application/json' }, cache: 'no-store', signal });
  if (!response.ok) {
    if (response.status === 429) throw new ScenarioError('演示入口限流，请稍后手动重试', 'error');
    throw new ScenarioError(`HTTP ${response.status}：未取得完整运行结果，请核对后台后再重试`);
  }
  return parse(await response.json());
}
