/** 可复现实作样例：非线上缺陷报告，不访问真实工单或生产系统。 */
public final class TicketQuery {
    private TicketQuery() {}

    /** 方法签名和返回字段保持一致；页号从零开始。 */
    public record PageRequest(int page, int size, long offset, String query) {}

    public static PageRequest prepare(int page, int size, String query) {
        // 非法参数直接拒绝，不截断；两项均非法时先报告页号错误。
        if (page < 0) {
            throw new IllegalArgumentException("page 必须 >= 0");
        }
        if (size < 1 || size > 200) {
            throw new IllegalArgumentException("size 必须在 1..200 之间");
        }

        // 先提升为 long 再相乘；合法 int 页号乘以最大页大小不会溢出 long。
        long offset = (long) page * size;
        String normalized = query == null ? "" : query;
        int start = 0;
        int end = normalized.length();

        // 按码点扫描首尾，避免拆分补充平面字符；内部字符原样保留。
        while (start < end) {
            int codePoint = normalized.codePointAt(start);
            if (!isBoundaryWhitespace(codePoint)) {
                break;
            }
            start += Character.charCount(codePoint);
        }
        while (start < end) {
            int codePoint = normalized.codePointBefore(end);
            if (!isBoundaryWhitespace(codePoint)) {
                break;
            }
            end -= Character.charCount(codePoint);
        }

        // 全空白或 null 得到空串；零宽字符不属于以下判定时不会被删除。
        return new PageRequest(page, size, offset, normalized.substring(start, end));
    }

    private static boolean isBoundaryWhitespace(int codePoint) {
        return Character.isWhitespace(codePoint) || Character.isSpaceChar(codePoint);
    }
}
