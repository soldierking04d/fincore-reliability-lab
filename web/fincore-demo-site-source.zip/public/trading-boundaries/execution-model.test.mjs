import test from 'node:test';
import assert from 'node:assert/strict';
import { createExecutionState, reduceExecution, reconcileAtCut, buildExecutionCase, executionScenarios } from './execution-model.mjs';

const money = value => BigInt(value) * 10000n;
const startPayment = () => reduceExecution(createExecutionState('payment-unknown'), { type: 'START', id: 'A1', channel: 'BANK_A' });
const reserve = (state, id, amount) => reduceExecution(state, { type: 'RESERVE', id, amount: money(amount) });
const post = (state, side, id, amount) => reduceExecution(state, { type: 'POST', side, id, amount: money(amount) });
const receipt = () => reduceExecution(createExecutionState('hedge-partial'), { type: 'RECEIVE', id: 'RC1', amount: money(1000) });
const execute = (state, overrides = {}) => reduceExecution(state, { type: 'EXECUTE', id: 'F1', quantity: money(600), price: 10000n, feeBps: 10n, ...overrides });

test('付款超时保留 Attempt，同一请求重试不增发，另一通道禁止付款', () => {
  const state = reduceExecution(startPayment(), { type: 'TIMEOUT', id: 'A1' });
  assert.equal(state.attempt.status, 'UNKNOWN');
  assert.equal(state.attempt.id, 'A1');
  assert.equal(reduceExecution(state, { type: 'START', id: 'A1', channel: 'BANK_A' }), state);
  assert.throws(() => reduceExecution(state, { type: 'START', id: 'A2', channel: 'BANK_B' }), /PAYMENT_UNRESOLVED/);
  assert.throws(() => reduceExecution(state, { type: 'START', id: 'A1', channel: 'BANK_B' }), /IDEMPOTENCY_CONFLICT/);
  assert.equal(state.journals.length, 0);
});

test('晚到成功只记一组分录，重复成功和迟到超时无新分录', () => {
  const unknown = reduceExecution(startPayment(), { type: 'TIMEOUT', id: 'A1' });
  const paid = reduceExecution(unknown, { type: 'RESULT', id: 'A1', status: 'SUCCESS' });
  assert.equal(paid.paid, money(100));
  assert.equal(paid.journals.length, 2);
  assert.equal(paid.journals.reduce((sum, row) => sum + row.delta, 0n), 0n);
  assert.equal(reduceExecution(paid, { type: 'RESULT', id: 'A1', status: 'SUCCESS' }), paid);
  assert.equal(reduceExecution(paid, { type: 'TIMEOUT', id: 'A1' }), paid);
  assert.equal(unknown.paid, 0n);
});

test('付款成功不可被失败回调反转，也不可重新付款', () => {
  const state = reduceExecution(startPayment(), { type: 'RESULT', id: 'A1', status: 'SUCCESS' });
  assert.throws(() => reduceExecution(state, { type: 'RESULT', id: 'A1', status: 'FAILED' }), /TERMINAL_RESULT/);
  assert.throws(() => reduceExecution(state, { type: 'START', id: 'A2', channel: 'BANK_B' }), /PAYMENT_ALREADY_PAID/);
  assert.throws(() => reduceExecution(state, { type: 'RESULT', id: 'OTHER', status: 'SUCCESS' }), /ATTEMPT_MISMATCH/);
});

test('退款按当前预占状态判断额度，交错请求不能基于旧余额超退', () => {
  const initial = createExecutionState('refund-reservation');
  const first = reserve(initial, 'R1', 60);
  assert.equal(initial.reserved, 0n);
  assert.throws(() => reserve(first, 'R2', 50), /REFUND_LIMIT/);
  const second = reserve(first, 'R2', 40);
  assert.equal(second.reserved, money(100));
  assert.throws(() => reserve(second, 'R3', 1), /REFUND_LIMIT/);
  assert.equal(reserve(second, 'R2', 40), second);
  assert.throws(() => reserve(second, 'R2', 39), /IDEMPOTENCY_CONFLICT/);
});

test('退款失败释放一次预占，后续成功累计与预占之和不超原款', () => {
  let state = reserve(reserve(createExecutionState('refund-reservation'), 'R1', 60), 'R2', 40);
  state = reduceExecution(state, { type: 'REFUND_RESULT', id: 'R1', status: 'FAILED' });
  assert.equal(state.reserved, money(40));
  assert.equal(reduceExecution(state, { type: 'REFUND_RESULT', id: 'R1', status: 'FAILED' }), state);
  state = reserve(state, 'R3', 60);
  state = reduceExecution(state, { type: 'REFUND_RESULT', id: 'R2', status: 'SUCCESS' });
  assert.equal(state.refunded + state.reserved, state.captured);
  state = reduceExecution(state, { type: 'REFUND_RESULT', id: 'R3', status: 'SUCCESS' });
  assert.equal(state.refunded, money(100));
  assert.equal(state.reserved, 0n);
  assert.equal(state.journals.length, 4);
  assert.throws(() => reserve(state, 'R4', 1), /REFUND_LIMIT/);
});

test('退款成功终态不可逆，重复成功不生成新分录，失败 ID 不复活', () => {
  const reserved = reserve(createExecutionState('refund-reservation'), 'R1', 60);
  const succeeded = reduceExecution(reserved, { type: 'REFUND_RESULT', id: 'R1', status: 'SUCCESS' });
  assert.equal(reduceExecution(succeeded, { type: 'REFUND_RESULT', id: 'R1', status: 'SUCCESS' }), succeeded);
  assert.throws(() => reduceExecution(succeeded, { type: 'REFUND_RESULT', id: 'R1', status: 'FAILED' }), /TERMINAL_RESULT/);
  const failed = reduceExecution(reserved, { type: 'REFUND_RESULT', id: 'R1', status: 'FAILED' });
  assert.equal(reserve(failed, 'R1', 60), failed);
  assert.throws(() => reduceExecution(failed, { type: 'REFUND_RESULT', id: 'R1', status: 'SUCCESS' }), /TERMINAL_RESULT/);
});

test('只允许正数 BigInt 金额，不接受浮点、零额或负数', () => {
  for (const amount of [1.1, 100, 0n, -1n]) {
    assert.throws(() => reduceExecution(createExecutionState('refund-reservation'), { type: 'RESERVE', id: 'R1', amount }), /INVALID_AMOUNT/);
  }
});

test('1000 稳定币收款，模拟执行 600 后余 400 敞口，同执行键重放无变化', () => {
  const state = execute(receipt());
  assert.equal(state.received, money(1000));
  assert.equal(state.hedged, money(600));
  assert.equal(state.inventory, money(400));
  assert.equal(state.quoteGross, money(600));
  assert.equal(state.fees, 6000n);
  assert.equal(state.quoteNet, 5994000n);
  assert.equal(state.quoteNet + state.fees, state.quoteGross);
  assert.equal(execute(state), state);
  assert.equal(reduceExecution(state, { type: 'RECEIVE', id: 'RC1', amount: money(1000) }), state);
});

test('对冲执行前门禁拒绝超库存、低底价、超费率和精度越界；不采集外部成交', () => {
  const state = execute(receipt());
  assert.throws(() => execute(state, { id: 'F2', quantity: money(500) }), /INSUFFICIENT_INVENTORY/);
  assert.throws(() => execute(state, { id: 'F2', price: 9800n }), /PRICE_LIMIT/);
  assert.throws(() => execute(state, { id: 'F2', feeBps: 21n }), /FEE_LIMIT/);
  assert.throws(() => execute(state, { id: 'F2', quantity: 1n, price: 9999n }), /INEXACT_AMOUNT/);
  assert.throws(() => execute(state, { quantity: money(599) }), /IDEMPOTENCY_CONFLICT/);
  assert.throws(() => execute(state, { type: 'FILL' }), /INVALID_EVENT/);
  assert.equal(state.inventory, money(400));
});

test('ID 102 先提交时最大 ID 不能作为完整水位，101 仍在途', () => {
  let state = createExecutionState('reconciliation-cut');
  state = post(state, 'statement', 101, 100);
  state = post(state, 'statement', 102, 200);
  state = post(state, 'ledger', 102, 200);
  assert.equal(state.ledger.maxSeen, 102);
  assert.equal(state.ledger.completeThrough, 100);
  assert.throws(() => reconcileAtCut(state, 102), /INCOMPLETE_CUT/);
  assert.equal(reconcileAtCut(state).cut, 100);
  assert.ok(reconcileAtCut(state).rows.every(row => row.state === 'IN_FLIGHT'));
  state = post(state, 'ledger', 101, 100);
  assert.equal(state.ledger.completeThrough, 102);
  assert.ok(reconcileAtCut(state).rows.every(row => row.state === 'MATCH'));
});

test('共同切面揭示真实金额差异，隔离幂等且不修复账本', () => {
  let state = createExecutionState('reconciliation-cut');
  for (const [side, id, amount] of [['statement', 101, 99], ['statement', 102, 200], ['ledger', 102, 200], ['ledger', 101, 100]]) state = post(state, side, id, amount);
  const result = reconcileAtCut(state);
  assert.equal(result.cut, 102);
  assert.equal(result.rows.find(row => row.id === 101).state, 'DIFFERENCE');
  assert.equal(result.rows.find(row => row.id === 101).difference, money(1));
  const isolated = reduceExecution(state, { type: 'RECONCILE' });
  assert.equal(isolated.isolations.length, 1);
  assert.deepEqual(isolated.ledger, state.ledger);
  assert.deepEqual(isolated.statement, state.statement);
  assert.equal(reduceExecution(isolated, { type: 'RECONCILE' }), isolated);
  assert.throws(() => post(isolated, 'ledger', 101, 99), /IDEMPOTENCY_CONFLICT/);
});

test('确认完整切面内缺失才是差异，完整水位必须单调且不能跳过未决 ID', () => {
  let state = post(createExecutionState('reconciliation-cut'), 'ledger', 101, 100);
  state = post(state, 'ledger', 102, 200);
  state = post(state, 'statement', 102, 200);
  assert.equal(reconcileAtCut(state).cut, 100);
  state = reduceExecution(state, { type: 'CONFIRM_ABSENT', side: 'statement', id: 101 });
  assert.equal(reconcileAtCut(state).rows.find(row => row.id === 101).state, 'MISSING');
  assert.throws(() => post(state, 'statement', 101, 100), /CLOSED_OBSERVATION/);
});

test('四个场景快照可序列化、检查来自状态、步骤选择有边界', () => {
  assert.deepEqual(executionScenarios.map(row => row.id), ['payment-unknown', 'refund-reservation', 'hedge-partial', 'reconciliation-cut']);
  for (const { id } of executionScenarios) {
    const result = buildExecutionCase({ scenario: id });
    assert.equal(result.kind, 'execution');
    assert.equal(result.current, result.snapshots.at(-1));
    assert.equal(result.maxStep, result.snapshots.length - 1);
    assert.match(result.limitation, /内存/);
    assert.doesNotThrow(() => JSON.stringify(result));
    for (const snapshot of result.snapshots) {
      assert.ok(snapshot.checks.length > 0);
      assert.ok(snapshot.checks.every(check => check.ok), `${id}/${snapshot.step}`);
      assert.ok(snapshot.metrics.every(metric => typeof metric.value === 'string'));
    }
    assert.equal(buildExecutionCase({ scenario: id, step: 0 }).current.step, 0);
    assert.throws(() => buildExecutionCase({ scenario: id, step: -1 }), /步骤/);
    assert.throws(() => buildExecutionCase({ scenario: id, step: 1.5 }), /步骤/);
    assert.throws(() => buildExecutionCase({ scenario: id, step: result.maxStep + 1 }), /步骤/);
  }
  assert.throws(() => buildExecutionCase({ scenario: 'unknown' }), /未知/);
});
