// 顺序内存恢复教学：日志记录仅为命令键与整数位置，不执行任何资金写入。
const LIMITATION = '仅为顺序内存模型，不证明真实持久化、网络分区安全或生产高可用；epoch 仲裁和消费者幂等也只是模型前提。';
const check = (name, ok, detail) => ({ name, ok, detail });
const integer = (value, name, minimum = 0) => {
  if (!Number.isSafeInteger(value) || value < minimum) throw new Error(`${name}必须是大于等于 ${minimum} 的安全整数`);
};
const nodeState = () => ({
  status: 'RUNNING', volumePresent: true, accepted: 0, durable: 0, applied: 0, published: 0,
  pending: [], log: [], appliedIds: [], snapshot: { position: 0, published: 0, ids: [] },
});

export const recoveryScenarios = [
  { id: 'recovery-replay', title: '持久日志与快照恢复', summary: '区分四个水位；宕机丢弃未持久尾部，先装载快照再重放日志，缺卷时阻塞启动。' },
  { id: 'recovery-fencing', title: '落后副本与 epoch 接管', summary: '落后副本不能接管；追平后提高 epoch，存活的旧主也不能继续确认和发布。' },
];

export function createRecoveryState() {
  return { leader: 'primary', epoch: 1, requiredPosition: 0, nodes: { primary: nodeState(), replica: nodeState() }, acknowledgedIds: [], publishedIds: [], lostIds: [] };
}

const cloneState = state => ({
  ...state,
  nodes: Object.fromEntries(Object.entries(state.nodes).map(([id, node]) => [id, {
    ...node, pending: node.pending.map(row => ({ ...row })), log: node.log.map(row => ({ ...row })), appliedIds: [...node.appliedIds],
    snapshot: { ...node.snapshot, ids: [...node.snapshot.ids] },
  }])),
  acknowledgedIds: [...state.acknowledgedIds], publishedIds: [...state.publishedIds], lostIds: [...state.lostIds],
});
const available = node => {
  if (!node.volumePresent) throw new Error('持久卷缺失：阻塞启动，不能创建空账本替代');
};
const running = node => {
  available(node);
  if (node.status !== 'RUNNING') throw new Error('节点必须处于运行状态');
};
const epochMatches = (state, epoch) => {
  integer(epoch, 'epoch', 1);
  if (epoch !== state.epoch) throw new Error('fencing 拒绝：epoch 已过期');
};
const authority = (state, action, node) => {
  epochMatches(state, action.epoch);
  if (action.node !== state.leader) throw new Error('fencing 拒绝：节点不是当前主节点');
  running(node);
};
const appendUnique = (list, ids) => {
  for (const id of ids) if (!list.includes(id)) list.push(id);
};
const applyNext = (node, position) => {
  integer(position, '位置', 1);
  if (position > node.durable) throw new Error('不能应用未持久的日志位置');
  if (position !== node.applied + 1) throw new Error('必须按顺序应用下一条日志');
  node.appliedIds.push(node.log[position - 1].id);
  node.applied = position;
};

// 每次返回独立状态；非法操作抛错，调用者保留原状态，不把异常转成成功。
export function recoveryTransition(state, action) {
  const next = cloneState(state);
  const node = next.nodes[action.node];
  if (!node) throw new Error(`未知节点：${action.node}`);
  const { type, position } = action;
  switch (type) {
    case 'accept': {
      authority(next, action, node);
      if (typeof action.id !== 'string' || !action.id.trim()) throw new Error('命令键不能为空');
      if ([...node.log, ...node.pending].some(row => row.id === action.id)) throw new Error('重复命令键：应查询原位置');
      integer(node.accepted + 1, '接受位置', 1);
      node.accepted += 1;
      node.pending.push({ position: node.accepted, id: action.id });
      break;
    }
    case 'persist': {
      authority(next, action, node);
      integer(position, '位置');
      if (position <= node.durable || position > node.accepted) throw new Error('持久位置必须前进且不超过接受位置');
      node.log.push(...node.pending.filter(row => row.position <= position));
      node.pending = node.pending.filter(row => row.position > position);
      node.durable = position;
      // 这是模型已知的恢复下限，真实系统须有可靠的提交/仲裁协议维护它。
      next.requiredPosition = position;
      break;
    }
    case 'acknowledge': {
      authority(next, action, node);
      integer(position, '位置', 1);
      if (position > node.durable) throw new Error('未持久的位置不能向调用方作承诺');
      appendUnique(next.acknowledgedIds, node.log.slice(0, position).map(row => row.id));
      break;
    }
    case 'apply': {
      epochMatches(next, action.epoch);
      running(node);
      // 副本可以本地应用已复制的日志；确认和发布仍必须通过主节点 fencing。
      applyNext(node, position);
      break;
    }
    case 'publish': {
      authority(next, action, node);
      integer(position, '位置', 1);
      if (position > node.applied) throw new Error('不能发布尚未应用的位置');
      if (position !== node.published + 1) throw new Error('必须按顺序发布下一位置');
      // 只模拟接收者按命令键去重；不声称网络发送具有恰好一次语义。
      appendUnique(next.publishedIds, [node.log[position - 1].id]);
      node.published = position;
      break;
    }
    case 'snapshot': {
      authority(next, action, node);
      node.snapshot = { position: node.applied, published: node.published, ids: [...node.appliedIds] };
      break;
    }
    case 'crash': {
      available(node);
      if (!['RUNNING', 'RECOVERING'].includes(node.status)) throw new Error('节点已停止');
      appendUnique(next.lostIds, node.pending.map(row => row.id));
      node.pending = [];
      node.accepted = node.durable;
      // 进程水位清零，不撤回外部已收到的承诺/发布；那些历史单独保留。
      node.applied = 0;
      node.published = 0;
      node.appliedIds = [];
      node.status = 'DOWN';
      break;
    }
    case 'restore': {
      available(node);
      if (node.status !== 'DOWN') throw new Error('只能对停止的节点开始恢复');
      node.applied = node.snapshot.position;
      node.published = node.snapshot.published;
      node.appliedIds = [...node.snapshot.ids];
      node.status = 'RECOVERING';
      break;
    }
    case 'replay': {
      available(node);
      if (node.status !== 'RECOVERING') throw new Error('必须先进入快照恢复阶段');
      applyNext(node, position);
      break;
    }
    case 'resume': {
      available(node);
      if (node.status !== 'RECOVERING') throw new Error('必须先恢复快照与日志');
      if (node.applied !== node.durable) throw new Error('应用位置尚未追平持久位置，不能启动服务');
      node.status = 'RUNNING';
      break;
    }
    case 'detach-volume': {
      if (node.status !== 'DOWN') throw new Error('只在停止状态模拟持久卷缺失');
      node.volumePresent = false;
      node.status = 'BLOCKED';
      break;
    }
    case 'replicate': {
      authority(next, action, node);
      const target = next.nodes[action.target];
      if (!target || action.target === next.leader) throw new Error('复制目标必须是另一副本');
      running(target);
      integer(position, '位置', 1);
      if (target.pending.length) throw new Error('副本存在冲突的未持久尾部，须先恢复');
      if (position <= target.durable || position > node.durable) throw new Error('复制位置必须前进且不超过源持久位置');
      if (target.log.some((row, index) => row.id !== node.log[index]?.id)) throw new Error('副本日志前缀冲突，拒绝覆盖');
      target.log = node.log.slice(0, position).map(row => ({ ...row }));
      target.accepted = position;
      target.durable = position;
      break;
    }
    case 'promote': {
      running(node);
      integer(action.epoch, 'epoch', 1);
      if (action.node === next.leader || action.epoch <= next.epoch) throw new Error('接管必须使用更高 epoch 和另一节点');
      if (node.durable < next.requiredPosition) throw new Error('落后副本拒绝接管：持久位置未达到恢复下限');
      if (node.applied < next.requiredPosition) throw new Error('副本应用位置未追平，拒绝接管');
      if (node.pending.length) throw new Error('副本存在未恢复的未持久尾部');
      if (node.log.slice(0, next.requiredPosition).some((row, index) => row.id !== next.nodes[next.leader].log[index]?.id)) throw new Error('候选日志前缀冲突');
      next.leader = action.node;
      next.epoch = action.epoch;
      break;
    }
    default: throw new Error(`未知恢复操作：${type}`);
  }
  return next;
}

export function buildRecoveryCase({ scenario = 'recovery-replay', step } = {}) {
  const definition = recoveryScenarios.find(row => row.id === scenario);
  if (!definition) throw new Error(`未知恢复场景：${scenario}`);
  let state = createRecoveryState();
  const snapshots = [], rejections = [];
  const act = (type, fields = {}) => {
    state = recoveryTransition(state, { type, node: state.leader, epoch: state.epoch, ...fields });
  };
  const reject = (title, type, fields = {}) => {
    try {
      recoveryTransition(state, { type, node: state.leader, epoch: state.epoch, ...fields });
    } catch (error) {
      rejections.push({ subject: title, state: 'REJECTED', detail: error.message });
      return;
    }
    throw new Error(`预期非法操作未被拒绝：${title}`);
  };
  const snapshot = (title, notes = []) => {
    const leader = state.nodes[state.leader];
    const nodes = Object.values(state.nodes);
    const checks = [
      check('四水位有序', nodes.every(node => node.published <= node.applied && node.applied <= node.durable && node.durable <= node.accepted), '发布 ≤ 应用 ≤ 持久 ≤ 接受；恢复时为当前进程的水位'),
      check('日志连续且应用前缀一致', nodes.every(node => node.log.length === node.durable && node.log.every((row, index) => row.position === index + 1) && node.appliedIds.length === node.applied && node.appliedIds.every((id, index) => id === node.log[index]?.id)), '从快照位置 + 1 开始重放，不跳号，不重复应用'),
      check('已承诺记录未丢失', state.acknowledgedIds.every(id => leader.log.some(row => row.id === id)), '只有持久日志中的命令可被确认；卷缺失时保留历史元数据并阻塞'),
      check('缺失持久卷禁止服务', nodes.every(node => node.volumePresent || node.status === 'BLOCKED'), '不以新建空账本伪装恢复成功'),
    ];
    if (checks.some(row => !row.ok)) throw new Error('恢复模型不变量失败');
    snapshots.push({
      step: snapshots.length, title, notes,
      metrics: [
        { label: '接受位置', value: String(leader.accepted) }, { label: '持久位置', value: String(leader.durable) },
        { label: '应用位置', value: String(leader.applied) }, { label: '发布位置', value: String(leader.published) },
        { label: '当前 epoch', value: String(state.epoch) }, { label: '接管最低位置', value: String(state.requiredPosition) },
      ],
      rows: [
        ...Object.entries(state.nodes).map(([id, node]) => ({ subject: id, state: node.status, detail: `${id === state.leader ? '当前主节点' : '副本/旧主'}；接受 ${node.accepted} / 持久 ${node.durable} / 应用 ${node.applied} / 发布 ${node.published}；快照 ${node.snapshot.position}；持久卷${node.volumePresent ? '存在' : '缺失'}` })),
        { subject: '当前主持久日志', state: leader.volumePresent ? 'AVAILABLE' : 'UNAVAILABLE', detail: leader.volumePresent ? leader.log.map(row => `${row.position}:${row.id}`).join('，') || '尚无日志' : '卷不可访问；保留的元数据不是可用日志，恢复被阻塞' },
        { subject: '已确认命令', state: 'ACKNOWLEDGED', detail: state.acknowledgedIds.join('，') || '无' },
        { subject: '消费者已接收命令', state: 'DELIVERED', detail: state.publishedIds.join('，') || '无' },
        { subject: '宕机丢弃的未持久命令', state: 'LOST_UNACKNOWLEDGED', detail: state.lostIds.join('，') || '无' },
        ...rejections.map(row => ({ ...row })),
      ], checks,
    });
  };

  snapshot('初始：四个水位均为 0', [LIMITATION, '接受仅表示进入进程；持久表示模型日志保存；应用表示状态重建；发布表示可见结果的顺序推进。']);
  act('accept', { id: 'C1' });
  act('persist', { position: 1 });
  act('acknowledge', { position: 1 });
  act('apply', { position: 1 });
  act('publish', { position: 1 });
  if (scenario === 'recovery-replay') {
    act('snapshot');
    snapshot('C1 已应用并发布，保存位置 1 的快照', ['快照包含应用前缀和发布检查点；此模型保留全部日志，不模拟日志裁剪。']);
    act('accept', { id: 'C2' });
    act('persist', { position: 2 });
    act('acknowledge', { position: 2 });
    act('accept', { id: 'C3' });
    reject('拒绝承诺尚未持久的 C3', 'acknowledge', { position: 3 });
    snapshot('接受 3、持久 2、应用 1、发布 1', ['C2 已达到持久承诺，但还未应用；C3 只有接受回执，不能向调用方承诺可恢复。']);
    act('crash');
    snapshot('进程宕机：C3 丢失，C1/C2 的持久日志保留', ['应用/发布为当前进程的恢复水位，此时清零；外部已收到的 C1 发布和 C1/C2 承诺不会撤回。']);
    reject('拒绝未加载快照就重放', 'replay', { position: 2 });
    act('restore');
    reject('拒绝日志未追平就启动', 'resume');
    snapshot('先装载快照：从位置 1 恢复', ['只能从快照的下一位置开始重放；不能把接受位置 3 当作持久日志结尾。']);
    act('replay', { position: 2 });
    act('resume');
    snapshot('顺序重放 C2 后，应用位置追平持久位置', ['恢复后仍须单独推进发布；命令是否已持久、已应用、已发布是不同问题。']);
    act('publish', { position: 2 });
    snapshot('C2 发布完成；C3 从未获得持久承诺', ['模型以命令键模拟消费者去重，真实重投需要持久幂等或 outbox/inbox 协议。']);
    act('crash');
    act('detach-volume');
    reject('拒绝缺卷后空账本启动', 'restore');
    snapshot('持久卷缺失：恢复保持阻塞', ['必须找回权威持久数据或执行经过授权的数据恢复流程；本例没有初始化空账本的替代分支。']);
  } else {
    act('replicate', { target: 'replica', position: 1 });
    act('apply', { node: 'replica', position: 1 });
    act('accept', { id: 'C2' });
    act('persist', { position: 2 });
    act('acknowledge', { position: 2 });
    act('apply', { position: 2 });
    snapshot('主节点到 2，副本仍在 1', ['接管最低位置是模型已知的持久下限 2；生产系统必须另有可靠协议确定该下限。']);
    reject('拒绝落后副本接管', 'promote', { node: 'replica', epoch: 2 });
    snapshot('副本持久进度不足，接管失败');
    act('replicate', { target: 'replica', position: 2 });
    reject('拒绝尚未应用到 2 的副本接管', 'promote', { node: 'replica', epoch: 2 });
    act('apply', { node: 'replica', position: 2 });
    snapshot('副本先补齐持久日志，再应用到 2', ['复制到盘不等于状态已重建，接管前需要分别核对。']);
    act('promote', { node: 'replica', epoch: 2 });
    snapshot('副本以 epoch 2 接管', ['模型将仲裁结果作为可信输入；未实现租约、选举、法定多数或网络分区协议。']);
    reject('旧主继续接受命令', 'accept', { node: 'primary', epoch: 1, id: 'STALE' });
    reject('旧主继续确认结果', 'acknowledge', { node: 'primary', epoch: 1, position: 2 });
    reject('旧主继续发布结果', 'publish', { node: 'primary', epoch: 1, position: 2 });
    snapshot('旧主仍存活，但旧 epoch 的操作被 fencing 拒绝', ['只关闭页面或修改角色标签不构成隔离；接收、持久确认和发布入口都必须校验当前权限。']);
    act('publish', { position: 1 });
    act('publish', { position: 2 });
    act('accept', { id: 'C3' });
    act('persist', { position: 3 });
    act('acknowledge', { position: 3 });
    act('apply', { position: 3 });
    act('publish', { position: 3 });
    snapshot('新主在 epoch 2 推进 C3', ['C1 的重投在模型消费者处按命令键去重；旧主的失效权限不因它仍运行而恢复。']);
  }
  const selected = step === undefined ? snapshots.length - 1 : step;
  if (!Number.isSafeInteger(selected) || selected < 0 || selected >= snapshots.length) throw new Error('步骤必须是范围内的整数');
  return { kind: 'recovery', scenario, title: definition.title, limitation: LIMITATION, snapshots, current: snapshots[selected], maxStep: snapshots.length - 1 };
}
