import test from 'node:test';
import assert from 'node:assert/strict';
import { createRecoveryState, recoveryTransition, recoveryScenarios, buildRecoveryCase } from './recovery-model.mjs';

const transition = (state, type, fields = {}) => recoveryTransition(state, { type, node: state.leader, epoch: state.epoch, ...fields });
const accept = (state, id) => transition(state, 'accept', { id });
const prepared = () => {
  let state = accept(createRecoveryState(), 'command-1');
  state = transition(state, 'persist', { position: 1 });
  state = transition(state, 'apply', { position: 1 });
  state = transition(state, 'publish', { position: 1 });
  return state;
};

test('接受回执不构成持久承诺：未落盘命令丢失且不能确认、应用或发布', () => {
  const initial = createRecoveryState();
  const state = accept(initial, 'volatile-only');
  assert.deepEqual([state.nodes.primary.accepted, state.nodes.primary.durable], [1, 0]);
  assert.deepEqual(initial.nodes.primary.pending, []);
  for (const type of ['acknowledge', 'apply', 'publish']) {
    assert.throws(() => transition(state, type, { position: 1 }), /持久|应用/);
  }
  const crashed = transition(state, 'crash');
  assert.deepEqual(crashed.lostIds, ['volatile-only']);
  assert.deepEqual(crashed.acknowledgedIds, []);
  assert.equal(crashed.nodes.primary.accepted, 0);
  const restored = transition(crashed, 'restore');
  const resumed = transition(restored, 'resume');
  assert.deepEqual(resumed.nodes.primary.appliedIds, []);
});

test('快照先恢复，日志从快照下一位严格顺序重放，未持久尾部不会回来', () => {
  let state = transition(prepared(), 'snapshot');
  state = accept(state, 'command-2');
  state = accept(state, 'command-3');
  state = transition(state, 'persist', { position: 3 });
  state = transition(state, 'acknowledge', { position: 3 });
  state = accept(state, 'command-4');
  state = transition(state, 'crash');
  assert.throws(() => transition(state, 'replay', { position: 2 }), /恢复/);
  assert.equal(state.nodes.primary.durable, 3);
  state = transition(state, 'restore');
  assert.deepEqual(state.nodes.primary.appliedIds, ['command-1']);
  assert.deepEqual([state.nodes.primary.accepted, state.nodes.primary.durable, state.nodes.primary.applied, state.nodes.primary.published], [3, 3, 1, 1]);
  assert.throws(() => transition(state, 'replay', { position: 3 }), /顺序/);
  assert.throws(() => transition(state, 'resume'), /追平/);
  assert.throws(() => transition(state, 'accept', { id: 'too-early' }), /运行/);
  state = transition(state, 'replay', { position: 2 });
  assert.throws(() => transition(state, 'replay', { position: 2 }), /顺序/);
  state = transition(state, 'replay', { position: 3 });
  state = transition(state, 'resume');
  assert.deepEqual(state.nodes.primary.appliedIds, ['command-1', 'command-2', 'command-3']);
  assert.deepEqual(state.lostIds, ['command-4']);
  assert.deepEqual(state.acknowledgedIds, ['command-1', 'command-2', 'command-3']);
  assert.throws(() => transition(state, 'apply', { position: 4 }), /持久/);
});

test('发布和确认均不跳过前置进度，重复发布非法且拒绝不会改动状态', () => {
  let state = accept(createRecoveryState(), 'one');
  state = transition(state, 'persist', { position: 1 });
  assert.throws(() => transition(state, 'publish', { position: 1 }), /应用/);
  state = transition(state, 'apply', { position: 1 });
  state = transition(state, 'publish', { position: 1 });
  const before = JSON.stringify(state);
  assert.throws(() => transition(state, 'publish', { position: 1 }), /顺序/);
  assert.equal(JSON.stringify(state), before);
  assert.deepEqual(state.publishedIds, ['one']);
});

test('恢复后重复发布以命令键模拟消费者幂等，不重复增加交付记录', () => {
  let state = prepared();
  state = transition(state, 'crash');
  state = transition(state, 'restore');
  assert.equal(state.nodes.primary.applied, 0);
  state = transition(state, 'replay', { position: 1 });
  state = transition(state, 'resume');
  state = transition(state, 'publish', { position: 1 });
  assert.deepEqual(state.publishedIds, ['command-1']);
});

test('落后副本不能接管，持久但未应用的副本也必须先追平', () => {
  let state = prepared();
  state = accept(state, 'command-2');
  state = transition(state, 'persist', { position: 2 });
  state = transition(state, 'replicate', { target: 'replica', position: 1 });
  state = transition(state, 'apply', { node: 'replica', position: 1 });
  assert.throws(() => transition(state, 'promote', { node: 'replica', epoch: 2 }), /落后/);
  assert.equal(state.leader, 'primary');
  state = transition(state, 'replicate', { target: 'replica', position: 2 });
  assert.throws(() => transition(state, 'promote', { node: 'replica', epoch: 2 }), /应用/);
  state = transition(state, 'apply', { node: 'replica', position: 2 });
  assert.throws(() => transition(state, 'promote', { node: 'replica', epoch: 1 }), /epoch/);
  state = transition(state, 'promote', { node: 'replica', epoch: 2 });
  assert.deepEqual([state.leader, state.epoch, state.requiredPosition], ['replica', 2, 2]);
});

test('较高 epoch 生效后旧主的接收、落盘、确认、发布和复制都被拒绝', () => {
  let state = prepared();
  state = transition(state, 'replicate', { target: 'replica', position: 1 });
  state = transition(state, 'apply', { node: 'replica', position: 1 });
  state = accept(state, 'old-primary-buffer');
  state = transition(state, 'promote', { node: 'replica', epoch: 2 });
  const before = JSON.stringify(state);
  for (const type of ['accept', 'persist', 'acknowledge', 'publish', 'snapshot', 'replicate']) {
    assert.throws(() => transition(state, type, { node: 'primary', epoch: 1, id: 'stale', position: 2, target: 'replica' }), /fencing/);
  }
  assert.throws(() => transition(state, 'accept', { node: 'primary', epoch: 2, id: 'impersonation' }), /fencing/);
  assert.equal(JSON.stringify(state), before);
  state = accept(state, 'new-primary-command');
  state = transition(state, 'persist', { position: 2 });
  assert.deepEqual(state.nodes.replica.log.map(row => row.id), ['command-1', 'new-primary-command']);
  assert.deepEqual(state.nodes.primary.pending.map(row => row.id), ['old-primary-buffer']);
});

test('持久卷缺失时恢复和启动失败，不能初始化空账本', () => {
  let state = transition(prepared(), 'crash');
  state = transition(state, 'detach-volume');
  assert.equal(state.nodes.primary.status, 'BLOCKED');
  assert.equal(state.nodes.primary.volumePresent, false);
  assert.throws(() => transition(state, 'restore'), /持久卷缺失/);
  assert.throws(() => transition(state, 'resume'), /持久卷缺失/);
  assert.throws(() => transition(state, 'accept', { id: 'empty-restart' }), /持久卷缺失/);
  assert.equal(state.nodes.primary.durable, 1);
  assert.equal(state.nodes.primary.log[0].id, 'command-1');
});

test('位置和 epoch 仅接受安全整数，并拒绝未知操作、重复命令与越界', () => {
  const state = accept(createRecoveryState(), 'one');
  for (const position of [-1, 0.1, NaN, Infinity, '1', Number.MAX_SAFE_INTEGER + 1]) {
    assert.throws(() => transition(state, 'persist', { position }), /整数/);
  }
  for (const epoch of [0, 1.1, '1', Number.MAX_SAFE_INTEGER + 1]) {
    assert.throws(() => transition(state, 'accept', { epoch, id: 'two' }), /epoch/);
  }
  assert.throws(() => transition(state, 'accept', { id: 'one' }), /重复/);
  assert.throws(() => transition(state, 'persist', { position: 2 }), /接受/);
  assert.throws(() => transition(state, 'unknown'), /未知/);
  assert.throws(() => transition(state, 'accept', { node: 'missing', id: 'two' }), /节点/);
});

test('两个教学场景提供独立步骤快照、数字字符串和真实拒绝的结果', () => {
  assert.deepEqual(recoveryScenarios.map(row => row.id), ['recovery-replay', 'recovery-fencing']);
  for (const scenario of recoveryScenarios) {
    const result = buildRecoveryCase({ scenario: scenario.id });
    assert.equal(result.kind, 'recovery');
    assert.equal(result.current, result.snapshots.at(-1));
    assert.match(result.limitation, /内存.*持久化.*网络分区.*高可用/);
    assert(result.snapshots.some(snapshot => snapshot.rows.some(row => row.state === 'REJECTED')));
    for (const [step, snapshot] of result.snapshots.entries()) {
      assert.equal(snapshot.step, step);
      assert(snapshot.notes.every(note => typeof note === 'string'));
      assert(snapshot.metrics.every(metric => typeof metric.value === 'string'));
      assert(snapshot.checks.every(check => check.ok));
    }
    assert.doesNotThrow(() => JSON.stringify(result));
    assert.equal(buildRecoveryCase({ scenario: scenario.id, step: 0 }).current.step, 0);
  }
  const replay = buildRecoveryCase();
  assert.equal(replay.current.rows.find(row => row.subject === 'primary').state, 'BLOCKED');
  assert.deepEqual(replay.snapshots[0].metrics.slice(0, 4).map(row => row.value), ['0', '0', '0', '0']);
  for (const step of [-1, 0.5, '0', 999]) assert.throws(() => buildRecoveryCase({ step }), /步骤/);
  assert.throws(() => buildRecoveryCase({ scenario: 'unknown' }), /未知/);
});
