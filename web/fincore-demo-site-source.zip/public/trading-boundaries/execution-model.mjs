// 确定性内存教学模型；金额均为 BigInt，四位小数仅为本实验的记账精度。
// 纯状态转换没有数据库、网络、钱包或真实并发，不能证明生产事务原子性。
const SCALE = 10000n;
const amount = value => BigInt(value) * SCALE;
const LIMITATION = '确定性顺序内存模型；不连接钱包、银行或外部金融 API，不证明真实并发原子性、持久化、回调真实性或生产渠道能力。四位最小单位为教学设定，并非链上代币精度。';
const fail = code => { throw new Error(code); };
const positive = value => { if (typeof value !== 'bigint' || value <= 0n) fail('INVALID_AMOUNT'); };
const identified = id => { if (typeof id !== 'string' || !id.trim()) fail('INVALID_ID'); };
const decimal = value => {
  const absolute = value < 0n ? -value : value;
  const fraction = String(absolute % SCALE).padStart(4, '0').replace(/0+$/, '');
  return `${value < 0n ? '-' : ''}${absolute / SCALE}${fraction ? `.${fraction}` : ''}`;
};
const check = (name, ok, detail) => ({ name, ok, detail });
const sum = (rows, field) => rows.reduce((total, row) => total + row[field], 0n);
const journal = (id, value) => [{ id: `${id}:debit`, delta: -value }, { id: `${id}:credit`, delta: value }];

export const executionScenarios = [
  { id: 'payment-unknown', title: '付款超时与晚到成功', summary: 'UNKNOWN 保留原 Attempt；禁止切换通道再付，重复成功只记账一次。' },
  { id: 'refund-reservation', title: '部分退款预占与交错请求', summary: '累计成功额加预占额不超过原款；失败释放，成功不可反转。' },
  { id: 'hedge-partial', title: '部分对冲与残余敞口', summary: '收款 1000 USDT，经执行前门禁模拟成交 600，保留 400 敞口；未实现外部成交采集。' },
  { id: 'reconciliation-cut', title: '倒序提交与对账共同切面', summary: '最大 ID 不代表完整水位；在途不判错，真实差异仅隔离。' },
];

export function createExecutionState(scenario) {
  const base = { scenario };
  if (scenario === 'payment-unknown') return { ...base, amount: amount(100), paid: 0n, attempt: null, attempts: [], journals: [] };
  if (scenario === 'refund-reservation') return { ...base, captured: amount(100), reserved: 0n, refunded: 0n, refunds: [], journals: [] };
  if (scenario === 'hedge-partial') return { ...base, received: 0n, hedged: 0n, inventory: 0n, quoteGross: 0n, quoteNet: 0n, fees: 0n, minPrice: 9990n, maxFeeBps: 20n, receipts: [], fills: [] };
  if (scenario === 'reconciliation-cut') {
    const side = () => ({ rows: [], absent: [], completeThrough: 100, maxSeen: 100 });
    return { ...base, ids: [101, 102], ledger: side(), statement: side(), isolations: [] };
  }
  fail(`未知执行场景：${scenario}`);
}

function payment(state, event) {
  identified(event.id);
  const previous = state.attempt;
  if (event.type === 'START') {
    identified(event.channel);
    const existing = state.attempts.find(row => row.id === event.id);
    // 同一业务键固定通道；重放只返回已有状态，不代表重新向渠道发送付款。
    if (existing) {
      if (existing.channel !== event.channel) fail('IDEMPOTENCY_CONFLICT');
      return state;
    }
    if (state.paid) fail('PAYMENT_ALREADY_PAID');
    if (previous && previous.status !== 'FAILED') fail('PAYMENT_UNRESOLVED');
    const attempt = { id: event.id, channel: event.channel, status: 'SUBMITTED' };
    return { ...state, attempt, attempts: [...state.attempts, attempt] };
  }
  if (!previous || previous.id !== event.id) fail('ATTEMPT_MISMATCH');
  const replace = (status, extra = {}) => {
    const attempt = { ...previous, status };
    return { ...state, ...extra, attempt, attempts: state.attempts.map(row => row.id === attempt.id ? attempt : row) };
  };
  if (event.type === 'TIMEOUT') {
    if (previous.status !== 'SUBMITTED') return state;
    return replace('UNKNOWN');
  }
  if (event.type !== 'RESULT' || !['SUCCESS', 'FAILED'].includes(event.status)) fail('INVALID_EVENT');
  if (previous.status === event.status) return state;
  // SUCCESS 不可逆；FAILED 是已核实的终态失败，网络超时必须走 UNKNOWN。
  if (['SUCCESS', 'FAILED'].includes(previous.status)) fail('TERMINAL_RESULT');
  return event.status === 'SUCCESS'
    ? replace('SUCCESS', { paid: state.amount, journals: [...state.journals, ...journal(previous.id, state.amount)] })
    : replace('FAILED');
}

function refund(state, event) {
  identified(event.id);
  const existing = state.refunds.find(row => row.id === event.id);
  if (event.type === 'RESERVE') {
    positive(event.amount);
    if (existing) {
      if (existing.amount !== event.amount) fail('IDEMPOTENCY_CONFLICT');
      return state;
    }
    // 校验和预占属于一次模型转换；真实并发必须用数据库锁/条件更新及事务保证。
    if (state.refunded + state.reserved + event.amount > state.captured) fail('REFUND_LIMIT');
    return { ...state, reserved: state.reserved + event.amount, refunds: [...state.refunds, { id: event.id, amount: event.amount, status: 'RESERVED' }] };
  }
  if (event.type !== 'REFUND_RESULT' || !existing || !['SUCCESS', 'FAILED'].includes(event.status)) fail('INVALID_EVENT');
  if (existing.status === event.status) return state;
  if (existing.status !== 'RESERVED') fail('TERMINAL_RESULT');
  // 失败仅释放预占；成功追加原款返还分录。两种终态均不允许重新复活旧 ID。
  const success = event.status === 'SUCCESS';
  return {
    ...state, reserved: state.reserved - existing.amount, refunded: state.refunded + (success ? existing.amount : 0n),
    refunds: state.refunds.map(row => row.id === existing.id ? { ...row, status: event.status } : row),
    journals: success ? [...state.journals, ...journal(existing.id, existing.amount)] : state.journals,
  };
}

function hedge(state, event) {
  identified(event.id);
  if (event.type === 'RECEIVE') {
    positive(event.amount);
    const existing = state.receipts.find(row => row.id === event.id);
    if (existing) {
      if (existing.amount !== event.amount) fail('IDEMPOTENCY_CONFLICT');
      return state;
    }
    return { ...state, received: state.received + event.amount, inventory: state.inventory + event.amount, receipts: [...state.receipts, { id: event.id, amount: event.amount }] };
  }
  // EXECUTE 是执行前门禁通过后模拟成交，不是外部已成交事实的采集入口。
  // 外部已成交即使越限，也必须记账、记录风险并隔离，不能复用此处的拒绝逻辑。
  if (event.type !== 'EXECUTE') fail('INVALID_EVENT');
  positive(event.quantity); positive(event.price);
  const existing = state.fills.find(row => row.id === event.id);
  if (existing) {
    if (['quantity', 'price', 'feeBps'].some(key => existing[key] !== event[key])) fail('IDEMPOTENCY_CONFLICT');
    return state;
  }
  if (event.price < state.minPrice) fail('PRICE_LIMIT');
  if (typeof event.feeBps !== 'bigint' || event.feeBps < 0n || event.feeBps > state.maxFeeBps) fail('FEE_LIMIT');
  if (event.quantity > state.inventory) fail('INSUFFICIENT_INVENTORY');
  // 模拟执行请求锁定价格和 USD 费率；执行前拒绝非精确最小单位，避免暗含舍入政策。
  if (event.quantity * event.price % SCALE) fail('INEXACT_AMOUNT');
  const gross = event.quantity * event.price / SCALE;
  if (gross * event.feeBps % 10000n) fail('INEXACT_AMOUNT');
  const fee = gross * event.feeBps / 10000n;
  return {
    ...state, hedged: state.hedged + event.quantity, inventory: state.inventory - event.quantity,
    quoteGross: state.quoteGross + gross, quoteNet: state.quoteNet + gross - fee, fees: state.fees + fee,
    fills: [...state.fills, { id: event.id, quantity: event.quantity, price: event.price, feeBps: event.feeBps, gross, fee }],
  };
}

export function reconcileAtCut(state, cut = Math.min(state.ledger.completeThrough, state.statement.completeThrough)) {
  if (!Number.isInteger(cut) || cut < 100 || cut > Math.min(state.ledger.completeThrough, state.statement.completeThrough)) fail('INCOMPLETE_CUT');
  const rows = state.ids.map(id => {
    const local = state.ledger.rows.find(row => row.id === id), external = state.statement.rows.find(row => row.id === id);
    const difference = (local?.amount ?? 0n) - (external?.amount ?? 0n);
    const status = id > cut ? 'IN_FLIGHT' : !local && !external ? 'MATCH' : !local || !external ? 'MISSING' : difference ? 'DIFFERENCE' : 'MATCH';
    return { id, state: status, local: local?.amount ?? null, external: external?.amount ?? null, difference };
  });
  return { cut, rows };
}

function reconciliation(state, event) {
  if (event.type === 'RECONCILE') {
    const result = reconcileAtCut(state, event.cut);
    // 完整共同切面内的真实差异只进入隔离队列；账本和外部观察均不改写。
    const fresh = result.rows.filter(row => ['MISSING', 'DIFFERENCE'].includes(row.state) && !state.isolations.some(item => item.id === row.id));
    return fresh.length ? { ...state, isolations: [...state.isolations, ...fresh.map(row => ({ ...row, cut: result.cut, status: 'ISOLATED' }))] } : state;
  }
  if (!['POST', 'CONFIRM_ABSENT'].includes(event.type) || !['ledger', 'statement'].includes(event.side) || !state.ids.includes(event.id)) fail('INVALID_EVENT');
  const source = state[event.side], existing = source.rows.find(row => row.id === event.id);
  if (event.type === 'POST') {
    positive(event.amount);
    if (existing) {
      if (existing.amount !== event.amount) fail('IDEMPOTENCY_CONFLICT');
      return state;
    }
    if (source.absent.includes(event.id)) fail('CLOSED_OBSERVATION');
  } else {
    if (existing) fail('CLOSED_OBSERVATION');
    if (source.absent.includes(event.id)) return state;
  }
  const next = event.type === 'POST'
    ? { ...source, rows: [...source.rows, { id: event.id, amount: event.amount }], maxSeen: Math.max(source.maxSeen, event.id) }
    : { ...source, absent: [...source.absent, event.id] };
  // ID 分配不等于提交。只有前面的每个 ID 已提交或被权威确认无记录，才推进完整水位。
  let completeThrough = 100;
  for (const id of state.ids) {
    if (!next.rows.some(row => row.id === id) && !next.absent.includes(id)) break;
    completeThrough = id;
  }
  return { ...state, [event.side]: { ...next, completeThrough } };
}

export function reduceExecution(state, event) {
  const reducers = { 'payment-unknown': payment, 'refund-reservation': refund, 'hedge-partial': hedge, 'reconciliation-cut': reconciliation };
  if (!reducers[state.scenario]) fail('INVALID_SCENARIO');
  return reducers[state.scenario](state, event);
}

function describe(state) {
  const metric = (label, value) => ({ label, value: typeof value === 'bigint' ? decimal(value) : String(value) });
  const row = (subject, status, detail) => ({ subject, state: status, detail });
  if (state.scenario === 'payment-unknown') return {
    metrics: [metric('付款额（CNY）', state.amount), metric('已付款（CNY）', state.paid), metric('Attempt 数', state.attempts.length), metric('资金分录数', state.journals.length)],
    rows: state.attempts.map(item => row(`Attempt ${item.id}`, item.status, `固定通道 ${item.channel}；${decimal(state.amount)} CNY`)),
    checks: [check('成功只记账一次', state.journals.length === (state.paid ? 2 : 0) && state.paid <= state.amount, '成功只有一组借贷分录'), check('分录平衡', sum(state.journals, 'delta') === 0n, '借贷最小单位之和为零'), check('成功金额对应终态', (state.paid > 0n) === (state.attempt?.status === 'SUCCESS'), 'UNKNOWN 没有确认付款成功')],
  };
  if (state.scenario === 'refund-reservation') return {
    metrics: [metric('原收款（CNY）', state.captured), metric('退款预占（CNY）', state.reserved), metric('退款成功（CNY）', state.refunded), metric('可申请退款（CNY）', state.captured - state.reserved - state.refunded), metric('资金分录数', state.journals.length)],
    rows: state.refunds.map(item => row(`退款 ${item.id}`, item.status, `${decimal(item.amount)} CNY；${item.status === 'RESERVED' ? '额度已预占' : item.status === 'SUCCESS' ? '已追加退款分录' : '已释放预占'}`)),
    checks: [check('累计退款不超原款', state.refunded + state.reserved <= state.captured && state.reserved >= 0n, '成功额 + 预占额 ≤ 原收款'), check('预占与明细一致', state.reserved === sum(state.refunds.filter(item => item.status === 'RESERVED'), 'amount'), '每个未决退款持有自己的额度'), check('成功额与流水一致', state.refunded === sum(state.refunds.filter(item => item.status === 'SUCCESS'), 'amount') && state.journals.length === state.refunds.filter(item => item.status === 'SUCCESS').length * 2 && sum(state.journals, 'delta') === 0n, '失败不产生成功分录；成功只记一次')],
  };
  if (state.scenario === 'hedge-partial') return {
    metrics: [metric('已收款（USDT）', state.received), metric('已对冲（USDT）', state.hedged), metric('剩余敞口（USDT）', state.inventory), metric('成交总款（USD）', state.quoteGross), metric('手续费（USD）', state.fees), metric('净回款（USD）', state.quoteNet)],
    rows: [row('USDT 库存', state.inventory ? 'EXPOSED' : 'EMPTY', `${decimal(state.inventory)} USDT；残余敞口没有假定按 1 USD 兑现`), ...state.fills.map(item => row(`模拟执行 ${item.id}`, 'FILLED', `${decimal(item.quantity)} USDT × ${decimal(item.price)} USD；费用 ${decimal(item.fee)} USD（${item.feeBps} bp）`))],
    checks: [check('库存与模拟成交闭合', state.inventory >= 0n && state.inventory + state.hedged === state.received && state.hedged === sum(state.fills, 'quantity'), 'USDT 收款 = 模拟已售数量 + 剩余库存'), check('USD 费用闭合', state.quoteNet + state.fees === state.quoteGross && state.fees === sum(state.fills, 'fee'), '净回款 + USD 手续费 = USD 成交款'), check('模拟执行前价格与费率通过门禁', state.fills.every(item => item.price >= state.minPrice && item.feeBps <= state.maxFeeBps), `底价 ${decimal(state.minPrice)} USD/USDT；费率上限 ${state.maxFeeBps} bp`)],
  };
  const comparison = reconcileAtCut(state);
  return {
    metrics: [metric('账本最大已见 ID', state.ledger.maxSeen), metric('账本完整水位', state.ledger.completeThrough), metric('账单完整水位', state.statement.completeThrough), metric('共同切面', comparison.cut), metric('隔离差异数', state.isolations.length)],
    rows: comparison.rows.map(item => row(`记录 ${item.id}`, state.isolations.some(isolated => isolated.id === item.id) ? 'ISOLATED' : item.state, `账本 ${item.local === null ? '未见' : decimal(item.local)} CNY；账单 ${item.external === null ? '未见' : decimal(item.external)} CNY；${item.id > comparison.cut ? '切面之外，保留在途' : `差额 ${decimal(item.difference)} CNY`}`)),
    checks: [check('共同切面完整', ['ledger', 'statement'].every(side => state.ids.filter(id => id <= comparison.cut).every(id => state[side].rows.some(item => item.id === id) || state[side].absent.includes(id))), '切面内每个 ID 均有已提交记录或权威缺失确认'), check('切面外不隔离', state.isolations.every(item => item.id <= item.cut), '未完整提交的记录仅标记在途'), check('隔离保留原始差异', state.isolations.every(item => comparison.rows.some(current => current.id === item.id && current.difference === item.difference && current.state === item.state)), '没有静默改账或追加修复流水')],
  };
}

export function buildExecutionCase({ scenario = 'payment-unknown', step } = {}) {
  const metadata = executionScenarios.find(item => item.id === scenario);
  if (!metadata) fail(`未知执行场景：${scenario}`);
  let state = createExecutionState(scenario);
  const snapshots = [];
  const snapshot = (title, notes = [], extraChecks = []) => {
    const view = describe(state), checks = [...view.checks, ...extraChecks];
    if (checks.some(item => !item.ok)) fail(`执行边界不变量失败：${checks.filter(item => !item.ok).map(item => item.name).join('、')}`);
    snapshots.push({ step: snapshots.length, title, notes, ...view, checks });
  };
  const advance = (title, event, notes = []) => { state = reduceExecution(state, event); snapshot(title, notes); };
  const rejected = (event, code, name) => {
    let observed = '未拒绝';
    try { reduceExecution(state, event); } catch (error) { observed = error.message; }
    return check(name, observed === code, `实际结果：${observed}`);
  };
  const duplicate = (title, event) => {
    const next = reduceExecution(state, event);
    snapshot(title, ['重放只返回原状态；不重新发送外部指令。'], [check('重复请求无状态变化', next === state, '相同业务键、相同参数返回原状态')]);
  };
  snapshot('初始状态', [LIMITATION]);
  if (scenario === 'payment-unknown') {
    advance('A1 向通道 A 提交付款', { type: 'START', id: 'A1', channel: 'BANK_A' });
    advance('请求超时，A1 进入 UNKNOWN', { type: 'TIMEOUT', id: 'A1' }, ['超时不能证明渠道未付款；保留原 Attempt 与通道，通过查询或晚到结果收敛。']);
    snapshot('尝试切到通道 B 再付：拒绝', ['未知结果占住付款权；不能自动创建另一笔付款。'], [rejected({ type: 'START', id: 'A2', channel: 'BANK_B' }, 'PAYMENT_UNRESOLVED', '未知结果禁止二次付款')]);
    advance('原 A1 的成功结果晚到', { type: 'RESULT', id: 'A1', status: 'SUCCESS' }, ['此处假设收到可信结果；真实系统必须验签、查询核实并持久化幂等键。']);
    duplicate('重复成功回调：无新分录', { type: 'RESULT', id: 'A1', status: 'SUCCESS' });
    snapshot('迟到失败不能覆盖成功', [], [rejected({ type: 'RESULT', id: 'A1', status: 'FAILED' }, 'TERMINAL_RESULT', '成功终态不可逆')]);
  } else if (scenario === 'refund-reservation') {
    advance('R1 预占 60', { type: 'RESERVE', id: 'R1', amount: amount(60) }, ['两个申请方可以同时读到旧额度 100；执行时必须重新验证当前权威占用。']);
    snapshot('交错的 R2 申请 50：拒绝', [], [rejected({ type: 'RESERVE', id: 'R2', amount: amount(50) }, 'REFUND_LIMIT', '旧余额不能绕过预占')]);
    advance('R2 改为预占剩余 40', { type: 'RESERVE', id: 'R2', amount: amount(40) });
    advance('R1 确认失败，释放 60', { type: 'REFUND_RESULT', id: 'R1', status: 'FAILED' }, ['失败必须已经核实；未知结果不能按失败释放额度。']);
    advance('新的 R3 预占释放出的 60', { type: 'RESERVE', id: 'R3', amount: amount(60) });
    advance('R2 退款成功 40', { type: 'REFUND_RESULT', id: 'R2', status: 'SUCCESS' });
    advance('R3 退款成功 60，原款额度用完', { type: 'REFUND_RESULT', id: 'R3', status: 'SUCCESS' });
    duplicate('重复 R3 成功：不重复退款记账', { type: 'REFUND_RESULT', id: 'R3', status: 'SUCCESS' });
    snapshot('成功后失败通知与继续超退均拒绝', [], [rejected({ type: 'REFUND_RESULT', id: 'R3', status: 'FAILED' }, 'TERMINAL_RESULT', '成功不可改失败'), rejected({ type: 'RESERVE', id: 'R4', amount: amount(1) }, 'REFUND_LIMIT', '不能超过原款')]);
  } else if (scenario === 'hedge-partial') {
    advance('确认收款 1000 USDT', { type: 'RECEIVE', id: 'RC1', amount: amount(1000) }, ['收款与对冲是独立进度；1000 USDT 尚未自动成为 USD。', '本场景只有执行前门禁与模拟成交，未实现外部成交采集；外部已成交即使越限仍须记账、记录风险并隔离，不能拒绝事实入账。']);
    const execute = { type: 'EXECUTE', id: 'F1', quantity: amount(600), price: SCALE, feeBps: 10n };
    advance('执行前门禁通过，模拟成交 600 USDT', execute, ['本笔价格为 1 USD/USDT；10 bp 手续费 0.6 USD，净回款 599.4 USD；留下 400 USDT 敞口。', '底价 0.999 USD/USDT，最高费用 20 bp；不将 USDT 与 USD 混成一个守恒总量。']);
    duplicate('同一执行键重放：库存与费用不变', execute);
    snapshot('模拟执行请求越界，在执行前拒绝', ['剩余 400 USDT 仍承担价格风险；未计入未成交收益。', '以下拒绝只适用于尚未执行的请求，不能用于丢弃已发生的外部成交。'], [rejected({ ...execute, id: 'F2', quantity: amount(500) }, 'INSUFFICIENT_INVENTORY', '执行前检查库存'), rejected({ ...execute, id: 'F2', quantity: amount(400), price: 9800n }, 'PRICE_LIMIT', '执行前检查底价'), rejected({ ...execute, id: 'F2', quantity: amount(400), feeBps: 21n }, 'FEE_LIMIT', '执行前检查费用')]);
  } else {
    advance('账单先确认 101 的 99 CNY', { type: 'POST', side: 'statement', id: 101, amount: amount(99) });
    advance('账单确认 102，账单切面完整到 102', { type: 'POST', side: 'statement', id: 102, amount: amount(200) });
    advance('账本 ID 102 先提交，101 尚未提交', { type: 'POST', side: 'ledger', id: 102, amount: amount(200) }, ['最大已见 ID 是 102，完整水位仍是 100；不能把 101 当作永久缺失。']);
    snapshot('拒绝以最大 ID 102 强行对账', ['共同切面为 100，两条观察都保留在途。'], [rejected({ type: 'RECONCILE', cut: 102 }, 'INCOMPLETE_CUT', '不能跳过未决 ID')]);
    advance('账本 101 晚提交，完整水位推进到 102', { type: 'POST', side: 'ledger', id: 101, amount: amount(100) }, ['完整共同切面内，101 的账本 100 与账单 99 才构成真实差异；102 一致。']);
    advance('真实差异进入隔离，等待人工复核', { type: 'RECONCILE' }, ['原账本保留 100，外部账单保留 99；不改历史、不自动补齐，也不将隔离等同于修复。']);
    duplicate('重复对账：不重复隔离或修复', { type: 'RECONCILE' });
  }
  const selected = step === undefined ? snapshots.length - 1 : step;
  if (!Number.isInteger(selected) || selected < 0 || selected >= snapshots.length) fail('步骤必须是范围内的整数');
  return { kind: 'execution', scenario, title: metadata.title, limitation: LIMITATION, snapshots, current: snapshots[selected], maxStep: snapshots.length - 1 };
}
