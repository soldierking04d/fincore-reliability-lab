# 交易、支付与资金事务边界实施手册

本文补充从成交到资金终态、从单库到外部渠道之间的实施细节，供设计、开发、测试和值班共同使用。
金额示例都是隔离教学数据；本文没有连接支付渠道、链上托管或新的生产数据库，也不代表这些能力已经发布。
现有实现以[现货资金闭环](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/spot-funds-closure.md)及下列源码为准；独立状态模型通过只能证明其覆盖的规则。

| 证据层 | 当前事实 | 不能据此推出的结论 |
| --- | --- | --- |
| Java 与 PostgreSQL | `SpotDeliveryService.settle` 同事务处理双资产、四账户、账本、Inbox、终态和 Outbox | 已经跨账户数据库分片提交 |
| 费用模型 | `FeeEngine` 有 Maker/Taker、费率阶梯、舍入和原额冲正规则 | 现货资金交割已经扣收手续费 |
| 恢复模型 | `MatchingRecoveryLog` 使用内存日志、快照、摘要和 Epoch | 已有磁盘持久化、复制协议或撮合主备 |
| 本文及隔离实验 | 描述跨分片、支付、托管的状态与失败契约 | 已接入真实渠道、已实现 XA 或已完成高可用验收 |

教学实验见 [`experiments/funds-boundaries`](README.md)；运行方法和实际覆盖范围以其 README 与测试为准。
实验中的内存 branch、决议、渠道响应及水位均为替身；进程退出后仍可恢复必须由后续持久化集成测试证明。

## 1. 一张买单、三笔成交与剩余撤单

### 1.1 固定输入与成交顺序

U 初始持有 1,500 USDT、0 ABC，准备提交限价买单 B：数量 100 ABC，价格 10 USDT/ABC。
A、B卖方、C 先按顺序挂数量 40、40、50 的限价卖单，价格均为 10，再由 U 买入；卖方 B 的订单记作 S-B。
三个卖方初始 ABC 分别为 40、40、50，初始 USDT 为 0；不允许自成交，示例没有价格改善。
下表按撮合系统确认的命令顺序执行，网络包到达顺序或客户端时钟不构成撮合顺序。

| 成交 | 买订单 | 卖订单 | 数量 ABC | 名义金额 USDT | Maker / Taker | 成交后余量 |
| --- | --- | --- | ---: | ---: | --- | --- |
| T1 | B | S-A | 40 | 400 | S-A / B | B 余 60，S-A 完成 |
| T2 | B | S-B | 40 | 400 | S-B / B | B 余 20，S-B 完成 |
| T3 | B | S-C | 20 | 200 | S-C / B | B 完成，S-C 余 30 |

Maker/Taker 是每笔成交中提供或消耗簿上流动性的角色，不是用户、买卖方向或整张订单的永久属性。
对照场景中，如果 U 先挂买单、三个卖方随后主动卖出，三笔成交的 Maker/Taker 反转；该分支必须显式选择其角色费率。
对照中的 S-C 在 T3 是 Taker，余量 30 挂簿后被新买单吃掉时成为 Maker；主例的 S-C 在 T3、T4 均为 Maker。
若 T4 只买 10，则 S-C 的累计成交为 30、余量 20；之后撤单只释放这 20，不改写 T3 或 T4。

### 1.2 三条权威成交与六条参与方明细

当前 [`trade_execution`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/resources/db/migration/V3__matching_engine.sql) 每个 `trade_id` 一行，所以 T1—T3 是三行。
每行保存 `maker_order_id`、`taker_order_id`、`price`、`quantity`、`quote_amount`、`trade_sequence` 等权威字段。
买卖双方各看一条成交明细可以投影成六条 `(trade_id, participant_side)` 记录；它们是展示模型，不是六笔成交。
当前表结构没有这张六行参与方明细表，不应把它写成已经存在的落库结构。
新增参与方投影时应设置唯一键 `(trade_id, participant_side)`，重建依据仍是三条不可变成交及对应订单。
统计交易量用权威三笔；直接汇总六行的名义金额会把 1,000 USDT 错报为 2,000 USDT。

### 1.3 固定教学费用与双资产守恒

主例固定买方 Taker 收取收到 ABC 的 0.1%，卖方 Maker 收取收到 USDT 的 0.05%。
这是便于核算的教学费率；角色反转分支应按显式 Maker/Taker 费率另算，不沿用下表金额，也不能当作当前现货配置。
ABC 与 USDT 分别使用十进制定点金额，先明确资产精度和舍入规则，再把舍入结果成对记账。

| 成交 | U 收到 ABC 毛额 | U 费用 ABC | U 净得 ABC | 卖方毛收 USDT | 卖方费用 USDT | 卖方净得 USDT |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| T1 | 40 | 0.04 | 39.96 | 400 | 0.20 | 399.80 |
| T2 | 40 | 0.04 | 39.96 | 400 | 0.20 | 399.80 |
| T3 | 20 | 0.02 | 19.98 | 200 | 0.10 | 199.90 |
| 合计 | 100 | 0.10 | 99.90 | 1,000 | 0.50 | 999.50 |

全部交割后 U 持有 500 USDT、99.90 ABC；平台费用账户分别增加 0.50 USDT、0.10 ABC。
USDT 核对：`1,500 = U 500 + A 399.80 + B卖方 399.80 + C 199.90 + 平台 0.50`。
ABC 核对：`130 = U 99.90 + C 30 + 平台 0.10`；不能把两个资产的数量直接相加做守恒。
每笔先记毛额双资产转移，再记用户到同资产费用账户的转移；每组借贷必须按资产独立平衡。
接入后成交需固化 `fee_rule_version`、`role`、`fee_asset`、`rate`、`basis`、`rounded_fee` 和费用业务键。
冲正引用原舍入费用生成反向分录，不能用新费率重新计算历史；当前 [`FeeEngine`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/exchange/FeeEngine.java) 可复用计算规则，但接入现货需另行实现。

### 1.4 资金桶与撤单竞争

当前账户定义 `available = balance - reserved_balance - pending_debit`；订单定义 `initial = held + pending + settled + released`。
教学模型若把未交割金额统一标为 `frozen`，它表达不可花费约束；下表使用当前 Java 的 held/pending 分桶，不能混称同一表结构。
U 下单后 USDT 为 `balance=1500, available=500, reserved=1000, pending=0`；撮合三笔后为 `1500,500,0,1000`。
三笔交割全部完成后为 `balance=500, available=500, reserved=0, pending=0`；教学买方费用从收到的 ABC 中扣收。

| S-C 阶段 | 总 ABC | 可用 ABC | held / reserved | pending | 累计 settled / released |
| --- | ---: | ---: | ---: | ---: | --- |
| 下单预占 50 | 50 | 0 | 50 | 0 | 0 / 0 |
| T3 撮合已提交，尚未交割 | 50 | 0 | 30 | 20 | 0 / 0 |
| 此时撤销余单 | 50 | 30 | 0 | 20 | 0 / 30 |
| T3 后续交割完成 | 30 | 30 | 0 | 0 | 20 / 30 |

“撤单先于 T3”必须写明先于哪一步：先于 T3 的交割，并不先于 T3 已提交的撮合事实，此时不能解冻 50。
若撤单在同一交易对序列中先于 T3 撮合生效，则 S-C 可以释放 50，但该订单之后不得再产生 T3。
实现要在同一锁或确定序列下比较订单状态、余量与版本，不能先读缓存 50 再无条件释放。
验收分别暂停交割、竞争撮合与撤单、重复撤单、重放 T3；检查无负桶、无重复释放、无已成交金额复活。

## 2. 账户分片之后，谁决定一笔资金业务完成

### 2.1 先定义不可变分支清单

当前 Worker 的逻辑分片不等于账户已分散在不同数据库；四账户仍由一个 PostgreSQL 事务提交。
候选跨库方案必须先保存完整清单，不能以“已收到几个成功回调”猜测所有参与方都已完成。
按本例无费用交割，一个业务至少涉及 U-USDT、卖方-USDT、卖方-ABC、U-ABC 四个账户效果；费用接入还涉及费用账户。
同库账户可以归并为一个本地分支，跨库账户不得靠远程串行调用假装共享本地事务。

| 候选持久化对象 | 必填字段 | 约束 |
| --- | --- | --- |
| transfer_manifest | global_id、trade_id、manifest_version、manifest_hash、expected_branch_ids | 创建后清单不可变；总额按资产平衡 |
| transfer_branch | global_id、branch_id、shard_id、routing_version、account_id、asset、signed_amount | `(global_id,branch_id)` 唯一；重试金额与版本一致 |
| branch_effect | operation_key、state、held_debit、pending_credit、account_version、applied_journal_id | 同一效果不能重复应用；状态转换有版本条件 |
| transfer_decision | global_id、decision、decision_version、owner_epoch、decided_at | 唯一且不可逆；不能 COMMIT 后改 ABORT |
| recovery_task | global_id、next_attempt_at、attempt_count、last_error、lease_epoch | 可扫描、可接管、可限速，不能只放 JVM 定时器 |

`pending_credit` 是候选收款隔离桶，当前现货账户尚无此字段；其值不能计入可用、授信或再次支付额度。
清单摘要必须覆盖账户、资产、金额、方向、路由版本及所有分支；相同 ID 不同摘要应拒绝并进入调查。
账户迁移期间按固定路由版本处理存量业务；旧新分片不能分别把同一业务当成首次扣款。

### 2.2 可恢复业务协议

本节是“预留后确认记账”的候选协议，不是页面模型的逐步实现。页面模型演示“先分别记账到隔离余额，再作可用化决议”；两者都必须保留不可用中间态和可恢复的唯一决议，但决议前的效果不同，不可混用补偿规则。

1. 本地持久化清单与 `PREPARING` 状态，确认所有借方金额、贷方金额及受影响资产。
2. 分支在本地事务中幂等预占借方或登记不可用的待入账，并记录业务状态；网络调用位于事务之外。
3. 只有全部预期分支、金额和版本核对通过，协调者才持久化唯一 `COMMIT` 决议；确认失败则持久化 `ABORT`。
4. `COMMIT` 后恢复 Worker 按固定清单推进每个分支的不可逆记账；回复丢失时查原分支或重试原操作键。
5. 全部分支已确认提交后只能标记“分支记账完成”，再有序开放贷方可用；开放过程仍须幂等恢复。全部可用化效果确认后才进入 `SETTLED`（业务资金完成）并发布最终成功结果。
6. `ABORT` 只解除仍处于预留阶段的效果；任何已确定 COMMIT 的业务都不能因为超时转入自动补偿。

这属于业务层预留、决议、确认协议，并非数据库 XA 2PC；各分支的本地事务已经分别提交。
异步释放不同账户的可用额度可能有短暂可见性差异；需要严格跨库原子可见时，应另设计读写屏障或选择支持该语义的事务系统。
恢复保证依赖持久决议、分支保留期、幂等约束和最终能通信，不能只靠正常路径跑完一次证明。
`COMMIT_UNKNOWN` 表示观察者尚不知道提交结果，不是新的可补偿业务终态。

### 2.3 丢回复、接管与验收

| 故障 | 应执行的动作 | 禁止的动作 |
| --- | --- | --- |
| 分支已预留但回复丢失 | 使用相同 branch_id 查询并校验摘要 | 新建分支再次冻结 |
| 决议提交返回超时 | 查询权威决议；无法查询则保持冻结并重试 | 假定 ABORT，释放全部金额 |
| 一边已提交，另一边暂时离线 | COMMIT 恢复继续完成剩余分支，贷方保持隔离 | 对已经成功分支直接回滚历史 |
| 恢复 Worker 被接管 | 新 owner 获得更高 epoch，分支写入校验 epoch | 只在内存检查 owner 名称 |
| 原协调者恢复并发送旧命令 | 用权威决议和数据面 Fence 拒绝冲突指令 | 接受最后到达的请求覆盖状态 |

验收需真实独立数据库、持久决议存储和进程重启；在每个发送前后、落库前后注入中断，逐笔重算金额与最终状态。
同一业务允许重复投递，不允许重复效果；报警分别观察最老未决年龄、冻结金额、缺失分支及旧 epoch 拒绝次数。

## 3. 本地事务、XA、TCC、Saga 与 Outbox 的适用边界

| 方法 | 原子范围与中间态 | 主要失败责任 | 本项目定位 |
| --- | --- | --- | --- |
| 本地事务 | 单库内余额、账本、状态、Inbox、Outbox 一次提交 | 提交结果未知时查业务唯一键 | 当前现货交割实现 |
| XA / 2PC | 资源管理器先 prepare，再按协调者决议完成 | 持久决议、未决事务、锁与恢复管理 | 待验证候选，未接入 |
| TCC | Try 预留资源，Confirm/Cancel 各自本地事务 | 幂等、空回滚、防悬挂、业务隔离 | 可用于受控资源预留 |
| Saga | 多个已提交本地业务组成流程 | 补偿是新业务，可能失败或不能撤回 | 跨外部系统流程候选 |
| Outbox | 业务状态与待发事件同库原子写入 | 发布重试、重复消费、下游收件去重 | 已有实现；不包办跨库原子性 |

### 3.1 XA prepare 与决议故障

参与者的 prepare 成功意味着其具备按决议完成的准备状态；协调者必须持久记录全体投票及最终决议。
prepare 回复丢失时，协调者不能把“未收到”当成“参与者没准备”，需要按全局事务标识恢复查询。
协调者持久化 COMMIT 后宕机，恢复必须继续 COMMIT；参与者不能根据本地等待超时自行改为回滚。
COMMIT 回复丢失时，重试或查询同一事务结果，不能另起一个业务再扣款；启发式处理需人工记录并对账。
长期 prepared 会占用资源，应设置未决年龄告警和恢复责任人；“两阶段”不自动消除阻塞或网络分区问题。
PostgreSQL 提供 `PREPARE TRANSACTION`、`COMMIT PREPARED`、`ROLLBACK PREPARED` 和 `pg_prepared_xacts`，面向外部事务管理器使用。[官方说明](https://www.postgresql.org/docs/current/two-phase.html)

隔离验证步骤如下；只适用于专用一次性测试实例，不要对现网执行配置变更或遗留事务清理。

1. 固定 PostgreSQL 版本和镜像，启用测试所需 `max_prepared_transactions`，记录独立数据卷和端口。
2. 创建测试账户与唯一业务键，开启事务、修改余额后执行 `PREPARE TRANSACTION 'lab-tx-001'`。
3. 断开原连接，在另一连接查询 `pg_prepared_xacts`，观察普通读取、竞争写入和锁等待。
4. 模拟协调者已有持久 COMMIT 决议，执行 `COMMIT PREPARED 'lab-tx-001'`，故意丢弃客户端回复。
5. 重连后以唯一业务键和余额核验结果；prepared 列表无该项本身不能区分已提交还是已回滚。
6. 用另一个测试标识验证明确 ABORT，再重启实例验证 prepared 恢复；清理前核对每项决议与最终余额。

这只能验证 PostgreSQL prepared transaction 的行为，不能把手动 SQL 演示称为完整 XA 协调器。

### 3.2 TCC 与 Saga 必须补齐的条件

TCC 建议使用 `(global_id,branch_id)` 的防悬挂记录，状态为 `TRYING/TRIED/CONFIRMED/CANCELED` 并施加唯一约束。
Cancel 先到、Try 尚未执行时也应原子保存取消墓碑；迟到 Try 发现墓碑后必须拒绝，这同时覆盖空回滚和防悬挂。
重复 Confirm 或 Cancel 返回既有结果；Confirm 与 Cancel 并发只能由确定决议驱动一次合法迁移。
Try 成功到 Confirm 之间的预留必须从可用余额扣除；墓碑保留期不得短于最大消息延迟与重试生命周期。
Saga 补偿保存 `compensation_id` 和 `original_operation_id`，以反向分录及独立状态跟踪，不能删除原分录。
短信发送、已最终确认的链上转出、外部已收妥付款等可能不可逆；流程必须允许止付、人工处理或新的退回业务。
Outbox 应与这类状态转换同事务保存；事件成功发布并不证明 Saga 全部完成或外部资金已回收。

## 4. 撮合恢复、四个水位与存储故障

### 4.1 把接受、持久、执行、发布分开

| 水位 | 准确定义 | 恢复要求 |
| --- | --- | --- |
| received | 当前实例收到并通过入口校验的连续命令位置 | 可能未持久，不能据此确认资金完成 |
| committed | 达到所选持久化及复制承诺的连续日志位置 | ACK 的承诺必须与它一致 |
| applied | 已确定性应用到撮合状态的连续位置 | 快照覆盖不能超过可恢复 committed |
| published | 已确认输出事件的连续输入前缀 | 发布丢回复可重发，消费以业务键去重 |

本方案选择 `published <= applied <= committed <= received`，不发布尚未持久的推测结果。
每条命令可产生多个成交事件，published 只有在该命令所有输出都确认后才能越过它；没有输出也需显式完成标记。
多个分区分别保存水位及 epoch，不能以各分区最大值的总和宣称全链路完整。
这些是待接入恢复设计；当前 [`MatchingRecoveryLog`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/exchange/MatchingRecoveryLog.java) 没有上述磁盘和复制承诺。

### 4.2 快照与确定性重放

快照清单应含 `snapshot_id`、schema_version、engine_version、last_applied_seq、source_epoch、log_term/hash 和 state_hash。
状态覆盖订单价格、时间优先顺序、剩余量、命令去重索引、成交序号及必要规则版本，不能只保存订单总数。
写临时快照、刷写数据与清单、验证摘要后原子发布；旧快照及尾日志在新副本验证成功前保留。
恢复先验证快照摘要和版本，再回放 `(last_applied_seq, committed]` 连续日志；缺口、冲突摘要或不兼容版本即停止接单。
`trade_id` 必须稳定：可记录在持久成交事实中，或由固定命名空间、命令标识和成交序号确定生成，禁止每次重放随机换 ID。
重放重新生成相同成交内容和业务键；比较状态摘要之外，还逐笔比较成交集合、顺序、资金预占和输出去重结果。
对 committed 之后的未确认命令，客户端使用原 command_id 重试并校验参数；不能用新 ID 掩盖接受状态未知。

### 4.3 Node、Pod、PV、PVC 与两种恢复路径

Node 是承载运行时的节点，Pod 是可被重建的工作负载；Pod 重建不意味着原 Node 上的本地数据仍可访问。
PV 表示存储资源，PVC 是工作负载的存储申请；StatefulSet 的身份和 PVC 绑定不能替代数据库或日志复制。
RWO 表示卷可以由单个节点读写，同节点仍可能有多个 Pod 使用；RWOP 限定单个 Pod，并依赖对应 CSI 与集群支持。
访问模式不是撮合 leader 的数据面 Fence，也不是备份或多副本协议。[Kubernetes 官方存储说明](https://kubernetes.io/docs/concepts/storage/persistent-volumes/)

| 恢复路径 | 所需证据 | 仍需处理的问题 |
| --- | --- | --- |
| 共享持久卷重新挂载 | 存储可用、旧挂载解除、文件完整、合法新 epoch | 故障节点未彻底隔离、卷成为单点、跨区挂载时延 |
| 每节点独立卷与日志复制 | 明确提交规则、足够复制确认、落后副本追赶 | 丢失未提交尾部、选主与复制延迟、旧主再次写入 |

脑裂演练应同时切断旧主控制面和部分数据通路，证明旧主即使继续运行也无法提交资金或发布有效新成交。
新主先取得更高任期、恢复 committed 前缀并核对状态，再开放入口；只改服务发现地址不能隔离旧主。
故障矩阵至少覆盖进程退出、Pod 重建、Node 丢失、卷不可用、复制落后、网络分区和备份恢复，分别测 RPO/RTO。
当前公开服务的单机部署、普通容器重启和内存恢复测试均不能表述为多节点高可用已经落地。

## 5. 支付系统：业务目标、渠道尝试与不确定结果

### 5.1 三层对象及状态

以下是候选内部模型，不假设不同渠道拥有相同 API、状态名或保证。

| 对象 | 职责与关键字段 | 状态示例 |
| --- | --- | --- |
| PaymentIntent | 业务支付目标；merchant_id、merchant_order_id、amount、currency、purpose、fingerprint | CREATED / PROCESSING / SUCCEEDED / CANCELED |
| PaymentOrder | 此目标的一次收款或付款执行编排；intent_id、direction、payee_ref、routing_version、version | READY / PROCESSING / UNKNOWN / SUCCEEDED / FAILED |
| PaymentAttempt | 对特定渠道的一次业务尝试；order_id、provider、provider_request_key、provider_ref、result_evidence | CREATED / SENT / UNKNOWN / SUCCEEDED / FAILED |

一个 Order 可以先后有多个 Attempt，但存在 UNKNOWN 时禁止创建新的资金尝试，尤其禁止改通道重付。
超时、断连、渠道 5xx 或本地进程退出均不能独立证明付款失败；先查询原 Attempt 或等待可信回调、渠道对账。
只有原尝试被确定拒绝、取消或未受理，并满足渠道契约，才允许以新 Attempt 路由重试。
查询仍未知时订单保持 UNKNOWN 并占用资金；通知运营的是需核验状态，而非自动归类为失败后退款。

### 5.2 四层幂等与参数指纹

| 层 | 唯一键建议 | 同键必须一致的内容 |
| --- | --- | --- |
| 商户业务请求 | merchant_id + merchant_order_id + operation | 金额、币种、收款方、业务目的 |
| 内部订单与状态转换 | payment_order_id + operation_type | 原订单版本、目标操作、金额及因果引用 |
| 渠道请求 | provider + provider_request_key | 原 Attempt 的规范化请求参数 |
| 收件与账本效果 | provider + event_id；order_id + ledger_operation | 事件摘要；资产、账户、金额与业务方向 |

指纹对规范化的币种、精确金额、受益方引用和业务参数计算；排序 JSON 字段、明确空值与缺省语义，排除易变签名及时间戳。
同键同参数返回原结果；同键不同参数拒绝冲突，不能复用旧成功，更不能覆盖旧请求。
渠道幂等保留时间可能有限，内部唯一业务记录应覆盖完整资金生命周期；超过窗口应查询及核对，不能盲目重发。
Stripe 的幂等请求会保存首次执行结果并校验重复参数；这是该渠道契约，接入其他渠道需逐项确认。[官方幂等说明](https://docs.stripe.com/api/idempotent_requests)

### 5.3 回调收件、验签与乱序

入口保留原始请求字节，用渠道规定的签名串、算法、密钥版本及时间戳验证；JSON 重新序列化可能改变被签名内容。
检查时间窗口、密钥轮换期、商户与环境归属；拒绝错误签名，敏感正文与支付凭据不得出现在普通日志中。
验签通过后，把 `event_id/raw_digest/received_at/provider_ref/verification_version` 及必要受保护载荷持久化到 Inbox。
只有持久收件事务已成功才返回成功 ACK；异步处理订单和账本，处理失败可重试，不能 ACK 后只保留内存任务。
重复事件返回已收件结果，但同 event_id 不同摘要应隔离；不同事件指向同一笔成功也只能生成一次账本效果。
乱序时以合法状态转换、渠道对象版本及必要的渠道查询判断，不能让晚到的处理中事件覆盖已核验成功。
某些渠道存在后续撤回或拒付，应建独立事件与资金业务，不把已成功记录倒改为从未发生。
Stripe 明确要求验签使用原始正文，并说明重复、重试和无顺序保证；其他渠道的签名时窗须按其文档配置。[官方回调说明](https://docs.stripe.com/webhooks)

### 5.4 多次退款、拒付与渠道能力矩阵

退款以独立 RefundOrder/RefundAttempt 保存 `refund_id`、original_payment_id、amount、currency、reason、provider_ref 和状态。
锁定原付款的可退预算，在同一事务内预留退款额度；`已成功退款 + 未决退款 + 本次退款 <= 当前可退上限`。
当前可退上限结合实际已收妥金额、渠道规则、已扣回拒付和重叠争议确定，不能把拒付损失再退一次。
退款 UNKNOWN 继续占用预算；明确失败才释放预留。多次部分退款与重复请求必须独立幂等，同时受累计上限约束。
拒付保存 dispute_id、争议阶段、证据截止时间、冻结金额、渠道扣回和最终裁定，账本用独立调整记录处理。

| 接入前逐渠道确认 | 需保存的配置或证据 | 不能默认 |
| --- | --- | --- |
| 幂等与查单 | 保留窗口、参数约束、查询键、未知结果规则 | 所有 5xx 都可换通道 |
| 回调 | 原始体验签规则、事件 ID、重试、乱序、密钥轮换 | 一次成功 ACK 表示业务已入账 |
| 撤销与退款 | 截止时间、部分/多次退款、手续费退还、在途状态 | 收款成功就一定能实时撤回 |
| 结算与争议 | 清算币种、结算周期、扣费明细、拒付流程、文件水位 | 渠道余额等于可立即提现余额 |

验收同时注入超时后成功、重复回调、成功先到、退款并发和渠道查单不可用；每个场景核对原 Attempt 不被替换、净资金效果唯一。

## 6. 稳定币收款、兑换与法币付款

### 6.1 资产身份与流程对象

资产键至少包含 `network_id + contract_address/native_asset + decimals`；同名符号不能用于跨网络资产归并。
链上入账保存 network、tx_hash、log_index、block_hash、block_height、recipient、amount 与确认策略版本。
事件去重用网络与交易内事件位置，区块归属单独记录并跟踪重组；错误网络、错误合约或错误收款地址不能自动到账。
未达到确认与风险门槛的收款为 OBSERVED/CONFIRMING，不进入可花余额；重组后按保留证据回退观察状态或启动已入账异常流程。

| 业务对象 | 关键数据 | 独立状态 |
| --- | --- | --- |
| Deposit | 资产身份、链上事件键、确认高度、归属账户 | OBSERVED / CONFIRMING / CREDITED / REORG_REVIEW |
| Quote | 入币数量、出币数量、汇率、费率、expires_at、库存预留、版本 | OFFERED / ACCEPTED / EXPIRED / EXECUTED |
| Conversion | quote_id、执行渠道、预期/实际数量、各笔 fill、尾差 | READY / EXECUTING / PARTIAL / COMPLETED / REVIEW |
| Payout | 受益方、法币、金额、来源资金、PaymentOrder | READY / HELD / SENT / UNKNOWN / PAID / FAILED |
| Hedge | exposure_id、方向、目标数量、已成交数量、均价与费用 | NOT_REQUIRED / PLANNED / PARTIAL / FILLED / FAILED |

收币、兑换、付款和对冲都要独立业务键；它们不能被一个“大 SUCCESS”吞掉中间的敞口与未知状态。
具体确认数、链重组策略、渠道账户及受益方要求需针对实际网络与服务方设计，本文不声明任何资质或认证。

### 6.2 托管签名是独立控制边界

转出意图应冻结 network、资产合约、目标地址、数量、nonce/输入、最大手续费及政策版本，再进入签名审批。
HSM 可提供受保护的密钥操作边界，MPC 可分散签名份额，多签可要求多个独立签署者；它们解决的故障模型不同。
任一机制都不会自动判断付款业务是否真实，仍需要限额、地址白名单、审批分离、重放保护和完整审计。
签名服务验证结构化交易与批准意图一致，不接受应用任意上传待签名摘要并默认放行；签后核对网络和接收方。
私钥、份额、恢复材料和生产地址不进入教学仓库；备份恢复、份额轮换和审批者失联必须在隔离环境演练。
广播超时保留原交易标识与 nonce/输入占用，通过链上查询判定；替换交易需关联原意图，不能再生成无关付款。

### 6.3 锁价、库存、预融资与对冲

接受报价时原子预留可交付库存、价差预算和必要法币头寸；`expires_at` 超时后重新报价，不能默默沿用过期价格。
若承诺先付款、后等待稳定币结算，就是使用预融资；需记录额度提供者、成本、占用时长和可回收来源。
法币付款额度扣除所有未决 Payout，避免多个订单重复消耗同一银行余额；银行休市或渠道限额也进入路由判断。
对冲是降低市场敞口的独立业务；Hedge 成功不等于用户已到账，Payout 成功也不等于对冲已完全成交。
例如收 1,000 单位稳定币、目标对冲 1,000，只成交 600 时保留剩余 400 的敞口、价格基准及超时动作。
计量按资产数量和统一估值时点分别展示：净持仓、已锁未执行兑换、对冲成交及法币应付，避免多次扣减同一风险。
库存不足时拒绝新报价或暂停接受；部分成交按合同选择继续、重新报价或人工终止，不能把部分兑换当足额付款资金。
出现脱锚、流动性消失、报价源过期或敞口超过限额时触发人工止付；保留旧单、已广播转出和渠道 UNKNOWN 的核验队列。
止付只能阻止尚未越过不可逆点的新动作，不能撤销已经最终确认的链上转账或银行已完成付款。

### 6.4 Gas、尾差与验收

Gas 使用链的原生资产独立记账，预估与实际消耗分离；不能把 USDT 本金扣减直接记作 ETH Gas。
兑换手续费、链费、渠道费用、汇兑损益和精度尾差各有业务键与对应资产账户，原始金额及汇率保留。
每次按目标币种最小单位舍入，把差额记到显式尾差账户；禁止循环重试时反复舍入本金。
验收包含错误网络/合约、重组、广播丢回复、报价过期、对冲部分成交、库存不足、法币 UNKNOWN 和脱锚止付。
每个用例同时检查客户负债、平台资产、在途头寸和各资产账本；只验证签名成功或链上交易存在不足以完成验收。

## 7. 对账：完整数据、经济守恒与止付恢复

### 7.1 先证明窗口完整，再计算差异

为每次对账保存 `run_id/source/snapshot_id/cutoff_utc/watermark/schema_version/expected_count/actual_count/hash/status`。
数据库以一致读快照或明确提交边界取数；事件流保存每分区连续水位；渠道文件保存文件编号、日期、页码及完成标志。
链上取数同时记录网络、区块高度和区块哈希，并遵循确认策略；只记“最新高度”无法排除重组或分页缺口。
存在缺页、未关闭窗口、长事务或落后副本时先标为 `INCOMPLETE`，不能把暂未到达的记录全部认作资金差错。
UUID、雪花 ID、数据库序列只提供标识或分配顺序，不保证提交顺序；`id <= max_seen_id` 不能证明不存在晚提交记录。
解决路径是稳定快照、带重叠窗口的幂等扫描或可验证提交日志，并保存上次边界及重扫结果。

### 7.2 三类核对与差异分流

机器数、各节点 count/hash 或 Kafka 消费数量对齐，只能说明相应数据集合的一种一致性，不能单独证明经济守恒。
同一错误可能被复制到所有节点；相等总金额也可能同时遗漏一借一贷，所以要联合逐笔业务键、分录与资产负债关系检查。
第一类核对交易事实与投影：确认三笔成交没有缺失、重复或错值，参与方六行视图不得用于重复记量。
第二类核对资金桶与账本：余额按不可变分录重算，held/pending 按订单与交割状态重算，费用账户包含在资产守恒内。
第三类核对外部资产与内部义务：渠道、银行及链上受控余额，加减明确在途、费用和结算时差后，与内部客户及平台账户解释一致。

| 差异类型 | 核验动作 | 处理边界 |
| --- | --- | --- |
| 数据未齐或时间差 | 等待来源关闭窗口，重抓缺页和落后分区 | 先补完整性，不改资金 |
| 事件重复或缺投影 | 以权威事实和事件键重放投影 | 不重做已成功资金效果 |
| 金额、币种或收款方冲突 | 查不可变请求、成交和渠道原始证据 | 冻结受影响业务，人工复核 |
| 渠道已付、内部 UNKNOWN | 查原 Attempt 并补齐同一效果 | 不建立第二次付款 |
| 内部已成功、外部缺证据 | 核查查询范围、在途和渠道异常 | 暂停后续放款，不能自动冲正 |
| 手续费或汇率尾差 | 按规则版本复算并匹配费用单据 | 只接受有来源的差额，禁用“容差”吞大额问题 |

### 7.3 止付与恢复条件

差异先建立唯一未结工单，记录范围、金额、证据、水位、负责人和截止时间；按影响冻结账户、渠道或资产方向。
冻结必须拦截新资金风险，同时允许受控查询、对账及按已确定决议完成的必要恢复，不能把恢复任务永久封死。
确需纠错时审批独立调整或冲正业务，关联原始事实，不删除历史分录、不重置已成功交易。
恢复前要求数据完整、原因有证据、调整有审核、重算通过、未知余额可解释，并由授权角色决定分批解除止付。
现有 [`ReconciliationService`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/ReconciliationService.java) 与现货冻结逻辑可复用；跨渠道对账和上述完整水位模型尚待集成。

## 8. Java 事务、控制面与运行时故障

### 8.1 事务代理和线程边界

[`SpotDeliveryService`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/SpotDeliveryService.java) 使用 `@Transactional(rollbackFor = Exception.class)`，并在事务内及提交前核验 Fence。
Spring 默认代理模式只拦截经代理的外部调用；同类 `this.method()` 自调用不会为被调用方法新建声明式事务边界。
入口拆到独立受管 Bean，或显式使用事务模板；测试通过真实 Spring 代理调用，并在最后一步注入异常核对整笔回滚。[Spring 官方代理说明](https://docs.spring.io/spring-framework/reference/data-access/transaction/declarative/annotations.html)
普通 JDBC 事务绑定当前线程；`@Async`、线程池和并行流的新线程不会自动继承原事务，不能用它们并行提交四个账户。
跨线程任务应各有明确本地事务，通过持久消息接续；这与 Reactor 事务上下文是不同模型。[Spring 事务注解契约](https://docs.spring.io/spring-framework/docs/6.2.x/javadoc-api/org/springframework/transaction/annotation/Transactional.html)
捕获异常后返回成功、提前发外部通知、在提交前计成功指标，都会制造业务与账本分离；结果指标与通知依据提交后的事实。
只读副本可能落后，不能用于判定“原交易不存在”后重新扣款；幂等核验、额度与终态恢复从权威写库或明确一致读入口获取。

### 8.2 Nacos 控制面与资金写入权

服务注册、配置和发现解决地址及规则分发；资金 leader 还需要明确分片归属、单调 epoch、数据面校验和提交前防旧主写入。
Nacos 中仍可见旧实例、客户端缓存尚未更新或配置推送延迟，都不能成为允许该实例写资金的依据。
不要用一句 AP/CP 概括所有模块：先记录服务端/客户端版本、临时或持久实例、配置模块、协议与故障测试条件。
核验到 Nacos 3.0 官方参数文档分别列出 Distro 与 Raft 配置；本文只据此要求区分协议，未声明项目已引入该版本。[版本化官方资料](https://nacos.io/en/docs/v3.0/manual/admin/system-configurations/)
本仓库资金 Worker 的写入权以 [`ShardLeaseService`](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/ShardLeaseService.java) 的数据库 Lease/Fence 为依据；迁移到新协调组件需重新验证完整故障矩阵。

### 8.3 堆扩容失败与重试预算

先区分 Java heap space、原生内存、线程创建、Metaspace、容器 OOMKill 与启动时无法保留地址空间，不把所有异常归为堆太小。
收集失败时刻的 JVM 版本/有效参数、容器 memory limit/RSS、GC 日志、线程数量和进程退出原因，关联请求与恢复队列增长。
比较 GC 后存活集与 Xmx、瞬时大对象和缓存保留；需要时在受保护位置采集堆转储，避免把凭据或用户数据上传公共仓库。
容器预算还要容纳直接内存、线程栈、Metaspace、代码缓存与本地库；只增加 Xmx 可能挤压这些空间并导致新故障。
依据证据选择限制批量、分页、减少队列驻留或修复引用保留，再评估扩容；OOM 本身不证明存在内存泄漏。[JDK 21 官方排障](https://docs.oracle.com/en/java/javase/21/troubleshoot/troubleshooting-memory-leaks.html)
数据库提交期间进程被杀，应按业务唯一键核验结果；内存压力不能成为新建业务键重试或自动补偿的理由。
重试预算按全链路计算：入口、HTTP 客户端、消息消费者、恢复 Worker 不应各自无限叠加；统一最大并发、退避、抖动和超时预算。
临时失败可以重试原业务，参数冲突与不变量失败直接隔离；超出快速重试预算的资金业务转持久待恢复队列，不能静默丢弃。
性能诊断、热点账户和线程/连接预算复用[性能专项](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/performance/README.md)，本手册不替换已有测量方法。

## 9. 决策、跨时区接班与集成验收

### 9.1 ADR 与 RACI 的最小交付

每项改变资金边界的 ADR 保存背景、不变量、备选方案、选择原因、故障代价、回退限制、负责人、复查日期和证据链接。
示例 ADR：保留单库双资产提交；只有账户容量证据触发拆分评审后，才进入持久分支协议及故障测试，不能为展示复杂度先拆库。
支付路由 ADR 明确 UNKNOWN 的查证责任与新 Attempt 条件；托管 ADR 明确不可逆点和签名审批边界。

| 活动 | 执行 R | 最终负责 A | 协商 C | 知会 I |
| --- | --- | --- | --- | --- |
| 金额与状态协议 | 资金研发 | 资金领域负责人 | 财务、风险、渠道研发 | 值班与运营 |
| 故障演练与恢复 | 研发与平台值班 | 服务负责人 | 数据库、渠道负责人 | 产品与客服 |
| 冻结与解除止付 | 值班操作角色 | 授权风险负责人 | 财务与资金研发 | 受影响业务方 |
| 发布与回退 | 发布执行角色 | 发布负责人 | 值班、数据库、风险 | 产品与运营 |

角色是责任模型，实际人名、审批权限与备份人员在组织内部配置；每项决议只保留一个最终负责角色。

### 9.2 跨时区接班记录

所有事件同时记录 UTC 时间和明确时区；例如 `2026-10-12T08:00:00Z`，避免只写“今天下午”或“昨晚”。
接班卡包含源码/镜像版本、环境、影响范围、冻结金额、最老 UNKNOWN、四水位、未决事务、当前 epoch 与最近证据链接。
列出已经确认的事实、仍待核验的假设、已执行操作、禁止重复的付款/退款及下一步命令的前置条件。
每个待办有负责人、备份、下次检查 UTC 时间和升级条件；接班者确认理解后责任才转移，不能只发送链接即视为交接完成。
管理流程复用[交付质量实践](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/09-delivery-quality-playbook.md)及[SLO 与灾备实践](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/11-slo-disaster-recovery-playbook.md)。
AI 研发采用复用[共用流程](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/ai/developer-adoption/common-workflow.md)、[研发落地方案](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/19-agent-based-development-implementation.md)和[开发助手实践](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/18-ai-developer-assistant-playbook.md)，不另建一套审批体系。

### 9.3 从教学到真实集成的分阶段门槛

1. 规则阶段：隔离固定数据，覆盖三笔成交、费用守恒、取消竞争、UNKNOWN、恢复水位；报告写明替身和未执行项。
2. 数据库阶段：实现候选表、唯一约束、状态 CAS 与持久任务；真实进程重启、提交丢回复及并发竞争通过逐笔核验。
3. 跨资源阶段：独立数据库、渠道沙箱或受控签名测试环境，覆盖网络分区、乱序、过期 Fence、对账完整性和不可逆点。
4. 运行阶段：容量、最老未决年龄、冻结金额、RPO/RTO、告警和接班演练有原始证据，发布与回退兼容现有账本结构。
5. 交付阶段：关联提交 SHA、构建摘要、测试命令/退出状态、输入集、原始结果、失败记录和审核决定；页面演示不替代这些证据。

本次文档与教学实验交付止于其实际实现和本地验证；真实跨库事务、渠道支付、托管签名、复制与多节点接管仍待集成。

## 10. 增量覆盖矩阵

“新增”是补充此项方案与教学范围，“深化”是细化已有边界，“复用”是沿用现有资产；这些标签不表示生产能力已上线。

| 缺口或已有资产 | 本次类型 | 对应内容与复用入口 | 尚待集成或证明 |
| --- | --- | --- | --- |
| 1. 三笔成交、角色、费用、撤单 | 深化 | 第 1 节；[撮合](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/matching-engine.md)、[资金闭环](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/spot-funds-closure.md) | 现货费用落账及完整参数化场景 |
| 2. 跨账户数据库分片 | 新增 | 第 2 节；分支清单、决议、恢复、pending credit | 独立数据库与持久协调恢复 |
| 3. 本地/XA/TCC/Saga/Outbox | 深化 | 第 3 节；[Inbox/Outbox ADR](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/adr/0002-inbox-outbox.md) | XA 协调器、TCC 资源端及真实补偿流程 |
| 4. 日志恢复和基础设施边界 | 深化 | 第 4 节；[恢复模型](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/exchange/MatchingRecoveryLog.java) | 磁盘日志、复制、脑裂隔离及恢复演练 |
| 5. 支付生命周期与渠道能力 | 新增 | 第 5 节；Intent/Order/Attempt、退款、拒付 | 渠道适配器、持久收件与渠道对账 |
| 6. 稳定币、托管与法币付款 | 新增 | 第 6 节；[数字资产可靠性](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/blockchain-digital-asset-reliability.md) | 真实网络、签名策略、报价库存及外部付款 |
| 7. 对账完整性与经济守恒 | 深化 | 第 7 节；[对账源码](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/ReconciliationService.java) | 跨来源完整水位与止付审核闭环 |
| 8. Java、控制面与运行时 | 深化 | 第 8 节；[交割源码](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/SpotDeliveryService.java)、[围栏 ADR](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/adr/0003-shard-fencing.md) | 接入组件版本验证及新故障矩阵 |
| 9. ADR、接班、RACI 与证据 | 深化 | 第 9 节；[架构治理](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/07-technical-strategy-architecture-playbook.md) | 项目实际角色、演练与审核记录 |
| 既有性能优化 | 复用 | [中间件](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/performance/middleware-optimization-playbook.md)、[热点账户](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/performance/hot-account-optimization-playbook.md)、[结算](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/performance/settlement-performance-playbook.md) | 新协议的持续容量与恢复开销测量 |
| 既有 AI 研发流程 | 复用 | [采用工具包](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/ai/developer-adoption/README.md)、[统一实施方案](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/19-agent-based-development-implementation.md) | 本次变更实际测试与审核证据 |
| 既有治理与 Java 不变量 | 复用 | [管理入口](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/README.md)、[金融不变量 ADR](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/adr/0001-financial-invariants.md)、[账户锁顺序](https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/domain/UuidOrder.java) | 后续集成继续保持约束，不降低门禁 |
