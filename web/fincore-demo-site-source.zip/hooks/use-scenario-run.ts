import { useEffect, useRef, useState } from 'react';
import { requestReport, scenarioEndpoint, ScenarioError } from '@/lib/scenario-contract';

/** 同一组件一次只接受一个运行；卸载后迟到响应不能恢复旧结果。 */
export function useScenarioRun<T>(kind: 'market' | 'lifecycle' | 'exchange', parse: (value: unknown) => T) {
  const active = useRef<AbortController | null>(null);
  const [state, setState] = useState<'idle' | 'running' | 'success' | 'error' | 'unknown'>('idle');
  const [report, setReport] = useState<T | null>(null);
  const [message, setMessage] = useState('尚未运行；不会展示预设成功结果。');
  const [receivedAt, setReceivedAt] = useState<string | null>(null);
  useEffect(() => () => { const request = active.current; active.current = null; request?.abort(); }, []);
  async function run() {
    if (active.current) return;
    const controller = new AbortController();
    active.current = controller;
    setReport(null); setReceivedAt(null); setState('running');
    setMessage('后台正在执行隔离实验，等待完整业务报告；动画和 HTTP 200 都不代表验收成功。');
    const timeout = setTimeout(() => controller.abort(), kind === 'market' ? 125_000 : 65_000);
    try {
      const result = await requestReport(scenarioEndpoint(kind, window.location.hostname), parse, controller.signal);
      if (active.current !== controller) return;
      setReport(result); setReceivedAt(new Date().toISOString()); setState('success');
      setMessage('报告完整且全部必要检查通过。以下仅代表本次模拟资金实验，不代表生产容量认证。');
    } catch (error) {
      if (active.current !== controller) return;
      setState(error instanceof ScenarioError ? error.state : 'unknown');
      setMessage(error instanceof ScenarioError ? error.message : '未取得完整结果（超时、断网或响应格式异常）。后台可能仍在执行，请核对后再手动重试。');
    } finally {
      clearTimeout(timeout);
      if (active.current === controller) active.current = null;
    }
  }
  return { state, report, message, receivedAt, run };
}
