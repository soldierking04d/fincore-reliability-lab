import * as React from 'react';

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  // 媒体查询属于外部状态；订阅变化而不是在 Effect 内二次同步 setState。
  const subscribe = React.useCallback((onChange: () => void) => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, []);
  return React.useSyncExternalStore(subscribe,
    () => window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`).matches,
    () => false);
}
