import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { publicContentViolation, verifyPublicRoots } from '../scripts/verify-public-content.mjs';

void test('个人准备文字及文档链接不得进入网页', () => {
  for (const copy of ['面试追问', '90 秒回答结构', 'INTERVIEW POSITIONING', '先讲本质：', '备考手册']) {
    assert.ok(publicContentViolation('app/page.tsx', copy));
  }
  assert.ok(publicContentViolation('public/java-cpp-trading-interview.md', '内容'));
  assert.ok(publicContentViolation('app/page.tsx', 'https://example.org/interview.md'));
});

void test('系统说明、服务应答和团队招聘管理不受误伤', () => {
  assert.equal(publicContentViolation('app/page.tsx', '请求应答点、行情序号、资金守恒、团队招聘、培养与协作'), null);
});

void test('页面干净但构建脚本残留个人材料时仍应失败', async () => {
  const root = await mkdtemp(path.join(tmpdir(), 'fincore-public-content-'));
  try {
    await mkdir(path.join(root, '_next'));
    await writeFile(path.join(root, 'index.html'), '<h1>项目架构</h1>');
    await writeFile(path.join(root, '_next', 'bundle.js'), 'const hidden = "面试追问";');
    await assert.rejects(verifyPublicRoots([root]), /bundle\.js/);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

void test('不存在的目录和空目录不能伪造检查通过', async () => {
  const root = await mkdtemp(path.join(tmpdir(), 'fincore-empty-content-'));
  try {
    await assert.rejects(verifyPublicRoots([root]), /没有读取任何文本/);
    await assert.rejects(verifyPublicRoots([path.join(root, 'missing')]));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});
