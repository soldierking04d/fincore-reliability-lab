import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../components/low-latency-playbook.tsx', import.meta.url), 'utf8');

void test('低延迟展示必须明确证据等级，不能把专项设计包装成已经生产落地', () => {
  for (const label of ['VERIFIED', 'DEMO', 'POC', '不冒充直接生产经验', '需要目标硬件 PoC']) {
    assert.match(source, new RegExp(label));
  }
});

void test('CPU 专项同时覆盖硬件拓扑、尾延迟、失败模式和验证工具', () => {
  for (const concept of ['queue → IRQ → core → owner thread', 'NUMA', 'false sharing', 'page fault', 'P99.9', 'perf stat / record / c2c', 'numastat']) {
    assert.match(source, new RegExp(concept));
  }
});

void test('GPU 选择必须保留不进入默认交易热路径的边界', () => {
  for (const concept of ['GPU 不是更快的通用 CPU', '订单簿 / OMS / 单笔风控', 'Host → Device', 'GPU-hour', 'golden set', '回滚']) {
    assert.match(source, new RegExp(concept));
  }
});

void test('低延迟架构必须同时包含热路径、控制面和恢复面', () => {
  for (const plane of ['HOT PATH · DETERMINISTIC', 'CONTROL PLANE', 'RECOVERY / EVIDENCE PLANE', 'Kill / Fencing', '仓位 / 资金 / 对账']) {
    assert.match(source, new RegExp(plane));
  }
});
