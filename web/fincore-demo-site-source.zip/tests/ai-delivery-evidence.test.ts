import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const load=(file:string)=>readFileSync(new URL('../'+file,import.meta.url),'utf8');
const evidence=JSON.parse(load('public/ai-delivery/evidence.json'));
test('AI 模块包含只读实测证据、阶段耗时与 Token',()=>{
  const component=load('components/ai-delivery-evidence.tsx');
  assert.ok(load('components/developer-ai-delivery.tsx').includes('<AiDeliveryEvidence />'));
  for(const token of ['id="ai-delivery-evidence"','Token','待人工验收','不开放模型调用','stage.durationMs','result.actual','evidence.json'])assert.ok(component.includes(token),token);
  assert.doesNotMatch(component,/fetch\(|\/api\/runs|X-Lab-Token|127\.0\.0\.1|localhost|callCodex/);
  assert.equal(evidence.readOnly,true);assert.equal(evidence.modelCallsAvailable,false);
});
test('公开证据不含本机配置，源码摘要和下载资源一致',()=>{
  const text=load('public/ai-delivery/evidence.json');
  assert.doesNotMatch(text,/\/Users\/|PRIVATE KEY|connectionIp|X-Lab-Token|UserKnownHostsFile/);
  const primary=evidence.runs[0];
  assert.equal(createHash('sha256').update(primary.candidateSource).digest('hex'),primary.candidateSha256);
  assert.equal(load('public/ai-delivery/TicketQuery.candidate.java'),primary.candidateSource);
  assert.equal(load('public/ai-delivery/TicketQuery.before.java'),primary.beforeSource);
  for(const file of ['QueryProbe.java','cases.json'])assert.ok(load('public/ai-delivery/'+file).length>0);
  assert.ok(load('scripts/export-cloud.mjs').includes("'ai-delivery'"));
});
