import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const outline = readFileSync(
  new URL('../components/project-outline.tsx', import.meta.url),
  'utf8',
);
const page = readFileSync(new URL('../app/page.tsx', import.meta.url), 'utf8');
const overview = readFileSync(new URL('../components/portfolio-overview.tsx', import.meta.url), 'utf8');

void test('首页保留详细索引入口，代表案例先于目录，详细索引位于专题之后', () => {
  assert.ok(page.includes('<PortfolioOverview />'));
  assert.ok(overview.includes('href="#outline"'));
  assert.ok(overview.indexOf('<RepresentativeCases />') < overview.indexOf('id="knowledge-map"'));
  assert.ok(page.indexOf('<ProjectOutline />') > page.indexOf('<JavaCppMigration />'));
  assert.ok(page.includes('<ProjectOutline />'));
  assert.ok(outline.includes('id="outline"'));
});

void test('完整大纲必须覆盖端到端业务链路，而不是只介绍撮合', () => {
  for (const concept of [
    '用户与 KYC',
    '行情与盘前风控',
    '账户与有界准入',
    '下单、撮合与撤单',
    '成交与可靠事件',
    '清算、结算与账本',
    '对账、修复与恢复',
    '合约与链上扩展',
  ]) {
    assert.ok(
      outline.includes(concept),
      `missing business-flow concept: ${concept}`,
    );
  }
});

void test('详细索引保留业务、架构、工程、性能、AI 和管理资料入口', () => {
  for (const chapter of [
    '项目定位与结果边界',
    '完整交易与资金链路',
    '全局与单服务架构',
    '在线运行与监控演练',
    '行业问题与交易所九域',
    'Spring Boot 工程实现',
    '高并发、低延迟与 JVM',
    '合约与数字资产可靠性',
    'AI 工程化落地',
    '技术负责人工作系统',
  ]) {
    assert.ok(outline.includes(chapter), `missing outline chapter: ${chapter}`);
  }
});

void test('完整大纲必须给四类读者提供可点击阅读路线', () => {
  for (const audience of [
    '招聘负责人 / 管理者',
    'CTO / 技术评审',
    '业务 / 产品 / 运营',
    '交易 / 数字资产团队',
  ]) {
    assert.ok(
      outline.includes(audience),
      `missing audience route: ${audience}`,
    );
  }

  for (const target of [
    '#profile',
    '#full-lifecycle',
    '#system-architecture',
    '#demo',
    '#industry-cases',
    '#exchange-coverage',
    '#implementation',
    '#performance',
    '#low-latency',
    '#blockchain',
    '#ai',
    '#management',
  ]) {
    assert.ok(
      outline.includes(`'${target}'`),
      `missing outline target: ${target}`,
    );
  }
});

void test('完整大纲必须覆盖业务之外的五个运行平面', () => {
  for (const plane of [
    '业务交易面',
    '资金账务面',
    '数据事件面',
    '平台运行面',
    '治理与交付面',
  ]) {
    assert.ok(outline.includes(plane), `missing operating plane: ${plane}`);
  }
});

void test('完整大纲必须区分证据等级并声明不夸大的边界', () => {
  for (const level of [
    'RUNTIME VERIFIED',
    'DETERMINISTIC LAB',
    'DESIGN / ROADMAP',
    '明确不夸大的边界',
  ]) {
    assert.ok(outline.includes(level), `missing evidence level: ${level}`);
  }

  assert.ok(outline.includes('真实交易所认证'));
  assert.ok(outline.includes('生产容量'));
  assert.ok(outline.includes('SLA'));
});

void test('完整大纲必须提供代码、测试、数据、架构和治理证据索引', () => {
  for (const asset of ['代码', '测试', '运行数据', '架构', '治理']) {
    assert.ok(outline.includes(`['${asset}'`), `missing proof asset: ${asset}`);
  }
});
