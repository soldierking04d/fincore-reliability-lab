import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { assessPhpAsset } from '../public/runtime-security/php-policy.mjs';

const root = new URL('../public/runtime-security/', import.meta.url);
test('页面规则、下载源文件与本地验证记录的摘要一致', () => {
  const evidence = JSON.parse(readFileSync(new URL('evidence.json', root), 'utf8'));
  assert.equal(evidence.passed, true);
  assert.equal(evidence.java.passed, true);
  for (const [file, expected] of Object.entries(evidence.sourceSha256)) {
    assert.equal(createHash('sha256').update(readFileSync(new URL(file, root))).digest('hex'), expected, file);
  }
});

test('五条公开示例可重新计算，核心升级不会掩盖配置与依赖遗漏', () => {
  const assets: Record<string, unknown>[] = JSON.parse(readFileSync(new URL('inventory.example.json', root), 'utf8'));
  assert.deepEqual(assets.map(asset => assessPhpAsset(asset).status), ['action', 'action', 'covered', 'action', 'verify']);
});
