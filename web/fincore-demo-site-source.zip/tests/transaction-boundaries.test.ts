import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { buildOrderCase, buildWorkflowCase } from '../public/trading-boundaries/model.mjs';
import { buildExecutionCase } from '../public/trading-boundaries/execution-model.mjs';
import { buildRecoveryCase } from '../public/trading-boundaries/recovery-model.mjs';
import { createHash } from 'node:crypto';
import { transactionTopics, existingCoverage } from '../lib/transaction-topics.ts';

const source = await readFile(new URL('../components/transaction-boundaries.tsx', import.meta.url), 'utf8');
const read = (file: string) => readFile(new URL(file, import.meta.url), 'utf8');

test('页面实际引用同一可执行模型，不以静态成功文案冒充资金结果', async () => {
  assert.match(source, /buildOrderCase\(\{ scenario \}\)/);
  assert.match(source, /buildWorkflowCase\(\{ scenario \}\)/);
  assert.match(source, /current\.balances\.map/);
  assert.match(source, /current\.checks\.map/);
  assert.doesNotMatch(source, /\bfetch\s*\(|signTransaction|sendTransaction/);
  assert.equal(await read('../public/trading-boundaries/model.mjs'), await read('../../fincore-reliability-lab/experiments/funds-boundaries/model.mjs'));
});

test('默认案例和撤单竞争输出真实计算的独立预期', () => {
  const final = buildOrderCase().current;
  assert.equal(final.balances.find((r: {owner: string; asset: string}) => r.owner === 'U' && r.asset === 'ABC')?.available, '99.9');
  const cancel = buildOrderCase({ scenario: 'cancel-before-settle' }).snapshots.find((r: {event: string}) => r.event === 'canceled');
  assert.equal(cancel?.balances.find((r: {owner: string; asset: string}) => r.owner === 'C' && r.asset === 'ABC')?.frozen, '20');
  const failed = buildWorkflowCase().snapshots.find((r: {state: string}) => r.state === 'SELLER_FAILED');
  assert.equal(failed?.balances.find((r: {owner: string}) => r.owner === 'SELLER')?.available, '0');
});

test('下载证据的所有场景和实际模型一致，包含十四场景及明确能力边界', async () => {
  const report = JSON.parse(await read('../public/trading-boundaries/evidence.json'));
  assert.equal(report.cases.length, 14);
  for (const name of ['model.mjs','execution-model.mjs','recovery-model.mjs']) {
    const published = await read(`../public/trading-boundaries/${name}`);
    assert.equal(published, await read(`../../fincore-reliability-lab/experiments/funds-boundaries/${name}`));
    assert.equal(createHash('sha256').update(published).digest('hex'),report.sourceSha256[name]);
  }
  for (const c of report.cases) {
    const actual = c.kind === 'order' ? buildOrderCase({scenario: c.scenario}) : c.kind === 'workflow' ? buildWorkflowCase({scenario: c.scenario}) : c.kind === 'execution' ? buildExecutionCase({scenario:c.scenario}) : buildRecoveryCase({scenario:c.scenario});
    assert.deepEqual(c, actual);
    assert(actual.snapshots.every((s: {checks: {ok: boolean}[]}) => s.checks.every(x => x.ok)));
  }
  assert.match(report.limitation, /不证明.*持久化.*XA/);
});

test('八个深化专题有实施步骤、失败路径、验收和边界，已有治理复用', () => {
  assert.equal(transactionTopics.length, 8);
  assert.equal(new Set(transactionTopics.map(x => x.id)).size, 8);
  for (const topic of transactionTopics) {
    assert(topic.steps.length >= 4);
    for (const text of [topic.problem, topic.failure, topic.acceptance, topic.boundary, topic.code]) assert(text.length > 30);
  }
  assert(existingCoverage.some(([,href]) => href === '#management'));
  assert(existingCoverage.some(([,href]) => href === '#ai'));
});

test('入口、下载和能力限制全部出现在公开交付中', async () => {
  assert.match(await read('../app/page.tsx'), /<TransactionBoundaries\s*\/>/);
  assert.match(await read('../lib/portfolio-topics.ts'), /#transaction-boundaries/);
  assert.match(await read('../scripts/export-cloud.mjs'), /trading-boundaries/);
  for (const id of ['transaction-boundaries', 'order-case', 'workflow-case', 'boundary-coverage']) assert(source.includes(id));
  assert.match(source, /6 条参与方明细.*trade_execution.*1 行/);
  assert.match(source, /没有新增后台金融接口/);
  assert.match(await read('../public/trading-boundaries/coverage.md'), /新增|深化|复用/);
});
