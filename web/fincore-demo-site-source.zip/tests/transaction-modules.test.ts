import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { boundaryModules, moduleForHash } from '../lib/transaction-modules.ts';
import { transactionTopics } from '../lib/transaction-topics.ts';

test('四模块唯一归类八专题，首页先显示整体而不展开长表格', async () => {
  assert.equal(boundaryModules.length, 4);
  assert.deepEqual(boundaryModules.flatMap(m => [...m.topics]).sort(), transactionTopics.map(t=>t.id).sort());
  const source = await readFile(new URL('../components/transaction-boundaries.tsx',import.meta.url),'utf8');
  assert.match(source, /useState<BoundaryModuleId \| null>\(null\)/);
  assert.match(source, /hidden=\{selected !== module\.id\}/);
  assert.match(source, /明细与校验/);
  assert.match(source, /返回四模块概览/);
});

test('原有分享锚点和每个细节入口可还原正确模块', () => {
  assert.equal(moduleForHash('#order-case'), 'orders');
  assert.equal(moduleForHash('#workflow-case'), 'recovery');
  assert.equal(moduleForHash('#execution-case'), 'execution');
  assert.equal(moduleForHash('#reconciliation-case'), 'assurance');
  for(const m of boundaryModules) {
    assert.equal(moduleForHash(`#boundary-module-${m.id}`),m.id);
    for(const topic of m.topics) assert.equal(moduleForHash(`#boundary-${topic}`),m.id);
  }
  for(const hash of ['#transaction-boundaries','#boundary-coverage','#unrelated','#%zz']) assert.equal(moduleForHash(hash),null);
});

test('新增执行案例只在本地计算，源码和证据有可访问入口', async () => {
  const source = await readFile(new URL('../components/boundary-execution-player.tsx',import.meta.url),'utf8');
  assert.match(source,/buildExecutionCase/);
  assert.match(source,/buildRecoveryCase/);
  assert.doesNotMatch(source,/\bfetch\s*\(|sendTransaction|signTransaction/);
  assert.match(source,/current\.metrics\.map/);
  assert.match(source,/current\.rows\.map/);
  assert.match(source,/current\.checks\.map/);
});
