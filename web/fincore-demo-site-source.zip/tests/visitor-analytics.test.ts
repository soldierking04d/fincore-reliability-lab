import assert from 'node:assert/strict';
import test from 'node:test';
import { visitorPage, visitorReferrer, visitorEventId } from '../lib/visitor-analytics.ts';

test('page tracking only keeps public-shaped anchors and drops secret-like fragments', () => {
  assert.equal(visitorPage('#settlement-optimization'), '/#settlement-optimization');
  for (const hash of ['', '#token=secret', '#/account?key=abc', '#a'.repeat(100)]) assert.equal(visitorPage(hash), '/');
});
test('referrer keeps origin only and rejects credentials or nonweb schemes', () => {
  assert.equal(visitorReferrer('https://example.com/private?token=secret#abc'), 'https://example.com');
  for (const url of ['', 'javascript:alert(1)', 'https://user:pass@example.com']) assert.equal(visitorReferrer(url), '');
});
test('event UUIDs are disposable valid v4 identifiers', () => {
  const a = visitorEventId();
  assert.match(a, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
  assert.notEqual(a, visitorEventId());
});
