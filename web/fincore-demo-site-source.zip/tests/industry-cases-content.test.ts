import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../components/industry-cases.tsx', import.meta.url), 'utf8');

void test('互联网到数字资产案例必须覆盖技术、业务、风险和运营，而不是只说 7×24 小时', () => {
  for (const concept of ['经济后果', '市场驱动', '盘前 / 盘中 / 盘后', '跨时区值班', '互联网经验可以迁移']) {
    assert.match(source, new RegExp(concept));
  }
});

void test('撤单案例必须展示保留容量、同序、资金和前端成功边界', () => {
  for (const concept of ['撤单保留队列', '同一交易对 Lane', '只释放未成交部分', '不能显示“撤单成功”', 'CANCELED']) {
    assert.match(source, new RegExp(concept));
  }
});

void test('两个案例必须提供架构、代码和测试证据链接', () => {
  for (const evidence of ['SYSTEM ARCHITECTURE', 'CODE EVIDENCE', 'TEST DATA', 'internet-to-digital-asset-trading.md', 'cancellation-under-load.md']) {
    assert.match(source, new RegExp(evidence.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});
