import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import {
  developerAiCases,
  repositoryTrace,
} from '../lib/developer-ai-cases.ts';

const evidence = JSON.parse(
  readFileSync(
    new URL('../public/ai-developer/evidence.json', import.meta.url),
    'utf8',
  ),
);

void test('工具无关实施路径与三份任务下载均已接入', () => {
  const component = readFileSync(
    new URL('../components/agent-implementation.tsx', import.meta.url),
    'utf8',
  );
  for (const token of [
    'Claude Code',
    'Codex',
    '统一收件与验收',
    'AGENTS.md',
    'CLAUDE.md',
  ])
    assert.ok(component.includes(token));
  for (const id of ['understand', 'implement', 'repair']) {
    const content = readFileSync(
      new URL(`../public/ai-developer/tasks/${id}.md`, import.meta.url),
      'utf8',
    );
    assert.ok(content.includes('## 验收'));
    assert.ok(content.includes('SHA-256:'));
    assert.ok(
      !content.includes('## 来源：ai/developer-adoption/workshop/after/'),
    );
    assert.ok(
      !content.includes(
        '## 来源：ai/developer-adoption/workshop/solution.patch',
      ),
    );
  }
  const main = readFileSync(
    new URL('../components/developer-ai-delivery.tsx', import.meta.url),
    'utf8',
  );
  assert.ok(main.includes('<AgentImplementation />'));
});

void test('三个编程场景都包含输入、步骤、交付、收益和负面影响', () => {
  assert.deepEqual(
    developerAiCases.map((c) => c.id),
    ['understand', 'implement', 'repair'],
  );
  for (const c of developerAiCases) {
    assert.equal(c.steps.length, 3);
    for (const field of [
      'input',
      'output',
      'benefit',
      'downside',
      'measure',
    ] as const)
      assert.ok(c[field].length > 10);
  }
  assert.equal(repositoryTrace.length, 3);
});

void test('每份网页源码与实际执行报告的 SHA-256 一致', () => {
  const { report, files } = evidence;
  assert.equal(report.sampleOnly, true);
  assert.equal(report.cursorWasInvoked, false);
  assert.equal(report.representsProductionDefect, false);
  assert.equal(report.execution.externalCalls, 0);
  assert.equal(Object.keys(report.sourceHashes).length, 8);
  for (const [name, hash] of Object.entries(report.sourceHashes)) {
    assert.equal(
      createHash('sha256').update(files[name]).digest('hex'),
      hash,
      name,
    );
  }
});

void test('报告逐条由实际值与期望独立核对，不接受只有 aggregate 的通过', () => {
  assert.equal(evidence.report.status, 'demonstration_verified');
  assert.equal(evidence.report.variants.length, 3);
  for (const v of evidence.report.variants) {
    assert.equal(v.results.length, 12);
    assert.equal(new Set(v.results.map((r: { id: string }) => r.id)).size, 12);
    let passed = 0;
    for (const row of v.results) {
      if (row.pass) {
        assert.deepEqual(row.actual, row.expected);
        passed++;
      } else assert.notDeepEqual(row.actual, row.expected);
    }
    assert.equal(v.passed, passed);
    assert.equal(v.failed, 12 - passed);
  }
  const [before, after, surgical] = evidence.report.variants;
  assert.deepEqual([before.passed, after.passed, surgical.passed], [4, 12, 5]);
  assert.deepEqual(
    before.results.map((r: { input: unknown; expected: unknown }) => [
      r.input,
      r.expected,
    ]),
    after.results.map((r: { input: unknown; expected: unknown }) => [
      r.input,
      r.expected,
    ]),
  );
  assert.equal(
    before.results.find((r: { id: string }) => r.id === 'P03').actual.offset,
    '-200',
  );
  assert.equal(
    after.results.find((r: { id: string }) => r.id === 'P03').actual.offset,
    '429496729400',
  );
  assert.equal(evidence.report.contract.overflowReproducedExactly, true);
  for (let i = 0; i < surgical.results.length; i++) {
    if (surgical.results[i].id === 'P03')
      assert.equal(surgical.results[i].pass, true);
    else assert.deepEqual(surgical.results[i].actual, before.results[i].actual);
  }
});

void test('下载入口在本地可交付，不依赖尚未推送的 GitHub 文件', () => {
  for (const file of ['evidence.json', 'company-playbook.md', 'kit.zip'])
    assert.ok(
      existsSync(new URL(`../public/ai-developer/${file}`, import.meta.url)),
      file,
    );
  const component = readFileSync(
    new URL('../components/developer-code-evidence.tsx', import.meta.url),
    'utf8',
  );
  assert.ok(component.includes('不会触发重新运行'));
  const page = readFileSync(
    new URL('../app/page.tsx', import.meta.url),
    'utf8',
  );
  assert.ok(page.includes('id="ai"'));
});
