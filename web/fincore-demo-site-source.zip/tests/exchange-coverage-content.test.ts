import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const component = readFileSync(new URL('../components/exchange-coverage-lab.tsx', import.meta.url), 'utf8');
const page = readFileSync(new URL('../app/page.tsx', import.meta.url), 'utf8');
const topics = readFileSync(new URL('../lib/portfolio-topics.ts', import.meta.url), 'utf8');

void test('交易所九域必须全部出现在演示层，不能只保留撮合和账本', () => {
  for (const key of ['marketData', 'orderSemantics', 'fixOms', 'surveillance', 'apiSecurity',
    'fees', 'matchingRecovery', 'derivatives', 'digitalAssets']) assert.match(component, new RegExp(key));
});

void test('九域展示必须同时包含全局拓扑、实跑入口、数据和边界', () => {
  for (const text of ['GLOBAL TOPOLOGY', '运行 9 个能力域', 'live.metrics', 'BOUNDARY',
    '不冒充生产认证']) assert.ok(component.includes(text), `缺少展示证据：${text}`);
});

void test('首页导航和正文必须挂载交易所九域组件', () => {
  assert.ok(page.includes('<PortfolioOverview />'));
  assert.ok(topics.includes('#exchange-coverage'));
  assert.ok(page.includes('<ExchangeCoverageLab />'));
});
