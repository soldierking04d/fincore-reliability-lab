import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const read = (path: string) => readFileSync(new URL('../'+path, import.meta.url), 'utf8');
const component = read('components/performance-engineering.tsx');
const settlement = read('components/settlement-optimization.tsx');
const page = read('app/page.tsx');
const chapter = read('components/knowledge-chapter.tsx');
const exporter = read('scripts/export-cloud.mjs');

void test('三个专项挂载到网页，并随腾讯云发行包交付完整手册和工具', () => {
  assert.ok(page.includes('<PerformanceEngineering />'));
  assert.ok(page.includes('<SettlementOptimization />'));
  assert.ok(settlement.includes('id="settlement-optimization"'));
  assert.ok(!component.includes("id: 'settlement-optimization'"), '结算不再隐藏于综合专项tab');
  for (const id of ['middleware-optimization', 'hot-account-optimization']) {
    assert.ok(component.includes(id));
    const filename = id+'-playbook.md';
    assert.ok(read('public/performance/'+filename).startsWith('# '));
    assert.ok(exporter.includes(filename));
  }
  for (const file of ['settlement-performance-playbook.md','VERIFICATION.md','tool-guide.md','settlement-comparison.mjs',
    'settlement-comparison.test.mjs','compose.isolated.yml','01-audit-role.sql','settlement-completion.md',
    'settlement-database-audit.mjs','settlement-database-audit.test.mjs','settlement-source.zip','settlement-evidence.json']) {
    assert.ok(existsSync(new URL('../public/performance/'+file, import.meta.url)));
    assert.ok(exporter.includes(file));
  }
});

void test('新内容不宣称真实性能收益，也不提供资金写入与签名接口', () => {
  for (const text of ['尚无这些方案的持续容量数据','仍是候选','HTTP 202','COMMIT','SPOT_DVP_REQUESTED','没有持续容量实测','afterCommit']) {
    assert.ok((component+settlement).includes(text), text);
  }
  assert.ok(!component.includes('dangerouslySetInnerHTML'));
  assert.ok(!settlement.includes('dangerouslySetInnerHTML'));
  assert.ok(!/method:\s*['"]POST|signTransaction|sendTransaction/.test(component));
});

void test('结算具有独立目录、导航、事务图和四层验收证据', () => {
  assert.ok(read('lib/portfolio-topics.ts').includes("title: '结算性能优化'"));
  assert.ok(page.includes('<a href="#settlement-optimization">结算性能</a>'));
  for (const id of ['settlement-architecture','settlement-implementation','settlement-metrics','settlement-evidence','settlement-handbook']) {
    assert.ok(settlement.includes(`id="${id}"`));
    assert.ok(settlement.includes(`href="#${id}"`));
  }
  for (const text of ['<svg','逐笔借贷','账户净额','Outbox','未可见','TTL','不等于腾讯云交易后端已经切换']) {
    assert.ok(settlement.includes(text), text);
  }
  assert.ok(!/method:\s*['"]POST|signTransaction|sendTransaction/.test(settlement));
});

void test('章节保留原锚点并响应直接深链和重复点击，专项地址可分享', () => {
  assert.ok(chapter.includes('keepMounted'));
  assert.ok(chapter.includes("addEventListener('hashchange'"));
  assert.ok(chapter.includes("addEventListener('click'"));
  assert.ok(component.includes('window.history.replaceState'));
  for (const id of ['profile','demo','management','ai','performance','implementation','project']) {
    assert.ok(page.includes('id="'+id+'"'));
  }
});

void test('结算证据数字由套件求和，完整CI与本地回归、运行版本明确分开', () => {
  const evidence = JSON.parse(read('public/performance/settlement-evidence.json'));
  const suites = evidence.targeted.suites as {name:string; tests:number; failures:number; errors:number; skipped:number}[];
  assert.equal(suites.reduce((sum, suite) => sum + suite.tests, 0), evidence.targeted.total);
  assert.ok(suites.every(suite => suite.failures === 0 && suite.errors === 0 && suite.skipped === 0));
  assert.equal(suites.filter(suite => suite.name.endsWith('PostgresTest')).reduce((sum, suite) => sum + suite.tests, 0), evidence.targeted.realPostgresTests);
  assert.equal(evidence.quality.pmdViolations, 0);
  assert.equal(evidence.quality.spotBugs, 0);
  assert.equal(evidence.quality.rulesWeakened, false);
  assert.equal(evidence.runtimeBackendChanged, false);
  assert.match(evidence.sourceCommit, /^[0-9a-f]{40}$/);
  assert.equal(evidence.ci.conclusion, 'success');
  assert.equal(evidence.ci.tests.skipped + evidence.ci.tests.failed + evidence.ci.tests.errors, 0);
  assert.equal(evidence.ci.sourceCommit, evidence.sourceCommit);
});
