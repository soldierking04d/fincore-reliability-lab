import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { portfolioTopics } from '../lib/portfolio-topics.ts';

const read = (path:string) => readFileSync(new URL('../'+path,import.meta.url),'utf8');
const page = read('app/page.tsx');
const overview = read('components/portfolio-overview.tsx');
const cases = read('components/representative-cases.tsx');

test('首页与索引共享主题定义，不独立维护主题数量', () => {
  assert.equal(portfolioTopics.length,10);
  assert.equal(new Set(portfolioTopics.map(t=>t.href)).size,portfolioTopics.length);
  for(const component of [overview,read('components/project-outline.tsx')]) {
    assert.match(component,/import \{ portfolioTopics \}/);
    assert.match(component,/portfolioTopics\.map/);
    assert.doesNotMatch(component,/八个主题|下面 10|\['10', '主题模块'\]/);
  }
  assert(portfolioTopics.some(t=>t.href==='#management'));
  assert(portfolioTopics.some(t=>t.href==='#transaction-boundaries'));
  assert(portfolioTopics.some(t=>t.href==='#runtime-security'));
});

test('首屏案例包含技术、管理和AI，模拟范围与证据类型不会丢失', () => {
  assert(overview.indexOf('<RepresentativeCases />') < overview.indexOf('id="knowledge-map"'));
  assert.match(overview,/实验使用模拟资金/);
  for(const label of ['代码与测试','故障实验','管理方案示例','历史受控评测','不作为个人任职业绩','不是公司采用 AI 后的效率提升数据']) assert(cases.includes(label),label);
  for(const id of ['management-decisions','management-case','ai-evaluations']) assert(page.includes(`id="${id}"`),id);
  assert.match(read('components/knowledge-chapter.tsx'),/target instanceof HTMLDetailsElement/);
});

test('管理案例不把活动假设和演练时间当作实绩', () => {
  assert.match(page,/非任职业绩/);
  assert.match(page,/人员、活动规模和时间线为方案假设/);
  assert.match(page,/记录实际恢复时间/);
  assert.doesNotMatch(page,/value="16 min"|proof="16 分钟恢复"|原有团队与跨部门基础继续保留|补齐技术负责人完整职责/);
  assert.doesNotMatch(read('components/developer-ai-delivery.tsx'),/本轮没有调用/);
  assert.doesNotMatch(read('components/ai-company-delivery.tsx'),/不要多一份“检查 AI”的工作/);
});

test('性能历史摘要引用后续验收而非遗留失败状态，保留部署边界', () => {
  const verification=read('public/performance/VERIFICATION.md');
  assert.match(verification,/09a38d5/);
  assert.match(verification,/204 项通过/);
  assert.match(verification,/不代表当前公网后端版本/);
  assert.doesNotMatch(verification,/最新结果和未通过的完整发布门禁/);
});
