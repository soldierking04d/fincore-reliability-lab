import test from 'node:test';
import assert from 'node:assert/strict';
import { EXCHANGE_DOMAINS, MARKET_CHECKS, LIFECYCLE_CHECKS, parseExchangeCoverageReport, parseMarketReport, parseLifecycleReport, requestReport, scenarioEndpoint } from '../lib/scenario-contract.ts';
import { parseMetric, metricEndpoint } from '../lib/live-metrics.ts';

const market = () => ({ runId: 'test-run', finalStatus: 'RECOVERED',
  startedAt: '2026-09-03T00:00:00Z', completedAt: '2026-09-03T00:00:01Z',
  metrics: { makerOrders: 60, concurrentMarketSellers: 12, tradeCount: 60, uniqueTradeSequences: 60,
    tradeOutboxEvents: 60, settlementCommands: 3, duplicateSettlementDeliveries: 17, ledgerTransactions: 6,
    repairedProjections: 2, quarantinedProjections: 1, matchingElapsedMs: 100,
    observedTradesPerSecond: 600, endToEndElapsedMs: 1000 },
  recovery: { finalStatus: 'CLEAN' }, checks: Object.fromEntries(MARKET_CHECKS.map(key => [key, 'PASS：测试证据'])) });
const lifecycle = () => ({ runId: 'lifecycle-test', finalStatus: 'PASS',
  startedAt: '2026-09-03T00:00:00Z', completedAt: '2026-09-03T00:00:02Z',
  funds: { tradeId: 'c1f378ca-5c80-419c-a912-2c39e8f035ea', deliveryStatus: 'SETTLED', baseAsset: 'BTC', quoteAsset: 'USDT',
    reservedForCancel: 45, availableWhileReserved: 755, availableAfterCancel: 800,
    buyerQuoteBalance: 800, buyerBaseBalance: 2, sellerBaseBalance: 8, sellerQuoteBalance: 200,
    pendingDebit: 0, reconciledAccounts: 4, settledAt: '2026-09-03T00:00:01Z' },
  checks: Object.fromEntries(LIFECYCLE_CHECKS.map(key => [key, 'PASS：测试证据'])),
  data: { userId: 'test-user', userStatus: 'ACTIVE', kycStatus: 'VERIFIED', accountAsset: 'USDT',
    accountBalance: 800, symbol: 'BTC-USDT', referencePrice: 100, quantity: 2, orderNotional: 200,
    preTradeDecision: 'APPROVED', orderStatus: 'FILLED', tradeCount: 1, rejectedReasonCode: 'KYC_NOT_VERIFIED' } });
const exchange = () => ({ runId: 'exchange-test', generatedAt: '2026-09-04T00:00:00Z',
  status: 'PASS', domainCount: 9, evidenceBoundary: '确定性实验，不代表生产认证',
  domains: Object.fromEntries(EXCHANGE_DOMAINS.map((key, index) => [key, {
    title: `能力域 ${index + 1}`, status: 'PASS', flow: '输入→规则→结果',
    metrics: { checks: index + 1, balanced: true }, checks: ['业务断言通过'], boundary: '待真实集成',
  }])) });

void test('完整报告才能作为成功证据', () => {
  assert.equal(parseMarketReport(market()).finalStatus, 'RECOVERED');
  assert.equal(parseLifecycleReport(lifecycle()).finalStatus, 'PASS');
  assert.equal(parseExchangeCoverageReport(exchange()).domainCount, 9);
});
void test('九域报告缺一项、失败、空指标或空断言都不能显示成功', () => {
  for (const key of EXCHANGE_DOMAINS) {
    const missing = exchange(); delete missing.domains[key];
    assert.throws(() => parseExchangeCoverageReport(missing));
  }
  const failed = exchange(); failed.domains.fixOms.status = 'FAIL';
  assert.throws(() => parseExchangeCoverageReport(failed));
  const noMetrics = exchange(); Reflect.set(noMetrics.domains.fees, 'metrics', {});
  assert.throws(() => parseExchangeCoverageReport(noMetrics));
  const noChecks = exchange(); noChecks.domains.marketData.checks = [];
  assert.throws(() => parseExchangeCoverageReport(noChecks));
});
void test('空响应、空字段和缺失指标不能补默认成功', () => {
  for (const value of [{}, null, [], { ...market(), runId: '' }, { ...market(), metrics: {} }, { ...market(), finalStatus: undefined }]) assert.throws(() => parseMarketReport(value));
});
void test('任一个必要检查缺失或失败均拒绝成功', () => {
  for (const key of MARKET_CHECKS) {
    const payload = market(); delete payload.checks[key]; assert.throws(() => parseMarketReport(payload));
    payload.checks[key] = 'FAIL：故障'; assert.throws(() => parseMarketReport(payload));
  }
  for (const key of LIFECYCLE_CHECKS) {
    const payload = lifecycle(); payload.checks[key] = 'FAIL'; assert.throws(() => parseLifecycleReport(payload));
  }
});
void test('检查条目数量不代表检查全部通过', () => {
  const payload = lifecycle(); payload.checks['用户与 KYC'] = 'PASSING';
  assert.equal(Object.keys(payload.checks).length, 12); assert.throws(() => parseLifecycleReport(payload));
});
void test('旧版只有撮合成功或缺少资金证据，不能显示交割闭环完成', () => {
  assert.throws(() => parseLifecycleReport({ ...lifecycle(), funds: undefined }));
  for (const key of ['委托预占', '撤单释放', '双资产交割', '资金对账']) {
    const p = lifecycle(); delete p.checks[key]; assert.throws(() => parseLifecycleReport(p));
  }
});
void test('资金未交割、仍在途、单边到账或撤单重复释放必须拒绝成功', () => {
  for (const mutation of [
    (p: ReturnType<typeof lifecycle>) => { p.funds.deliveryStatus = 'PENDING'; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.pendingDebit = 200; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.buyerBaseBalance = 0; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.sellerQuoteBalance = 201; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.availableAfterCancel = 845; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.reconciledAccounts = 3; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.settledAt = 'invalid'; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.settledAt = '2026-09-03T00:00:03Z'; },
    (p: ReturnType<typeof lifecycle>) => { p.funds.quoteAsset = 'USD'; },
  ]) { const p = lifecycle(); mutation(p); assert.throws(() => parseLifecycleReport(p)); }
});
void test('时间、数值、成交唯一性、最终对账都必须一致', () => {
  for (const mutation of [
    (p: ReturnType<typeof market>) => { p.completedAt = 'not-a-date'; },
    (p: ReturnType<typeof market>) => { p.metrics.tradeCount = NaN; },
    (p: ReturnType<typeof market>) => { p.metrics.tradeCount = 61; },
    (p: ReturnType<typeof market>) => { p.recovery.finalStatus = 'DIRTY'; },
    (p: ReturnType<typeof market>) => { p.finalStatus = 'RUNNING'; },
  ]) { const p = market(); mutation(p); assert.throws(() => parseMarketReport(p)); }
});
void test('收到 HTTP 200 仍必须校验业务报告', async () => {
  await assert.rejects(requestReport('/test', parseMarketReport, new AbortController().signal,
    async () => Response.json({})), /不完整|缺少/);
});
for (const status of [429, 500, 503]) void test(`HTTP ${status} 不重试、不显示成功`, async () => {
  let calls = 0;
  await assert.rejects(requestReport('/test', parseMarketReport, new AbortController().signal,
    async () => { calls++; return new Response('failure', { status }); }));
  assert.equal(calls, 1);
});
void test('中止或超时不自动重试写请求', async () => {
  const controller = new AbortController(); controller.abort(); let calls = 0;
  await assert.rejects(requestReport('/test', parseMarketReport, controller.signal,
    async (_url, options) => { calls++; options?.signal?.throwIfAborted(); return Response.json(market()); }));
  assert.equal(calls, 1);
});
void test('没有返回的请求不能提前产生成功报告', async () => {
  let resolve!: (response: Response) => void;
  let completed = false;
  const pending = requestReport('/test', parseMarketReport, new AbortController().signal,
    () => new Promise<Response>(done => { resolve = done; })).then(() => { completed = true; });
  await new Promise(done => setTimeout(done, 25)); assert.equal(completed, false);
  resolve(Response.json(market())); await pending; assert.equal(completed, true);
});
void test('同一源码在公网 IP 和 Sites 使用正确入口', () => {
  assert.equal(scenarioEndpoint('lifecycle', '124.223.164.254'), '/lab/scenarios/trading-lifecycle');
  assert.equal(scenarioEndpoint('market', '124.223.164.254'), '/lab/scenarios/market-crash-day');
  assert.equal(scenarioEndpoint('exchange', '124.223.164.254'), '/lab/scenarios/exchange-coverage');
  assert.equal(scenarioEndpoint('lifecycle', 'fincore-reliability-demo.soldierking04d.chatgpt.site'),
    'https://124.223.164.254/lab/scenarios/trading-lifecycle');
  assert.equal(scenarioEndpoint('exchange', 'fincore-reliability-demo.soldierking04d.chatgpt.site'),
    'https://124.223.164.254/lab/scenarios/exchange-coverage');
  assert.match(metricEndpoint('cpu', '124.223.164.254'), /^\/prometheus\//);
  assert.match(metricEndpoint('cpu', 'fincore-reliability-demo.soldierking04d.chatgpt.site'),
    /^https:\/\/124\.223\.164\.254\/prometheus\//);
});
void test('监控空值、NaN 和过期样本不能显示为零', () => {
  const now = Date.now();
  const sample = (value: string, seconds = now / 1000) => ({ status: 'success', data: { result: [{ value: [seconds, value] }] } });
  assert.equal(parseMetric(sample('0'), now).value, 0);
  for (const value of [null, {}, sample('NaN'), sample(''), sample('1', now / 1000 - 120), { status: 'success', data: { result: [] } }]) assert.throws(() => parseMetric(value, now));
});
