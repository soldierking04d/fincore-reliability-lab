import { ArrowRight } from 'lucide-react';

const cases = [
  { title: '重复结算与旧节点写入', kind: '代码与测试', problem: '消息重试或旧 Worker 恢复后，不能再次扣款。', result: '固定实验中，17 次投递只产生 1 次资金效果；旧 epoch 写入在资金事务内被拒绝。', links: [['结算测试', 'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/test/java/dev/fincore/SettlementIntegrationTest.java'], ['接管设计', 'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/adr/0003-shard-fencing.md']] },
  { title: '发现漏数与错误投影', kind: '故障实验', problem: '成交同步出现遗漏、错值或额外记录时，先确定哪一份数据可信。', result: '以权威成交为准识别差异，只修复派生投影，再次对账核对结果。', links: [['运行与对账', '#demo'], ['实验说明', 'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/advanced-scenarios.md']] },
  { title: '运营放量与交付安排', kind: '管理方案示例', problem: '活动时间确定，但容量、功能和人员准备未必同时到位。', result: '按业务影响安排优先级，确定分档放量、暂停条件和主备责任人。这里展示决策方法，不作为个人任职业绩。', links: [['查看决策场景', '#management-decisions'], ['协作演练', '#management-case']] },
  { title: 'AI 候选代码的验收', kind: '历史受控评测', problem: '代码可以编译，不代表重复消费和事务竞态下的资金结果正确。', result: '54 次受控运行按固定任务与安全规则评测；这不是公司采用 AI 后的效率提升数据。', links: [['评测记录', '#ai-evaluations'], ['研发应用方案', '#ai']] },
] as const;

export function RepresentativeCases() {
  return <section id="profile-cases" className="representative-cases scroll-mt-24">
    <div className="knowledge-map-heading"><div><p className="overview-eyebrow">SELECTED CASES</p><h2>从具体问题看做法与结果</h2></div><a href="#profile">关于作者 <ArrowRight size={16}/></a></div>
    <div className="representative-grid">{cases.map(item => <article className="topic-card" key={item.title}>
      <span className="case-kind">{item.kind}</span><h3>{item.title}</h3><p>{item.problem}</p><p className="case-result">{item.result}</p>
      <div className="topic-shortcuts">{item.links.map(([label,href]) => <a key={href} href={href} {...(href.startsWith('https:') ? {target:'_blank',rel:'noreferrer'} : {})}>{label}</a>)}</div>
    </article>)}</div>
  </section>;
}
