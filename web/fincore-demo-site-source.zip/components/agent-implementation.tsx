import { ArrowDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

/** 展示公司共用层与 Agent 适配层，配置入口不是已连接或已运行的状态。 */
export function AgentImplementation() {
  return (
    <section className="explain-panel !p-5 md:!p-7">
      <p className="font-mono text-xs tracking-widest text-cyan-300">
        IMPLEMENTATION · 工具可替换，验收不变
      </p>
      <h3 className="mt-2 text-2xl font-semibold text-white">
        公司要做的，是把代码、任务和验证接起来
      </h3>
      <p className="mt-3 text-slate-300">
        这里借鉴的是 Cursor
        减少上下文切换、跨文件改代码、运行测试再修正的工作方式。采用现成 Claude
        Code 或
        Codex，即可先建立这些交付流程；不要求复刻它的编辑器界面或逐键补全体验。
      </p>
      <div className="mt-5 rounded-xl border border-cyan-300/20 bg-black/20 p-4 md:p-5">
        <div className="rounded-lg border border-white/10 p-4">
          <h4 className="font-medium text-white">公司共用层</h4>
          <p className="mt-2 text-slate-300">
            任务合同 + 获准源文件 + 编码规则 + 受信测试 + 结果格式
          </p>
        </div>
        <ArrowDown className="mx-auto my-3 size-5 text-cyan-300" />
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-lg border border-cyan-300/25 p-4">
            <h4 className="font-medium text-cyan-100">Claude Code</h4>
            <p className="mt-2 text-sm text-slate-300">
              CLAUDE.md 引用共同规范；读取同一任务包，在批准的开发副本中工作。
            </p>
          </div>
          <div className="rounded-lg border border-cyan-300/25 p-4">
            <h4 className="font-medium text-cyan-100">Codex</h4>
            <p className="mt-2 text-sm text-slate-300">
              AGENTS.md 指向共同流程；读取同一任务包，在批准的开发副本中工作。
            </p>
          </div>
        </div>
        <ArrowDown className="mx-auto my-3 size-5 text-cyan-300" />
        <div className="rounded-lg border border-emerald-300/20 p-4">
          <h4 className="font-medium text-emerald-100">统一收件与验收</h4>
          <p className="mt-2 text-slate-300">
            候选代码 / 补丁 → 独立测试 → 人工 review → 原有 CI 与发布流程
          </p>
        </div>
      </div>
      <p className="mt-3 text-sm text-slate-400">
        这些是上下文与流程适配，不保证两种工具表现完全相同。模型效果、耗时和成本要用同一批任务实际比较。
      </p>
      <Tabs defaultValue="first" className="mt-6">
        <TabsList className="h-auto min-h-11 w-full flex-wrap justify-start gap-1 p-1">
          <TabsTrigger value="first" className="min-h-10 px-3">
            第一步：直接给开发者用
          </TabsTrigger>
          <TabsTrigger value="shared" className="min-h-10 px-3">
            第二步：沉淀共享脚本
          </TabsTrigger>
          <TabsTrigger value="platform" className="min-h-10 px-3">
            何时才做内部平台
          </TabsTrigger>
        </TabsList>
        <TabsContent
          value="first"
          className="rounded-xl border border-white/10 p-4"
        >
          <h4 className="font-medium text-white">
            一个小组，一个仓库，一种小任务
          </h4>
          <ol className="mt-3 space-y-3 text-slate-300">
            <li>
              1.
              平台负责人批准工具、代码可发送范围和开发环境；模块负责人整理入口与参考实现。
            </li>
            <li>
              2. 开发者选下方一个任务包，确认验收条件；在独立开发副本中使用
              Claude Code 或 Codex，不需要改变原编辑器。
            </li>
            <li>
              3. Agent
              读相关文件、提出计划、生成候选代码并处理测试失败；人保留业务决定，不能让它顺带改别的模块。
            </li>
            <li>
              4. 用公司维护的测试验证候选，检查差异后交给同事
              review。记录总用时和返工，不用“生成成功”代替验收。
            </li>
          </ol>
          <p className="mt-3 text-sm text-slate-400">
            CLI
            入口与权限设置不同；这里不提供一个会暗中上传代码或调用付费模型的按钮。先用各工具的交互方式完成同一任务。
          </p>
        </TabsContent>
        <TabsContent
          value="shared"
          className="rounded-xl border border-white/10 p-4"
        >
          <h4 className="font-medium text-white">
            把反复做的准备与验收固化，别复制三套提示词
          </h4>
          <p className="mt-3 text-slate-300">
            本项目已提供
            prepare-task.mjs：按任务选定文件，附源码摘要，输出同一份任务材料。不扫描整个仓库、不调用模型、不读取参考补丁。两种
            Agent 都接收这份材料。
          </p>
          <p className="mt-3 text-slate-300">
            候选验收单独运行：开发者交
            TicketQuery.java，公司侧保留测试和期望。完整需求按 12
            条合同验收；单缺陷修复只允许 P03
            变化。不能运行固定参考答案，再声称新候选通过。
          </p>
          <p className="mt-3 text-sm text-amber-100">
            生成的任务包不是权限沙箱，也不自动证明已脱敏。不可信候选代码必须在公司批准的隔离环境执行。
          </p>
        </TabsContent>
        <TabsContent
          value="platform"
          className="rounded-xl border border-white/10 p-4"
        >
          <h4 className="font-medium text-white">
            多人排队、权限和成本确实难管时，再增加平台
          </h4>
          <p className="mt-3 text-slate-300">
            再接任务队列、隔离 Worker、Agent
            适配器、结果库和人工收件。每个任务固定仓库版本与测试版本，设置并发配额、超时和预算，保存失败原因；重试只重跑隔离任务，不重复创建
            PR 或发布。
          </p>
          <p className="mt-3 text-slate-300">
            如果只调 Claude／OpenAI 模型
            API，公司还要自己实现文件工具、编辑执行循环、会话管理、隔离和失败恢复。第一阶段直接复用现成
            Agent，不必为了三类日常任务就承担这一整套维护。
          </p>
          <p className="mt-3 text-sm text-slate-400">
            本项目尚未搭建这个集中执行平台。是否投入取决于试点后的实际规模与管理成本，不是必经步骤。
          </p>
        </TabsContent>
      </Tabs>
      <div className="mt-5 flex flex-wrap gap-3 text-sm">
        {[
          ['understand', '仓库理解任务'],
          ['implement', '小需求任务'],
          ['repair', '单缺陷任务'],
        ].map(([id, label]) => (
          <a
            key={id}
            href={`/ai-developer/tasks/${id}.md`}
            download
            className="nav-link inline-flex min-h-11 items-center"
          >
            下载{label}
          </a>
        ))}
      </div>
      <p className="mt-4 text-sm text-slate-400">
        官方入口：
        <a
          className="text-cyan-200 underline"
          href="https://learn.chatgpt.com/docs/agent-configuration/agents-md"
          target="_blank"
          rel="noreferrer"
        >
          Codex 项目上下文
        </a>{' '}
        ·{' '}
        <a
          className="text-cyan-200 underline"
          href="https://code.claude.com/docs/en/memory"
          target="_blank"
          rel="noreferrer"
        >
          Claude Code 项目上下文
        </a>
        。仓库已准备适配文件，实际客户端加载与模型运行另行验证。
      </p>
    </section>
  );
}
