import {
  Activity,
  ArrowRight,
  BadgeCheck,
  Braces,
  Cpu,
  Database,
  ExternalLink,
  GitBranch,
  Landmark,
  Network,
  ShieldCheck,
  Users,
  Workflow,
  Zap,
} from 'lucide-react';
import { portfolioTopics } from '@/lib/portfolio-topics';

const businessFlow = [
  ['01', '用户与 KYC', '身份、权限、资格'],
  ['02', '行情与盘前风控', '时效、价格笼子、额度'],
  ['03', '账户与有界准入', '余额、预占、背压'],
  ['04', '下单、撮合与撤单', '顺序、公平、确定性'],
  ['05', '成交与可靠事件', '事实、Outbox、Kafka'],
  ['06', '清算、结算与账本', 'Inbox、交割、借贷平衡'],
  ['07', '对账、修复与恢复', '差异、隔离、最终收敛'],
  ['08', '合约与链上扩展', '保证金、强平、充值提现'],
] as const;

const operatingPlanes = [
  {
    index: '01',
    icon: Workflow,
    title: '业务交易面',
    purpose: '决定订单能不能进入、以什么顺序成交，以及撤单何时真正成功。',
    scope: '用户 / KYC · 行情 · 风控 · 账户 · 准入 · 撮合 · 撤单',
    href: '#full-lifecycle',
    tone: 'border-cyan-300/14 bg-cyan-300/[0.035] text-cyan-300',
  },
  {
    index: '02',
    icon: Landmark,
    title: '资金账务面',
    purpose: '把成交变成唯一资金效果，并让每一笔变化都能审计、对平和追溯。',
    scope: '预占 / 释放 · 清算 · 结算 · 不可变账本 · 资金对账',
    href: '#full-lifecycle',
    tone: 'border-emerald-300/14 bg-emerald-300/[0.035] text-emerald-300',
  },
  {
    index: '03',
    icon: Database,
    title: '数据事件面',
    purpose: '明确谁是权威事实、事件如何可靠传播、重复和乱序如何收敛。',
    scope: 'PostgreSQL · Outbox · Kafka · Inbox · 投影 · 数据口径',
    href: '#system-architecture',
    tone: 'border-violet-300/14 bg-violet-300/[0.035] text-violet-200',
  },
  {
    index: '04',
    icon: Activity,
    title: '平台运行面',
    purpose: '在市场冲击和部分故障下保护容量、尾延迟、恢复时间和服务连续性。',
    scope: '限流 / 背压 · 指标 / 日志 · SLO · 值班 · 灾备 · 容量成本',
    href: '#performance',
    tone: 'border-amber-300/14 bg-amber-300/[0.035] text-amber-200',
  },
  {
    index: '05',
    icon: ShieldCheck,
    title: '治理与交付面',
    purpose: '记录权限审批、发布检查和故障责任人，关联对应流程与验收记录。',
    scope: 'RBAC · 安全合规 · 发布门禁 · AI 边界 · RACI · 产品运营协同',
    href: '#management',
    tone: 'border-rose-300/14 bg-rose-300/[0.035] text-rose-200',
  },
] as const;

const evidenceLevels = [
  {
    label: '真实运行证据',
    code: 'RUNTIME VERIFIED',
    detail: '可从页面触发后端实验，并核对新的业务报告与系统指标。',
    examples: '资金闭环 · 九域实验 · 监控接口',
    tone: 'border-emerald-300/15 bg-emerald-300/[0.04] text-emerald-300',
  },
  {
    label: '确定性实验',
    code: 'DETERMINISTIC LAB',
    detail: '用固定输入、自动测试和故障注入证明不变量与失败边界。',
    examples: '重复投递 · Worker 接管 · 对账修复 · 合约状态机',
    tone: 'border-cyan-300/15 bg-cyan-300/[0.04] text-cyan-300',
  },
  {
    label: '设计与验收路线',
    code: 'DESIGN / ROADMAP',
    detail: '目标架构、决策条件和验收方法；尚未获得本项目运行证据。',
    examples: '真实 KYC / 行情 · HSM/MPC · FPGA/GPU · 持续容量认证',
    tone: 'border-amber-300/15 bg-amber-300/[0.04] text-amber-200',
  },
] as const;

const proofAssets = [
  ['资金边界', '逐笔订单 / 跨账户恢复 / 支付与稳定币', '#transaction-boundaries'],
  ['代码', 'Spring Boot / MyBatis / 事务与状态机', '#implementation'],
  ['测试', 'JUnit / Testcontainers / 内容与数据契约', '#implementation'],
  ['运行数据', '价格、单量、QPS、系统指标与业务结果', '#demo'],
  ['架构', '全局图、服务拓扑、领域图与核心时序图', '#system-architecture'],
  ['低延迟', 'CPU / GPU / NUMA / 网络与测量口径', '#low-latency'],
  ['治理', '管理手册、服务/风险/指标台账与 AI 门禁', '#management'],
] as const;

const outlineGroups = [
  {
    index: 'A',
    label: '先建立全貌',
    title: '业务目标、完整链路与系统边界',
    description:
      '先回答为谁解决什么问题、钱和订单怎样流动、系统由哪些服务协作，再进入代码细节。',
    chapters: [
      {
        index: '01',
        icon: Landmark,
        title: '项目定位与结果边界',
        question: '这是什么项目，解决什么业务风险，哪些能力已经验证？',
        content: '专业方向、项目范围、量化结果、已完成与未完成边界。',
        evidence: '能力概览 · 代表案例',
        href: '#profile',
      },
      {
        index: '02',
        icon: Workflow,
        title: '完整交易与资金链路',
        question: '一笔请求如何从用户资格走到资产到账并被反向证明？',
        content:
          '用户、KYC、行情、风控、账户、准入、撮合、撤单、结算、账本、对账。',
        evidence: '全链路实验 · 资金断言',
        href: '#full-lifecycle',
      },
      {
        index: '03',
        icon: Network,
        title: '全局与单服务架构',
        question: '同步调用、异步事件、数据权威和失败路径如何组织？',
        content: '全局架构图、服务拓扑、领域架构与核心场景时序图。',
        evidence: '架构图 · 拓扑图 · 时序图',
        href: '#system-architecture',
      },
      {
        index: '04',
        icon: Activity,
        title: '在线运行与监控演练',
        question: '市场冲击、流量、系统指标和业务结果能否在同一时间轴联动？',
        content:
          '真实运行与教学回放分开，展示价格、单量、QPS、CPU、JVM、Lag 和恢复动作。',
        evidence: '在线数据 · 故障时间轴',
        href: '#demo',
      },
    ],
  },
  {
    index: 'B',
    label: '再核对深度',
    title: '行业场景、工程实现与性能证据',
    description:
      '从真实交易问题反推架构约束，再沿代码、测试和运行指标核对它是否真的落地。',
    chapters: [
      {
        index: '专项',
        icon: Database,
        title: '结算性能优化',
        question: '怎样提高真正到账且可核账的完成量，而不是只提高受理数？',
        content: '资金事务、幂等载荷与消息关联、跨 TTL 围栏、提交后计数、锁定快照复用与逐笔审计。',
        evidence: '代码 · 数据库回归 · 审计工具',
        href: '#settlement-optimization',
        secondaryHref: '#settlement-evidence',
        secondaryLabel: '测试与验收记录',
      },
      {
        index: '05',
        icon: ShieldCheck,
        title: '行业问题与交易所九域',
        question:
          '互联网能力怎样迁移到 7×24 交易？撤单洪峰和交易所核心域怎样处理？',
        content:
          '市场驱动流量、撤单优先、公平性、行情、订单、FIX/OMS、监察、API 与费率。',
        evidence: '系统案例 · 九域实验',
        href: '#industry-cases',
        secondaryHref: '#exchange-coverage',
        secondaryLabel: '交易所九域',
      },
      {
        index: '06',
        icon: Braces,
        title: 'Spring Boot 工程实现',
        question: '可靠性原则具体落在哪些类、事务、表、配置和自动化测试中？',
        content:
          'Spring Boot、MyBatis、PostgreSQL、Kafka，以及幂等、Outbox、Fencing、对账实现。',
        evidence: '代码导览 · 测试 · CI',
        href: '#implementation',
      },
      {
        index: '07',
        icon: Cpu,
        title: '高并发、低延迟与 JVM / Java-C++ 改造',
        question:
          '系统怎样抗住洪峰，并用可测量的方法判断 CPU、GPU、网络和 GC？',
        content:
          'Java/C++ 撮合对照、迁移与回退、实测证据，以及有界队列、CPU、JVM 与 GPU 边界。',
        evidence: '运行参数 · 性能门禁',
        href: '#performance',
        secondaryHref: '#java-cpp-migration',
        secondaryLabel: 'Java → C++ 改造专项',
      },
      {
        index: '08',
        icon: Database,
        title: '合约与数字资产可靠性',
        question: '从现货走向合约和链上资产，需要补哪些状态机与资金风险控制？',
        content:
          '保证金、标记价、强平、保险基金、ADL，以及充值确认、Reorg、Nonce、UTXO 和签名边界。',
        evidence: '能力映射 · 限制与验收路线',
        href: '#blockchain',
        secondaryHref: '#exchange-coverage',
        secondaryLabel: '合约风险实验',
      },
    ],
  },
  {
    index: 'C',
    label: '最后看负责人能力',
    title: 'AI 落地、团队治理与业务交付',
    description:
      '不仅判断技术方案，也说明如何组织团队、跨部门交付、治理风险，并把 AI 放进可审计的生产流程。',
    chapters: [
      {
        index: '09',
        icon: Zap,
        title: 'AI 工程化落地',
        question: '怎样基于 Claude Code 或 Codex 建立公司的 AI 辅助研发流程？',
        content:
          '仓库理解、小需求与缺陷修复；统一任务包、工具适配、独立候选验证、人工评审及分阶段实施。',
        evidence: '仓库规则 · 代码差异 · 测试证据',
        href: '#ai',
      },
      {
        index: '10',
        icon: Users,
        title: '技术负责人工作系统',
        question: '如何把架构判断变成团队能力、跨部门共识和持续业务结果？',
        content:
          '技术战略、组织梯队、交付治理、SLO/容灾、安全、FinOps、供应商与产品运营协同。',
        evidence: '管理概要 · 实战手册 · 台账',
        href: '#management',
      },
    ],
  },
] as const;

const readingRoutes = [
  {
    audience: '招聘负责人 / 管理者',
    time: '约 5 分钟',
    route: '01 项目定位 → 04 在线结果 → 10 负责人能力',
    href: '#profile-cases',
  },
  {
    audience: 'CTO / 技术评审',
    time: '约 15 分钟',
    route: '02 完整链路 → 03 架构 → 06 代码 → 07 性能',
    href: '#system-architecture',
  },
  {
    audience: '业务 / 产品 / 运营',
    time: '约 10 分钟',
    route: '01 业务目标 → 02 资金链路 → 05 行业场景 → 10 交付',
    href: '#full-lifecycle',
  },
  {
    audience: '交易 / 数字资产团队',
    time: '约 15 分钟',
    route: '05 交易九域 → 08 合约链上 → 07 低延迟 → 06 工程证据',
    href: '#exchange-coverage',
  },
] as const;

export function ProjectOutline() {
  return (
    <section
      id="outline"
      className="mt-5 scroll-mt-24 overflow-hidden rounded-2xl border border-cyan-300/12 bg-[linear-gradient(145deg,rgba(11,29,40,.98),rgba(6,15,23,.98)_52%,rgba(13,25,42,.96))]"
    >
      <div className="grid gap-6 border-b border-white/8 p-5 sm:p-7 xl:grid-cols-[1.25fr_.75fr] xl:p-8">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-xl border border-cyan-300/20 bg-cyan-300/10 font-mono text-sm font-semibold text-cyan-300">
              00
            </span>
            <div>
              <p className="font-mono text-sm tracking-[0.18em] text-cyan-300/75">
                REFERENCE INDEX · 详细索引
              </p>
              <p className="mt-1 text-sm text-slate-400">
                实现、运行记录与参考方案
              </p>
            </div>
          </div>
          <h2 className="mt-5 max-w-5xl text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">
            按专题查找实现与说明
          </h2>
          <p className="mt-4 max-w-5xl text-base leading-8 text-slate-400">
            专题入口与首页保持一致。下方保留业务阶段、系统分工、代码和资料索引，便于查找具体问题。
          </p>
          <nav className="mt-5 grid gap-2 sm:grid-cols-2" aria-label="专题索引">
            {portfolioTopics.map(topic => <a key={topic.href} href={topic.href} className="nav-link inline-flex">{topic.title}<ArrowRight className="size-3" /></a>)}
          </nav>
        </div>

        <aside className="rounded-xl border border-white/8 bg-black/15 p-5">
          <p className="font-mono text-sm tracking-[0.14em] text-emerald-300/80">
            查看资料时的范围说明
          </p>
          <div className="mt-4 space-y-3">
            {[
              '代码实验使用模拟资金；外部接口接入单独标注',
              '性能结果限定在报告中的机器、负载和版本',
              '故障案例附测试或运行记录，设计方案另行说明',
              '管理流程为方案示例，不代替个人任职经历',
            ].map((item) => (
              <div
                key={item}
                className="flex items-start gap-3 text-sm leading-6 text-slate-300"
              >
                <BadgeCheck className="mt-1 size-4 shrink-0 text-emerald-300" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </aside>
      </div>

      <div className="border-b border-white/8 p-5 sm:p-7 xl:p-8">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="font-mono text-sm tracking-[0.14em] text-cyan-300/70">
              END-TO-END BUSINESS FLOW
            </p>
            <h3 className="mt-2 text-xl font-semibold text-white">
              业务阶段与对应模块
            </h3>
          </div>
          <a
            href="#full-lifecycle"
            className="inline-flex items-center gap-2 text-sm text-cyan-300 transition hover:text-cyan-200"
          >
            进入可运行资金闭环 <ArrowRight className="size-4" />
          </a>
        </div>

        <div className="mt-5 overflow-x-auto pb-2">
          <div className="grid min-w-[1320px] grid-cols-8 gap-3">
            {businessFlow.map(([index, title, detail], position) => (
              <div
                key={index}
                className="relative rounded-xl border border-cyan-300/12 bg-cyan-300/[0.035] p-4"
              >
                <p className="font-mono text-sm text-cyan-300/70">{index}</p>
                <h4 className="mt-3 text-base font-semibold text-slate-100">
                  {title}
                </h4>
                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {detail}
                </p>
                {position < businessFlow.length - 1 ? (
                  <ArrowRight className="absolute top-1/2 -right-2.5 z-10 size-5 -translate-y-1/2 rounded-full bg-[#08131d] p-1 text-cyan-300/65" />
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border-b border-white/8 p-5 sm:p-7 xl:p-8">
        <div className="max-w-5xl">
          <p className="font-mono text-sm tracking-[0.14em] text-violet-200/75">
            SYSTEM RESPONSIBILITIES · 系统分工
          </p>
          <h3 className="mt-2 text-xl font-semibold text-white">
            系统分工与故障处理
          </h3>
          <p className="mt-3 text-base leading-8 text-slate-400">
            分别查看订单处理、资金记账、事件传播、平台运行和发布管理的职责与依赖。
          </p>
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-2 2xl:grid-cols-5">
          {operatingPlanes.map((plane) => {
            const Icon = plane.icon;
            return (
              <a
                key={plane.index}
                href={plane.href}
                className={`group rounded-xl border p-5 transition hover:-translate-y-0.5 ${plane.tone}`}
              >
                <div className="flex items-center justify-between gap-3">
                  <Icon className="size-5" />
                  <span className="font-mono text-sm opacity-65">
                    PLANE {plane.index}
                  </span>
                </div>
                <h4 className="mt-5 text-lg font-semibold text-white">
                  {plane.title}
                </h4>
                <p className="mt-3 text-sm leading-7 text-slate-300">
                  {plane.purpose}
                </p>
                <p className="mt-3 text-sm leading-7 text-slate-500">
                  {plane.scope}
                </p>
                <span className="mt-4 inline-flex items-center gap-2 text-sm font-medium">
                  查看对应证据 <ArrowRight className="size-4" />
                </span>
              </a>
            );
          })}
        </div>
      </div>

      <div className="space-y-8 p-5 sm:p-7 xl:p-8">
        {outlineGroups.map((group) => (
          <div
            key={group.index}
            className="grid gap-4 xl:grid-cols-[250px_1fr]"
          >
            <div className="xl:pr-4">
              <div className="flex items-center gap-3">
                <span className="font-mono text-3xl font-semibold text-cyan-300/20">
                  {group.index}
                </span>
                <p className="font-mono text-sm tracking-[0.12em] text-cyan-300/70">
                  {group.label}
                </p>
              </div>
              <h3 className="mt-3 text-lg font-semibold text-white">
                {group.title}
              </h3>
              <p className="mt-3 text-sm leading-7 text-slate-500">
                {group.description}
              </p>
            </div>

            <div
              className={`grid gap-3 ${group.chapters.length === 2 ? 'md:grid-cols-2' : 'md:grid-cols-2 2xl:grid-cols-4'}`}
            >
              {group.chapters.map((chapter) => {
                const Icon = chapter.icon;
                return (
                  <article
                    key={chapter.index}
                    className="group flex min-h-full flex-col rounded-xl border border-white/8 bg-black/15 p-5 transition hover:-translate-y-0.5 hover:border-cyan-300/20 hover:bg-cyan-300/[0.035]"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <span className="grid size-10 place-items-center rounded-xl bg-cyan-300/10 text-cyan-300">
                        <Icon className="size-5" />
                      </span>
                      <span className="font-mono text-sm text-slate-600">
                        TOPIC {chapter.index}
                      </span>
                    </div>
                    <h4 className="mt-5 text-lg font-semibold text-white">
                      {chapter.title}
                    </h4>
                    <p className="mt-3 text-base leading-7 text-slate-300">
                      {chapter.question}
                    </p>
                    <p className="mt-3 flex-1 text-sm leading-7 text-slate-500">
                      {chapter.content}
                    </p>
                    <div className="mt-5 border-t border-white/8 pt-4">
                      <p className="text-sm text-emerald-300/75">
                        证据：{chapter.evidence}
                      </p>
                      <div className="mt-3 flex flex-wrap gap-3">
                        <a
                          href={chapter.href}
                          className="inline-flex items-center gap-1.5 text-sm font-medium text-cyan-300 transition hover:text-cyan-200"
                        >
                          进入本章 <ArrowRight className="size-4" />
                        </a>
                        {'secondaryHref' in chapter ? (
                          <a
                            href={chapter.secondaryHref}
                            className="inline-flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-slate-200"
                          >
                            {chapter.secondaryLabel}{' '}
                            <ExternalLink className="size-3.5" />
                          </a>
                        ) : null}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="grid gap-6 border-t border-white/8 p-5 sm:p-7 xl:grid-cols-[1.1fr_.9fr] xl:p-8">
        <section>
          <p className="font-mono text-sm tracking-[0.14em] text-emerald-300/75">
            EVIDENCE LEVELS · 证据口径
          </p>
          <h3 className="mt-2 text-xl font-semibold text-white">
            所有能力先标证据等级，再谈结论
          </h3>
          <p className="mt-3 max-w-4xl text-base leading-8 text-slate-400">
            这个分级避免把“有设计”“有自动测试”和“生产验证”混成一句话，也让评审者知道每个结论还能继续核对到哪里。
          </p>
          <div className="mt-5 grid gap-3 lg:grid-cols-3">
            {evidenceLevels.map((level) => (
              <article
                key={level.code}
                className={`rounded-xl border p-5 ${level.tone}`}
              >
                <p className="font-mono text-sm tracking-[0.08em]">
                  {level.code}
                </p>
                <h4 className="mt-3 text-lg font-semibold text-white">
                  {level.label}
                </h4>
                <p className="mt-3 text-sm leading-7 text-slate-300">
                  {level.detail}
                </p>
                <p className="mt-3 text-sm leading-7 text-slate-500">
                  {level.examples}
                </p>
              </article>
            ))}
          </div>
        </section>

        <aside className="rounded-xl border border-white/8 bg-black/15 p-5 sm:p-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="font-mono text-sm tracking-[0.14em] text-cyan-300/75">
                PROOF ASSET INDEX
              </p>
              <h3 className="mt-2 text-xl font-semibold text-white">
                各类证据从哪里核对
              </h3>
            </div>
            <GitBranch className="size-6 text-cyan-300/70" />
          </div>
          <div className="mt-5 space-y-2">
            {proofAssets.map(([label, detail, href], index) => (
              <a
                key={label}
                href={href}
                className="grid grid-cols-[36px_72px_1fr_auto] items-center gap-3 rounded-lg border border-white/7 bg-white/[0.025] p-3 transition hover:border-cyan-300/18 hover:bg-cyan-300/[0.035]"
              >
                <span className="font-mono text-sm text-slate-600">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <strong className="text-sm font-semibold text-slate-100">
                  {label}
                </strong>
                <span className="text-sm leading-6 text-slate-500">
                  {detail}
                </span>
                <ArrowRight className="size-4 text-cyan-300/70" />
              </a>
            ))}
          </div>
          <div className="mt-5 rounded-lg border border-amber-300/12 bg-amber-300/[0.035] p-4">
            <p className="text-sm font-semibold text-amber-200">
              明确不夸大的边界
            </p>
            <p className="mt-2 text-sm leading-7 text-slate-400">
              当前作品证明架构方法、金融不变量和可运行实验；真实交易所认证、主网资金、HSM/MPC、低延迟专用硬件和生产容量
              SLA 仍需在目标环境中独立验收。
            </p>
          </div>
        </aside>
      </div>

      <div className="border-t border-white/8 bg-black/10 p-5 sm:p-7 xl:p-8">
        <div className="flex flex-col gap-2 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="font-mono text-sm tracking-[0.14em] text-amber-200/75">
              CHOOSE YOUR ROUTE
            </p>
            <h3 className="mt-2 text-xl font-semibold text-white">
              按你的角色走最短路线
            </h3>
          </div>
          <a
            href="https://github.com/soldierking04d/fincore-reliability-lab"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm text-slate-300 transition hover:text-white"
          >
            <GitBranch className="size-4" /> 直接核对 GitHub 证据{' '}
            <ExternalLink className="size-3.5" />
          </a>
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {readingRoutes.map((item) => (
            <a
              key={item.audience}
              href={item.href}
              className="rounded-xl border border-white/8 bg-white/[0.025] p-4 transition hover:border-amber-200/20 hover:bg-amber-200/[0.035]"
            >
              <div className="flex items-center justify-between gap-3">
                <p className="text-base font-semibold text-white">
                  {item.audience}
                </p>
                <span className="shrink-0 font-mono text-sm text-amber-200/70">
                  {item.time}
                </span>
              </div>
              <p className="mt-3 text-sm leading-7 text-slate-400">
                {item.route}
              </p>
              <span className="mt-4 inline-flex items-center gap-2 text-sm text-amber-200/80">
                从这里开始 <ArrowRight className="size-4" />
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
