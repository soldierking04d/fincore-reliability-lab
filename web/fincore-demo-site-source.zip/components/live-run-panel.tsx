'use client';

import { useEffect, useState } from 'react';
import { Activity, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { parseMarketReport } from '@/lib/scenario-contract';
import { METRICS, metricEndpoint, parseMetric, type MetricKey, type MetricSample } from '@/lib/live-metrics';
import { useScenarioRun } from '@/hooks/use-scenario-run';

/** 真实运行与回放使用独立界面，真实结果中没有预设曲线或预设成功证据。 */
export function LiveRunPanel() {
  const run = useScenarioRun('market', parseMarketReport);
  const [samples, setSamples] = useState<Partial<Record<MetricKey, MetricSample>>>({});
  const [sampledAt, setSampledAt] = useState<string | null>(null);
  useEffect(() => {
    let disposed = false;
    let timer: ReturnType<typeof setTimeout>;
    let active: AbortController | null = null;
    async function poll() {
      active = new AbortController();
      const signal = AbortSignal.any([active.signal, AbortSignal.timeout(10_000)]);
      const entries = await Promise.all((Object.keys(METRICS) as MetricKey[]).map(async key => {
        try {
          const response = await fetch(metricEndpoint(key, window.location.hostname), { signal, cache: 'no-store' });
          if (!response.ok) throw new Error('采集失败');
          return [key, parseMetric(await response.json())] as const;
        } catch { return [key, undefined] as const; }
      }));
      if (disposed) return;
      setSamples(Object.fromEntries(entries)); setSampledAt(new Date().toISOString());
      timer = setTimeout(() => { void poll(); }, 15_000);
    }
    void poll();
    return () => { disposed = true; active?.abort(); clearTimeout(timer); };
  }, []);

  const report = run.report;
  return <section className="space-y-4 rounded-2xl border border-cyan-300/15 bg-[#09151f] p-4 sm:p-6">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div><p className="text-sm text-cyan-300">腾讯云 · 真实采集 / 真实运行</p><h2 className="mt-2 text-xl font-semibold text-white">看实际负载，再验证一次故障恢复</h2>
        <p className="mt-2 max-w-4xl text-sm leading-6 text-slate-400">以下指标来自 FinCore 应用的 Prometheus，每 15 秒更新。它们不是整机指标，也不能单独归因于本次实验。价格波动讲解在“场景回放”中；这里不显示虚构价格曲线。</p></div>
      <a href="https://124.223.164.254/grafana/" target="_blank" rel="noreferrer" className="text-sm text-cyan-300 underline">查看完整监控</a>
      <a href="#full-lifecycle" className="text-sm text-emerald-300 underline">进入资金全链路实验：预占 → 撤单 → 双资产交割</a>
    </div>
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {(Object.keys(METRICS) as MetricKey[]).map(key => <div key={key} className="rounded-xl border border-white/10 bg-black/15 p-4">
        <p className="text-sm text-slate-400">{METRICS[key].label}</p>
        <p className="mt-3 font-mono text-2xl text-white">{samples[key] ? samples[key].value.toFixed(key === 'db' ? 0 : 2) : '—'} <span className="text-sm text-slate-500">{METRICS[key].unit}</span></p>
        <p className="mt-2 text-xs text-slate-500">{samples[key] ? `采样 ${new Date(samples[key].sampledAt).toLocaleTimeString()}` : '未取得有效采样，不以零或回放替代'}</p>
      </div>)}
    </div>
    <p className="text-xs text-slate-500">{sampledAt ? `最近采集尝试：${sampledAt}` : '正在读取监控…'} · QPS 不含 Actuator 请求</p>
    <div className="border-t border-white/10 pt-5">
      <div className="flex flex-wrap items-center gap-4"><Button onClick={() => { void run.run(); }} disabled={run.state === 'running'} className="h-11 bg-cyan-300 px-5 text-[#071019] hover:bg-cyan-200">
        {run.state === 'running' ? <RefreshCw className="animate-spin" /> : <Activity />}{run.state === 'running' ? '正在运行，等待后台结果' : '运行腾讯云故障恢复实验'}</Button>
        <span className={run.state === 'success' ? 'text-sm text-emerald-300' : 'text-sm text-amber-200'}>{({ idle: '尚未运行', running: '执行中', success: '已验证恢复', error: '未通过 / 未执行', unknown: '结果未知，请核对' })[run.state]}</span></div>
      <output className="mt-3 block text-sm leading-6 text-slate-300">{run.message}</output>
      <p className="mt-2 text-sm text-slate-500">使用隔离的模拟资金数据，固定注入撮合洪峰、重复消息和投影异常；入口限流。请求不会自动重试。</p>
    </div>
    {report && <div className="space-y-4 border-t border-white/10 pt-4">
      <p className="break-all text-sm text-emerald-200">Run {report.runId} · {report.finalStatus} · 后台完成：{report.completedAt} · 本页接收：{run.receivedAt}</p>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{[
        ['唯一成交', report.metrics.uniqueTradeSequences, '笔'], ['实验撮合吞吐', report.metrics.observedTradesPerSecond, 'trade/s'],
        ['账本事务', report.metrics.ledgerTransactions, '笔'], ['端到端耗时', report.metrics.endToEndElapsedMs, 'ms'],
      ].map(([label, value, unit]) => <div key={String(label)} className="rounded-lg border border-emerald-300/15 p-3"><p className="text-sm text-slate-400">{label}</p><p className="mt-2 text-xl text-white">{value} <span className="text-sm text-slate-500">{unit}</span></p></div>)}</div>
      <ul className="grid gap-2 lg:grid-cols-2">{Object.entries(report.checks).map(([key, value]) => <li key={key} className="rounded-lg bg-emerald-300/5 p-3 text-sm leading-6"><strong className="text-emerald-200">{key}</strong><p className="text-slate-400">{value}</p></li>)}</ul>
    </div>}
  </section>;
}
