'use client';

import { useEffect, useState } from 'react';

/** 本机执行器入口只在本地预览显示，不让公网访客连接自己的回环端口。 */
export function LocalAiDeliveryEntry() {
  const [local, setLocal] = useState(false);
  useEffect(() => {
    setLocal(['localhost', '127.0.0.1', '[::1]'].includes(window.location.hostname));
  }, []);
  if (!local) return null;
  return (
    <section id="ai-live-delivery" className="rounded-2xl border border-emerald-300/40 bg-emerald-100/10 p-5 md:p-7">
      <p className="font-mono text-xs tracking-widest text-emerald-500">LOCAL EXECUTION · 本地真实执行</p>
      <h3 className="mt-3 text-2xl font-semibold">AI 实现需求，独立测试验证</h3>
      <p className="mt-3">实际编译 Java、复现旧版缺陷、生成候选代码、审查差异，再运行受信测试。每次模型调用显示真实 Token 和耗时，单价未配置时不伪造金额。</p>
      <a className="mt-5 inline-flex rounded-lg border border-emerald-600 bg-emerald-700 px-5 py-3 font-medium text-white" href="http://127.0.0.1:4400/" target="_blank" rel="noreferrer">打开本机 AI 研发验证工作台 ↗</a>
      <p className="mt-3 text-sm opacity-75">仅限本地预览；执行器须已启动。参考演练与真实模型模式明确分开，候选通过测试后仍需人工验收，不自动合并或发布。</p>
    </section>
  );
}
