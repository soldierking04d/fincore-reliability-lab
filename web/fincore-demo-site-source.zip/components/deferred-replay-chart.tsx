'use client';

import { lazy, Suspense, useEffect, useRef, useState } from 'react';

const ReplayTelemetryChart = lazy(() => import('@/components/replay-telemetry-chart'));

export type ReplayPoint = {
  time: string; price: number; orderRate: number; qps: number; matchTps: number; p95: number;
  cpu: number; memory: number; heap: number; kafkaLag: number; outbox: number; dbActive: number;
};

/** 图表接近视口时再下载；预留固定高度，避免长页面首屏下载与布局跳动。 */
export function DeferredReplayChart({ kind, data, height }: {
  kind: 'market' | 'traffic' | 'runtime' | 'pipeline'; data: ReplayPoint[]; height: number;
}) {
  const host = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const node = host.current;
    if (!node) return;
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) {
        setVisible(true);
        observer.disconnect();
      }
    }, { rootMargin: '320px' });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  const fallback = <div style={{ height }} className="flex items-center justify-center rounded-lg border border-white/5 text-sm text-slate-600">图表接近视口时加载</div>;
  return <div ref={host}>{visible ? <Suspense fallback={fallback}><ReplayTelemetryChart kind={kind} data={data} height={height} /></Suspense> : fallback}</div>;
}
