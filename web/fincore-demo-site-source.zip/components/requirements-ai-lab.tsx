'use client';

import { useState } from 'react';
import { ArrowRight, Download, FileCheck2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  baselineRules,
  changedArtifacts,
  decisionVersion,
  initialDecisions,
  manualOnlyChecks,
  rawRequest,
  reportIsCurrent,
  requirements,
  runTestPlan,
  testCases,
  type Decisions,
  type Report,
  type SendingCancel,
  type Reschedule,
} from '@/lib/requirements-test-workflow';

const action = 'h-auto min-h-11 whitespace-normal px-4 py-2.5 text-sm';
const kicker = 'font-mono text-xs tracking-widest text-cyan-300/70';
const note = 'text-sm leading-6 text-slate-400';
const panel = 'rounded-xl border border-white/10 bg-black/15 p-4';
const docsRoot =
  'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/';

/** 需求与测试工作台：保留未决问题，显示产物版本；条件变化后旧草稿和测试结果不会继续显示为当前有效。 */
export function RequirementsAiLab() {
  const [decisions, setDecisions] = useState<Decisions>({
    ...initialDecisions,
  });
  const [draft, setDraft] = useState<Decisions | null>(null);
  const [testDraft, setTestDraft] = useState<Decisions | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  const [tab, setTab] = useState('clarify');
  const [feedback, setFeedback] = useState('');
  const [exported, setExported] = useState(false);
  const version = decisionVersion(decisions);
  const draftCurrent = !!draft && decisionVersion(draft) === version;
  const testsCurrent = !!testDraft && decisionVersion(testDraft) === version;
  const currentReport = reportIsCurrent(report, decisions);
  const impacted = draft ? changedArtifacts(draft, decisions) : [];
  const reqs = requirements(draft || decisions);
  const tests = testCases(testDraft || decisions);
  const confirmed = requirements(decisions).filter(
    (r) => r.status === 'confirmed',
  ).length;

  function reset() {
    setDecisions({ ...initialDecisions });
    setDraft(null);
    setTestDraft(null);
    setReport(null);
    setTab('clarify');
    setFeedback('');
    setExported(false);
  }
  function decide(next: Decisions) {
    setDecisions(next);
    setFeedback('');
    setExported(false);
  }
  function generateDraft() {
    setDraft({ ...decisions });
    setTestDraft(null);
    setReport(null);
    setFeedback('');
    setExported(false);
    setTab('spec');
  }
  function generateTests() {
    if (!draftCurrent) return;
    setTestDraft({ ...decisions });
    setReport(null);
    setFeedback('');
    setExported(false);
    setTab('tests');
  }
  function run() {
    if (!testsCurrent) return;
    setReport(runTestPlan(decisions));
    setTab('results');
  }
  function download() {
    if (!draftCurrent || !testsCurrent) return;
    const content = {
      mode: 'synthetic_template_and_local_reference',
      realModelConnected: false,
      rawRequest,
      version,
      decisions,
      requirements: reqs,
      tests,
      report: currentReport ? report : null,
      manualOnlyChecks,
      review: feedback || '未评审',
    };
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(content, null, 2)], {
        type: 'application/json',
      }),
    );
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'requirements-testing-demo.json';
    anchor.click();
    URL.revokeObjectURL(url);
    setExported(true);
  }

  return (
    <div className="mt-7 space-y-5 text-base leading-7">
      <section className="explain-panel !p-5 md:!p-7">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className={kicker}>INTERNAL DELIVERY · 需求与测试协作</p>
            <h3 className="mt-2 text-2xl font-semibold text-white">
              把一句需求，变成有依据的验收标准和测试清单
            </h3>
            <p className="mt-3 max-w-4xl text-slate-300">
              先处理团队最常见的问题：规则没问清、验收说不准、测试到后期才发现遗漏。AI
              帮助整理和找缺口，产品决定规则，研发与 QA 判断是否可实现、可验证。
            </p>
          </div>
          <Button variant="outline" className={action} onClick={reset}>
            <RotateCcw className="size-4" />
            重新开始
          </Button>
        </div>
        <div className="mt-5 grid gap-5 xl:grid-cols-[.9fr_1.1fr]">
          <div className={panel}>
            <p className="text-sm text-cyan-200">① 原始需求 · 运营提出</p>
            <blockquote className="mt-3 text-xl leading-8 text-slate-100">
              “{rawRequest}”
            </blockquote>
            <p className="mt-4 text-slate-400">
              只确定了预约和取消两个方向，还不能直接开工。下面三条来自
              <strong className="font-medium text-slate-200">
                教学补充纪要
              </strong>
              ，不是从一句话自动推断出的事实。
            </p>
            <ul className="mt-3 space-y-2">
              {baselineRules.map((r) => (
                <li key={r.id} className="text-sm text-slate-300">
                  <span className="mr-2 font-mono text-cyan-300">{r.id}</span>
                  {r.text
                    .replace('教学补充纪要：', '')
                    .replace('教学质量约定：', '')}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-cyan-300/20 bg-cyan-300/5 p-4">
            <p className="text-sm text-cyan-200">
              ② AI 提出待决问题 → 产品确认
            </p>
            <div className="mt-4 space-y-4">
              <div>
                <label
                  id="ai-sending-label"
                  htmlFor="ai-sending-choice"
                  className="mb-2 block font-medium text-slate-100"
                >
                  发送已经开始，还能取消吗？
                </label>
                <Select
                  value={decisions.sendingCancel}
                  onValueChange={(value) => {
                    if (value)
                      decide({
                        ...decisions,
                        sendingCancel: value as SendingCancel,
                      });
                  }}
                >
                  <SelectTrigger
                    id="ai-sending-choice"
                    aria-labelledby="ai-sending-label"
                    className="!h-auto min-h-11 w-full whitespace-normal px-3 py-3 text-base"
                  >
                    <SelectValue>
                      {
                        {
                          unresolved: '待产品确认',
                          reject: '拒绝取消，继续原发送',
                          stop_remaining: '只停止未发送部分，不撤回已发送',
                        }[decisions.sendingCancel]
                      }
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unresolved">待产品确认</SelectItem>
                    <SelectItem value="reject">拒绝取消，继续原发送</SelectItem>
                    <SelectItem value="stop_remaining">
                      只停止未发送部分，不撤回已发送
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="mt-2 text-sm text-slate-400">
                  会影响状态、剩余数量、页面提示，以及开始/取消顺序测试。
                </p>
              </div>
              <div>
                <label
                  id="ai-reschedule-label"
                  htmlFor="ai-reschedule-choice"
                  className="mb-2 block font-medium text-slate-100"
                >
                  未开始的预约，能修改时间吗？
                </label>
                <Select
                  value={decisions.reschedule}
                  onValueChange={(value) => {
                    if (value)
                      decide({ ...decisions, reschedule: value as Reschedule });
                  }}
                >
                  <SelectTrigger
                    id="ai-reschedule-choice"
                    aria-labelledby="ai-reschedule-label"
                    className="!h-auto min-h-11 w-full whitespace-normal px-3 py-3 text-base"
                  >
                    <SelectValue>
                      {
                        {
                          unresolved: '待产品确认',
                          allow: '允许改约，旧预约任务必须失效',
                          deny: '本期不支持改约，原计划保留',
                        }[decisions.reschedule]
                      }
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unresolved">待产品确认</SelectItem>
                    <SelectItem value="allow">
                      允许改约，旧预约任务必须失效
                    </SelectItem>
                    <SelectItem value="deny">
                      本期不支持改约，原计划保留
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="mt-2 text-sm text-slate-400">
                  会影响需求范围、版本处理和旧任务迟到时的预期。
                </p>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button className={action} onClick={generateDraft}>
                整理需求与验收草案
                <ArrowRight className="size-4" />
              </Button>
              <Button
                variant="outline"
                className={action}
                onClick={() =>
                  decide({ sendingCancel: 'reject', reschedule: 'allow' })
                }
              >
                代入一组教学产品决策
              </Button>
            </div>
            <p className="mt-3 text-sm text-amber-200/90">
              当前 {confirmed}/5
              组规则已具备预期，其余保持待确认。可以先出草案，不能把待决规则记为已通过。
            </p>
          </div>
        </div>
        <p className="mt-4 text-sm text-slate-400">
          固定合成需求与模板演示，未接真实模型。测试执行对象是本地参考模型，不是
          FinCore 业务服务或真实邮件系统；所有选择只保存在当前页面。
        </p>
      </section>

      {impacted.length > 0 && (
        <div
          className="rounded-xl border border-amber-300/30 bg-amber-300/5 p-4"
          aria-live="polite"
        >
          <p className="font-medium text-amber-200">
            产品规则已变化，旧草稿与旧结果需要更新
          </p>
          <p className="mt-2 text-slate-300">
            影响：{impacted.join(' · ')}
            。重新整理验收草案、生成对应测试，再执行；没有变化的规则也保留原来源。
          </p>
          <Button
            variant="outline"
            className={`${action} mt-3`}
            onClick={generateDraft}
          >
            按当前决定更新草案
          </Button>
        </div>
      )}

      <section className="explain-panel !p-5 md:!p-7">
        <Tabs value={tab} onValueChange={(v) => setTab(String(v))}>
          <TabsList className="!h-auto w-full flex-wrap justify-start gap-1 bg-black/20 p-1">
            <TabsTrigger value="clarify" className={action}>
              澄清清单
            </TabsTrigger>
            <TabsTrigger value="spec" className={action}>
              ③ 需求与验收
            </TabsTrigger>
            <TabsTrigger value="tests" className={action}>
              ④ 测试与数据
            </TabsTrigger>
            <TabsTrigger value="results" className={action}>
              ⑤ 执行与评审
            </TabsTrigger>
          </TabsList>

          <TabsContent value="clarify" className="pt-4 text-base leading-7">
            <h4 className="text-lg font-semibold text-white">
              输出“还不知道什么”，比急着补全更有价值
            </h4>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className={panel}>
                <p className="font-medium text-slate-100">本轮可以形成预期</p>
                <ul className="mt-3 space-y-2 text-slate-300">
                  <li>时间是否必须晚于当前时刻、是否带时区。</li>
                  <li>未开始取消后，计划还能不能启动。</li>
                  <li>同请求重试与同请求号不同内容如何处理。</li>
                  <li>上方两项产品决定对应的状态规则。</li>
                </ul>
              </div>
              <div className={panel}>
                <p className="font-medium text-amber-200">
                  真实服务仍需确认 / 本演示不擅自补完
                </p>
                <ul className="mt-3 space-y-2 text-slate-300">
                  <li>供应商超时但可能已发送，怎样查询和重试。</li>
                  <li>已经提交给供应商、但尚未回报的在途邮件。</li>
                  <li>收件人数量限制、权限范围、发送速率和通知方式。</li>
                  <li>这些条件未决，不进入“已完成”或真实系统通过率。</li>
                </ul>
              </div>
            </div>
            <p className="mt-4 text-slate-400">
              输入资料互相矛盾时，应列出冲突出处，请产品选定口径；没有接口说明时，不编造地址、参数或状态码。
            </p>
          </TabsContent>

          <TabsContent value="spec" className="pt-4 text-base leading-7">
            {!draft ? (
              <Empty text="先在上方整理需求与验收草案。即使还有待决项，也会明确保留，不自动替产品决定。" />
            ) : (
              <>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h4 className="text-lg font-semibold text-white">
                      每条需求都有来源、编号和可观察预期
                    </h4>
                    <p className={note}>
                      草案：{decisionVersion(draft)} ·{' '}
                      {draftCurrent ? '与当前决定一致' : '旧版本，需要更新'}
                    </p>
                  </div>
                  <Button
                    className={action}
                    disabled={!draftCurrent}
                    onClick={generateTests}
                  >
                    生成对应测试清单
                    <ArrowRight className="size-4" />
                  </Button>
                </div>
                <div className="mt-4 space-y-3">
                  {reqs.map((r) => (
                    <article key={r.id} className={panel}>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h5 className="font-medium text-slate-100">
                          {r.id} · {r.title}
                        </h5>
                        <span
                          className={`text-sm ${r.status === 'confirmed' ? 'text-emerald-300' : 'text-amber-200'}`}
                        >
                          {r.status === 'confirmed'
                            ? '规则已确认'
                            : '仍待产品确认'}
                        </span>
                      </div>
                      <p className="mt-2 text-slate-300">
                        <span className="mr-2 font-mono text-sm text-cyan-300">
                          {r.acId}
                        </span>
                        {r.acceptance}
                      </p>
                      <p className="mt-2 text-sm text-slate-500">
                        依据：{r.source}
                      </p>
                    </article>
                  ))}
                </div>
                <p className="mt-4 text-slate-400">
                  这是可供产品、研发和 QA
                  共同评审的需求草案。接口和实现方案应在真实项目中补齐，不能从草案直接宣布开发完成。
                </p>
              </>
            )}
          </TabsContent>

          <TabsContent value="tests" className="pt-4 text-base leading-7">
            {!testDraft ? (
              <Empty text="先生成当前版本的需求草案，再生成测试清单。" />
            ) : (
              <>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h4 className="text-lg font-semibold text-white">
                      用例不是标题列表：有前提、步骤、数据和预期
                    </h4>
                    <p className={note}>
                      {tests.filter((t) => t.expected).length} 条具备预期，
                      {tests.filter((t) => !t.expected).length}{' '}
                      条因规则未决而阻塞。数量不是覆盖率。
                    </p>
                  </div>
                  <Button
                    className={action}
                    disabled={!testsCurrent}
                    onClick={run}
                  >
                    执行本地参考模型
                  </Button>
                </div>
                <div className="mt-4 space-y-2">
                  {tests.map((t) => (
                    <details
                      key={t.id}
                      open={t.id === 'TC-06'}
                      className={panel}
                    >
                      <summary className="cursor-pointer text-base">
                        <span className="mr-2 font-mono text-sm text-cyan-300">
                          {t.id}
                        </span>
                        {t.name}
                        <span className="ml-3 text-sm text-slate-400">
                          {t.category} · {t.reqId} / {t.acId}
                        </span>
                        {!t.expected && (
                          <span className="ml-3 text-sm text-amber-200">
                            待确认
                          </span>
                        )}
                      </summary>
                      <dl className="mt-3 grid gap-2 text-slate-300">
                        <div>
                          <dt className="inline font-medium text-slate-100">
                            前提：
                          </dt>
                          <dd className="inline">{t.given}</dd>
                        </div>
                        <div>
                          <dt className="inline font-medium text-slate-100">
                            操作：
                          </dt>
                          <dd className="inline">{t.when}</dd>
                        </div>
                        <div>
                          <dt className="inline font-medium text-slate-100">
                            预期：
                          </dt>
                          <dd className="inline">{t.expectedBehavior}</dd>
                        </div>
                      </dl>
                      <details className="mt-3">
                        <summary className="cursor-pointer text-sm text-cyan-200">
                          查看合成输入与明确预期
                        </summary>
                        <pre className="mt-2 max-h-80 overflow-auto rounded-lg bg-black/25 p-3 text-xs leading-6 text-slate-300">
                          {JSON.stringify(
                            {
                              initial: t.initial,
                              commands: t.commands,
                              ...(t.schedule ? { schedule: t.schedule } : {}),
                              expected: t.expected,
                            },
                            null,
                            2,
                          )}
                        </pre>
                      </details>
                    </details>
                  ))}
                </div>
                <p className="mt-4 text-sm text-slate-400">
                  TC-07 / TC-08
                  枚举取消与开始的两种先后顺序，不代表运行了真实多线程竞争测试。
                </p>
              </>
            )}
          </TabsContent>

          <TabsContent value="results" className="pt-4 text-base leading-7">
            {!report ? (
              <Empty text="生成测试清单并执行后，才会出现实际结果。生成用例不等于已经执行。" />
            ) : (
              <>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h4 className="text-lg font-semibold text-white">
                      执行对象：本地确定性参考模型
                    </h4>
                    <p className={note}>
                      结果版本：{report.version} ·{' '}
                      {currentReport
                        ? '与当前产品决定一致'
                        : '已过期，不作为当前规则的结果'}
                    </p>
                  </div>
                  <div className="flex gap-4 text-sm">
                    <span className="text-emerald-300">
                      {report.rows.filter((r) => r.status === 'pass').length}{' '}
                      通过
                    </span>
                    <span className="text-rose-300">
                      {report.rows.filter((r) => r.status === 'fail').length}{' '}
                      失败
                    </span>
                    <span className="text-amber-200">
                      {report.rows.filter((r) => r.status === 'blocked').length}{' '}
                      待确认
                    </span>
                  </div>
                </div>
                <div className="mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-3">
                  {report.rows.map((r) => (
                    <details key={r.id} className={panel}>
                      <summary className="cursor-pointer text-sm">
                        <span className="font-mono">{r.id}</span> ·{' '}
                        {
                          {
                            pass: '预期与实际一致',
                            fail: '预期与实际不一致',
                            blocked: '没有确定预期，未执行',
                          }[r.status]
                        }
                      </summary>
                      <pre className="mt-2 overflow-auto text-xs leading-6 text-slate-400">
                        {JSON.stringify(
                          { expected: r.expected, actual: r.actual },
                          null,
                          2,
                        )}
                      </pre>
                    </details>
                  ))}
                </div>
                <div className="mt-5 rounded-xl border border-amber-300/20 bg-amber-300/5 p-4">
                  <h5 className="font-medium text-amber-200">
                    以下真实服务检查没有执行，不能用模型通过替代
                  </h5>
                  <ul className="mt-3 space-y-3">
                    {manualOnlyChecks.map((c) => (
                      <li key={c.id}>
                        <p className="text-slate-200">
                          {c.id} · {c.title}
                        </p>
                        <p className="mt-1 text-sm text-slate-400">
                          {c.expected}
                        </p>
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}
            <div className="mt-5 border-t border-white/10 pt-5">
              <h4 className="text-lg font-semibold text-white">
                产品、研发、QA 用正常评审流程收敛草案
              </h4>
              <p className="mt-2 text-slate-400">
                核对未知有没有被偷换成事实、预期能否观察、重复用例能否删除。真实缺陷需要回写到需求与回归样本，不修改预期去迎合错误实现。
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  className={action}
                  disabled={!draftCurrent}
                  onClick={() =>
                    setFeedback(
                      '规则仍有遗漏，退回澄清；不作为已确认开发范围。',
                    )
                  }
                >
                  规则不完整，退回澄清
                </Button>
                <Button
                  variant="outline"
                  className={action}
                  disabled={!testsCurrent}
                  onClick={() =>
                    setFeedback(
                      '测试草案可进入团队评审；不表示真实业务测试已通过或允许发布。',
                    )
                  }
                >
                  <FileCheck2 className="size-4" />
                  测试草案可进入团队评审
                </Button>
                <Button
                  variant="outline"
                  className={action}
                  disabled={!draftCurrent || !testsCurrent}
                  onClick={download}
                >
                  <Download className="size-4" />
                  下载本次教学产物
                </Button>
              </div>
              {feedback && (
                <p className="mt-3 text-sm text-cyan-200" aria-live="polite">
                  {feedback}
                </p>
              )}
              {exported && (
                <p className="mt-2 text-sm text-slate-400" aria-live="polite">
                  已生成本次 JSON
                  下载，含需求、用例、决定和执行对象；没有上传任何资料。
                </p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </section>

      <section className="explain-panel !p-5 md:!p-7">
        <p className={kicker}>变化时，产物要一起更新</p>
        <h3 className="mt-2 text-xl font-semibold text-white">
          试一次：把“发送中拒绝取消”改成“只停止剩余部分”
        </h3>
        <p className="mt-3 text-slate-300">
          先代入教学产品决策，生成并执行一次；再修改发送中取消规则。系统会标出
          REQ-03 / AC-03 / TC-08 / TC-09 的影响。重新生成后，“已发送 3、总量
          10”的预期从拒绝变成停止剩余 7，已发送的 3 不撤回。
        </p>
        <p className="mt-3 text-sm text-amber-200/90">
          实际在途邮件如何归类仍未定义，不能靠模型默认“都能停止”。这项必须进入真实实现前的澄清和集成测试。
        </p>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="explain-panel !p-5 md:!p-7">
          <p className={kicker}>收益：衡量整条需求</p>
          <h3 className="mt-2 text-xl font-semibold text-white">
            把遗漏提前暴露，把重复整理压缩
          </h3>
          <ul className="mt-4 space-y-3 text-slate-300">
            <li>需求会前先得到有依据的问题清单，减少边开发边猜规则。</li>
            <li>
              需求、验收标准、测试用例互相关联，变化时更容易找到影响范围。
            </li>
            <li>自动铺出边界、状态和重复操作候选，让 QA 集中检查重要遗漏。</li>
            <li>复用结构和测试数据，减少人工复制、整理与同步成本。</li>
          </ul>
          <p className="mt-4 text-sm text-emerald-200">
            评价指标：澄清 + 评审 + 测试设计 +
            返工的总用时，以及后期发现的需求漏项；不是生成速度或用例数量。
          </p>
        </div>
        <div className="explain-panel !p-5 md:!p-7">
          <p className="font-mono text-xs tracking-widest text-amber-200/80">
            代价：可能把返工放大
          </p>
          <h3 className="mt-2 text-xl font-semibold text-white">
            完整的格式，未必是正确的需求
          </h3>
          <ul className="mt-4 space-y-3 text-slate-300">
            <li>擅自补规则：把“行业通常这样”写成产品已经同意。</li>
            <li>测试膨胀：大量相似用例，没有明确预期，评审比重写还慢。</li>
            <li>同源错误：同一个模型生成需求和测试，把同一误解重复验证。</li>
            <li>版本漂移：需求已改，旧测试仍显示通过，误导团队。</li>
          </ul>
          <p className="mt-4 text-sm text-amber-200">
            保留人工反例、独立检查与真实 BUG
            回归；输入只用公司获准资料，敏感内容先处理。
          </p>
        </div>
      </section>

      <section className="explain-panel !p-5 md:!p-7">
        <p className={kicker}>放进现有研发流程</p>
        <h3 className="mt-2 text-xl font-semibold text-white">
          需求文档 → 草案 → 评审 → 测试管理 → 缺陷反馈
        </h3>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {[
            [
              '第一周：只选一条内部需求',
              '产品整理当前资料和模板；记录原流程用时。研发与 QA 准备独立反例，比较模板人工与 AI 草案。',
            ],
            [
              '第二周：跟一次真实评审',
              '接入公司获准的模型后再测真实输出。记录采纳、修改、漏项、冗余、总用时和模型费用，不强制使用。',
            ],
            [
              '每次变更：回到同一条记录',
              '确认需求版本，更新受影响用例，保留失败输入和实际证据。是否继续推广由净收益与质量决定。',
            ],
          ].map(([title, text]) => (
            <article key={title} className={panel}>
              <h4 className="font-medium text-slate-100">{title}</h4>
              <p className="mt-3 text-slate-400">{text}</p>
            </article>
          ))}
        </div>
        <p className="mt-4 text-slate-300">
          继续的条件是团队总劳动减少、关键遗漏没有增加、生成物有人维护。改稿和检查成本更高时，缩小到“只列澄清问题”或“只补测试候选”也合理。
        </p>
        <details className="mt-4">
          <summary className="cursor-pointer py-2 text-sm text-cyan-200">
            公司真正接入时，还要补什么？
          </summary>
          <p className="mt-2 text-slate-400">
            接入获准的需求文档与历史缺陷，保留来源和版本；为模型准备输出格式和独立验收样本；把结果写成待评审草稿，由现有需求/测试管理工具承接。真实服务执行、代码覆盖率和发布判断使用原有
            CI 与 QA 证据，不能由模型口头宣布。
          </p>
        </details>
      </section>
      <div className="flex flex-wrap gap-3 text-sm">
        <a
          className="nav-link inline-flex min-h-11"
          href={`${docsRoot}docs/management/detailed/17-ai-requirements-testing-playbook.md`}
          target="_blank"
          rel="noreferrer"
        >
          内部需求与测试完整说明
          <ArrowRight className="size-4" />
        </a>
        <a
          className="nav-link inline-flex min-h-11"
          href={`${docsRoot}ai/requirements-test-workflow.ts`}
          target="_blank"
          rel="noreferrer"
        >
          参考模型与追溯规则
          <ArrowRight className="size-4" />
        </a>
        <a
          className="nav-link inline-flex min-h-11"
          href={`${docsRoot}ai/requirements-test-workflow.test.ts`}
          target="_blank"
          rel="noreferrer"
        >
          独立自动测试
          <ArrowRight className="size-4" />
        </a>
      </div>
    </div>
  );
}
function Empty({ text }: { text: string }) {
  return (
    <p className="rounded-xl border border-dashed border-white/15 p-5 text-slate-400">
      {text}
    </p>
  );
}
