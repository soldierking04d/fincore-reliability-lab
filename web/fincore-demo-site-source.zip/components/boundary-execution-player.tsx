'use client';

import { useMemo, useState } from 'react';
import { buildExecutionCase, executionScenarios } from '@/public/trading-boundaries/execution-model.mjs';
import { buildRecoveryCase, recoveryScenarios } from '@/public/trading-boundaries/recovery-model.mjs';

type Frame = {
  step:number; title:string; notes:string[];
  metrics:{label:string; value:string}[];
  rows:{subject:string; state:string; detail:string}[];
  checks:{name:string; ok:boolean; detail:string}[];
};
type Experiment = { title:string; limitation:string; snapshots:Frame[] };

/** 使用与命令行验证相同的纯模型；交互仅改变本机步骤，不请求后台或钱包。 */
export function BoundaryExecutionPlayer({kind}:{kind:'execution'|'recovery'|'reconciliation'}) {
  const choices = kind === 'recovery' ? recoveryScenarios : executionScenarios.filter((s:{id:string}) =>
    kind === 'reconciliation' ? s.id === 'reconciliation-cut' : s.id !== 'reconciliation-cut');
  const [scenario,setScenario] = useState(choices[0].id);
  const [step,setStep] = useState(0);
  const result = useMemo(() => (kind === 'recovery' ? buildRecoveryCase({scenario}) : buildExecutionCase({scenario})) as unknown as Experiment, [kind,scenario]);
  const current = result.snapshots[Math.min(step,result.snapshots.length-1)];
  const label = kind === 'execution' ? '支付与兑换场景' : kind === 'recovery' ? '日志与接管场景' : '对账场景';
  const source = kind === 'recovery' ? 'recovery-model.mjs' : 'execution-model.mjs';
  return <div className="boundary-player" id={`${kind}-case`}>
    <div className="boundary-player-heading"><div><span className="boundary-label">独立内存实验 · 无外部请求</span><h3>{label}</h3></div><button onClick={()=>setStep(0)}>重置步骤</button></div>
    <label className="boundary-selector">选择场景<select aria-label={label} value={scenario} onChange={e=>{setScenario(e.target.value);setStep(0);}}>{choices.map((s:{id:string;title:string})=><option key={s.id} value={s.id}>{s.title}</option>)}</select></label>
    <p>{choices.find((s:{id:string})=>s.id===scenario)?.summary}</p>
    <div className="boundary-metrics">{current.metrics.map(m=><div key={m.label}><span>{m.label}</span><strong>{m.value}</strong></div>)}</div>
    <div className="boundary-stage" aria-live="polite"><strong>{step+1} / {result.snapshots.length} · {current.title}</strong><ul>{current.notes.map(n=><li key={n}>{n}</li>)}</ul></div>
    <div className="boundary-controls"><button disabled={step===0} onClick={()=>setStep(v=>v-1)}>上一步</button><button disabled={step===result.snapshots.length-1} onClick={()=>setStep(v=>v+1)}>下一步</button><button onClick={()=>setStep(result.snapshots.length-1)}>查看最终结果</button></div>
    <details className="boundary-detail"><summary>展开完整步骤、状态与校验</summary>
      <ol className="boundary-steps" aria-label={`${label}步骤`}>{result.snapshots.map((s,i)=><li key={i}><button aria-current={i===step?'step':undefined} onClick={()=>setStep(i)}><span>{String(i+1).padStart(2,'0')}</span>{s.title}</button></li>)}</ol>
      <div className="boundary-table" tabIndex={0}><table><thead><tr><th scope="col">对象</th><th scope="col">状态</th><th scope="col">含义</th></tr></thead><tbody>{current.rows.map((r,i)=><tr key={i}><td>{r.subject}</td><td>{r.state}</td><td>{r.detail}</td></tr>)}</tbody></table></div>
      <div className="boundary-checks">{current.checks.map(c=><div key={c.name} className={c.ok?'check-pass':'check-fail'}><strong>{c.ok?'PASS':'FAIL'} · {c.name}</strong><p>{c.detail}</p></div>)}</div>
      <a className="boundary-source-link" href={`/trading-boundaries/${source}`} target="_blank" rel="noreferrer">查看这段模型源码 ↗</a>
    </details>
    <p className="boundary-model-note">{result.limitation}</p>
  </div>;
}
