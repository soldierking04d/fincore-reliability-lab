'use client';

import { useState } from 'react';
import {
  ArrowRight,
  Cpu,
  ExternalLink,
  Gauge,
  HardDrive,
  Radio,
  ShieldCheck,
  TriangleAlert,
  Workflow,
} from 'lucide-react';

type DomainKey = 'cpu' | 'network' | 'fpga' | 'gpu' | 'research';

type Domain = {
  label: string;
  status: '专项设计' | '需要目标硬件 PoC';
  headline: string;
  conclusion: string;
  design: string[];
  failures: string[];
  evidence: string[];
};

const domains: Record<DomainKey, Domain> = {
  cpu: {
    label: 'CPU / NUMA',
    status: '需要目标硬件 PoC',
    headline: '不是多开线程，而是让数据、队列、IRQ 和单写者留在同一硬件局部性里',
    conclusion: 'FinCore 已验证有界 Lane 和单 symbol 顺序；绑核、NUMA、缓存行、页故障和频率控制尚待目标硬件实验。',
    design: ['NIC queue → IRQ → core → owner thread 同拓扑', '内存首次触碰、ring 与 hugepage 贴近 NIC NUMA node', '热冷字段拆分、顺序布局、预分配和 SPSC 优先', '隔离 GC、日志、监控与内核 housekeeping'],
    failures: ['线程迁核与上下文切换重新预热缓存', '远端内存穿越 UPI/QPI，P99.9 抖动', 'false sharing、LLC miss、page fault 或 TLB miss', 'cgroup 节流、C-state、Turbo 与超线程噪声'],
    evidence: ['P50 / P99 / P99.9 / max', 'perf stat / record / c2c', 'numastat + IRQ / queue mapping', 'throttled time + 正确性回归'],
  },
  network: {
    label: '网络 / 时钟',
    status: '需要目标硬件 PoC',
    headline: '先证明延迟来自协议栈，再决定中断、轮询、busy poll 或 DPDK',
    conclusion: 'RSS/RPS/RFS/XPS 的目标是队列与应用 owner 对齐；PTP 和硬件时间戳负责把跨机耗时变成可归因证据。',
    design: ['RSS 硬件队列与 CPU 亲和，XPS 对齐发送路径', 'UDP 行情保存频道、序号、快照与重建点', '订单会话保留 clientOrderId、序号、回报补发和查询', 'PTP offset、drift、holdover 与主时钟切换告警'],
    failures: ['行情丢包/乱序后本地簿仍被当成可信', '报单超时后生成新业务键盲重试', '网卡队列跨 NUMA 或软中断压住业务核', '时钟失锁却继续报告伪精确分段延迟'],
    evidence: ['wire-to-app / order-to-wire', 'drop / reorder / gap / retransmit', 'queue—IRQ—core 拓扑', 'PTP 最大偏差与回退演练'],
  },
  fpga: {
    label: 'FPGA / SmartNIC',
    status: '专项设计',
    headline: '固定、确定、低变更的逻辑适合下沉；复杂策略和异常编排留在 CPU',
    conclusion: '技术负责人负责性能预算、下沉边界、接口、验收、TCO 和回退；RTL 与时序实现由有生产经验的 owner 负责。',
    design: ['候选：协议解析、过滤、时间戳、固定风控', '复杂策略、大状态和频繁变更规则保留 CPU', '固件/协议版本、计数器、抓包和 shadow 双跑', 'CPU 安全慢路径 + 单一发单权威 fencing'],
    failures: ['局部延迟下降但端到端 P99.9 没改善', '协议升级导致字段错位或错误订单', '卡、PCIe、链路、时钟或逻辑异常', 'CPU 与 FPGA 两条路径同时发单'],
    evidence: ['端到端分位数与每拍吞吐', 'CRC / sequence / backpressure', '回放与 shadow 差异', '三年 TCO + 退出条件'],
  },
  gpu: {
    label: 'GPU / 异构计算',
    status: '专项设计',
    headline: 'GPU 放在训练、批量推理、Monte Carlo 和向量回测，不默认塞进单笔订单状态机',
    conclusion: '先分解读取、预处理、H2D、kernel、通信和排队。GPU 等数据时，加卡只会增加闲置和成本。',
    design: ['点时数据 → CPU 预处理 → pinned memory → H2D', 'batch、显存、混合精度和多卡通信联合调优', '实验绑定数据/特征/代码/镜像/随机种子/硬件', '离线 → 回放 → shadow → 小资金灰度 → 扩容'],
    failures: ['batch 提升吞吐却拉长研究反馈或在线延迟', '显存 OOM、通信瓶颈与扩卡收益递减', '数值精度或非确定算子造成结果漂移', '模型/GPU 故障后绕过风控继续交易'],
    evidence: ['GPU util / SM / memory / H2D', 'GPU-hour 与单位可信实验成本', 'scaling efficiency + 失败重跑', 'golden set + 漂移 + 回滚'],
  },
  research: {
    label: '研究 / 回测',
    status: '专项设计',
    headline: '研究平台先证明数据正确、实验可复现、实盘可归因，再追求更快',
    conclusion: '研究与实盘共享业务语义、特征和订单模型接口，不必强行使用完全相同的运行时。',
    design: ['raw immutable → point-in-time → feature/factor → snapshot', '交互研究与分布式回测共享血缘和 golden set', '实验注册 → 回放 → shadow → 灰度 → 监控/回滚', '偏差按数据、信号、成本、执行和容量归因'],
    failures: ['未来函数、存活者偏差、复权与时间对齐错误', '忽略冲击、排队、涨跌停、停牌和策略容量', '研究代码重写后与实盘语义分叉', '数据供应商回补或模型漂移没有版本证据'],
    evidence: ['点时覆盖与泄漏检测', '数据/代码/参数/环境完整率', '研究周期与排队时间', '回测—shadow—实盘偏差'],
  },
};

const domainKeys = Object.keys(domains) as DomainKey[];

export function LowLatencyPlaybook() {
  const [activeDomain, setActiveDomain] = useState<DomainKey>('cpu');
  const domain = domains[activeDomain];

  return (
    <section id="low-latency" className="chapter-section scroll-mt-20">
      <div className="grid gap-5 xl:grid-cols-[1fr_auto] xl:items-end">
        <div>
          <p className="panel-kicker">LOW LATENCY · CPU · NETWORK · FPGA · GPU</p>
          <h2 className="mt-2 max-w-6xl text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">
            把“高并发”与“低延迟”分开：从时间戳、CPU 拓扑走到 GPU 研究计算
          </h2>
          <p className="mt-3 max-w-6xl text-sm leading-7 text-slate-400">
            内容包括延迟测量、P99.9 抖动、CPU/NUMA/Cache、网卡队列、PTP、内核旁路、FPGA 回退、GPU 利用率和回测数据。
            已有实验结果、设计方案与待完成的硬件验证分别标注。
          </p>
        </div>
        <div className="flex flex-wrap gap-2 xl:max-w-md xl:justify-end">
          <EvidenceBadge tone="green">VERIFIED · 金融可靠性基线</EvidenceBadge>
          <EvidenceBadge tone="cyan">DEMO · 架构与故障推演</EvidenceBadge>
          <EvidenceBadge tone="amber">POC · 目标硬件待验证</EvidenceBadge>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[.8fr_1.2fr]">
        <section className="explain-panel">
          <p className="panel-kicker">EVIDENCE BOUNDARY</p>
          <h3 className="mt-2 text-lg font-semibold text-white">先说清项目已经证明什么</h3>
          <div className="mt-4 space-y-2">
            <BoundaryRow icon={ShieldCheck} title="已经落地并验证" detail="有界 Lane、幂等、Outbox、平衡账本、Worker 接管、Epoch Fencing、对账修复、JFR 与 Prometheus。" tone="green" />
            <BoundaryRow icon={Workflow} title="已经形成专项设计" detail="HFT 三平面、延迟预算、CPU/GPU 决策、行情缺口恢复、硬件慢路和研究可信链。" tone="cyan" />
            <BoundaryRow icon={TriangleAlert} title="不冒充直接生产经验" detail="C++ 热核、DPDK、FPGA RTL、GPU 集群和具体柜台协议需由领域 owner 在目标环境验证。" tone="amber" />
          </div>
        </section>

        <section className="explain-panel">
          <p className="panel-kicker">LATENCY CONTRACT</p>
          <h3 className="mt-2 text-lg font-semibold text-white">没有统一口径，就没有“微秒级”结论</h3>
          <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            <LatencyCard label="wire-to-app" start="网卡收到包" end="标准事件进入应用" />
            <LatencyCard label="tick-to-trade" start="可信行情到达" end="订单离开本机" />
            <LatencyCard label="order-to-ack" start="本地报单" end="交易所确认" />
            <LatencyCard label="fill-to-position" start="成交回报" end="仓位/风险可见" />
            <LatencyCard label="trade-to-settle" start="成交事实" end="账本完成" verified />
            <LatencyCard label="每条口径都要" start="P50 / P99 / P99.9" end="max + 样本 + 硬件" />
          </div>
        </section>
      </div>

      <section className="explain-panel mt-4 overflow-hidden">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="panel-kicker">THREE-PLANE HFT ARCHITECTURE</p>
            <h3 className="mt-2 text-lg font-semibold text-white">热路径、控制面和恢复面必须同时存在</h3>
            <p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">热路径追求确定性；控制面限制配置与风险；恢复面用录包、事件、快照和外部查询把未知状态收敛。</p>
          </div>
          <span className="font-mono text-[9px] text-slate-600">行情 → 信号 → 风控 → 报单 → 回报 → 资金</span>
        </div>
        <div className="mt-5 overflow-x-auto rounded-xl border border-white/7 bg-[#050c13] p-3">
          <LowLatencyArchitecture />
        </div>
      </section>

      <section className="explain-panel mt-4">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
          <div>
            <p className="panel-kicker">DECISION WORKBENCH</p>
            <h3 className="mt-2 text-lg font-semibold text-white">选择一个领域，继续追到失败模式和验收证据</h3>
          </div>
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="低延迟专项领域">
            {domainKeys.map((key) => (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={activeDomain === key}
                onClick={() => setActiveDomain(key)}
                className={`rounded-lg border px-3 py-2 text-[10px] transition ${activeDomain === key ? 'border-cyan-300/35 bg-cyan-300/10 text-cyan-200' : 'border-white/8 bg-black/10 text-slate-500 hover:border-white/15 hover:text-slate-300'}`}
              >
                {domains[key].label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-5 rounded-xl border border-cyan-300/12 bg-cyan-300/[0.025] p-4 sm:p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-mono text-[9px] text-cyan-300/70">{domain.label}</p>
              <h4 className="mt-2 max-w-5xl text-base font-semibold text-white">{domain.headline}</h4>
            </div>
            <span className="rounded-md border border-amber-300/15 bg-amber-300/[0.06] px-2.5 py-1.5 font-mono text-[8px] text-amber-200">{domain.status}</span>
          </div>
          <p className="mt-3 max-w-6xl text-xs leading-6 text-slate-400">{domain.conclusion}</p>

          <div className="mt-5 grid gap-3 lg:grid-cols-3">
            <DomainColumn icon={Workflow} title="设计要点" items={domain.design} tone="cyan" />
            <DomainColumn icon={TriangleAlert} title="失败模式" items={domain.failures} tone="rose" />
            <DomainColumn icon={Gauge} title="验收证据" items={domain.evidence} tone="green" />
          </div>
        </div>
      </section>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.08fr_.92fr]">
        <section className="explain-panel">
          <p className="panel-kicker">CPU OR GPU?</p>
          <h3 className="mt-2 text-lg font-semibold text-white">GPU 不是更快的通用 CPU，数据形状决定计算位置</h3>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[700px] text-left text-[10px] leading-5 text-slate-500">
              <thead><tr className="border-b border-white/8 font-mono text-[8px] uppercase tracking-[0.12em] text-slate-600"><th className="pb-2 pr-3">工作负载</th><th className="pb-2 pr-3">默认选择</th><th className="pb-2 pr-3">为什么</th><th className="pb-2">关键限制</th></tr></thead>
              <tbody>
                <ComputeRow workload="订单簿 / OMS / 单笔风控" target="CPU / FPGA" reason="强顺序、小状态、极低延迟" limit="GPU 传输、启动、batch 等待" />
                <ComputeRow workload="训练 / 大批量推理" target="GPU" reason="矩阵与高并行计算" limit="数据供应、显存、通信、复现" />
                <ComputeRow workload="Monte Carlo / 情景风险" target="CPU ↔ GPU PoC" reason="大量独立或向量任务" limit="精度、随机性、搬运成本" />
                <ComputeRow workload="因子矩阵 / 向量回测" target="CPU SIMD / GPU" reason="批量计算与数据复用" limit="未来函数、格式、分支发散" />
                <ComputeRow workload="账本 / 对账 / OLTP" target="CPU / 存储" reason="事务与 I/O 主导" limit="加卡不能消除锁与数据库瓶颈" />
              </tbody>
            </table>
          </div>
        </section>

        <section className="explain-panel">
          <p className="panel-kicker">GPU BOTTLENECK CHAIN</p>
          <h3 className="mt-2 text-lg font-semibold text-white">利用率低时，先沿数据流水线找等待</h3>
          <div className="mt-4 space-y-2">
            {[
              ['01', '读取 / 解压', '吞吐、cache hit、等待'],
              ['02', 'CPU 预处理', 'worker、向量化、排队'],
              ['03', 'Host → Device', 'pinned memory、带宽'],
              ['04', 'Kernel / 模型', 'SM、显存、batch、精度'],
              ['05', '多卡通信', '带宽、拓扑、scaling efficiency'],
              ['06', '检查点 / 注册', 'I/O、失败重跑、复现证据'],
            ].map(([index, title, detail]) => <PipelineRow key={index} index={index} title={title} detail={detail} />)}
          </div>
        </section>
      </div>

      <section className="explain-panel mt-4">
        <p className="panel-kicker">WAR GAMES</p>
        <h3 className="mt-2 text-lg font-semibold text-white">三个新增故障场景，验证负责人是否真的能接住系统</h3>
        <div className="mt-4 grid gap-3 lg:grid-cols-3">
          <WarGame icon={Cpu} title="CPU 尾延迟突增" trigger="P50 稳定，P99.9 从 80µs 升到 5ms" action="保护撤单/风控，按 queue、IRQ、迁核、NUMA、cache、page fault、频率和 GC 分段定位。" exit="多轮回放恢复且资金正确性回归通过" />
          <WarGame icon={HardDrive} title="GPU 一直在等数据" trigger="显卡利用率低，训练排队却持续升高" action="拆读取、预处理、H2D、kernel、通信与排队；不先加卡，先找饥饿点和单位实验成本。" exit="利用率与研究周期同向改善，实验可复现" />
          <WarGame icon={Radio} title="FPGA 输出不可信" trigger="序号、CRC 或时间戳异常，可能产生错误订单" action="隔离硬件路径并 fencing 防双发，切 CPU 安全慢路或停策略，保留录包和板卡计数器。" exit="外部订单/仓位/资金对账清零，shadow 通过" />
        </div>
      </section>

      <section className="mt-4 rounded-xl border border-emerald-300/12 bg-emerald-300/[0.035] p-4 sm:p-5">
        <div className="grid gap-4 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <p className="panel-kicker text-emerald-300/70">FULL PLAYBOOK</p>
            <h3 className="mt-2 text-base font-semibold text-white">页面先让人看懂，专项手册继续回答原理、边界、失败与验证</h3>
            <p className="mt-2 max-w-5xl text-xs leading-6 text-slate-500">完整文档还覆盖 C++ 内存序、lock-free 边界、DPDK/RDMA、点时数据、十类回测偏差、市场会话、策略容量、组合约束、90 天演进和团队 owner 分工。</p>
          </div>
          <div className="flex flex-wrap gap-2 lg:justify-end">
            <a href="#java-cpp-migration" className="nav-link">Java → C++ 改造、代码与实测 <ArrowRight className="size-3" /></a>
            <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/low-latency-compute-playbook.md" target="_blank" rel="noreferrer" className="nav-link">阅读低延迟专项手册 <ExternalLink className="size-3" /></a>
            <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/handbook-gap-coverage.md" target="_blank" rel="noreferrer" className="nav-link">查看逐章缺口矩阵 <ArrowRight className="size-3" /></a>
          </div>
        </div>
      </section>
    </section>
  );
}

function EvidenceBadge({ children, tone }: { children: string; tone: 'green' | 'cyan' | 'amber' }) {
  const tones = { green: 'border-emerald-300/15 bg-emerald-300/[0.06] text-emerald-300', cyan: 'border-cyan-300/15 bg-cyan-300/[0.06] text-cyan-300', amber: 'border-amber-300/15 bg-amber-300/[0.06] text-amber-200' };
  return <span className={`rounded-md border px-2.5 py-1.5 font-mono text-[8px] ${tones[tone]}`}>{children}</span>;
}

function BoundaryRow({ icon: Icon, title, detail, tone }: { icon: typeof ShieldCheck; title: string; detail: string; tone: 'green' | 'cyan' | 'amber' }) {
  const tones = { green: 'bg-emerald-300/10 text-emerald-300', cyan: 'bg-cyan-300/10 text-cyan-300', amber: 'bg-amber-300/10 text-amber-200' };
  return <div className="flex items-start gap-3 rounded-lg border border-white/7 bg-black/10 p-3"><span className={`grid size-8 shrink-0 place-items-center rounded-lg ${tones[tone]}`}><Icon className="size-4" /></span><div><h4 className="text-[11px] font-medium text-slate-200">{title}</h4><p className="mt-1 text-[10px] leading-5 text-slate-500">{detail}</p></div></div>;
}

function LatencyCard({ label, start, end, verified = false }: { label: string; start: string; end: string; verified?: boolean }) {
  return <article className={`rounded-lg border p-3 ${verified ? 'border-emerald-300/15 bg-emerald-300/[0.04]' : 'border-white/7 bg-black/10'}`}><div className="flex items-center justify-between gap-2"><span className={`font-mono text-[9px] ${verified ? 'text-emerald-300' : 'text-cyan-300/75'}`}>{label}</span>{verified && <span className="font-mono text-[7px] text-emerald-300/70">VERIFIED PATH</span>}</div><p className="mt-2 text-[10px] leading-5 text-slate-500">{start} <ArrowRight className="mx-1 inline size-3" /> {end}</p></article>;
}

function DomainColumn({ icon: Icon, title, items, tone }: { icon: typeof Workflow; title: string; items: string[]; tone: 'cyan' | 'rose' | 'green' }) {
  const tones = { cyan: 'text-cyan-300', rose: 'text-rose-300', green: 'text-emerald-300' };
  return <article className="rounded-xl border border-white/7 bg-black/10 p-4"><div className={`flex items-center gap-2 ${tones[tone]}`}><Icon className="size-4" /><h5 className="text-[11px] font-medium">{title}</h5></div><ul className="mt-3 space-y-2">{items.map((item) => <li key={item} className="flex gap-2 text-[10px] leading-5 text-slate-500"><span className={`mt-2 size-1 shrink-0 rounded-full bg-current ${tones[tone]}`} />{item}</li>)}</ul></article>;
}

function ComputeRow({ workload, target, reason, limit }: { workload: string; target: string; reason: string; limit: string }) {
  return <tr className="border-b border-white/6 last:border-0"><td className="py-3 pr-3 font-medium text-slate-300">{workload}</td><td className="py-3 pr-3 font-mono text-cyan-300/80">{target}</td><td className="py-3 pr-3">{reason}</td><td className="py-3">{limit}</td></tr>;
}

function PipelineRow({ index, title, detail }: { index: string; title: string; detail: string }) {
  return <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-lg border border-white/7 bg-black/10 px-3 py-2.5"><span className="font-mono text-[8px] text-cyan-300/70">{index}</span><strong className="text-[10px] font-medium text-slate-300">{title}</strong><span className="text-right font-mono text-[8px] text-slate-600">{detail}</span></div>;
}

function WarGame({ icon: Icon, title, trigger, action, exit }: { icon: typeof Cpu; title: string; trigger: string; action: string; exit: string }) {
  return <article className="rounded-xl border border-white/7 bg-black/10 p-4"><div className="flex items-center gap-2"><span className="grid size-8 place-items-center rounded-lg bg-rose-300/[0.08] text-rose-300"><Icon className="size-4" /></span><h4 className="text-[11px] font-medium text-slate-200">{title}</h4></div><p className="mt-3 text-[10px] leading-5 text-rose-200/60">触发：{trigger}</p><p className="mt-2 text-[10px] leading-5 text-slate-500">动作：{action}</p><p className="mt-2 border-t border-white/7 pt-2 text-[10px] leading-5 text-emerald-300/65">退出：{exit}</p></article>;
}

function LowLatencyArchitecture() {
  return (
    <svg viewBox="0 0 1480 610" className="min-w-[1120px]" aria-labelledby="latency-architecture-title latency-architecture-description">
      <title id="latency-architecture-title">低延迟交易三平面架构</title>
      <desc id="latency-architecture-description">主路径从行情、网卡、解码、订单簿、信号、风控、网关到交易所和回报；控制面提供限额与紧急停止；恢复面提供录包、重放和对账。</desc>
      <defs>
        <linearGradient id="latency-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#091722" /><stop offset="1" stopColor="#061019" /></linearGradient>
        <marker id="latency-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#67e8f9" /></marker>
        <marker id="control-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#a78bfa" /></marker>
      </defs>
      <rect x="0" y="0" width="1480" height="610" rx="18" fill="url(#latency-bg)" />
      <text x="34" y="47" fill="#64748b" fontSize="14" fontFamily="monospace" letterSpacing="2">HOT PATH · DETERMINISTIC</text>
      <text x="34" y="253" fill="#8b5cf6" fontSize="13" fontFamily="monospace" letterSpacing="2">CONTROL PLANE</text>
      <text x="34" y="447" fill="#34d399" fontSize="13" fontFamily="monospace" letterSpacing="2">RECOVERY / EVIDENCE PLANE</text>

      <ArchitectureLine y={134} color="#67e8f9" marker="url(#latency-arrow)" />
      <ArchitectureNode x={34} y={82} title="交易所行情" detail="channel · sequence" />
      <ArchitectureNode x={211} y={82} title="NIC / 时间戳" detail="RX queue · PTP" />
      <ArchitectureNode x={388} y={82} title="解码 / 缺口" detail="normalize · stale" />
      <ArchitectureNode x={565} y={82} title="订单簿 / 特征" detail="single writer" />
      <ArchitectureNode x={742} y={82} title="策略信号" detail="decision version" />
      <ArchitectureNode x={919} y={82} title="盘前风控" detail="limit · kill" tone="amber" />
      <ArchitectureNode x={1096} y={82} title="OMS / Gateway" detail="session · client id" />
      <ArchitectureNode x={1273} y={82} title="交易所 / 回报" detail="ack · reject · fill" />

      <path d="M 1000 310 L 1000 173" stroke="#a78bfa" strokeWidth="2" strokeDasharray="7 7" markerEnd="url(#control-arrow)" />
      <path d="M 1178 310 L 1178 173" stroke="#a78bfa" strokeWidth="2" strokeDasharray="7 7" markerEnd="url(#control-arrow)" />
      <ArchitectureNode x={560} y={286} title="策略 / 参数版本" detail="approval · audit" tone="violet" wide />
      <ArchitectureNode x={822} y={286} title="额度 / 权限 / 风险" detail="deterministic guard" tone="violet" wide />
      <ArchitectureNode x={1084} y={286} title="Kill / Fencing" detail="single order authority" tone="violet" wide />

      <path d="M 476 412 L 476 173" stroke="#34d399" strokeWidth="2" strokeDasharray="7 7" />
      <path d="M 1355 173 L 1355 490 L 1216 490" stroke="#34d399" strokeWidth="2" strokeDasharray="7 7" markerEnd="url(#control-arrow)" />
      <ArchitectureNode x={238} y={474} title="原始录包 / 事件日志" detail="immutable evidence" tone="green" wide />
      <ArchitectureNode x={500} y={474} title="快照 / 确定性重放" detail="gap rebuild · shadow" tone="green" wide />
      <ArchitectureNode x={762} y={474} title="外部订单状态查询" detail="unknown → known" tone="green" wide />
      <ArchitectureNode x={1024} y={474} title="仓位 / 资金 / 对账" detail="restore exit gate" tone="green" wide />

      <text x="34" y="588" fill="#475569" fontSize="12" fontFamily="monospace">P50 / P99 / P99.9 / max · queue wait + execution · correctness + fallback + TCO</text>
    </svg>
  );
}

function ArchitectureLine({ y, color, marker }: { y: number; color: string; marker: string }) {
  return <line x1="102" y1={y} x2="1366" y2={y} stroke={color} strokeWidth="2.5" markerEnd={marker} opacity="0.75" />;
}

function ArchitectureNode({ x, y, title, detail, tone = 'cyan', wide = false }: { x: number; y: number; title: string; detail: string; tone?: 'cyan' | 'amber' | 'violet' | 'green'; wide?: boolean }) {
  const palette = { cyan: ['#0b1d27', '#155e75', '#67e8f9'], amber: ['#20180d', '#92400e', '#fbbf24'], violet: ['#171329', '#6d28d9', '#c4b5fd'], green: ['#0b201b', '#047857', '#6ee7b7'] }[tone];
  const width = wide ? 226 : 154;
  return <g><rect x={x} y={y} width={width} height="92" rx="12" fill={palette[0]} stroke={palette[1]} strokeWidth="1.5" /><circle cx={x + 18} cy={y + 22} r="4" fill={palette[2]} /><text x={x + 30} y={y + 27} fill="#e2e8f0" fontSize="13" fontWeight="600">{title}</text><text x={x + 18} y={y + 59} fill="#64748b" fontSize="11" fontFamily="monospace">{detail}</text></g>;
}
