'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { ArrowRight, BookOpen, CheckCircle2, Download, FileCode2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';

const specialisms = [
  {
    id: 'middleware-optimization', title: '中间件优化', subtitle: '让消息、连接和数据库形成可控的并发预算',
    file: 'middleware-optimization-playbook.md',
    question: 'Kafka 已接收，为什么结算仍然积压？',
    current: '默认 Hikari 12 个连接、有效 Consumer 为 min(4, CPU)、Outbox 每批 200 条；这些是源码默认值，不是云端实测容量。',
    diagnosis: [['连接等待', 'pending 高时同时看 DB CPU、锁等待及连接占用；不要直接扩大连接池。'], ['消息积压', '按分区观察 Lag；把 PENDING、退避中、PROCESSING 与最老年龄分开。'], ['数据库工作量', '检查扫描、排序、SQL 次数、WAL 与死元组，确认瓶颈是否真的在 Broker。']],
    steps: [['固定基线', '记录依赖版本、配额、分区、数据倾斜与最终完成量。'], ['一次只改一项', '先比较池 8/12/16 或 Consumer 1/2/4，再独立比较 Outbox 批次与调度间隔。'], ['保留可靠性', '不降低 acks、不提前提交 offset；业务幂等覆盖崩溃后的重复发送。'], ['做恢复验收', '暂停 Broker / Worker，记录重复、未知、恢复时间和排空过程。']],
    boundary: '15 秒只是整批 Future 的等待预算，不是发布全流程硬超时；60 秒回收短于 120 秒投递超时，旧发送可能仍在途。claim token 与全局在途上限尚需实现。',
    acceptance: '完成量与 P99 同报；Outbox 最老年龄和 Lag 不持续增长；重复资金效果为 0；故障后可解释地排空。',
    code: `SELECT pid, wait_event_type, wait_event,\n       pg_blocking_pids(pid) AS blockers\nFROM pg_stat_activity\nWHERE datname = current_database()\n  AND pid <> pg_backend_pid();`,
  },
  {
    id: 'hot-account-optimization', title: '热点账户优化', subtitle: '减少共享资金行争用，而不是复制可花余额',
    file: 'hot-account-optimization-playbook.md',
    question: '不同订单、不同币对，为什么仍排在同一把锁上？',
    current: '已有正式费用分片与确定性路由 API；结算仍接受调用方传入的费用账户。当前归集一次锁全部费用分片和财资，尚非有界归集项。',
    diagnosis: [['公共手续费', '每个用户独立仍可能写同一收入行；费用分片并不解决共同 payer / payee。'], ['大户共享资金', 'BTC-USDT 与 ETH-USDT 争用同一 USDT 预算；按交易对分 Lane 不等于资金隔离。'], ['归集与退款', '财资成为第二个共享写点；费用源被清空后，原单退款还可能余额不足。']],
    steps: [['证明热点在哪', '分别比较公共费用、16 个费用分片和热点付款方，关联阻塞样本与真实账户分布。'], ['固化服务端路由', '候选映射包含资产、版本、分片与正式账户；旧键重放保持原路由。'], ['做账户级准入', '候选按账户资产限制在途预算，给冷账户保留额度；资金决定仍在数据库事务内。'], ['小步归集与迁移', '候选按单源/小批次记双腿账，保留退款缓冲或幂等回补，版本迁移只单次记账。']],
    boundary: '账户 Lane、强制版本化路由、归集项和退款回补仍是候选。预算子账户必须由正式转账支持；不能让 N 个分片各自持有完整总余额。',
    acceptance: '余额与账本守恒；跨币对不超花；同键只一次效果；新旧映射重放不改账；前台尾延迟与归集完成时间一起验收。',
    code: `可用余额 = balance - reserved - pending >= 0\n归集前后：来源 + 财资总额不变\n\n同一资产 / 同一账本事务：\nΣ DEBIT = Σ CREDIT\n\n退款仍使用原费用事实，不按新路由改写历史。`,
  },
] as const;

export function PerformanceEngineering() {
  const [active, setActive] = useState<string>(specialisms[0].id);
  useEffect(() => {
    const followHash = () => {
      const hash = window.location.hash.slice(1);
      if (specialisms.some(item => item.id === hash)) setActive(hash);
    };
    followHash(); window.addEventListener('hashchange', followHash);
    const onClick = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (!(anchor instanceof HTMLAnchorElement)) return;
      const url = new URL(anchor.href, window.location.href);
      if (url.origin === window.location.origin && url.pathname === window.location.pathname
        && specialisms.some(item => '#'+item.id === url.hash)) setActive(url.hash.slice(1));
    };
    document.addEventListener('click', onClick);
    return () => { window.removeEventListener('hashchange', followHash); document.removeEventListener('click', onClick); };
  }, []);
  return <section id="performance-engineering" className="performance-engineering scroll-mt-24">
    <div className="engineering-intro"><p className="overview-eyebrow">PERFORMANCE ENGINEERING</p><h2>中间件与热点账户优化</h2><p>定位等待发生在哪里，减少真正的串行工作；用资金正确性与故障恢复验证每一项优化。</p><a href="#settlement-optimization">结算性能已独立成篇：查看资金事务、故障测试与验收证据 →</a></div>
    <div className="engineering-evidence"><CheckCircle2 size={20} /><div><strong>实现与验证范围</strong><p>路由与工具测试不替代容量认证。公共账户争用、归集与多实例扩容仍需独立验证；尚无这些方案的持续容量数据。结算实现与测试见独立章节。</p></div><a href="/performance/VERIFICATION.md" target="_blank" rel="noreferrer">验证记录 <ArrowRight size={16} /></a></div>
    <PerformanceTopology />
    <Tabs value={active} onValueChange={value => { setActive(String(value)); window.history.replaceState(null, '', '#'+value); }}>
      <TabsList className="engineering-tabs">{specialisms.map(item => <TabsTrigger key={item.id} value={item.id} id={item.id}>{item.title}</TabsTrigger>)}</TabsList>
      {specialisms.map(item => <TabsContent value={item.id} key={item.id}>
        <div className="engineering-question"><span>真实问题</span><h3>{item.question}</h3><p>{item.subtitle}</p></div>
        <div className="engineering-current"><strong>当前代码事实</strong><p>{item.current}</p></div>
        <div className="engineering-diagnosis">{item.diagnosis.map(([title, description]) => <article key={title}><h4>{title}</h4><p>{description}</p></article>)}</div>
        <div className="engineering-work"><div><h3>从诊断到实施</h3><ol>{item.steps.map(([title, detail], i) => <li key={title}><span>{i + 1}</span><div><h4>{title}</h4><p>{detail}</p></div></li>)}</ol></div><aside><h3>诊断与约束</h3><pre><code>{item.code}</code></pre><h4>验收条件</h4><p>{item.acceptance}</p></aside></div>
        <div className="engineering-boundary"><strong>尚未完成 / 不能夸大的边界</strong><p>{item.boundary}</p></div>
        <HandbookReader file={item.file} />
      </TabsContent>)}
    </Tabs>
    <div className="engineering-experiments"><h3>三组可运行的账户分布对照</h3><div className="engineering-scenarios">
      {[['shared-fee', '独立付款 / 收款 + 公共费用', '找出共同费用行的影响'], ['sharded-fee', '独立付款 / 收款 + 16 费用分片', '观察费用写入分散后的变化'], ['hot-payer', '公共付款 + 独立收款 + 16 分片', '识别尚未消失的付款方热点']].map(([key, title, purpose]) => <article key={key}><code>{key}</code><h4>{title}</h4><p>{purpose}</p></article>)}
    </div><p>默认只生成计划、零网络请求。实际执行仅限独立本地实验环境；有限闭环对照不等于持续容量认证。核账不可用标为未核实，不误报资金不平。</p><div className="engineering-downloads"><a href="/performance/compose.isolated.yml" download>下载隔离环境配置</a><a href="/performance/settlement-comparison.mjs" download><FileCode2 size={17} /> 下载对照工具</a><a href="/performance/settlement-comparison.test.mjs" download><Download size={17} /> 下载协议测试</a></div><HandbookReader file="tool-guide.md" /></div>
  </section>;
}

function PerformanceTopology() {
  const nodes = [['请求 / 成交', '稳定业务键'], ['Kafka', '分区与积压'], ['Consumer', 'Lease / Fence'], ['Hikari', '连接与等待'], ['资金事务', '账户锁 / COMMIT']];
  return <figure className="performance-topology"><figcaption>优化全景：每个资源边界分别观察，资金结果统一核对</figcaption><p className="topology-note">通用结算请求由 API 发往 Kafka；现货成交先在撮合事务写入 SPOT_DVP_REQUESTED Outbox，再可靠发布到 Kafka。下图聚焦两条路径汇合后的结算资源边界。</p><div className="topology-scroll"><svg viewBox="0 0 1020 235" role="img" aria-label="请求到Kafka、Consumer、连接池和资金事务，事务原子写账本与Outbox，热点归集另受共享账户约束">
    <defs><marker id="perf-edge" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#59799e" /></marker></defs>
    {nodes.map(([title, detail], i) => <g key={title}><rect x={20+i*200} y={24} width="170" height="70" rx="10" fill="#f0f6ff" stroke="#afc8e7" /><text x={105+i*200} y={53} textAnchor="middle" fill="#203e64" fontSize="17" fontWeight="600">{title}</text><text x={105+i*200} y={77} textAnchor="middle" fill="#58718d" fontSize="13">{detail}</text>{i<4&&<path d={`M${190+i*200},59 H${216+i*200}`} stroke="#59799e" strokeWidth="1.5" markerEnd="url(#perf-edge)" />}</g>)}
    <path d="M905,94 V128 H702 V153 M905,128 H905 V153" fill="none" stroke="#59799e" strokeWidth="1.5" markerEnd="url(#perf-edge)" />
    <rect x="600" y="157" width="200" height="56" rx="8" fill="#edf8f4" stroke="#9dcfbd" /><text x="700" y="190" textAnchor="middle" fill="#246451" fontSize="16">账本 / 余额 / Inbox</text>
    <rect x="820" y="157" width="170" height="56" rx="8" fill="#f0effc" stroke="#b6b0de" /><text x="905" y="190" textAnchor="middle" fill="#534b8d" fontSize="16">Outbox → 通知</text>
    <text x="24" y="156" fill="#526b86" fontSize="14">共享写点：费用账户 · 大户余额 · 公共池 · 财资归集</text><text x="24" y="184" fill="#526b86" fontSize="14">共同门槛：唯一效果 · 逐资产平衡 · 可恢复 · 不丢未知</text>
  </svg></div></figure>;
}

export function HandbookReader({ file }: { file: string }) {
  const [content, setContent] = useState(''); const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<'idle'|'loading'|'error'>('idle');
  async function read() {
    if (content) { setOpen(!open); return; }
    setStatus('loading');
    try {
      const response = await fetch(`/performance/${file}`, { signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error('unavailable');
      const text = await response.text();
      if (!text.startsWith('# ')) throw new Error('invalid document');
      setContent(text); setOpen(true); setStatus('idle');
    } catch { setStatus('error'); }
  }
  return <div className="handbook-reader"><div className="handbook-actions"><Button onClick={read} disabled={status==='loading'} variant="outline" aria-expanded={open}><BookOpen size={16} />{status==='loading'?'正在读取完整手册…':open?'收起完整手册':'在本页展开完整手册、SQL 与故障案例'}</Button><a href={`/performance/${file}`} download><Download size={16} /> 下载 Markdown</a></div>{status==='error'&&<p role="alert">手册暂时无法读取，请重试；也可使用下载链接查看。</p>}{open&&<div className="handbook-text"><ReadableMarkdown text={content} file={file} /></div>}</div>;
}

/** 仅渲染文本结构，不执行 HTML、脚本或 Mermaid；图示定义可展开核对。 */
function ReadableMarkdown({ text, file }: { text: string; file: string }) {
  const lines=text.split('\n'); const blocks:ReactNode[]=[];
  for(let i=0;i<lines.length;i++) {
    const line=lines[i]; if(!line.trim())continue;
    if(line.startsWith('```')) { const language=line.slice(3); const code:string[]=[]; while(++i<lines.length&&!lines[i].startsWith('```'))code.push(lines[i]); const block=<pre key={i}><code>{code.join('\n')}</code></pre>;blocks.push(language==='mermaid'?<details key={i}><summary>查看本节图示定义（Mermaid）</summary>{block}</details>:block);continue; }
    if(line.startsWith('|')) { const rows:string[][]=[]; do { if(!/^\|[\s:|-]+\|$/.test(lines[i]))rows.push(lines[i].split('|').slice(1,-1).map(cell=>cell.trim())); i++; }while(i<lines.length&&lines[i].startsWith('|'));i--;blocks.push(<div key={i} className="handbook-table"><table><thead><tr>{rows[0].map((c,j)=><th key={j}>{inline(c,file)}</th>)}</tr></thead><tbody>{rows.slice(1).map((row,j)=><tr key={j}>{row.map((c,k)=><td key={k}>{inline(c,file)}</td>)}</tr>)}</tbody></table></div>);continue; }
    const heading=line.match(/^(#{1,6}) (.*)$/);if(heading){blocks.push(heading[1].length<=2?<h3 key={i}>{inline(heading[2],file)}</h3>:<h4 key={i}>{inline(heading[2],file)}</h4>);continue;}
    blocks.push(<p key={i} className={/^(\d+\.|-) /.test(line)?'handbook-list-item':undefined}>{inline(line,file)}</p>);
  }
  return blocks;
}
function inline(text:string,file:string):ReactNode[] {
  return text.split(/(\[[^\]]+\]\([^)]+\)|`[^`]+`|\*\*[^*]+\*\*)/g).filter(Boolean).map((part,i)=>{
    const link=part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if(link){
      const base=file==='tool-guide.md'?'scripts/performance/README.md':`docs/performance/${file}`;
      const url=new URL(link[2],`https://repo.invalid/${base}`);
      const localAssets: Record<string,string> = {
        '/docs/performance/README.md':'README.md',
        '/docs/performance/middleware-optimization-playbook.md':'middleware-optimization-playbook.md',
        '/docs/performance/hot-account-optimization-playbook.md':'hot-account-optimization-playbook.md',
        '/docs/performance/settlement-performance-playbook.md':'settlement-performance-playbook.md',
        '/docs/performance/settlement-completion.md':'settlement-completion.md',
        '/docs/performance/VERIFICATION.md':'VERIFICATION.md',
        '/scripts/performance/README.md':'tool-guide.md',
        '/scripts/performance/settlement-comparison.mjs':'settlement-comparison.mjs',
        '/scripts/performance/settlement-comparison.test.mjs':'settlement-comparison.test.mjs',
        '/scripts/performance/settlement-database-audit.mjs':'settlement-database-audit.mjs',
        '/scripts/performance/settlement-database-audit.test.mjs':'settlement-database-audit.test.mjs',
        '/infra/performance/compose.isolated.yml':'compose.isolated.yml',
        '/infra/performance/01-audit-role.sql':'01-audit-role.sql',
      };
      if(url.protocol!=='https:')return link[1];
      const href=url.hostname!=='repo.invalid'?url.href:localAssets[url.pathname]?`/performance/${localAssets[url.pathname]}`:`https://github.com/soldierking04d/fincore-reliability-lab/blob/main${url.pathname}${url.hash}`;
      return <a key={i} href={href} target="_blank" rel="noreferrer">{link[1]}</a>;
    }
    if(part.startsWith('`'))return <code key={i}>{part.slice(1,-1)}</code>;
    if(part.startsWith('**'))return <strong key={i}>{part.slice(2,-2)}</strong>;
    return part;
  });
}
