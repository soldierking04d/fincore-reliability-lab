'use client';

import { useEffect, useRef, useState } from 'react';
import { visitorEventId, visitorPage, visitorReferrer } from '@/lib/visitor-analytics';

const preferenceKey = 'fincore-visit-opt-out';

export function VisitorAnalytics() {
  const [optedOut, setOptedOut] = useState(false);
  const disabledRef = useRef(false);
  useEffect(() => {
    // 只对当前腾讯云站点上报；本机开发、旧展示域和预览均不收集。
    if (location.hostname !== '124.223.164.254') return;
    const privacyRequested = navigator.doNotTrack === '1'
      || (navigator as Navigator & { globalPrivacyControl?: boolean }).globalPrivacyControl === true;
    let disabled = privacyRequested;
    try { disabled ||= localStorage.getItem(preferenceKey) === '1'; } catch { disabled = true; }
    setOptedOut(disabled);
    disabledRef.current = disabled;
    if (disabled) return;
    let lastPage = '';
    let count = 0;
    let timer: ReturnType<typeof setTimeout>;
    const send = () => {
      if (disabledRef.current || document.visibilityState !== 'visible' || count >= 20) return;
      try { if (localStorage.getItem(preferenceKey) === '1') return; } catch { return; }
      const pagePath = visitorPage(document.getElementById(location.hash.slice(1)) ? location.hash : '');
      if (pagePath === lastPage) return;
      lastPage = pagePath;
      count += 1;
      // 不带 Cookie，不传原始来源，不重试；统计失败不会打断浏览或交易演示。
      void fetch('/api/analytics/page-view', {
        method: 'POST', credentials: 'omit', keepalive: true, referrerPolicy: 'no-referrer',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: visitorEventId(), pagePath, referrerOrigin: visitorReferrer(document.referrer) }),
        signal: AbortSignal.timeout(3000),
      }).catch(() => {});
    };
    const schedule = () => { clearTimeout(timer); timer = setTimeout(send, 1000); };
    schedule();
    window.addEventListener('hashchange', schedule);
    document.addEventListener('visibilitychange', schedule);
    return () => { clearTimeout(timer); window.removeEventListener('hashchange', schedule); document.removeEventListener('visibilitychange', schedule); };
  }, []);

  return <aside className="pb-6 text-sm leading-6 text-slate-600" aria-label="访问统计说明">
    <p>访问统计：记录 IP、访问时间、公开页面、来源域名和浏览器信息，默认保留 30 天，仅供站点管理者查看；不使用跟踪 Cookie，不记录搜索参数。</p>
    <button type="button" disabled={optedOut} className="underline underline-offset-4 disabled:no-underline"
      onClick={() => { disabledRef.current = true; setOptedOut(true); try { localStorage.setItem(preferenceKey, '1'); } catch { /* 本次页面立即停止；浏览器禁用存储时无法持久化偏好。 */ } }}>
      {optedOut ? '已停止记录后续访问（也尊重浏览器隐私偏好）' : '停止记录我的后续访问'}
    </button>
  </aside>;
}
