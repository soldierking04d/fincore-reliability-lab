'use client';

import { useState } from 'react';
import { ArrowRight, BookOpen, Check, FileText, MessageSquare, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { RequirementsAiLab } from '@/components/requirements-ai-lab';
import { DeveloperAiDelivery } from '@/components/developer-ai-delivery';
import {
  conditions, estimateValue, examples, nextStep, recordFeedback, startSession,
  type Condition, type UseCase,
} from '@/lib/ai-company-workflow';

const sourceRoot='https://github.com/soldierking04d/fincore-reliability-lab/blob/main/';
const buttonClass='min-h-11 h-auto whitespace-normal px-4 py-2.5 text-sm';
const kicker='font-mono text-xs tracking-widest text-cyan-300/70';
const stepNames=['收到问题','找到资料','整理草稿','核对后使用'];

/** 展示普通公司需求的收益与代价，所有交互都调用确定性教学规则，不伪装成已接入模型。 */
export function AiCompanyDelivery() {
  return <><DeveloperAiDelivery/><details className="mt-6 rounded-xl border border-white/10 p-5"><summary className="cursor-pointer py-2 text-base text-slate-300">补充：内部需求澄清与测试设计</summary><RequirementsAiLab/></details><details className="mt-6 rounded-xl border border-white/10 p-5"><summary className="cursor-pointer py-2 text-base text-slate-300">补充：其他日常 AI 场景</summary><OtherAiExamples/></details></>;
}

function OtherAiExamples() {
  const [session,setSession]=useState(()=>startSession());
  const [editNote,setEditNote]=useState('');
  const [adoption,setAdoption]=useState(70);
  const [usable,setUsable]=useState(90);
  const selected=examples.find(e=>e.id===session.useCase)!;
  const stageIndex=({input:0,retrieved:1,drafted:2,ready:3,blocked:3,feedback:3})[session.stage];
  const value=estimateValue(adoption,usable);
  function reset(useCase:UseCase=session.useCase,condition:Condition=session.condition){setSession(startSession(useCase,condition));setEditNote('');}
  const nextLabel=({input:'1. 找相关资料',retrieved:'2. 整理候选草稿',drafted:'3. 检查来源与内容'})[session.stage as 'input'|'retrieved'|'drafted'];
  return <div className="mt-7 space-y-6 text-base leading-7">
    <section className="rounded-2xl border border-cyan-300/20 bg-[#0b1b25] p-5 md:p-7">
      <p className={kicker}>EVERYDAY AI · 从日常工作开始</p>
      <h3 className="mt-3 text-2xl font-semibold text-white md:text-3xl">查找、复核和返工，<br className="hidden md:block"/>都要计入总成本</h3>
      <p className="mt-4 max-w-4xl text-slate-300">先看三类常见需求，从重复多、资料有依据、结果容易检查的环节开始试用。</p>
      <div className="mt-5 grid gap-3 lg:grid-cols-3">{examples.map((e,i)=>{
        const Icon=[MessageSquare,BookOpen,FileText][i];
        return <Button key={e.id} variant="outline" aria-pressed={e.id===selected.id} onClick={()=>reset(e.id)} className={`h-auto min-h-28 justify-start whitespace-normal rounded-xl p-4 text-left ${e.id===selected.id?'border-cyan-300/50 bg-cyan-300/10':'bg-black/15'}`}><div><div className="flex items-center gap-2 text-base font-medium text-white"><Icon className="size-5 text-cyan-300"/>{e.title}</div><p className="mt-2 text-sm font-normal leading-6 text-slate-400">{e.before}</p><p className="mt-2 text-sm text-cyan-200">{e.id===selected.id?'正在演示':'查看这个场景'} →</p></div></Button>;
      })}</div>
      <p className="mt-4 text-sm text-slate-400">下面使用虚构资料与固定候选演示流程，未接入真实模型或公司系统。不会上传输入或发送消息；当前模型调用、Token 和模型费用均为 0。</p>
    </section>

    <section className="explain-panel !p-5 md:!p-7" aria-labelledby="everyday-ai-demo">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><p className={kicker}>01 / 一次完整的日常使用</p><h3 id="everyday-ai-demo" className="mt-2 text-xl font-semibold text-white">{selected.title}：从问题到可用草稿</h3></div><Button variant="outline" className={buttonClass} onClick={()=>reset()}><RotateCcw className="size-4"/>重新演示</Button></div>
      <blockquote className="mt-5 rounded-xl border-l-2 border-cyan-300/70 bg-cyan-300/5 px-5 py-4 text-lg leading-8 text-slate-100">“{selected.question}”</blockquote>
      <div className="mt-4 flex flex-wrap gap-2" aria-label="演示条件">{conditions.map(c=><Button key={c.id} variant={session.condition===c.id?'default':'outline'} className={buttonClass} aria-pressed={session.condition===c.id} onClick={()=>reset(session.useCase,c.id)} title={c.effect}>{c.label}</Button>)}</div>
      <ol className="mt-5 grid grid-cols-2 gap-2 lg:grid-cols-4">{stepNames.map((s,i)=><li key={s} aria-current={i===stageIndex?'step':undefined} className={`rounded-lg border px-3 py-2 text-sm ${i===stageIndex?'border-cyan-300/40 bg-cyan-300/10 text-cyan-100':i<stageIndex?'border-emerald-300/20 text-emerald-200':'border-white/10 text-slate-400'}`}>{i+1}. {s}</li>)}</ol>
      <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_1.2fr]">
        <div className="rounded-xl border border-white/10 bg-black/15 p-4">
          <p className="text-sm text-cyan-200">依据是什么？</p>
          {session.stage==='input'?<p className="mt-3 text-slate-400">先在公司获准的资料中查找。客服帮助说明、内部流程、需求纪要不能靠模型凭记忆编造。</p>:session.sources.length===0?<p className="mt-3 text-amber-200">没有找到相关资料，请负责人补充。</p>:<div className="mt-3 space-y-3">{session.sources.map(d=><article key={d.id} className="rounded-lg border border-white/10 p-3"><div className="flex flex-wrap items-center justify-between gap-2"><h4 className="text-sm font-medium text-slate-100">{d.id} · {d.title}</h4><span className={`text-xs ${d.current?'text-emerald-300':'text-amber-200'}`}>{d.version} · {d.current?'有效':'已过期'}</span></div><ul className="mt-2 space-y-1 text-sm leading-6 text-slate-400">{d.points.map(p=><li key={p.id}>{p.text}</li>)}</ul></article>)}</div>}
          <p className="mt-4 text-sm text-slate-500">本演示是固定资料召回，不是已部署的向量检索。公司落地时应保留来源、负责人、版本与更新日期。</p>
        </div>
        <div className={`rounded-xl border p-4 ${session.stage==='blocked'?'border-amber-300/30 bg-amber-300/5':'border-cyan-300/20 bg-cyan-300/5'}`} aria-live="polite">
          <p className="text-sm text-cyan-200">整理结果与下一步</p>
          <p className="mt-3 text-slate-200">{session.message}</p>
          {(session.stage==='ready'||(session.stage==='feedback'&&session.feedback!=='manual'))&&<div className="mt-4 space-y-3">{session.candidate.map(p=><p key={p.pointId} className="text-slate-100">{p.text} <span className="font-mono text-xs text-cyan-300">[{p.sourceId}]</span></p>)}<div className="border-t border-white/10 pt-3"><p className="text-sm font-medium text-amber-200">仍需确认 / 不应擅自下结论</p>{selected.unknowns.map(t=><p key={t} className="mt-2 text-sm text-slate-300">{t}</p>)}</div></div>}
          {session.stage==='drafted'&&<p className="mt-3 text-sm text-slate-400">候选已生成，先检查再使用。若选了“擅自做承诺”，下一步会拒绝该预置错误。</p>}
          {nextLabel&&<Button className={`${buttonClass} mt-5`} onClick={()=>setSession(s=>nextStep(s))}>{nextLabel}<ArrowRight className="size-4"/></Button>}
          {session.stage==='ready'&&<div className="mt-5 space-y-3"><label htmlFor="ai-edit-note" className="block text-sm text-slate-300">需要改哪里？（选“修改后采用”时填写，仅本页内存）</label><Textarea id="ai-edit-note" value={editNote} onChange={e=>setEditNote(e.target.value)} maxLength={500} placeholder="例如：回复太长，改成三步；补充客服需要记录的发生时间。" className="min-h-20 text-base"/><div className="flex flex-wrap gap-2"><Button className={buttonClass} onClick={()=>setSession(s=>recordFeedback(s,'adopted'))}><Check className="size-4"/>可直接采用</Button><Button variant="outline" className={buttonClass} onClick={()=>setSession(s=>recordFeedback(s,'edited',editNote))}>修改后采用</Button><Button variant="outline" className={buttonClass} onClick={()=>setSession(s=>recordFeedback(s,'manual'))}>转人工</Button></div></div>}
          {session.stage==='blocked'&&<Button variant="outline" className={`${buttonClass} mt-4`} onClick={()=>setSession(s=>recordFeedback(s,'manual'))}>记录问题，转人工继续</Button>}
          {session.feedback&&<p className="mt-4 rounded-lg bg-black/20 p-3 text-sm text-cyan-100">本次反馈：{({adopted:'直接采用',edited:'修改后采用',manual:'转人工'})[session.feedback]}{session.editNote&&`。修改说明：${session.editNote}`}。此处只记录教学选择，不表示真实业务完成。</p>}
        </div>
      </div>
      <p className="mt-4 text-sm text-slate-400">真实 AI 的价值在于理解不同问法、整理分散资料和组织文字。来源是否有效、答案是否可靠、员工是否愿意用，仍需真实模型试点验证；本演示不把模板结果当模型成绩。</p>
    </section>

    <section className="grid gap-4 lg:grid-cols-2">
      <div className="explain-panel !p-5 md:!p-7"><p className={kicker}>02 / 可以带来的收益</p><h3 className="mt-2 text-xl font-semibold text-white">减少重复劳动，不替代业务判断</h3><p className="mt-3 text-emerald-200">{selected.benefit}</p><ul className="mt-4 space-y-3 text-slate-300"><li>少翻资料：把多个文档里的信息集中到一个可核对的答案。</li><li>少写重复文字：先生成草稿，人把精力留给特殊情况。</li><li>降低新人上手成本：常见规则和流程更容易找到。</li><li>暴露流程缺口：反复答不好的问题，提示文档或需求本身不清楚。</li></ul></div>
      <div className="explain-panel !p-5 md:!p-7"><p className="font-mono text-xs tracking-widest text-amber-200/80">同时付出的代价</p><h3 className="mt-2 text-xl font-semibold text-white">“写得快”可能把工作推给检查的人</h3><p className="mt-3 text-amber-200">{selected.downside}</p><ul className="mt-4 space-y-3 text-slate-300"><li>一本正经地说错：统一回复也可能统一放大错误。</li><li>新增维护工作：更新资料、检查结果、处理反馈都要有人做。</li><li>过度依赖：员工不再核对来源，边界需求被“自动补全”。</li><li>隐私与供应商风险：输入范围、服务故障、版本和价格变化需要管理。</li></ul></div>
    </section>

    <section className="explain-panel !p-5 md:!p-7">
      <p className={kicker}>03 / 怎样接入现有工作</p><h3 className="mt-2 text-xl font-semibold text-white">先把资料和流程整理好，模型只是中间一步</h3>
      <div className="mt-5 overflow-x-auto rounded-xl border border-white/10 bg-black/15">
        <svg viewBox="0 0 1050 242" aria-labelledby="everyday-ai-architecture-title" className="block min-w-[850px] w-full">
          <title id="everyday-ai-architecture-title">日常 AI 辅助参考架构：工作台到资料检索、模型草稿、人工使用；反馈回到知识维护</title>
          <defs><marker id="everyday-ai-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#67e8f9"/></marker></defs>
          {[['现有工作入口','客服台 / 内部搜索 / 研发工具'],['获准资料检索','范围、版本、来源'],['模型组织草稿','整理文字，不补事实'],['人工核对使用','采用 / 修改 / 转人工']].map(([title,desc],i)=><g key={title}><rect x={20+i*260} y="25" width="230" height="95" rx="12" fill="#0b1c28" stroke="#286371"/><text x={135+i*260} y="62" textAnchor="middle" fill="#e2edf3" fontSize="17">{title}</text><text x={135+i*260} y="91" textAnchor="middle" fill="#91a8b6" fontSize="14">{desc}</text>{i<3&&<path d={`M${250+i*260} 72H${276+i*260}`} stroke="#67e8f9" strokeWidth="2" markerEnd="url(#everyday-ai-arrow)"/>}</g>)}
          <path d="M915 120V171H395V124" fill="none" stroke="#67e8f9" strokeWidth="2" strokeDasharray="6 5" markerEnd="url(#everyday-ai-arrow)"/>
          <text x="650" y="197" textAnchor="middle" fill="#a5bcc9" fontSize="15">反馈错误 / 缺资料 / 返工 → 每周更新知识与验收样本</text>
          <text x="23" y="225" fill="#718997" fontSize="13">参考集成方案。当前页面只运行合成资料、固定候选与反馈演示；真实接口和模型尚未接入。</text>
        </svg>
      </div>
      <div className="mt-5 grid gap-4 md:grid-cols-3">{[
        ['业务负责人','选一个高频小问题，说明什么叫答对；记录原来花多少时间、谁来维护资料。'],
        ['产品与研发','把助手放在原工作入口；接入获准文档，显示引用、无答案提示和反馈，不强迫员工换一套流程。'],
        ['执行团队','先检查再采用；每周把错误与重复修改交回资料负责人，确认是在省时间还是制造返工。'],
      ].map(([title,text])=><div key={title}><h4 className="font-medium text-slate-100">{title}</h4><p className="mt-2 text-slate-400">{text}</p></div>)}</div>
      <p className="mt-5 rounded-lg bg-white/3 px-4 py-3 text-sm text-slate-300">简单规则能解决，就用规则；文档搜索已经够用，就先把搜索做好。问法变化多、资料分散、整理文字耗时，才更适合引入模型。</p>
    </section>

    <section className="explain-panel !p-5 md:!p-7">
      <p className={kicker}>04 / 收益要减掉返工和维护</p><h3 className="mt-2 text-xl font-semibold text-white">两种假设，看看什么时候值得做</h3><p className="mt-3 text-slate-400">以普通客服辅助为例：每月 2,000 个问题，60% 适用；纯人工 8 分钟，可用草稿仍需 3 分钟检查，25% 再返工 2 分钟；不可用时多花 1 分钟，再走原人工流程。</p>
      <div className="mt-5 grid gap-5 lg:grid-cols-[1.15fr_1fr]"><div><div className="flex flex-wrap gap-2"><Button variant={adoption===70&&usable===90?'default':'outline'} className={buttonClass} onClick={()=>{setAdoption(70);setUsable(90);}}>采用较顺利：70% / 90%</Button><Button variant={adoption===40&&usable===60?'default':'outline'} className={buttonClass} onClick={()=>{setAdoption(40);setUsable(60);}}>采用差、返工多：40% / 60%</Button></div><p className="mt-3 text-sm text-slate-400">前者是适用问题的采用率，后者是采用后得到可用结果的比例；转人工与失败都保留在分母里。</p><details className="mt-4"><summary className="cursor-pointer py-2 text-sm text-cyan-200">查看完整成本假设和公式</summary><p className="mt-2 text-sm text-slate-400">人力 ¥100/小时；变动 ¥0.20/次；平台 ¥500/月；维护 8 小时/月；建设 ¥12,000 分摊 12 个月。每月价值差 = 净释放工时 × 人力成本 − 变动成本 − 平台与维护 − 建设分摊。</p></details><p className="mt-4 text-sm text-amber-200/80">这些是教学假设，不是公司的实测成绩或供应商报价。释放工时是可重新安排的时间，不等于节省了同额现金。</p></div><div className="rounded-xl border border-white/10 bg-black/20 p-5" aria-live="polite"><p className="text-sm text-slate-400">含维护与建设分摊的月度机会价值差</p><p className={`mt-3 font-mono text-4xl ${value.net<0?'text-amber-200':'text-emerald-200'}`}>{value.net<0?'−':'+'}¥{Math.abs(value.net).toLocaleString('en-US')}</p><dl className="mt-4 space-y-2 text-sm"><div className="flex justify-between"><dt>采用问题</dt><dd>{value.used} 个</dd></div><div className="flex justify-between"><dt>净释放工时</dt><dd>{value.hours.toFixed(1)} 小时</dd></div><div className="flex justify-between"><dt>工时机会价值</dt><dd>¥{value.value.toFixed(0)}</dd></div><div className="flex justify-between"><dt>变动 + 平台维护 + 建设</dt><dd>¥{value.variable.toFixed(0)} + ¥1,300 + ¥1,000</dd></div></dl><p className="mt-4 text-sm text-slate-300">{value.net<0?'这组假设不值得继续扩大：先降低返工、缩小范围，必要时回到模板或人工。':'这组假设值得小范围验证，不能直接当成收益承诺。'}</p></div></div>
    </section>

    <section className="explain-panel !p-5 md:!p-7">
      <p className={kicker}>05 / 两周小试点，不先铺满全公司</p><h3 className="mt-2 text-xl font-semibold text-white">先证明有用，再决定扩大还是停下</h3>
      <div className="mt-5 grid gap-4 md:grid-cols-3">{[
        ['第 1–3 天：记清现状','选一种高频问题，抽取脱敏样本；统计人工用时、常见错误与资料缺口，指定维护人。'],
        ['第 4–7 天：小样本对照','先比较“原人工 / 搜索与模板 / AI 草稿”；同类问题核对正确性、完整性与复核时间。'],
        ['第 2 周：少量员工试用','保留人工入口，记录采用、修改、转人工、总用时、调用及维护成本；周末决定继续、改进或退出。'],
      ].map(([title,text])=><div key={title} className="rounded-xl border border-white/10 p-4"><h4 className="font-medium text-slate-100">{title}</h4><p className="mt-3 text-slate-400">{text}</p></div>)}</div>
      <p className="mt-5 text-slate-300">继续的依据：同类问题的总处理时间下降，答案质量不下降，员工愿意用，维护成本可承担。停止或缩小的信号：改答案比重写还慢、关键问题反复答错、资料没人更新。</p>
      <p className="mt-3 text-sm text-slate-400">两周是观察起点，不是安全认证。公司接入前仍需确认可用资料范围、个人信息处理和供应商条款；外部发送或执行操作走原有流程。</p>
    </section>
    <div className="flex flex-wrap gap-3 text-sm"><a className="nav-link inline-flex min-h-11" href={`${sourceRoot}docs/management/detailed/16-ai-company-delivery-casebook.md`} target="_blank" rel="noreferrer">日常需求落地完整说明 <ArrowRight className="size-4"/></a><a className="nav-link inline-flex min-h-11" href={`${sourceRoot}ai/company-workflow.ts`} target="_blank" rel="noreferrer">演示代码与边界 <ArrowRight className="size-4"/></a><a className="nav-link inline-flex min-h-11" href={`${sourceRoot}ai/company-workflow.test.ts`} target="_blank" rel="noreferrer">可重复测试 <ArrowRight className="size-4"/></a></div>
  </div>;
}
