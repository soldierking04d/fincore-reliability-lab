'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

/** 延续旧锚点：从外部链接或目录进入时先展开对应专题，再定位原内容。 */
export function KnowledgeChapter({ title, description, number, children }: {
  title: string; description: string; number: string; children: ReactNode;
}) {
  const [value, setValue] = useState<string[]>([]);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function reveal(hash: string) {
      let id: string;
      try { id = decodeURIComponent(hash.replace(/^#/, '')); } catch { return; }
      if (!id) return;
      const target = document.getElementById(id);
      if (!target || !ref.current?.contains(target)) return;
      setValue(['content']);
      if (target instanceof HTMLDetailsElement) target.open = true;
      // 滚动页面而非折叠面板，避免 overflow:hidden 的祖先截断深层锚点定位。
      window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
        const headerHeight = document.querySelector('.site-header')?.getBoundingClientRect().height ?? 80;
        window.scrollTo({ top: window.scrollY + target.getBoundingClientRect().top - headerHeight - 24, behavior: 'instant' });
      }));
    }
    const onHash = () => reveal(window.location.hash);
    const onClick = (event: MouseEvent) => {
      if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (!(anchor instanceof HTMLAnchorElement)) return;
      const url = new URL(anchor.href, window.location.href);
      if (url.origin === window.location.origin && url.pathname === window.location.pathname && url.hash) reveal(url.hash);
    };
    onHash();
    window.addEventListener('hashchange', onHash);
    document.addEventListener('click', onClick);
    return () => { window.removeEventListener('hashchange', onHash); document.removeEventListener('click', onClick); };
  }, []);
  return <div className="knowledge-chapter" ref={ref}>
    <Accordion value={value} onValueChange={next => setValue(next as string[])}>
      <AccordionItem value="content">
        <AccordionTrigger className="chapter-trigger">
          <span className="chapter-index">{number}</span>
          <span className="chapter-title-group"><strong>{title}</strong><span>{description}</span></span>
          <span className="chapter-expand-label">{value.length ? '收起' : '展开内容'}</span>
        </AccordionTrigger>
        <AccordionContent keepMounted className="chapter-body">{children}</AccordionContent>
      </AccordionItem>
    </Accordion>
  </div>;
}
