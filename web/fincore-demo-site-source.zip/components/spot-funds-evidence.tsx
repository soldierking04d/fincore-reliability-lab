import type { LifecycleReport } from '@/lib/scenario-contract';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

/** 只渲染完整后台报告；不使用教学样本或预设数字替代实测资金。 */
export function SpotFundsEvidencePanel({ report }: { report: LifecycleReport }) {
  const f = report.funds;
  const amounts = [
    ['挂单预占', f.reservedForCancel, f.quoteAsset],
    ['挂单时可用', f.availableWhileReserved, f.quoteAsset],
    ['撤单后可用', f.availableAfterCancel, f.quoteAsset],
    ['交割后在途', f.pendingDebit, f.quoteAsset],
  ] as const;
  return <section className="mt-5 space-y-5 rounded-xl border border-emerald-300/20 bg-emerald-300/5 p-4 sm:p-6" aria-label="本次模拟资金交割证据">
    <div><p className="text-sm text-emerald-300">本次后台证据 · {Object.keys(report.checks).length} 项检查全部通过</p>
      <h4 className="mt-2 text-xl font-semibold text-white">成交之外，钱和资产也已经交付</h4>
      <p className="mt-2 break-all text-sm leading-6 text-slate-400">运行 {report.runId} · 成交 {f.tradeId}<br />交割完成 {f.settledAt}</p>
    </div>
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">{amounts.map(([label, value, unit]) =>
      <div key={label} className="rounded-lg border border-white/10 bg-black/15 p-4"><p className="text-sm text-slate-400">{label}</p>
        <p className="mt-2 font-mono text-2xl text-white">{value.toLocaleString()} <span className="text-sm text-slate-400">{unit}</span></p></div>)}</div>
    <p className="text-sm leading-6 text-slate-300">本次实验先完成一笔买入，再挂出未成交订单，核对预占后连续撤单两次。撤单只返还一次未成交资金；已经成交的在途资金由 Kafka Worker 完成双资产交割。</p>
    <Table className="text-sm"><TableHeader><TableRow><TableHead>交割后的模拟账户</TableHead><TableHead>{f.quoteAsset}</TableHead><TableHead>{f.baseAsset}</TableHead></TableRow></TableHeader>
      <TableBody><TableRow><TableCell>买方</TableCell><TableCell>{f.buyerQuoteBalance.toLocaleString()}</TableCell><TableCell>{f.buyerBaseBalance.toLocaleString()}</TableCell></TableRow>
        <TableRow><TableCell>卖方</TableCell><TableCell>{f.sellerQuoteBalance.toLocaleString()}</TableCell><TableCell>{f.sellerBaseBalance.toLocaleString()}</TableCell></TableRow></TableBody></Table>
    <p className="text-sm text-emerald-200">{f.deliveryStatus} · {f.reconciledAccounts} 个账户完成总余额、预占、在途和账本核对。</p>
    <ul className="grid gap-3 lg:grid-cols-2">{Object.entries(report.checks).map(([key, value]) =>
      <li key={key} className="rounded-lg bg-black/10 p-3 text-sm leading-6"><strong className="text-emerald-200">{key}</strong><p className="text-slate-400">{value}</p></li>)}</ul>
  </section>;
}
