'use client';

import {
  Activity,
  ArrowRight,
  BadgeCheck,
  Blocks,
  Check,
  CircleDollarSign,
  DatabaseZap,
  ExternalLink,
  FileClock,
  KeyRound,
  Play,
  RadioTower,
  RefreshCw,
  Scale,
  Siren,
  WalletCards,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useScenarioRun } from '@/hooks/use-scenario-run';
import {
  parseExchangeCoverageReport,
  type ExchangeCoverageReport,
  type ExchangeDomainReport,
} from '@/lib/scenario-contract';

const repository = 'https://github.com/soldierking04d/fincore-reliability-lab';

const domains = {
  marketData: {
    group: 'core', icon: RadioTower, title: '行情完整性',
    question: '隔离丢包、乱序、多源分歧和慢消费者对交易决策的影响',
    evidence: '序号缺口 → STALE → 快照+增量恢复；异常源剔除；缓冲有界',
    boundary: '真实 Feed、SBE/Aeron、ITCH/OUCH 与多播仍需专项接入',
  },
  orderSemantics: {
    group: 'core', icon: Blocks, title: '完整订单语义',
    question: '定义 IOC、FOK、Post-only、STP 和撤改单部分成功的结果契约',
    evidence: 'IOC 余量取消；FOK 全成或全拒；撤单与新单保留两个结果',
    boundary: '条件单持久化与生产撮合状态机仍需串联',
  },
  fixOms: {
    group: 'core', icon: FileClock, title: 'FIX / OMS / Drop Copy',
    question: '恢复会话与回报序号，将 UNKNOWN 订单收敛至权威状态',
    evidence: 'Resend / PossDup；ExecID 去重；权威回报收敛未知结果',
    boundary: 'QuickFIX、证书和交易所 Sandbox 尚未连接',
  },
  matchingRecovery: {
    group: 'core', icon: DatabaseZap, title: '撮合快照与重放',
    question: '通过连续重放和状态校验，验证节点接管后的订单簿一致性',
    evidence: '顺序命令日志；快照摘要；连续重放；旧 Epoch 拒写',
    boundary: '磁盘刷写、复制共识和微秒级内存订单簿尚未实现',
  },
  surveillance: {
    group: 'post', icon: Siren, title: '市场监察与最佳执行',
    question: '保留自成交、快速撤单、Layering 和异常滑点的调查证据',
    evidence: '五类规则信号；同价不同 scale 归一；只入调查队列',
    boundary: '信号不等于违规结论，仍需图谱、上下文与人工复核',
  },
  apiSecurity: {
    group: 'post', icon: KeyRound, title: '交易 API 安全',
    question: '对签名滥用、重放、越权与突发请求执行失败关闭和有界限频',
    evidence: 'HMAC + 时间窗 + Nonce + Scope + IP + 有界限频',
    boundary: 'KMS、分布式限频、WAF/DDoS 和接管检测待生产化',
  },
  fees: {
    group: 'post', icon: CircleDollarSign, title: '手续费经济正确性',
    question: '约束 VIP 阶梯、Maker 返佣、舍入与成交冲正的账务守恒',
    evidence: '负费率返佣；一次舍入；双腿和为零；原额冲正',
    boundary: '费率快照、活动、税务和多币种估值未接入账本',
  },
  derivatives: {
    group: 'risk', icon: Scale, title: '合约风险生命周期',
    question: '贯通全仓/逐仓、IM/MM、部分强平、保险基金和 ADL 状态',
    evidence: '阶梯保证金；资金费方向；分步减仓；损失瀑布',
    boundary: '强平成交、仓位账本和标记价治理尚未端到端串联',
  },
  digitalAssets: {
    group: 'risk', icon: WalletCards, title: '数字资产状态机',
    question: '保留充值重组、提现超时、Nonce 接管与替换交易的资金因果',
    evidence: '最小单位整数；重组调整；UNKNOWN；Epoch；替换哈希链',
    boundary: '测试网、多 RPC、索引器和 HSM/MPC 尚未连接',
  },
} as const;

type DomainKey = keyof typeof domains;

const metricLabels: Record<string, string> = {
  referenceSource: '参考源', acceptedSources: '有效来源', coalescedUpdates: '合并更新',
  droppedSymbols: '明确丢弃', instrumentVersion: '产品版本', iocExecuted: 'IOC 成交',
  iocCanceled: 'IOC 取消', cancelReplace: '撤改单结果', expectedSequence: '期待序号',
  filledOrders: '已收敛订单', pendingCancelConfirmations: '待确认撤单', signals: '监察信号',
  signalTypes: '信号类型', rapidLargeCancels: '快速大单撤销', allowed: '合法请求',
  replayRejected: '重放拒绝', rateLimited: '限频拒绝', tier: '费率层级',
  makerRateBps: 'Maker bps', fee: '手续费', balanced: '是否平衡', snapshotSequence: '快照序号',
  recoveredSequence: '恢复序号', epoch: '新 Epoch', checksumMatches: '摘要一致',
  crossStatus: '全仓状态', isolatedStatus: '逐仓状态', fundingLongDelta: '多头资金费',
  insuranceUsed: '保险基金承担', adlAccounts: 'ADL 账户', depositAfterReorg: '重组后充值',
  withdrawal: '提现终态', replacementHashes: '替换哈希数',
};

export function ExchangeCoverageLab() {
  const run = useScenarioRun<ExchangeCoverageReport>('exchange', parseExchangeCoverageReport);
  const resultState = run.state === 'success' ? '9 / 9 PASS' : run.state === 'running' ? '运行中' : '等待实跑';

  return (
    <section id="exchange-coverage" className="mx-auto max-w-[1680px] scroll-mt-20 px-4 py-5 sm:px-6 lg:px-8">
      <div className="chapter-section mt-0">
        <div className="grid gap-5 xl:grid-cols-[170px_1fr]">
          <div>
            <p className="chapter-number">09</p>
            <p className="mt-3 font-mono text-xs tracking-[0.16em] text-cyan-300/70">EXCHANGE CORE</p>
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="border border-cyan-300/20 bg-cyan-300/10 text-cyan-200">21 个新增自动测试</Badge>
              <Badge className="border border-emerald-300/20 bg-emerald-300/10 text-emerald-300">代码 · 数据 · 边界</Badge>
              <Badge className="border border-amber-300/15 bg-amber-300/[0.07] text-amber-200">不冒充生产认证</Badge>
            </div>
            <h2 className="mt-4 max-w-5xl text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">
              从行情入口到链上资产：交易所九个能力域的实现与验证
            </h2>
            <p className="mt-3 max-w-5xl text-sm leading-7 text-slate-400">
              不只展示现货撮合。这里补齐行情完整性、高级订单、FIX/OMS、市场监察、API 安全、手续费、撮合恢复、合约风险与数字资产状态机；每个能力域都有输入、失败路径、业务断言、运行指标和未完成边界。
            </p>
          </div>
        </div>

        <section className="explain-panel mt-6 border-cyan-300/10">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <p className="panel-kicker text-cyan-300">GLOBAL TOPOLOGY · 全局服务走向</p>
              <h3 className="mt-2 text-lg font-semibold text-white">接入完整性 → 确定性核心 → 权威收敛；控制面和恢复面贯穿全链路</h3>
              <p className="mt-2 max-w-5xl text-xs leading-6 text-slate-500">箭头表示业务事实流向，不表示所有模块都在一个同步请求里。热路径、账务、风险和链上工作流各自使用与业务后果匹配的一致性边界。</p>
            </div>
            <a href={`${repository}/blob/main/docs/exchange-core-capability-lab.md`} target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0 text-xs">
              查看 7 张时序图与代码映射 <ExternalLink className="size-3" />
            </a>
          </div>
          <ExchangeTopology />
        </section>

        <section className="mt-4 overflow-hidden rounded-2xl border border-white/8 bg-[#09141e]">
          <div className="grid gap-5 border-b border-white/7 p-4 sm:p-5 xl:grid-cols-[1fr_auto] xl:items-center">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className={`data-source ${run.state === 'success' ? 'verified' : 'replay'}`}><Activity className="size-3" /> {resultState}</span>
                {run.report && <span className="font-mono text-[10px] text-slate-600">Run {run.report.runId}</span>}
              </div>
              <h3 className="mt-3 text-lg font-semibold text-white">在腾讯云重新运行全部九域断言</h3>
              <p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">按钮发起一次真实后端写请求，不使用预设成功数据，也不会自动重试。完整 JSON 逐域通过前，页面不会显示 PASS。</p>
            </div>
            <Button onClick={() => void run.run()} disabled={run.state === 'running'} className="bg-cyan-300 text-[#061018] hover:bg-cyan-200">
              {run.state === 'running' ? <RefreshCw className="size-4 animate-spin" /> : <Play className="size-4" />}
              {run.state === 'running' ? '正在执行九域实验' : '运行 9 个能力域'}
            </Button>
          </div>
          <div className={`px-4 py-3 text-xs leading-6 sm:px-5 ${run.state === 'success' ? 'bg-emerald-300/[0.035] text-emerald-100/70' : run.state === 'error' || run.state === 'unknown' ? 'bg-rose-300/[0.035] text-rose-100/70' : 'text-slate-500'}`}>
            {run.message}{run.receivedAt ? ` · 页面接收时间 ${new Date(run.receivedAt).toLocaleString('zh-CN')}` : ''}
          </div>
        </section>

        <Tabs defaultValue="core" className="mt-4">
          <div className="overflow-x-auto pb-1">
            <TabsList className="h-auto min-w-max border border-white/7 bg-[#0a1721] p-1">
              <TabsTrigger value="core" className="px-4 py-2 text-xs data-active:bg-cyan-300/10 data-active:text-cyan-200">交易热路径 · 4</TabsTrigger>
              <TabsTrigger value="post" className="px-4 py-2 text-xs data-active:bg-violet-300/10 data-active:text-violet-200">交易后与治理 · 3</TabsTrigger>
              <TabsTrigger value="risk" className="px-4 py-2 text-xs data-active:bg-amber-300/10 data-active:text-amber-200">合约与链上 · 2</TabsTrigger>
            </TabsList>
          </div>
          {(['core', 'post', 'risk'] as const).map((group) => (
            <TabsContent key={group} value={group} className="mt-3">
              <div className={`grid gap-3 ${group === 'core' ? 'lg:grid-cols-2' : group === 'post' ? 'lg:grid-cols-3' : 'lg:grid-cols-2'}`}>
                {(Object.keys(domains) as DomainKey[]).filter((key) => domains[key].group === group).map((key) => (
                  <DomainCard key={key} domainKey={key} live={run.report?.domains[key]} />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-4 grid gap-3 lg:grid-cols-[1.2fr_.8fr]">
          <article className="explain-panel border-emerald-300/10">
            <p className="panel-kicker text-emerald-300">EVIDENCE CONTRACT · 证据契约</p>
            <h3 className="mt-2 text-base font-semibold text-white">已实现能力、确定性实验与待集成边界</h3>
            <div className="mt-4 grid gap-2 sm:grid-cols-3">
              <EvidenceLevel label="VERIFIED" tone="green" detail="领域代码、自动测试和一键场景能复算语义。" />
              <EvidenceLevel label="DETERMINISTIC LAB" tone="cyan" detail="固定输入证明边界，不是生产流量或协议认证。" />
              <EvidenceLevel label="NEXT INTEGRATION" tone="amber" detail="目标交易所、测试网、硬件和安全环境仍需补证。" />
            </div>
          </article>
          <article className="explain-panel border-amber-300/10">
            <p className="panel-kicker text-amber-200">IMPLEMENTATION SCOPE</p>
            <h3 className="mt-2 text-base font-semibold text-white">规则、状态与恢复形成可验证的交付范围</h3>
            <p className="mt-3 text-sm leading-7 text-slate-400">每个能力域将交易规则映射到状态、不变量、容量、失败契约、监控和恢复检查。真实 FIX 接入、公链及低延迟硬件仍按集成计划单独验收，不将确定性实验等同于生产认证。</p>
          </article>
        </div>
      </div>
    </section>
  );
}

function ExchangeTopology() {
  const stages = [
    { label: '外部输入', items: ['多源行情', 'Web / API', 'FIX 客户', '公链 RPC'], tone: 'text-slate-300' },
    { label: '接入完整性', items: ['Gap 恢复', 'API 安全', 'FIX Session', '链索引'], tone: 'text-cyan-200' },
    { label: '确定性核心', items: ['订单规则', '盘前风控', '单写撮合', '合约风险'], tone: 'text-amber-200' },
    { label: '权威收敛', items: ['Drop Copy', '手续费', '账本对账', '市场监察'], tone: 'text-emerald-200' },
  ];
  return (
    <div className="architecture-svg-scroll mt-4 rounded-xl border border-white/6 p-4">
      <div className="min-w-[960px]">
        <div className="grid grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] items-stretch gap-3">
          {stages.map((stage, index) => (
            <div key={stage.label} className="contents">
              <div className="rounded-xl border border-white/8 bg-black/15 p-3">
                <p className="font-mono text-[9px] tracking-[0.14em] text-slate-600">0{index + 1} · {stage.label}</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  {stage.items.map((item) => <span key={item} className={`rounded-lg border border-white/6 bg-white/[0.025] px-2.5 py-2 text-center text-[11px] ${stage.tone}`}>{item}</span>)}
                </div>
              </div>
              {index < stages.length - 1 && <ArrowRight className="my-auto size-5 text-cyan-300/40" />}
            </div>
          ))}
        </div>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-violet-300/10 bg-violet-300/[0.025] px-3 py-2 text-[10px] text-violet-100/60"><strong className="mr-2 text-violet-200">控制面</strong>产品版本 · 交易模式 · 风险阈值 · API Key · Kill Switch</div>
          <div className="rounded-lg border border-emerald-300/10 bg-emerald-300/[0.025] px-3 py-2 text-[10px] text-emerald-100/60"><strong className="mr-2 text-emerald-200">恢复面</strong>录包 · 命令日志 · 快照 · Epoch · 审计 · 对账</div>
        </div>
      </div>
    </div>
  );
}

function DomainCard({ domainKey, live }: { domainKey: DomainKey; live?: ExchangeDomainReport }) {
  const domain = domains[domainKey];
  const Icon = domain.icon;
  return (
    <article className={`rounded-xl border p-4 sm:p-5 ${live ? 'border-emerald-300/14 bg-emerald-300/[0.025]' : 'border-white/7 bg-[#0a151f]'}`}>
      <div className="flex items-start justify-between gap-3">
        <span className="grid size-9 place-items-center rounded-lg border border-cyan-300/10 bg-cyan-300/[0.06] text-cyan-300"><Icon className="size-4" /></span>
        <span className={`data-source ${live ? 'verified' : 'replay'}`}>{live ? <Check className="size-3" /> : <Activity className="size-3" />}{live ? '本次 PASS' : '可运行'}</span>
      </div>
      <h3 className="mt-4 text-base font-semibold text-white">{domain.title}</h3>
      <p className="mt-2 text-xs leading-6 text-slate-400">{domain.question}</p>
      <div className="mt-4 rounded-lg border border-white/6 bg-black/10 p-3">
        <p className="panel-kicker">已落地证据</p>
        <p className="mt-2 text-[11px] leading-5 text-emerald-100/65">{live?.flow ?? domain.evidence}</p>
      </div>
      {live && (
        <div className="mt-3 grid grid-cols-2 gap-2">
          {Object.entries(live.metrics).map(([key, value]) => (
            <div key={key} className="rounded-lg border border-white/6 bg-white/[0.018] p-2.5">
              <p className="text-[9px] text-slate-600">{metricLabels[key] ?? key}</p>
              <p className="mt-1 break-all font-mono text-[11px] text-cyan-200">{String(value)}</p>
            </div>
          ))}
        </div>
      )}
      <div className="mt-3 space-y-1.5">
        {(live?.checks ?? [domain.evidence]).map((check) => (
          <p key={check} className="flex items-start gap-2 text-[10px] leading-5 text-slate-500"><Check className="mt-1 size-3 shrink-0 text-emerald-300" />{check}</p>
        ))}
      </div>
      <p className="mt-4 border-t border-white/6 pt-3 text-[10px] leading-5 text-amber-100/50"><span className="mr-1 font-mono text-amber-300/70">BOUNDARY</span>{live?.boundary ?? domain.boundary}</p>
    </article>
  );
}

function EvidenceLevel({ label, tone, detail }: { label: string; tone: 'green' | 'cyan' | 'amber'; detail: string }) {
  const colors = tone === 'green' ? 'border-emerald-300/10 bg-emerald-300/[0.025] text-emerald-300'
    : tone === 'cyan' ? 'border-cyan-300/10 bg-cyan-300/[0.025] text-cyan-300'
      : 'border-amber-300/10 bg-amber-300/[0.025] text-amber-300';
  return <div className={`rounded-lg border p-3 ${colors}`}><p className="flex items-center gap-2 font-mono text-[9px]"><BadgeCheck className="size-3.5" />{label}</p><p className="mt-2 text-[10px] leading-5 text-slate-500">{detail}</p></div>;
}
