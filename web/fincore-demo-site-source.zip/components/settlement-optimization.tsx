'use client';

import { ArrowRight, CheckCircle2, FileCode2 } from 'lucide-react';
import { HandbookReader } from '@/components/performance-engineering';

const safeguards = [
  ['幂等必须比较内容', '同一业务键只能代表同一笔经济事实。金额、资产、付款方、收款方、费用账户或费用变化，必须明确冲突，不能返回一次貌似成功的旧结果。'],
  ['消息编号能追到原单', '同一业务键换 messageId 重投，先留存 Inbox 关联；再次重放时沿已保存的业务键找到原结果，不依赖订单第一次的 messageId。'],
  ['未看到结果不等于失败', '查询不到已提交订单时给出明确的未可见响应；调用方保留原键继续有限查询，不能立即创建新键、退款或认定资金丢失。'],
  ['持锁等待后复核租约', '通用结算与现货交割都在 beforeCommit 复核 Fence；即使加入外层事务，也随真实提交再检查。持锁等待或事务延迟跨过 TTL 后，异常使整笔回滚。'],
  ['规避外键锁升级死锁', '账户余额不修改主键，使用 FOR NO KEY UPDATE 与外键 KEY SHARE 兼容。余额写入仍互斥，统一 UUID 锁序与条件扣款仍保留。'],
  ['完成计数放在提交之后', 'success/completed 在 afterCommit 更新；资金、分录、Inbox、终态、Outbox 仍在原事务，不挪到回调。计数用于监控，账本才是最终事实。'],
  ['已锁定数据只读一次', '现货交割复用本事务获取的账户快照，减少重复读取。它不是跨请求缓存，也没有删除余额、资产、预占与 Fence 校验。'],
] as const;

export function SettlementOptimization() {
  return <section id="settlement-optimization" className="performance-engineering settlement-specialism scroll-mt-24">
    <div className="engineering-intro"><p className="overview-eyebrow">SETTLEMENT PERFORMANCE / 独立专项</p><h2>结算性能优化</h2><p>真正要提高的不是“已接收订单数”，而是单位时间内完成、可核账、可恢复的资金结果。</p></div>
    <div className="settlement-objectives">
      <article><span>正确性</span><strong>一笔业务，一次资金效果</strong><p>冲突拒绝、事务原子、逐笔对账。</p></article>
      <article><span>性能</span><strong>先缩短持锁，再增加并发</strong><p>减少重复 SQL，联合观察锁、池与消费。</p></article>
      <article><span>可恢复性</span><strong>未知结果有明确去处</strong><p>保留原键、查询事实，不盲目补单。</p></article>
    </div>
    <nav className="settlement-subnav" aria-label="结算专项目录"><a href="#settlement-architecture">架构与事务</a><a href="#settlement-implementation">实现与代码</a><a href="#settlement-metrics">观测口径</a><a href="#settlement-evidence">测试与验收</a><a href="#settlement-handbook">完整手册</a></nav>

    <section id="settlement-architecture" className="settlement-part">
      <h3>01 / 先划清资金事务与外部等待</h3>
      <p>HTTP 202 是 Broker 接收确认，不是到账。通用结算从 API 入队；现货先将成交与 SPOT_DVP_REQUESTED 写入 Outbox，再进入交割消费。以下聚焦共用的可靠性边界。</p>
      <SettlementArchitecture />
      <div className="settlement-contract"><strong>不能以性能换掉的约束</strong><p>账户按统一 UUID 顺序锁定；余额、账本、Inbox、终态与 Outbox 在同一事务。技术异常继续抛出；SUCCESS 不回退；修正已提交的经济结果只能走独立反向账务。</p></div>
    </section>

    <section id="settlement-implementation" className="settlement-part">
      <h3>02 / 从缺口到代码：七项实现</h3>
      <div className="settlement-safeguards">{safeguards.map(([title, text], index) => <article key={title}><span>{String(index + 1).padStart(2, '0')}</span><h4>{title}</h4><p>{text}</p></article>)}</div>
      <div className="engineering-work"><div><h3>一次重试应如何处理</h3><ol>
        {[
          ['先关联消息', '读取 Inbox 保存的 businessKey 与经济载荷；不让同一个 messageId 指向另一笔资金事实。'],
          ['再核对业务', '同 businessKey 比较经济字段；金额按数值比较，10.0 与 10.00 不制造伪冲突。'],
          ['只执行未完成的资金动作', '已提交终态返回既有事实，不新增分录；新消息关联随事务一起提交。'],
          ['失败也保留语义', '提交前错误整单回滚；提交后丢响应先查原键。查询未可见继续有界观察，不假装失败。'],
        ].map(([title, detail], i) => <li key={title}><span>{i+1}</span><div><h4>{title}</h4><p>{detail}</p></div></li>)}
      </ol></div><aside><h3>事务骨架（流程示意）</h3><pre><code>{`@Transactional
settle(command, fence) {
  validateFenceAndRegisterBeforeCommit(fence);
  validateInboxAndBusinessPayload(command);
  if (alreadyTerminal) return originalOutcome;
  lockAccountsInUuidOrder();
  verifyFundsAndBuildBalancedJournal();
  writeJournalAndBalances();
  writeTerminalInboxAndOutbox();
  registerAfterCommitCounter();
}
// Spring: beforeCommit 再验 Fence → COMMIT
// → afterCommit 计数；回调中不写资金。
// 任何技术异常抛出后整笔回滚。`}</code></pre><p>资金代码、实际 SQL 和回归测试随本页源码快照提供；示意骨架不是另一个绕过 Kafka 的接口。</p></aside></div>
      <p>现货交割省去四次重复账户读取，同时增加一次提交前 Fence 校验：正常成功路径净少三次 SQL；预占再少一次重复读取。这是调用次数改进，不是未经实测的吞吐提升比例。</p>
      <div className="engineering-downloads"><a href="/performance/settlement-source.zip" download><FileCode2 size={17} /> 下载本次实现与测试源码</a><a href="/performance/settlement-completion.md" target="_blank" rel="noreferrer">修改位置与实现详解 <ArrowRight size={16} /></a></div>
    </section>

    <section id="settlement-metrics" className="settlement-part">
      <h3>03 / 让等待可见，避免用受理速度冒充到账速度</h3>
      <div className="handbook-table"><table><thead><tr><th>观测段</th><th>回答的问题</th><th>不能误读成</th></tr></thead><tbody>
        <tr><td>Consumer 总处理</td><td>路由、租约与业务处理合计花多久？</td><td>Broker 排队时间或端到端到账时间</td></tr>
        <tr><td>路由 / Lease</td><td>分片争用、租约获取是否拖慢消费？</td><td>数据库资金事务耗时</td></tr>
        <tr><td>事务代理调用</td><td>借连接、资金 SQL、提交或回滚花多久？</td><td>可再叠加一次 Hikari 等待的纯 SQL 时长</td></tr>
        <tr><td>提交后完成计数</td><td>已提交的资金结果有多少？</td><td>可替代持久账本的严格总账</td></tr>
        <tr><td>客户端终态观察</td><td>从发起到查到结果多久？</td><td>无轮询误差的精确 COMMIT 时刻</td></tr>
      </tbody></table></div>
      <p>Histogram 使用低基数类型与结果标签；businessKey、账户编号留在日志或追踪中，避免指标基数失控。consumer success 表示消费正常返回，包含重复和已提交的业务拒绝；资金成功另看提交后计数与账本。连接等待、锁等待、Lag、Outbox 最老年龄与完成量要同时看。</p>
    </section>

    <section id="settlement-evidence" className="settlement-part">
      <h3>04 / 测试不是勾选项，每项都要对到资金事实</h3>
      <div className="engineering-evidence"><CheckCircle2 size={20} /><div><strong>完整 CI：204 项通过 · 0 失败 · 0 跳过</strong><p>覆盖率、PMD、SpotBugs 与报告门禁全部通过。本机另完成 68 项定向回归（含 33 项真实 PostgreSQL）及 34 项工具协议测试。隔离 CI 的有限样本完成 64 笔成交、核对 256 个账户，资金差异为 0；没有持续容量实测，不填写 TPS 或 P99 提升。</p></div><a href="/performance/settlement-evidence.json" target="_blank" rel="noreferrer">测试清单与证据摘要 <ArrowRight size={16} /></a></div>
      <p><a href="https://github.com/soldierking04d/fincore-reliability-lab/actions/runs/35524253125" target="_blank" rel="noreferrer">查看完整 CI 与原始运行证据</a>。下载包是本次专项源码快照；完整复验请克隆仓库并使用证据摘要中的 sourceCommit，保留全部治理和测试夹具。</p>
      <div className="handbook-table"><table><thead><tr><th>输入 / 故障</th><th>应观察到的结果</th><th>资金验收</th></tr></thead><tbody>
        <tr><td>同键、不同金额或账户</td><td>显式载荷冲突</td><td>原单不变；没有第二次扣款</td></tr>
        <tr><td>新消息重投旧业务，再重放该消息</td><td>两次都查到原业务结果</td><td>一笔原始账本、一条成功事件</td></tr>
        <tr><td>查询先于消费落库</td><td>明确未可见响应</td><td>不换键补单、不自动冲正</td></tr>
        <tr><td>持锁等待跨过 Lease TTL</td><td>提交前二验拒绝</td><td>分录、余额、Inbox、终态、Outbox 整体回滚</td></tr>
        <tr><td>共同账户外键引用与并发余额写入</td><td>不发生已复现的锁升级死锁</td><td>写入仍串行互斥；余额不足与冻结资金不能绕过</td></tr>
        <tr><td>最后写入失败或回滚</td><td>错误抛回消费者</td><td>完成计数不增加；资金不留半笔</td></tr>
        <tr><td>工具审计漏单、错分录或通知未发布</td><td>失败或未完成，不能宣称全链路通过</td><td>业务全集、逐笔借贷、账户净额、Outbox 分别核对</td></tr>
      </tbody></table></div>
      <h4>性能实验顺序</h4><p>先验证资金正确性，再固定账户分布与硬件；Consumer 按 1 / 2 / 4 单变量对照。分别运行公共费用、费用分片与热点付款方，每组至少三轮；同时报告完成量、尾延迟、锁等待、积压与排空。没有显著收益，也应保留原始结果。</p>
      <div className="engineering-boundary"><strong>交付边界与不采用的“优化”</strong><p>本页新增实现不等于腾讯云交易后端已经切换，也不等于通过生产容量认证。多实例归属协调、持续现货负载、COMMIT 网络回包丢失仍需完整环境验证；账户 Lane、版本化费用路由和归集回补属于另一个热点账户专项。多笔资金合成大事务、跳过资金校验和无限加线程不作为默认方案。</p></div>
    </section>

    <section id="settlement-handbook" className="settlement-part"><h3>05 / 完整实施手册与可复现工具</h3><p>从链路拆解、诊断 SQL 到故障恢复，详细步骤保留在手册中；本轮变更记录与历史基线分开，避免旧结论覆盖新实现。</p><HandbookReader file="settlement-completion.md" /><HandbookReader file="settlement-performance-playbook.md" /><div className="engineering-downloads"><a href="/performance/settlement-comparison.mjs" download>账户分布对照工具</a><a href="/performance/settlement-database-audit.mjs" download>逐笔账本与 Outbox 审计</a><a href="/performance/compose.isolated.yml" download>隔离实验环境</a></div></section>
  </section>;
}

function SettlementArchitecture() {
  const row = [
    ['校验与幂等', 'Fence / Inbox / 经济载荷'],
    ['全序账户锁', '复用锁定快照 / 校验资金'],
    ['原子资金写入', '平衡分录 / 余额 / 状态'],
    ['终态 / Inbox / Outbox', 'beforeCommit 再验 Fence'],
  ];
  return <figure className="performance-topology"><figcaption>结算服务拓扑与事务边界</figcaption><div className="topology-scroll"><svg viewBox="0 0 1100 440" role="img" aria-label="API或成交Outbox通过Kafka到Worker，单资金事务内完成幂等、全序锁、账务写入和围栏复核，提交后计数与异步通知">
    <defs><marker id="settlement-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#456d9c" /></marker></defs>
    {['API / 成交 Outbox', 'Kafka / 有限 Consumer', 'Worker 路由与 Lease'].map((title, i) => <g key={title}><rect x={25+i*360} y={20} width="300" height="54" rx="9" fill="#edf4ff" stroke="#aec8e8"/><text x={175+i*360} y={53} textAnchor="middle" fill="#173a65" fontSize="17">{title}</text>{i<2&&<path d={`M${325+i*360},47 H${380+i*360}`} stroke="#456d9c" markerEnd="url(#settlement-arrow)"/>}</g>)}
    <rect x="20" y="112" width="1060" height="165" rx="12" fill="#f0f8f5" stroke="#8cbaa6" strokeDasharray="6 4"/><text x="42" y="140" fill="#2b6550" fontSize="16">单个 PostgreSQL 事务 / 所有资金事实共同提交或共同回滚</text>
    <path d="M895,74 V95 H150 V167" fill="none" stroke="#456d9c" markerEnd="url(#settlement-arrow)"/>
    {row.map(([title, detail], i) => <g key={title}><rect x={40+i*260} y="176" width="230" height="76" rx="8" fill="white" stroke="#9bbcaf"/><text x={155+i*260} y="208" textAnchor="middle" fill="#214a3c" fontSize="17">{title}</text><text x={155+i*260} y="232" textAnchor="middle" fill="#496a5f" fontSize="13">{detail}</text>{i<3&&<path d={`M${270+i*260},214 H${296+i*260}`} stroke="#456d9c" markerEnd="url(#settlement-arrow)"/>}</g>)}
    <path d="M935,252 V309 H550 V326 M550,309 H166 V326" fill="none" stroke="#456d9c" markerEnd="url(#settlement-arrow)"/>
    <rect x="30" y="330" width="300" height="65" rx="8" fill="#edf4ff" stroke="#aec8e8"/><text x="180" y="357" textAnchor="middle" fill="#173a65" fontSize="17">COMMIT 后 / 结果可见</text><text x="180" y="382" textAnchor="middle" fill="#526d8c" fontSize="14">完成计数 / 查询原业务键</text>
    <rect x="400" y="330" width="300" height="65" rx="8" fill="#edf4ff" stroke="#aec8e8"/><text x="550" y="357" textAnchor="middle" fill="#173a65" fontSize="17">Outbox Publisher</text><text x="550" y="382" textAnchor="middle" fill="#526d8c" fontSize="14">提交后另行发布 / 下游业务幂等</text>
    <rect x="770" y="330" width="300" height="65" rx="8" fill="#fff5f1" stroke="#e4b5a5"/><text x="920" y="357" textAnchor="middle" fill="#855144" fontSize="17">任一技术异常 → 整体回滚</text><text x="920" y="382" textAnchor="middle" fill="#855144" fontSize="14">原键重试 / 未知先查询</text>
    <path d="M1060,214 H1090 V315 H920 V326" fill="none" stroke="#b66e59" strokeDasharray="5 4" markerEnd="url(#settlement-arrow)"/>
  </svg></div></figure>;
}
