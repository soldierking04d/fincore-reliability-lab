'use client';

import { ArrowRight, ExternalLink, GitCompareArrows } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import evidence from '@/lib/java-cpp-evidence.json';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const repository = 'https://github.com/soldierking04d/fincore-reliability-lab';
const playbook = `${repository}/blob/main/docs/java-cpp-trading-migration.md`;
const experiment = `${repository}/tree/main/experiments/java-cpp-matching`;

const comparisons = [
  [
    '订单簿',
    '数据库索引查询、行锁与事务',
    '进程内订单簿、顺序执行',
    '进程内订单簿、顺序执行',
  ],
  [
    '资金正确性',
    '撮合与预占/在途在同一事务回滚',
    '独立实验不连接资金账本',
    '独立实验不连接资金账本',
  ],
  [
    '内存与 CPU',
    '数据库往返、对象分配、JIT、GC',
    '可研究紧凑布局与预分配，仍有 JIT/GC',
    '可控制对象生命周期，仍有分配、缺页和缓存成本',
  ],
  [
    '故障恢复',
    '数据库事务、Outbox、消费幂等与 Fencing',
    '完整日志/快照/切换仍需另行实现',
    '完整日志/快照/切换仍需另行实现',
  ],
  [
    '对比口径',
    '完整 HTTP → 成交 → 资金交割',
    '命令进入内存引擎 → 结果形成',
    '命令进入内存引擎 → 结果形成',
  ],
];

const implementationDetails = [
  {
    title: '金额、精度和溢出：价格改成整数，不等于资金问题消失',
    summary:
      '两种实验实现使用相同的整数刻度；生产接口仍要执行市场精度、最小手数和最大名义金额检查。',
    details: [
      '协议必须带 instrumentVersion，明确 priceTicks、quantityLots、tickSize、lotSize 和结算精度。价格×数量的中间结果可能溢出；拒绝必须发生在订单簿产生任何成交之前。',
      'Java 可用显式范围检查或 Math.multiplyExact；C++ 的有符号溢出不能依赖“自然回绕”。费用、折扣和价格改善需要独立的舍入合同，并用边界值逐笔核对。',
      '例：买入上限价 100、数量 10，先成交 4。剩余冻结、在途、已结算和已释放必须能解释原始预占；不能因为 C++ 返回了成交就直接把 Java 全部冻结解开。',
    ],
  },
  {
    title: '订单簿与撤单：统一的是业务次序，不只是两个队列',
    summary:
      '新单与撤单都由同一个交易对写入者处理。撤单保留容量负责过载保护，不能打断已经执行的成交。',
    details: [
      '现有 Lane 为撤单保留独立容量，并用最多连续 8 条优先命令限制饥饿。移植后要记录真正执行的命令序号，影子实例回放这个序号，不能再次按网络到达时间自行调度。',
      '撤单返回成功的条件是权威订单状态已确认并达到规定的持久化保证。请求接收、入队成功和撤单完成必须使用不同状态；超时必须查询原命令，不能提前释放资金。',
      '自成交保护沿用 CANCEL_TAKER：先遇到其他用户可成交，随后遇到本人挂单才取消剩余量。把整个新单提前拒绝会改变成交历史，双跑必须检查这一类细节。',
    ],
  },
  {
    title: 'CPU 与内存：先定位热路径，再挑优化手段',
    summary:
      '对比采集排队、计算、GC/分配、缓存、缺页和调度证据，不能只比较平均耗时。',
    details: [
      'Java：分开 JIT 预热与稳定测量，观察 safepoint、分配率和 GC；数组化热字段、减少装箱和临时对象通常比增加线程更值得先验证。虚拟线程主要服务等待型请求。',
      'C++：预分配与稳定所有权可以减少热路径分配，但对象池也引入容量、复用和悬空引用问题。单写者优先于复杂共享无锁结构；SPSC 的 acquire/release 要有明确发布关系。',
      '目标 Linux 机器再测 perf、LLC miss、branch miss、page fault、上下文切换、NUMA 与节流。Mac 本地实验不能证明腾讯云机器或独占交易节点的尾延迟。GPU 只在批量风险/研究任务中另做预算。',
    ],
  },
  {
    title: 'Java 与 C++ 的服务边界：协议必须覆盖失败',
    summary:
      '跨进程二进制协议可以隔离故障；JNI/FFM 会把原生代码的故障带入 JVM 进程。',
    details: [
      '命令至少携带 schemaVersion、symbol、epoch、commandId、业务幂等键、reservationId、整数价格与数量。事件携带确定性序号与事件编号；重投必须保持原编号。',
      '同机 IPC、网络传输和 JNI 各有拷贝、排队、运维与崩溃影响。选择要通过端到端实验；本实验使用离线共享输入文件，尚未声称实装 Aeron、SBE 或 JNI。',
      '协议升级采用可明确识别的版本，未知枚举/精度变化失败关闭。增加字段、缩窄整数、字节序以及 Java 有符号类型映射都需要跨语言 golden 数据。',
    ],
  },
  {
    title: '拆开数据库事务后，如何避免“撮合成功、资金失败”',
    summary:
      '先持久预占，再向有写入权的撮合引擎提交；撮合事件通过幂等账务消费者更新在途和交割。',
    details: [
      '当前代码可先在数据库事务里计算成交，再进行资金检查；检查失败会连订单簿一起回滚。独立 C++ 进程没有这层回滚保护，不能照搬原调用顺序。',
      '候选协议先固定预占事实与待发送命令，再由引擎校验预占引用和配置版本。引擎决定必须进入可恢复日志，账务侧以事件唯一键消费；所有余额、流水和状态仍在账务事务内原子更新。',
      '网络超时后资金维持受控冻结，查询权威日志决定接受、拒绝或撤销；只有证明命令不会再被接受，才允许补偿释放。重启后无法证明状态时停止接单并恢复，不能猜测成功或失败。',
      '成交与撤单事件还要按已提交顺序应用：若 CANCEL 先于之前的 FILL 落账，就可能释放本应转在途的冻结。去重、消费检查点、资金变化和 Outbox 必须在同一数据库事务提交。',
    ],
  },
  {
    title: '可恢复日志、快照与 epoch：谁能继续产生有效成交',
    summary:
      '应用存活和持有旧租约都不足以取得交易写入权；持久日志与下游接收点要共同拒绝旧 epoch。',
    details: [
      '快照必须覆盖订单、剩余量、价格队列、命令去重结果、成交序号和市场规则版本。仅保存余额或最后一条序号，无法恢复完整撮合语义。',
      '明确“入内存、写日志、fsync、复制确认、业务确认”的不同持久级别；RPO 和应答点必须一致。单机文件写入成功不能等同跨机复制成功。',
      '影子引擎只生成对比结果，不能发真实结算、更新余额或对外宣告成交。切换写入权后要记录 epoch 边界，拒绝旧写入者的新事件，同时按边界接纳旧 epoch 已提交且尚未消费的事件。',
    ],
  },
];

const cutover = [
  ['建立基线', '同一输入、规则和确认点；明确 p99.9、容量与资金不变量。'],
  ['离线回放', '历史与边界数据逐笔对比；成交、状态、资金结果零差异。'],
  ['影子双跑', '镜像已经确定顺序的命令；仅权威引擎能产生账务效果。'],
  [
    '暂停该交易对准入',
    '新单拒绝或受控等待；撤单按既定维护政策处理并告知客户端。',
  ],
  [
    '排空并固定切换点',
    '记录已提交序号、未决请求、冻结与在途资金，保存完整状态摘要。',
  ],
  [
    '提升 epoch 并恢复',
    '隔离旧写入者；新引擎从快照/日志恢复到同一切换点并核对。',
  ],
  ['小范围恢复准入', '只开放已验收交易对，观察尾延迟、积压和资金差异。'],
  [
    '带状态回退',
    '新引擎受理过命令后，旧引擎必须追平新日志再接管；否则停交易恢复。',
  ],
];

export function JavaCppMigration() {
  return (
    <section id="java-cpp-migration" className="chapter-section scroll-mt-24">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div className="max-w-5xl">
          <p className="panel-kicker">JAVA → C++ · 交易核心改造专项</p>
          <h2 className="mt-3 text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            从迁移价值到撮合代码：怎样把低延迟改造做得快、准、可恢复
          </h2>
          <p className="mt-4 text-base leading-8 text-slate-300">
            先定位数据库、排队与运行时成本，再决定是否提取撮合核心。这里可以查看三种方案、服务拓扑、资金时序、源码实验、切换门禁和团队交付方案。
          </p>
        </div>
        <a
          href={playbook}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 rounded-xl border border-cyan-300/30 bg-cyan-300/10 px-4 py-3 text-sm text-cyan-200"
        >
          完整专项手册 <ExternalLink className="size-4" />
        </a>
      </div>

      <div className="mt-6 grid gap-3 md:grid-cols-3">
        {[
          [
            '当前运行',
            'Java + 数据库事务',
            '已实现完整资金闭环；保留现有公网应用。',
          ],
          [
            '可运行实验',
            'Java / C++ 内存撮合',
            '共享输入、黄金样本、差分回放和本地性能测量。',
          ],
          [
            '迁移设计',
            '独立热路径 + Java 账务',
            '持久预占、日志确认、单一写入权和分交易对切换。',
          ],
        ].map(([label, title, detail]) => (
          <article
            key={title}
            className="rounded-xl border border-cyan-300/15 bg-cyan-300/[0.04] p-5"
          >
            <p className="text-sm text-cyan-300">{label}</p>
            <h3 className="mt-2 text-lg font-semibold text-white">{title}</h3>
            <p className="mt-2 text-base leading-7 text-slate-400">{detail}</p>
          </article>
        ))}
      </div>

      <Tabs defaultValue="architecture" className="mt-6 gap-5">
        <div className="overflow-x-auto pb-1">
          <TabsList
            aria-label="Java 与 C++ 交易改造内容"
            className="h-auto min-w-max gap-1 bg-slate-900 p-1"
          >
            {[
              ['architecture', '方案与架构'],
              ['implementation', '代码与关键细节'],
              ['evidence', '实验与测量'],
              ['migration', '切换与故障'],
              ['leadership', '团队与投入'],
            ].map(([value, label]) => (
              <TabsTrigger
                key={value}
                value={value}
                className="px-4 py-3 text-sm text-slate-300 data-active:bg-cyan-300 data-active:text-slate-950"
              >
                {label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <TabsContent value="architecture" className="space-y-5">
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              三组基线，分别回答架构收益与语言差异
            </h3>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[860px] text-left text-sm leading-6">
                <caption className="sr-only">
                  数据库撮合与两种内存撮合方案对照
                </caption>
                <thead>
                  <tr className="border-b border-cyan-300/20 text-cyan-200">
                    {[
                      '维度',
                      'A · 当前 Java 数据库撮合',
                      'B · Java 内存候选',
                      'C · C++ 内存候选',
                    ].map((t) => (
                      <th key={t} className="px-3 py-3">
                        {t}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisons.map((row) => (
                    <tr key={row[0]} className="border-b border-white/8">
                      {row.map((text, i) => (
                        <td
                          key={`${row[0]}-${i}`}
                          className={`px-3 py-4 ${i === 0 ? 'font-semibold text-slate-200' : 'text-slate-400'}`}
                        >
                          {text}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-4 text-base leading-7 text-amber-200">
              A 与 B/C 的持久化、网络和资金工作量不同，不能直接计算“C++ 比 Java
              快多少倍”。B/C 才能在同一实验合同内比较。
            </p>
          </article>
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              全局服务拓扑：热路径提取后，账务仍有自己的权威
            </h3>
            <p className="mt-3 text-base leading-7 text-slate-400">
              上半部分是当前事务边界，下半部分是候选迁移设计。虚线表示监控、影子和恢复关系。
            </p>
            <ArchitectureDiagram />
          </article>
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              新单到资金交割：受理、成交与入账分别确认
            </h3>
            <p className="mt-3 text-base leading-7 text-slate-400">
              设计时序。每一步都要能回答“掉电或超时后，谁来证明已经发生什么”。
            </p>
            <FundsSequence />
          </article>
        </TabsContent>

        <TabsContent value="implementation" className="space-y-5">
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              对照可运行源码，再看提取生产热路径需要补什么
            </h3>
            <p className="mt-3 text-base leading-8 text-slate-300">
              实验专注订单簿与命令语义；现有 Java
              服务继续承担资金事务。以下六项说明每个模块解决的问题、CPU
              成本以及失败处理。
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <SourceLink href={experiment}>Java / C++ 实验源码</SourceLink>
              <SourceLink
                href={`${repository}/blob/main/src/main/java/dev/fincore/application/MatchingService.java`}
              >
                现有撮合事务
              </SourceLink>
              <SourceLink
                href={`${repository}/blob/main/src/main/java/dev/fincore/application/SpotFundsService.java`}
              >
                资金预占与释放
              </SourceLink>
              <SourceLink
                href={`${repository}/blob/main/src/main/java/dev/fincore/infrastructure/concurrent/StripedTaskExecutor.java`}
              >
                撤单优先 Lane
              </SourceLink>
            </div>
          </article>
          <Accordion
            defaultValue={['0']}
            multiple
            className="rounded-xl border border-white/10 bg-slate-950/40 px-5"
          >
            {implementationDetails.map((item, index) => (
              <AccordionItem
                key={item.title}
                value={String(index)}
                className="border-white/10 py-2"
              >
                <AccordionTrigger className="text-base leading-7 text-white">
                  {item.title}
                </AccordionTrigger>
                <AccordionContent className="py-4 text-base leading-8 text-slate-400">
                  <p className="text-cyan-200">{item.summary}</p>
                  {item.details.map((p) => (
                    <p key={p}>{p}</p>
                  ))}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </TabsContent>

        <TabsContent value="evidence" className="space-y-5">
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              先验证结果一致，再解释延迟
            </h3>
            <p className="mt-3 text-base leading-8 text-slate-300">
              共享命令流先通过人工定义的黄金样本，再逐笔核对两种实现的响应、成交、剩余量和终态。性能计时排除文件读取、解码和输出，报告预热、重复次数、机器与进程架构。
            </p>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {[
                [
                  '必须一致',
                  '价格时间优先、部分成交、撤单所有权、重复/冲突幂等键、自成交保护、金额溢出和状态重放。',
                ],
                [
                  '必须如实报告',
                  '命令耗时 p50/p99/p99.9/max、有限样本吞吐、运行参数；缺少的数据标为未测，不填 0。',
                ],
                [
                  '不混在同一图上',
                  '数据库 HTTP 到交割的历史运行数据，与内存方法耗时属于不同测量区间。',
                ],
                [
                  '进一步上线验收',
                  '开放到达率、热点交易对、行情波动、撤单风暴、长时稳定运行、持久化和故障恢复。',
                ],
              ].map(([title, detail]) => (
                <div
                  key={title}
                  className="rounded-xl border border-white/10 p-4"
                >
                  <h4 className="text-base font-semibold text-cyan-200">
                    {title}
                  </h4>
                  <p className="mt-2 text-base leading-7 text-slate-400">
                    {detail}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-5 flex flex-wrap gap-3">
              <SourceLink href={experiment}>复现实验与原始报告说明</SourceLink>
              <SourceLink
                href={`${repository}/blob/main/docs/java-cpp-trading-evidence.md`}
              >
                本次实测报告
              </SourceLink>
            </div>
          </article>
          <JavaCppEvidence />
        </TabsContent>

        <TabsContent value="migration" className="space-y-5">
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              按交易对切换，保留可以证明的状态接续点
            </h3>
            <ol className="mt-5 grid gap-3 md:grid-cols-2">
              {cutover.map(([title, detail], index) => (
                <li
                  key={title}
                  className="flex gap-4 rounded-xl border border-white/10 p-4"
                >
                  <span className="font-mono text-lg text-cyan-300">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <div>
                    <h4 className="text-base font-semibold text-white">
                      {title}
                    </h4>
                    <p className="mt-2 text-base leading-7 text-slate-400">
                      {detail}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </article>
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              三种故障，决定能否真正上线
            </h3>
            <div className="mt-4 space-y-4">
              {[
                [
                  'C++ 已撮合，Java 暂时收不到成交',
                  '保留资金在途与事件编号；从权威日志补发，账务消费幂等。不能重新撮合原订单，也不能因超时释放冻结。',
                ],
                [
                  '新引擎已接受订单，需要退回 Java',
                  '先停止该交易对新准入并固定提交点。旧引擎导入新引擎接受过的命令与状态、核对摘要后才可接管；直接改路由会丢新状态。',
                ],
                [
                  '旧进程卡顿后恢复，继续发送旧 epoch',
                  '在权威提交与事件接收边界拒绝越过围栏的输出。已经合法提交的旧事件按明确序号边界补消费；心跳恢复不能自动重新取得写入权。',
                ],
              ].map(([title, detail]) => (
                <div
                  key={title}
                  className="rounded-xl border border-rose-300/15 bg-rose-300/[0.025] p-5"
                >
                  <h4 className="text-base font-semibold text-rose-200">
                    {title}
                  </h4>
                  <p className="mt-2 text-base leading-8 text-slate-300">
                    {detail}
                  </p>
                </div>
              ))}
            </div>
          </article>
        </TabsContent>

        <TabsContent value="leadership" className="space-y-5">
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              改造收益、团队责任与交付风险
            </h3>
            <p className="mt-3 text-base leading-8 text-slate-300">
              业务目标应对应撤单等待、行情波动时拒单与积压、尾延迟预算和每单位吞吐成本。只有瓶颈定位和等价实验能说明本项目是否需要
              C++。
            </p>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {[
                [
                  '产品与运营',
                  '共同定义用户可见状态、维护窗口、撤单政策、交易对灰度、客户沟通和恢复时限。',
                ],
                [
                  '技术负责人',
                  '负责边界、性能口径、资金不变量、投入预算、评审、上线门禁与停止条件。',
                ],
                [
                  'Java / C++ 负责人',
                  '共同维护协议和黄金数据；分别对资金事务、订单簿、内存安全与故障恢复负责。',
                ],
                [
                  'QA / SRE / 安全',
                  '独立验证差分、故障演练、压测与恢复；至少两人能值守和接管关键模块。',
                ],
              ].map(([title, detail]) => (
                <div
                  key={title}
                  className="rounded-xl border border-white/10 p-5"
                >
                  <h4 className="text-base font-semibold text-cyan-200">
                    {title}
                  </h4>
                  <p className="mt-2 text-base leading-8 text-slate-400">
                    {detail}
                  </p>
                </div>
              ))}
            </div>
            <p className="mt-5 text-base leading-8 text-slate-300">
              成本同时计算研发、招聘与培训、专用硬件、双栈值守、回归工具和迁移窗口。未达到约定收益或出现无法解释的业务差异，阶段评审停止推进。
            </p>
          </article>
          <article className="explain-panel">
            <h3 className="text-xl font-semibold text-white">
              阶段验收与停止条件
            </h3>
            <p className="mt-3 text-base leading-8 text-slate-300">
              当前 Java 资金闭环提供正确性基线，Java/C++ 内存实验用于隔离语言与数据结构因素。进入生产迁移前，还需完成预占、日志确认、影子零副作用、带状态回退和故障恢复验收。
            </p>
            <p className="mt-3 text-base leading-8 text-slate-400">
              财务事实与业务语义必须零差异。无法解释的差异、恢复门禁未通过，或收益不足以覆盖双栈维护成本时，不扩大迁移范围。当前实验不代表已完成生产 C++ 替换。
            </p>
            <div className="mt-4">
              <SourceLink href={playbook}>
                查看技术设计、验收清单与交付计划
              </SourceLink>
            </div>
          </article>
        </TabsContent>
      </Tabs>
    </section>
  );
}

function SourceLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="inline-flex items-center gap-2 rounded-lg border border-cyan-300/20 px-3 py-2 text-sm text-cyan-200 hover:bg-cyan-300/10"
    >
      {children}
      <ExternalLink className="size-4" />
    </a>
  );
}

function ArchitectureDiagram() {
  return (
    <div className="mt-5 overflow-x-auto rounded-xl border border-cyan-300/15 bg-[#040d14] p-4">
      <svg
        viewBox="0 0 1120 650"
        aria-labelledby="cpp-architecture-title"
        className="min-w-[1000px] w-full"
      >
        <title id="cpp-architecture-title">
          当前 Java 数据库事务与候选 C++ 撮合服务拓扑
        </title>
        <defs>
          <marker
            id="cpp-arrow"
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M0 0 10 5 0 10z" fill="#67e8f9" />
          </marker>
        </defs>
        <rect
          x="15"
          y="20"
          width="1090"
          height="205"
          rx="18"
          fill="#0b1d29"
          stroke="#234c5a"
        />
        <text x="38" y="54" fill="#67e8f9" fontSize="18">
          当前已实现 · 数据库事务决定撮合与资金事实
        </text>
        <Box
          x={40}
          y={82}
          w={175}
          title="API / 有界 Lane"
          detail="普通与撤单保留容量"
        />
        <Box
          x={260}
          y={82}
          w={245}
          title="Java 盘前 + 撮合 + 资金"
          detail="一个事务，失败整体回滚"
        />
        <Box
          x={550}
          y={82}
          w={215}
          title="PostgreSQL"
          detail="订单 / 成交 / 账本 / Outbox"
        />
        <Box
          x={810}
          y={82}
          w={260}
          title="Kafka → 交割 / 对账"
          detail="唯一键、事务、Epoch Fencing"
        />
        <Arrow x1={215} y1={122} x2={260} y2={122} />
        <Arrow x1={505} y1={122} x2={550} y2={122} />
        <Arrow x1={765} y1={122} x2={810} y2={122} />
        <text x="40" y="195" fill="#94a3b8" fontSize="16">
          语言替换不会自动移除数据库往返；现有资金失败回滚能力必须有等价替代。
        </text>
        <rect
          x="15"
          y="250"
          width="1090"
          height="380"
          rx="18"
          fill="#091c20"
          stroke="#25645a"
        />
        <text x="38" y="286" fill="#6ee7b7" fontSize="18">
          候选迁移设计 · Java 账务 + 有围栏的独立热路径
        </text>
        <Box
          x={40}
          y={316}
          w={210}
          title="Java 用户 / 风控 / 预占"
          detail="DB 提交 + 待发送命令"
        />
        <Box
          x={305}
          y={316}
          w={210}
          title="准入 / 序号 / Epoch"
          detail="持久命令提交后执行"
        />
        <Box
          x={570}
          y={316}
          w={220}
          title="Java 或 C++ 单写订单簿"
          detail="价格时间优先 / 有界状态"
        />
        <Box
          x={845}
          y={316}
          w={220}
          title="已提交决定日志"
          detail="达到持久级别后才发布"
        />
        <Arrow x1={250} y1={356} x2={305} y2={356} />
        <Arrow x1={515} y1={356} x2={570} y2={356} />
        <Arrow x1={790} y1={356} x2={845} y2={356} />
        <Box
          x={40}
          y={462}
          w={260}
          title="Java 幂等账务 / 双资产交割"
          detail="余额、流水与状态同事务"
        />
        <Box
          x={350}
          y={462}
          w={205}
          title="影子引擎 / 差分"
          detail="无账务写入和外发"
        />
        <Box
          x={600}
          y={462}
          w={230}
          title="快照 / 重放 / 恢复校验"
          detail="去重结果 + 状态 + 序号"
        />
        <path
          d="M955 396 V420 H170 V462"
          fill="none"
          stroke="#67e8f9"
          strokeWidth="2"
          markerEnd="url(#cpp-arrow)"
        />
        <text x="835" y="452" fill="#a5f3fc" fontSize="16">
          已提交事件
        </text>
        <path
          d="M410 396 V462"
          fill="none"
          stroke="#6ee7b7"
          strokeWidth="2"
          strokeDasharray="5 6"
          markerEnd="url(#cpp-arrow)"
        />
        <path
          d="M955 396 V555 H715 V542"
          fill="none"
          stroke="#6ee7b7"
          strokeWidth="2"
          strokeDasharray="5 6"
          markerEnd="url(#cpp-arrow)"
        />
        <text x="40" y="602" fill="#94a3b8" fontSize="16">
          共同控制面：市场规则版本 · Kill Switch · 指标 / 审计 · 故障演练 ·
          分交易对切换
        </text>
      </svg>
    </div>
  );
}

function Box({
  x,
  y,
  w,
  title,
  detail,
}: {
  x: number;
  y: number;
  w: number;
  title: string;
  detail: string;
}) {
  return (
    <g>
      <rect
        x={x}
        y={y}
        width={w}
        height="80"
        rx="10"
        fill="#102a37"
        stroke="#337386"
      />
      <text
        x={x + w / 2}
        y={y + 30}
        fill="#e2e8f0"
        textAnchor="middle"
        fontSize="15"
      >
        {title}
      </text>
      <text
        x={x + w / 2}
        y={y + 57}
        fill="#94a3b8"
        textAnchor="middle"
        fontSize="13"
      >
        {detail}
      </text>
    </g>
  );
}
function Arrow({
  x1,
  y1,
  x2,
  y2,
}: {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}) {
  return (
    <line
      x1={x1}
      y1={y1}
      x2={x2}
      y2={y2}
      stroke="#67e8f9"
      strokeWidth="2"
      markerEnd="url(#cpp-arrow)"
    />
  );
}

function FundsSequence() {
  const actors = [
    '客户端',
    'Java 预占 / DB',
    '准入 / C++ 引擎',
    '可恢复日志',
    'Java 账务',
  ];
  const steps: [number, number, string][] = [
    [0, 1, '1. 新单 + 稳定 clientOrderId'],
    [1, 1, '2. 原子保存冻结与待发送命令'],
    [1, 2, '3. reservationId + epoch + 规则版本'],
    [2, 3, '4. 记录顺序与决定，达到约定持久级别'],
    [3, 2, '5. 确认已提交序号'],
    [2, 0, '6. 权威订单结果；超时则保持未知并查询'],
    [3, 4, '7. 同一 eventId 可重投，账务只应用一次'],
    [4, 1, '8. 冻结 → 在途 → 已交割 / 撤单释放'],
  ];
  return (
    <div className="mt-5 overflow-x-auto rounded-xl border border-cyan-300/15 bg-[#040d14] p-4">
      <svg
        viewBox="0 0 1120 640"
        aria-labelledby="cpp-sequence-title"
        className="w-full min-w-[1000px]"
      >
        <title id="cpp-sequence-title">
          候选迁移架构中新单、资金预占与幂等交割时序
        </title>
        <defs>
          <marker
            id="cpp-seq-arrow"
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M0 0 10 5 0 10z" fill="#67e8f9" />
          </marker>
        </defs>
        {actors.map((actor, i) => (
          <g key={actor}>
            <rect
              x={30 + i * 220}
              y="20"
              width="185"
              height="55"
              rx="9"
              fill="#102a37"
              stroke="#337386"
            />
            <text
              x={122 + i * 220}
              y="54"
              fill="#e2e8f0"
              textAnchor="middle"
              fontSize="16"
            >
              {actor}
            </text>
            <line
              x1={122 + i * 220}
              x2={122 + i * 220}
              y1="75"
              y2="610"
              stroke="#285766"
              strokeDasharray="5 7"
            />
          </g>
        ))}
        {steps.map(([from, to, label], i) => {
          const y = 124 + i * 61;
          const start = 122 + from * 220;
          const end = 122 + to * 220;
          return (
            <g key={label}>
              {from === to ? (
                <path
                  d={`M${start} ${y} h100 v23 h-100`}
                  fill="none"
                  stroke="#67e8f9"
                  markerEnd="url(#cpp-seq-arrow)"
                />
              ) : (
                <line
                  x1={start}
                  y1={y}
                  x2={end}
                  y2={y}
                  stroke="#67e8f9"
                  strokeWidth="2"
                  markerEnd="url(#cpp-seq-arrow)"
                />
              )}
              <text
                x={from === to ? start + 12 : (start + end) / 2}
                y={y - 12}
                textAnchor={from === to ? 'start' : 'middle'}
                fill="#cbd5e1"
                fontSize="15"
              >
                {label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function JavaCppEvidence() {
  const names: Record<string, string> = {
    mixed: '下单 / 撤单混合',
    sweeps: '连续扫单',
    retries: '重复请求密集',
  };
  const number = (value: number) => Math.round(value).toLocaleString('en-US');
  return (
    <article className="explain-panel">
      <div className="flex items-center gap-3">
        <GitCompareArrows className="size-5 text-cyan-300" />
        <h3 className="text-xl font-semibold text-white">
          实际测量：相同指令，两个实现
        </h3>
      </div>
      <p className="mt-3 text-base leading-8 text-slate-300">
        {evidence.generatedAt.slice(0, 10)} · {evidence.configuration.cpu} ·
        Java 21 / C++20 · 两个计时进程均为 x86_64 / Rosetta。每种负载 24,000
        条指令，每种语言 5 次独立进程运行，每次预热 3 遍。
      </p>
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[
          ['7 个典型场景', '49 条人工期望指令'],
          ['9,000 条差分指令', '独立 BigInt 模型 + 三个引擎核对'],
          ['72 万条延迟样本', '保留 30 次测量及原始 CSV'],
        ].map(([value, detail]) => (
          <div
            key={value}
            className="rounded-xl border border-cyan-300/15 bg-cyan-300/5 p-4"
          >
            <p className="text-lg font-semibold text-cyan-200">{value}</p>
            <p className="mt-2 text-base text-slate-400">{detail}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full min-w-[850px] text-left text-base">
          <caption className="px-4 py-3 text-left text-slate-400">
            仅内存命令处理；吞吐单位 ops/s，延迟单位 ns。各次统计取中位数，Max
            取最坏值。
          </caption>
          <thead className="bg-white/5 text-cyan-200">
            <tr>
              {[
                '负载',
                '实现',
                '吞吐 ops/s',
                'p50 ns',
                'p99 ns',
                'p99.9 ns',
                'Max ns',
              ].map((label) => (
                <th key={label} className="p-4 font-medium">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {evidence.workloads.flatMap((workload) =>
              (['java', 'cpp'] as const).map((language) => {
                const result = workload[language];
                return (
                  <tr
                    key={`${workload.name}-${language}`}
                    className="border-t border-white/10 text-slate-300"
                  >
                    <th scope="row" className="p-4 font-normal">
                      {names[workload.name]}
                    </th>
                    <td className="p-4">
                      {language === 'java' ? 'Java 21' : 'C++20'}
                    </td>
                    {[
                      result.medianThroughputOpsSec,
                      result.medianP50Ns,
                      result.medianP99Ns,
                      result.medianP999Ns,
                      result.worstMaxNs,
                    ].map((value, index) => (
                      <td key={index} className="p-4 font-mono tabular-nums">
                        {number(value)}
                      </td>
                    ))}
                  </tr>
                );
              }),
            )}
          </tbody>
        </table>
      </div>
      <div className="mt-5 rounded-xl border border-amber-300/20 bg-amber-300/5 p-5 text-base leading-8 text-slate-300">
        <p className="font-semibold text-amber-200">
          怎样解读，以及不能推导什么
        </p>
        <p>
          本次 C++ 吞吐更高，Java p50 更低；重试负载的 Java p99
          也更低。尾延迟有波动，没有用诊断数据证明波动成因，不能把差异直接归因于
          GC。
        </p>
        <p>
          这里没有网络、数据库、资金预占、Kafka、持久日志或恢复，不是公网
          QPS，也不是线上订单延迟。没有绑核或隔离系统噪声，未证明 JIT
          已稳态。数据库基线未按相同口径测量，不加入倍数比较。
        </p>
        <p>
          进程 CPU 含解析、预热和输出，不代表撮合 CPU；RSS 因本机限制未测，C++
          分配量未插桩。生产决定仍需在原生 Linux
          上完成相同持久确认与资金闭环测试。
        </p>
      </div>
      <a
        href={`${repository}/blob/main/docs/java-cpp-trading-evidence.md`}
        target="_blank"
        rel="noreferrer"
        className="mt-4 inline-flex items-center gap-2 text-base text-cyan-200"
      >
        打开实测数据与复现步骤 <ArrowRight className="size-4" />
      </a>
    </article>
  );
}
