'use client';

import { useState } from 'react';
import { ArrowDown, ArrowRight, Code2, FileCode2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { developerAiCases, repositoryTrace } from '@/lib/developer-ai-cases';
import { DeveloperCodeEvidence } from '@/components/developer-code-evidence';
import { AgentImplementation } from '@/components/agent-implementation';
import { LocalAiDeliveryEntry } from '@/components/local-ai-delivery-entry';
import { AiDeliveryEvidence } from '@/components/ai-delivery-evidence';

const sourceRoot =
  'https://github.com/soldierking04d/fincore-reliability-lab/blob/main/';

/** 公司研发落地说明：可展开任务与证据，不在浏览器假装调用 IDE、模型或执行 Java。 */
export function DeveloperAiDelivery() {
  const [selected, setSelected] = useState(0);
  const current = developerAiCases[selected];
  return (
    <div className="mt-7 space-y-6 text-base leading-7">
      <LocalAiDeliveryEntry />
      <AiDeliveryEvidence />
      <section className="rounded-2xl border border-cyan-300/25 bg-[#0b1b25] p-5 md:p-7">
        <p className="font-mono text-xs tracking-widest text-cyan-300">
          AI CODING · 从个人工具到团队工作方式
        </p>
        <h3 className="mt-3 text-2xl font-semibold text-white md:text-3xl">
          让 AI 在公司的代码里，
          <br />
          完成一个能验收的研发任务
        </h3>
        <p className="mt-4 max-w-4xl text-slate-300">
          以 Claude Code 或 Codex
          作为执行工具，把仓库上下文、编码约定、任务和测试交付串起来。 借鉴
          Cursor 解决研发问题的方式，不绑定某个产品；先做好下面三类任务。
        </p>
        <div className="mt-6 grid gap-3 lg:grid-cols-3">
          {developerAiCases.map((item, index) => (
            <Button
              key={item.id}
              variant="outline"
              aria-pressed={selected === index}
              onClick={() => setSelected(index)}
              className={`h-auto min-h-28 justify-start whitespace-normal p-4 text-left ${selected === index ? 'border-cyan-300/50 bg-cyan-300/10' : 'bg-black/15'}`}
            >
              <span>
                <span className="block text-sm text-cyan-200">
                  0{index + 1} · {item.short}
                </span>
                <span className="mt-2 block text-lg font-medium text-white">
                  {item.title}
                </span>
                <span className="mt-2 flex items-center gap-2 text-sm text-slate-400">
                  {selected === index ? '正在查看' : '展开做法与交付物'}
                  <ArrowRight className="size-4" />
                </span>
              </span>
            </Button>
          ))}
        </div>
        <p className="mt-4 text-sm text-slate-400">
          下方保留工具无关的实施包与既有 Java 代码实验。独立本地工作台支持真实模型调用、
          候选审查和 Java 验证，逐次保存耗时与 Token；本展示页自身不调用模型或执行 Java。
          能跑通案例不等于已证明团队提效，仍需人工基线对照。
        </p>
      </section>
      <AgentImplementation />
      <section className="explain-panel !p-5 md:!p-7" aria-live="polite">
        <p className="text-sm text-cyan-200">场景 0{selected + 1}</p>
        <h3 className="mt-2 text-2xl font-semibold text-white">
          {current.title}
        </h3>
        <p className="mt-4 text-slate-300">{current.problem}</p>
        <div className="mt-5 grid gap-5 xl:grid-cols-2">
          <div>
            <h4 className="flex items-center gap-2 font-medium text-white">
              <Code2 className="size-5 text-cyan-300" />
              交给 AI 的任务
            </h4>
            <blockquote className="mt-3 rounded-xl border-l-2 border-cyan-300/60 bg-black/20 p-4 text-slate-200">
              {current.input}
            </blockquote>
            <h4 className="mt-5 font-medium text-white">必须交付</h4>
            <p className="mt-2 text-slate-300">{current.output}</p>
          </div>
          <ol className="space-y-3">
            {current.steps.map((step, index) => (
              <li
                key={step}
                className="flex gap-3 rounded-xl border border-white/10 p-4"
              >
                <span className="font-mono text-cyan-300">0{index + 1}</span>
                <span className="text-slate-300">{step}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="mt-5 grid gap-4 lg:grid-cols-3">
          {[
            ['收益', current.benefit],
            ['负面影响与处理', current.downside],
            ['怎样判断是否值得', current.measure],
          ].map(([label, text]) => (
            <div key={label} className="rounded-xl bg-black/15 p-4">
              <h4 className="font-medium text-cyan-100">{label}</h4>
              <p className="mt-2 text-slate-400">{text}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="explain-panel !p-5 md:!p-7">
        <h3 className="text-xl font-semibold text-white">
          证据一：这份仓库地图能打开源文件核对
        </h3>
        <p className="mt-3 text-slate-400">
          以已有账户摘要查询为只读示例；下面是源码调用关系，不是新开发的业务，也不是实时链路追踪。
        </p>
        <div className="mt-5 space-y-2">
          {repositoryTrace.map((entry, index) => (
            <div key={entry.path}>
              {index > 0 && (
                <ArrowDown className="mx-auto my-2 size-5 text-cyan-300/60" />
              )}
              <a
                href={`${sourceRoot}${entry.path}`}
                target="_blank"
                rel="noreferrer"
                className="block rounded-xl border border-white/10 bg-black/15 p-4 transition hover:border-cyan-300/40"
              >
                <div className="flex flex-wrap items-center gap-2 font-mono text-sm text-cyan-200">
                  <FileCode2 className="size-4" />
                  {entry.symbol}
                </div>
                <p className="mt-2 text-slate-200">{entry.detail}</p>
                <p className="mt-2 break-all font-mono text-xs text-slate-400">
                  {entry.path}
                </p>
              </a>
            </div>
          ))}
        </div>
        <p className="mt-4 text-sm text-amber-200/80">
          例如“找不到账户返回什么状态”必须继续检查异常处理与测试，不能仅凭这三份文件推断。AI
          的未知项也应当交付。
        </p>
      </section>
      <DeveloperCodeEvidence />
      <section className="explain-panel !p-5 md:!p-7">
        <h3 className="text-xl font-semibold text-white">
          怎样接进公司现有研发流程
        </h3>
        <ol className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {[
            [
              '01 · 团队准备上下文',
              '平台负责人维护共享规则；模块负责人给代码入口和参考实现；测试负责人确定独立验收条件。',
            ],
            [
              '02 · 开发者使用助手',
              '在获准的仓库和开发分支中，给一个有限任务。AI 读代码、生成候选补丁、辅助处理测试失败。',
            ],
            [
              '03 · 正常评审与 CI',
              '开发者先解释差异，再由同事 review；沿用现有测试和合并门禁，不自动推送、部署或修改生产。',
            ],
            [
              '04 · 回收真实反馈',
              '记录总用时、返工、漏检缺陷。重复错误才沉淀进共享规则；没有改善的场景及时停用。',
            ],
          ].map(([title, detail]) => (
            <li key={title} className="rounded-xl border border-white/10 p-4">
              <h4 className="font-medium text-cyan-100">{title}</h4>
              <p className="mt-3 text-slate-400">{detail}</p>
            </li>
          ))}
        </ol>
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <div className="rounded-xl bg-black/15 p-4">
            <h4 className="font-medium text-white">接入包已经有什么</h4>
            <p className="mt-3 text-slate-300">
              AGENTS.md / CLAUDE.md
              入口、共同流程、任务包生成器、独立候选验证、仓库地图、评审模板与
              Java 代码实验。 原 Cursor
              规则作为可选适配保留；公司的任务和验收不随工具变化。
            </p>
          </div>
          <div className="rounded-xl border border-amber-200/15 bg-amber-200/5 p-4">
            <h4 className="font-medium text-amber-100">
              “内部使用”不等于“代码不出内网”
            </h4>
            <p className="mt-3 text-slate-300">
              公司要确认所选
              Agent、模型供应商、代码传输与保留策略。规则文件不是访问控制，忽略文件也不是通用沙箱。
              先批准可输入的仓库和资料，再配置真实文件、网络和命令权限；换工具时重新核对。
            </p>
            <p className="mt-3 text-sm">
              <a
                href="https://learn.chatgpt.com/docs/security"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-200 underline"
              >
                Codex 安全说明
              </a>{' '}
              ·{' '}
              <a
                href="https://code.claude.com/docs/en/permissions"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-200 underline"
              >
                Claude Code 权限说明
              </a>
            </p>
          </div>
        </div>
      </section>
      <section className="explain-panel !p-5 md:!p-7">
        <h3 className="text-xl font-semibold text-white">
          负责人看什么：四周试点，算总账
        </h3>
        <p className="mt-3 text-slate-300">
          第 1 周整理上下文并记录人工基线；第 2 周试仓库理解和小需求；第 3
          周加入缺陷修复与同类任务对照；第 4
          周决定扩大、缩小或停止。这是建议实施计划，尚非公司实绩。
        </p>
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <div>
            <h4 className="font-medium text-cyan-100">收益指标</h4>
            <p className="mt-3 text-slate-400">
              找到正确代码的时间、需求到可评审补丁的时间、复现与修复耗时。加上
              review、测试处理、返工和维护投入，对比同难度人工任务；放弃的任务也计入。
            </p>
          </div>
          <div>
            <h4 className="font-medium text-amber-100">负面影响与退出条件</h4>
            <p className="mt-3 text-slate-400">
              错误上下文带来误改、测试迎合实现、同事评审负担上升、开发者难以解释代码。若总用时变长或漏检缺陷增加，先缩小范围；数据越界立即停下处理。
            </p>
          </div>
        </div>
        <p className="mt-4 text-sm text-slate-400">
          不按生成行数考核开发者，不承诺固定提效比例。节约工时是可用于其他任务的容量，不自动等于现金节省；工具费用另计。
        </p>
        <div className="mt-5 flex flex-wrap gap-3">
          <a
            href="/ai-developer/kit.zip"
            download
            className="nav-link inline-flex min-h-11 items-center gap-2 text-sm"
          >
            下载接入包：规则、任务、代码、测试 <ArrowRight className="size-4" />
          </a>
          <a
            href="/ai-developer/company-playbook.md"
            download
            className="nav-link inline-flex min-h-11 items-center gap-2 text-sm"
          >
            下载完整落地手册 <ArrowRight className="size-4" />
          </a>
        </div>
      </section>
    </div>
  );
}
