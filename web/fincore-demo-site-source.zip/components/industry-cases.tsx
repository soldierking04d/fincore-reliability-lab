import {
  Activity,
  Check,
  ExternalLink,
  Gauge,
  ShieldCheck,
  TimerReset,
  Workflow,
} from 'lucide-react';

const repository = 'https://github.com/soldierking04d/fincore-reliability-lab';

const transitionDimensions = [
  {
    title: '流量与市场',
    internet: '活动流量可预告、可预热',
    trading: '价格波动外生触发，订单、撤单和风控形成正反馈',
    response: '把波动率、盘口深度和订单/撤单比纳入容量模型',
  },
  {
    title: '错误的经济后果',
    internet: '部分失败可以退款或延迟补偿',
    trading: '重复成交、错账、穿仓会直接形成资产损失',
    response: '状态机、幂等、不可变账本、审计与对账内建',
  },
  {
    title: '延迟与一致性',
    internet: '大量读链路可缓存，写入常可异步',
    trading: '行情新鲜度、公平顺序和资金因果同时成立',
    response: '确定性热路径强约束，外围异步可恢复',
  },
  {
    title: '过载与退出风险',
    internet: '推荐、搜索和营销可大幅降级',
    trading: '新单可拒绝，但撤单和只减仓必须优先保护',
    response: '分级准入、独立保留容量、明确未知结果',
  },
  {
    title: '组织与运营',
    internet: '通常存在发布低峰和维护窗口',
    trading: '7×24 小时、跨时区、多供应商和监管边界',
    response: '跨时区值班、事故指挥、灰度回滚和统一事实口径',
  },
];

const cancelChecks = [
  ['普通队列背压', '满载后新单明确返回 429，不进入无界队列'],
  ['撤单保留容量', '普通新单已满，撤单仍可进入独立有界容量'],
  ['同一交易对 Lane', '撤单只越过未开始积压，不抢占进行中的成交事务'],
  ['资金释放', '部分成交后只释放未成交部分，重复撤单不重复释放'],
  ['前端语义', '未得到权威 CANCELED 就不能显示“撤单成功”；超时显示确认中'],
];

export function IndustryCases() {
  return (
    <section id="industry-cases" className="mx-auto max-w-[1680px] scroll-mt-20 px-4 py-5 sm:px-6 lg:px-8">
      <div className="chapter-section mt-0 border-t-0 pt-5">
        <div className="grid gap-5 xl:grid-cols-[170px_1fr]">
          <div>
            <p className="chapter-number">CASE</p>
            <p className="mt-3 font-mono text-xs tracking-[0.16em] text-cyan-300/70">SYSTEM · BUSINESS · PEOPLE</p>
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <EvidenceTag>行业与高并发系统案例</EvidenceTag>
              <EvidenceTag tone="green">代码、数据、测试可核验</EvidenceTag>
            </div>
            <h2 className="mt-4 max-w-5xl text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">
              数字资产交易约束与大流量撤单的端到端实现
            </h2>
            <p className="mt-3 max-w-5xl text-sm leading-7 text-slate-400">
              数字资产交易需要同时约束市场波动、资金安全和 7×24 小时运营。大流量撤单案例进一步给出有界容量、交易顺序、资金事务、前端状态、监控指标和自动化测试。
            </p>
          </div>
        </div>

        <article className="mt-6 overflow-hidden rounded-2xl border border-cyan-300/12 bg-[linear-gradient(145deg,rgba(11,31,42,.96),rgba(7,16,25,.98)_55%,rgba(12,28,38,.96))]">
          <header className="grid gap-5 border-b border-white/7 p-5 sm:p-7 xl:grid-cols-[1.15fr_.85fr]">
            <div>
              <p className="panel-kicker text-cyan-300">CASE 01 · INDUSTRY TRANSITION</p>
              <h3 className="mt-3 text-xl font-semibold text-white sm:text-2xl">从互联网系统到数字资产交易：约束与架构变化</h3>
              <p className="mt-3 text-sm leading-7 text-slate-400">
                流量由市场驱动、错误有直接经济后果、交易公平与资金因果必须同时成立，并且全年没有统一停机窗口。互联网经验可以迁移，但必须由金融不变量重新约束。
              </p>
            </div>
            <aside className="rounded-xl border border-emerald-300/12 bg-emerald-300/[0.035] p-4 sm:p-5">
              <p className="panel-kicker text-emerald-300">系统设计与运行责任</p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {['行业风险理解', '架构取舍能力', '业务与产品判断', '盘前 / 盘中 / 盘后风控', '7×24 运营体系', '跨团队事故指挥'].map((item) => (
                  <p key={item} className="flex items-center gap-2 rounded-lg border border-white/6 bg-black/10 px-3 py-2 text-xs text-slate-300">
                    <Check className="size-3.5 shrink-0 text-emerald-300" />{item}
                  </p>
                ))}
              </div>
            </aside>
          </header>

          <div className="p-5 sm:p-7">
            <div className="overflow-x-auto rounded-xl border border-white/7">
              <table className="min-w-[920px] w-full border-collapse text-left text-sm">
                <thead className="bg-white/[0.035] text-xs text-slate-300">
                  <tr><th className="p-3">维度</th><th className="p-3">互联网 / 电商</th><th className="p-3">数字资产交易</th><th className="p-3">工程与管理措施</th></tr>
                </thead>
                <tbody>
                  {transitionDimensions.map((item) => (
                    <tr key={item.title} className="border-t border-white/6 align-top">
                      <th className="p-3 font-medium text-cyan-200">{item.title}</th>
                      <td className="p-3 leading-6 text-slate-500">{item.internet}</td>
                      <td className="p-3 leading-6 text-slate-300">{item.trading}</td>
                      <td className="p-3 leading-6 text-emerald-100/70">{item.response}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <section className="mt-5 rounded-xl border border-white/7 bg-black/10 p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><p className="panel-kicker">SYSTEM ARCHITECTURE</p><h4 className="mt-2 text-base font-semibold text-white">迁移不是换术语，而是把工程底座接到交易全链路</h4></div>
                <a href={`${repository}/blob/main/docs/internet-to-digital-asset-trading.md`} target="_blank" rel="noreferrer" className="nav-link inline-flex text-xs">打开完整系统说明 <ExternalLink className="size-3" /></a>
              </div>
              <TransitionArchitecture />
            </section>

            <div className="mt-5 grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
              <section className="rounded-xl border border-cyan-300/10 bg-cyan-300/[0.025] p-4 sm:p-5">
                <p className="panel-kicker text-cyan-300">关键控制措施</p>
                <div className="mt-3 space-y-3 text-sm leading-7 text-slate-300">
                  <p><strong className="text-white">风险隔离：</strong>将市场冲击纳入容量和故障模型，优先保护撤单与减仓，禁止未知结果下重复扣款或提前释放资金。</p>
                  <p><strong className="text-white">一致性边界：</strong>盘前准入、确定性撮合、清结算账本和对账恢复分层；每次状态迁移保留资金不变量与审计记录。</p>
                  <p><strong className="text-white">持续运营：</strong>价格、订单、风险、资金和系统指标联动，配套跨时区值班、灰度、回滚和客户沟通。</p>
                </div>
              </section>
              <section className="rounded-xl border border-white/7 bg-black/10 p-4 sm:p-5">
                <p className="panel-kicker">TEST DATA</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <CaseMetric value="60 = 60" label="成交 / 唯一序列" />
                  <CaseMetric value="17 → 1" label="重复投递 / 资金效果" />
                  <CaseMetric value="10 / 10" label="暴跌日恢复检查" />
                  <CaseMetric value="最终 CLEAN" label="对账修复结果" />
                </div>
                <p className="mt-3 text-xs leading-6 text-slate-500">数据证明正确性与恢复语义，不冒充目标硬件上的生产容量承诺。</p>
              </section>
            </div>
          </div>
        </article>

        <article className="mt-6 overflow-hidden rounded-2xl border border-amber-300/12 bg-[linear-gradient(145deg,rgba(33,26,12,.5),rgba(7,16,25,.98)_48%,rgba(24,15,23,.78))]">
          <header className="grid gap-5 border-b border-white/7 p-5 sm:p-7 xl:grid-cols-[1.15fr_.85fr]">
            <div>
              <p className="panel-kicker text-amber-200">CASE 02 · CANCELLATION UNDER LOAD</p>
              <h3 className="mt-3 text-xl font-semibold text-white sm:text-2xl">新单积压与撤单风暴下的准入、顺序和资金保护</h3>
              <p className="mt-3 text-sm leading-7 text-slate-400">
                撤单缓存只能做提示，不能做权威事实。正确做法是给撤单保留独立有界容量，但仍让下单、成交和撤单进入同一交易对 Lane 决定先后；订单、资金、审计和 Outbox 同事务提交。
              </p>
            </div>
            <aside className="rounded-xl border border-rose-300/12 bg-rose-300/[0.035] p-4 sm:p-5">
              <p className="panel-kicker text-rose-300">不能跨越的产品边界</p>
              <p className="mt-3 text-sm leading-7 text-rose-100/70">
                “请求已接收”不等于“撤单成功”。如果接口超时或只完成排队，前端必须显示“结果确认中”；只有读到权威 <span className="font-mono text-rose-200">CANCELED</span>，才能显示“撤单成功”。
              </p>
            </aside>
          </header>

          <div className="p-5 sm:p-7">
            <section className="rounded-xl border border-white/7 bg-black/10 p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div><p className="panel-kicker">SYSTEM ARCHITECTURE</p><h4 className="mt-2 text-base font-semibold text-white">双有界容量、单一顺序边界、权威资金事务</h4></div>
                <a href={`${repository}/blob/main/docs/cancellation-under-load.md`} target="_blank" rel="noreferrer" className="nav-link inline-flex text-xs">打开撤单完整设计 <ExternalLink className="size-3" /></a>
              </div>
              <CancellationArchitecture />
            </section>

            <div className="mt-5 grid gap-4 xl:grid-cols-[.88fr_1.12fr]">
              <section className="rounded-xl border border-white/7 bg-black/10 p-4 sm:p-5">
                <p className="panel-kicker">TEST DATA · 256 BACKLOG</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <CaseMetric value="256" label="普通新单积压" tone="amber" />
                  <CaseMetric value="429" label="第 257 笔新单" tone="rose" />
                  <CaseMetric value="0" label="撤单完成时普通已完成" tone="green" />
                  <CaseMetric value="CANCELED" label="权威订单终态" tone="green" />
                </div>
                <p className="mt-3 text-xs leading-6 text-slate-500">可通过 lab 场景重新生成 runId、交易对、耗时和全部 PASS 断言。</p>
              </section>
              <section className="rounded-xl border border-white/7 bg-black/10 p-4 sm:p-5">
                <p className="panel-kicker">INVARIANTS · 验收标准</p>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {cancelChecks.map(([title, detail]) => (
                    <div key={title} className="rounded-lg border border-white/6 bg-white/[0.018] p-3">
                      <p className="flex items-center gap-2 text-sm font-medium text-slate-200"><Check className="size-3.5 text-emerald-300" />{title}</p>
                      <p className="mt-2 text-xs leading-6 text-slate-500">{detail}</p>
                    </div>
                  ))}
                </div>
              </section>
            </div>

            <section className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
              <EvidenceCard icon={Gauge} title="入口" detail="普通 256 / Lane；撤单保留 32 / Lane" />
              <EvidenceCard icon={Workflow} title="顺序" detail="当前事务 → 撤单 → 普通积压；8:1 防饥饿" />
              <EvidenceCard icon={ShieldCheck} title="资金" detail="只释放未成交部分，重复请求只有一次效果" />
              <EvidenceCard icon={Activity} title="监控" detail="撤单深度、拒绝数与价格波动联动" />
              <EvidenceCard icon={TimerReset} title="未知结果" detail="429/503/超时先查询，不提前报告成功" />
            </section>

            <section className="mt-5 rounded-xl border border-emerald-300/10 bg-emerald-300/[0.025] p-4 sm:p-5">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                  <p className="panel-kicker text-emerald-300">CODE EVIDENCE</p>
                  <h4 className="mt-2 text-base font-semibold text-white">实现、测试、数据基线可以逐项核对</h4>
                  <p className="mt-2 max-w-4xl text-sm leading-7 text-slate-400">核心代码不是“优先线程池”一句话：它包含普通/撤单双容量、最大优先批次、同交易对路由、数据库锁、状态 CAS、部分成交资金释放和失败 HTTP 语义。</p>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  <a href={`${repository}/blob/main/src/main/java/dev/fincore/infrastructure/concurrent/StripedTaskExecutor.java`} target="_blank" rel="noreferrer" className="nav-link inline-flex text-xs">并发实现 <ExternalLink className="size-3" /></a>
                  <a href={`${repository}/blob/main/src/test/java/dev/fincore/infrastructure/concurrent/StripedTaskExecutorTest.java`} target="_blank" rel="noreferrer" className="nav-link inline-flex text-xs">优先测试 <ExternalLink className="size-3" /></a>
                  <a href={`${repository}/blob/main/reports/cancellation-storm-baseline.json`} target="_blank" rel="noreferrer" className="nav-link inline-flex text-xs">测试数据 <ExternalLink className="size-3" /></a>
                </div>
              </div>
            </section>

            <section className="mt-4 rounded-xl border border-amber-300/10 bg-amber-300/[0.025] p-4 sm:p-5">
              <p className="panel-kicker text-amber-200">LIMITS · 不夸大边界</p>
              <p className="mt-2 text-sm leading-7 text-slate-400">当前撤单保留队列是单实例内存准入层；进程在命令执行前崩溃时，客户端需要查询并重试。生产级超低延迟升级应采用按交易对分区的持久化命令日志、单写者内存订单簿、快照和确定性重放。</p>
            </section>
          </div>
        </article>
      </div>
    </section>
  );
}

function TransitionArchitecture() {
  const nodes = [
    ['互联网底座', '限流 · 幂等 · MQ · 灰度', 30, 'cyan'],
    ['用户 / KYC', '身份与交易权限', 230, 'neutral'],
    ['行情 / 盘前风控', '新鲜度 · 敞口 · 余额', 430, 'amber'],
    ['确定性交易核心', '有界 Lane · 撮合 · 撤单', 630, 'cyan'],
    ['清结算 / 账本', 'DvP · 不可变分录', 830, 'green'],
  ] as const;
  return <div className="architecture-svg-scroll mt-4 rounded-xl border border-white/6">
    <svg className="block h-auto w-full min-w-[1000px]" viewBox="0 0 1060 300" aria-labelledby="transition-architecture-title">
      <title id="transition-architecture-title">互联网工程能力迁移到数字资产交易全链路的系统架构</title>
      <defs><marker id="transition-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker></defs>
      <text x="30" y="34" className="architecture-zone-title">ENGINEERING FOUNDATION → FINANCIAL INVARIANTS → 7×24 OPERATIONS</text>
      {nodes.map(([title, detail, x, tone], index) => <g key={title}>
        <g className={`architecture-svg-node architecture-svg-node-${tone}`}><rect x={x} y="86" width="170" height="76" rx="12" /><circle cx={x + 18} cy="106" r="4" /><text x={x + 18} y="126" className="architecture-svg-title">{title}</text><text x={x + 18} y="146" className="architecture-svg-detail">{detail}</text></g>
        {index < nodes.length - 1 && <path d={`M${x + 170} 124 H${x + 194}`} className="service-topology-arrow" markerEnd="url(#transition-arrow)" />}
      </g>)}
      <path d="M315 162 V220 H690 V162" className="module-svg-data-arrow" />
      <g className="architecture-database-node"><rect x="318" y="220" width="370" height="52" rx="10" /><ellipse cx="503" cy="230" rx="145" ry="9" /><text x="503" y="251" textAnchor="middle" className="architecture-svg-title">权威事实：订单 · 成交 · 资金 · 审计</text></g>
      <text x="845" y="210" className="architecture-svg-proof">监控：价格 × 单量 × 风险 × 资金 × 系统</text>
    </svg>
  </div>;
}

function CancellationArchitecture() {
  return <div className="architecture-svg-scroll mt-4 rounded-xl border border-white/6">
    <svg className="block h-auto w-full min-w-[1000px]" viewBox="0 0 1080 350" aria-labelledby="cancel-architecture-title">
      <title id="cancel-architecture-title">大流量下撤单的双有界队列、同交易对顺序与资金事务架构</title>
      <defs><marker id="cancel-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker></defs>
      <text x="28" y="32" className="architecture-zone-title">ADMISSION</text><text x="420" y="32" className="architecture-zone-title">SINGLE ORDERING BOUNDARY</text><text x="750" y="32" className="architecture-zone-title">AUTHORITATIVE TRANSACTION</text>
      <CaseNode x={30} y={120} width={150} title="交易 API" detail="place / cancel" tone="neutral" />
      <CaseNode x={230} y={72} width={180} title="普通新单队列" detail="256 / Lane · 满载 429" tone="amber" />
      <CaseNode x={230} y={182} width={180} title="撤单保留队列" detail="32 / Lane · 优先出队" tone="rose" />
      <CaseNode x={470} y={120} width={190} title="同一交易对 Lane" detail="1 platform thread · 8:1" tone="cyan" />
      <CaseNode x={720} y={120} width={160} title="交易对事务锁" detail="跨实例确定顺序" tone="cyan" />
      <CaseNode x={930} y={72} width={125} title="订单" detail="CAS 终态" tone="green" />
      <CaseNode x={930} y={182} width={125} title="资金" detail="释放余单" tone="green" />
      <path d="M180 145 H210 V107 H230" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M180 157 H210 V217 H230" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M410 107 H445 V145 H470" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M410 217 H445 V157 H470" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M660 152 H720" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M880 145 H905 V107 H930" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <path d="M880 157 H905 V217 H930" className="service-topology-arrow" markerEnd="url(#cancel-arrow)" />
      <rect x="470" y="272" width="410" height="48" rx="10" className="legend-target" />
      <text x="675" y="293" textAnchor="middle" className="architecture-svg-title">订单状态 + 资金释放 + 审计 + Outbox 同事务</text>
      <text x="675" y="310" textAnchor="middle" className="architecture-svg-detail">COMMIT 后才能向前端返回 CANCELED</text>
    </svg>
  </div>;
}

function CaseNode({ x, y, width, title, detail, tone }: { x: number; y: number; width: number; title: string; detail: string; tone: 'neutral' | 'amber' | 'rose' | 'cyan' | 'green' }) {
  return <g className={`architecture-svg-node architecture-svg-node-${tone}`}><rect x={x} y={y} width={width} height="72" rx="11" /><circle cx={x + 18} cy={y + 20} r="4" /><text x={x + 18} y={y + 40} className="architecture-svg-title">{title}</text><text x={x + 18} y={y + 59} className="architecture-svg-detail">{detail}</text></g>;
}

function EvidenceTag({ children, tone = 'cyan' }: { children: React.ReactNode; tone?: 'cyan' | 'green' }) {
  return <span className={`rounded-full border px-3 py-1.5 font-mono text-xs ${tone === 'green' ? 'border-emerald-300/15 bg-emerald-300/[0.05] text-emerald-300' : 'border-cyan-300/15 bg-cyan-300/[0.05] text-cyan-300'}`}>{children}</span>;
}

function CaseMetric({ value, label, tone = 'cyan' }: { value: string; label: string; tone?: 'cyan' | 'amber' | 'rose' | 'green' }) {
  const colors = { cyan: 'text-cyan-300', amber: 'text-amber-200', rose: 'text-rose-300', green: 'text-emerald-300' };
  return <div className="rounded-lg border border-white/6 bg-white/[0.018] p-3"><p className={`font-mono text-lg font-semibold ${colors[tone]}`}>{value}</p><p className="mt-1 text-xs leading-5 text-slate-500">{label}</p></div>;
}

function EvidenceCard({ icon: Icon, title, detail }: { icon: typeof Activity; title: string; detail: string }) {
  return <div className="rounded-xl border border-white/7 bg-black/10 p-4"><Icon className="size-4 text-cyan-300" /><p className="mt-3 text-sm font-medium text-white">{title}</p><p className="mt-2 text-xs leading-6 text-slate-500">{detail}</p></div>;
}
