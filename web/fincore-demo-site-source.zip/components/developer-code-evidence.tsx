'use client';

import { useState } from 'react';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import evidence from '@/public/ai-developer/evidence.json';

const { report, files } = evidence;
const before = report.variants.find((v) => v.variant === 'before')!;
const after = report.variants.find((v) => v.variant === 'after')!;
const surgical = report.variants.find((v) => v.variant === 'overflow-only')!;

function outcome(value: {
  kind: string;
  offset?: string;
  query?: string;
  type?: string;
}) {
  return value.kind === 'error'
    ? `拒绝：${value.type}`
    : `offset=${value.offset}；query=${JSON.stringify(value.query)}`;
}

/** 只展示落盘的真实 Java 结果；浏览器切换视图不会触发重新运行或模型调用。 */
export function DeveloperCodeEvidence() {
  const [expanded, setExpanded] = useState(false);
  const rows = expanded
    ? before.results
    : before.results.filter((r) => ['P03', 'P05', 'P09'].includes(r.id));
  return (
    <section className="explain-panel !p-5 md:!p-7">
      <p className="font-mono text-xs tracking-widest text-cyan-300">
        CODE → TEST → REVIEW
      </p>
      <h3 className="mt-2 text-xl font-semibold text-white">
        证据二：从一个小需求，到可复查的代码交付
      </h3>
      <p className="mt-3 text-slate-300">
        内部工单分页参数练习。先看旧版，再看只修溢出的一行补丁，最后看包含参数校验与关键词处理的完整实现。
      </p>
      <div className="mt-5 grid gap-3 md:grid-cols-3">
        {[
          [
            '旧版',
            `${before.passed}/${before.total}`,
            `${before.failed} 项失败，保留正常基线`,
            'text-amber-200',
          ],
          [
            '只修溢出',
            `${surgical.passed}/${surgical.total}`,
            '仅 P03 转绿，其余行为不变',
            'text-cyan-200',
          ],
          [
            '完整需求',
            `${after.passed}/${after.total}`,
            '所有既定合同用例通过',
            'text-emerald-200',
          ],
        ].map(([title, value, note, color]) => (
          <div
            key={title}
            className="rounded-xl border border-white/10 bg-black/20 p-4"
          >
            <h4 className="text-sm text-slate-300">{title}</h4>
            <p className={`mt-2 font-mono text-3xl ${color}`}>{value}</p>
            <p className="mt-2 text-sm text-slate-400">{note}</p>
          </div>
        ))}
      </div>
      <p className="mt-3 text-sm text-slate-400">
        实际执行：{report.generatedAt.replace('T', ' ').replace('Z', ' UTC')} ·
        Java {report.execution.java} · Node {report.execution.node}
        。合成样例，不接数据库或 HTTP 服务；不是模型质量评分。
      </p>
      <Tabs defaultValue="minimal" className="mt-6">
        <TabsList className="h-auto min-h-11 w-full flex-wrap justify-start gap-1 p-1">
          <TabsTrigger value="before" className="min-h-10 px-3">
            旧版源码
          </TabsTrigger>
          <TabsTrigger value="minimal" className="min-h-10 px-3">
            一行缺陷修复
          </TabsTrigger>
          <TabsTrigger value="after" className="min-h-10 px-3">
            完整需求实现
          </TabsTrigger>
          <TabsTrigger value="patch" className="min-h-10 px-3">
            完整差异
          </TabsTrigger>
        </TabsList>
        {[
          ['before', files['before/TicketQuery.java']],
          ['minimal', files['overflow-only.patch']],
          ['after', files['after/TicketQuery.java']],
          ['patch', files['solution.patch']],
        ].map(([id, code]) => (
          <TabsContent key={id} value={id}>
            <pre className="max-h-[30rem] overflow-auto rounded-xl border border-white/10 bg-[#060d14] p-4 text-sm leading-6 text-slate-200">
              <code>{code}</code>
            </pre>
          </TabsContent>
        ))}
      </Tabs>
      <p className="mt-3 text-amber-100">
        关键点：先把 page 转成 long 再乘。若写成 (long)(page * size)，int
        乘法已先溢出，转型也救不回来。
      </p>
      <p className="mt-3 text-sm text-slate-400">
        单缺陷补丁仍有 7
        项未满足完整需求，不能交付成“全部修好”。完整实现会拒绝过去放行的非法参数，属于行为收紧；long
        计算也没有解决数据库深分页性能问题。
      </p>
      <div className="mt-6 rounded-xl border border-white/10 p-3">
        <Table className="min-w-[760px] text-sm">
          <TableHeader>
            <TableRow>
              <TableHead>独立用例 / 输入</TableHead>
              <TableHead>预期值</TableHead>
              <TableHead>旧版实际值</TableHead>
              <TableHead>完整实现实际值</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row) => {
              const fixed = after.results.find((r) => r.id === row.id)!;
              return (
                <TableRow key={row.id}>
                  <TableCell className="max-w-64 whitespace-normal">
                    <p className="text-slate-100">
                      {row.id} · {row.name}
                    </p>
                    <code className="mt-2 block break-all text-xs text-slate-400">
                      {JSON.stringify(row.input)}
                    </code>
                  </TableCell>
                  <TableCell className="max-w-56 whitespace-normal break-all">
                    {outcome(row.expected)}
                  </TableCell>
                  <TableCell className="max-w-56 whitespace-normal break-all">
                    <p
                      className={
                        row.pass ? 'text-emerald-200' : 'text-amber-200'
                      }
                    >
                      {row.pass ? '通过' : '失败'}
                    </p>
                    {outcome(row.actual)}
                  </TableCell>
                  <TableCell className="max-w-56 whitespace-normal break-all">
                    <p
                      className={
                        fixed.pass ? 'text-emerald-200' : 'text-amber-200'
                      }
                    >
                      {fixed.pass ? '通过' : '失败'}
                    </p>
                    {outcome(fixed.actual)}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
      <Button
        variant="outline"
        className="mt-4 h-auto min-h-11 px-4 py-2.5 text-sm"
        onClick={() => setExpanded(!expanded)}
        aria-expanded={expanded}
      >
        {expanded ? '收起到 3 个关键用例' : '展开全部 12 个用例'}
      </Button>
      <p className="mt-3 text-sm text-slate-400">
        源码、测试与补丁的 SHA-256
        摘要都在报告内。切换标签或展开表格只是查看同一次执行的保存结果，不会在网页里重新运行。
      </p>
      <details className="mt-4 rounded-xl border border-white/10 p-4">
        <summary className="cursor-pointer text-base text-cyan-200">
          在自己的开发机重新验证
        </summary>
        <p className="mt-3 text-slate-300">
          下载下方接入包，准备已有 Node 24 和 JDK 21，在解压目录执行：
        </p>
        <pre className="mt-3 overflow-x-auto rounded-lg bg-black/25 p-3 text-sm">
          <code>node ai/developer-adoption/workshop/run-workshop.mjs</code>
        </pre>
        <p className="mt-3 text-sm text-slate-400">
          会启动本地 Java，报告与 class
          写到新建临时目录。不下载依赖、不接生产；缺 JDK
          或编译错误会报错退出，不算复现成功。
        </p>
      </details>
      <a
        href="/ai-developer/evidence.json"
        download
        className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm text-cyan-200"
      >
        <Download className="size-4" />
        下载本次报告与源码（JSON）
      </a>
    </section>
  );
}
