import { ArrowRight, BookOpen, GitBranch, Layers3, Radio, ShieldCheck } from 'lucide-react';
import { portfolioTopics } from '@/lib/portfolio-topics';
import { RepresentativeCases } from '@/components/representative-cases';

export function PortfolioOverview() {
  return <section id="overview" className="portfolio-overview">
    <div className="overview-heading">
      <div className="overview-copy">
        <p className="overview-eyebrow">FINCORE RELIABILITY LAB / 项目综述</p>
        <h1>交易、结算<br /><span>与故障恢复实验。</span></h1>
        <p className="overview-lead">用代码和实验说明订单如何完成交割，重复消息与节点故障如何处理；同时记录性能取舍、团队交付方案和 AI 辅助研发实践。</p>
        <p className="overview-position">技术负责人 · 研发负责人 · 金融系统架构方向</p>
        <div className="overview-actions">
          <a className="overview-primary" href="#profile-cases">查看代表案例 <ArrowRight size={17} /></a>
          <a className="overview-secondary" href="#demo"><Radio size={17} /> 打开运行演示</a>
          <a className="overview-source" href="https://github.com/soldierking04d/fincore-reliability-lab" target="_blank" rel="noreferrer"><GitBranch size={17} /> 源码</a>
        </div>
      </div>
      <aside className="overview-system" aria-label="项目完整业务闭环">
        <div className="overview-system-heading"><Layers3 size={19} /><span>一笔交易，如何走到可信结果</span></div>
        <ol className="overview-flow">
          {[
            ['01', '准入与风险', '用户 / KYC · 行情 · 风控 · 账户'],
            ['02', '交易与成交', '有界准入 · 下单 / 撤单 · 撮合'],
            ['03', '资金与账本', '可靠事件 · 清结算 · 双资产交割'],
            ['04', '验证与恢复', '对账 · 幂等修复 · 接管 / 围栏'],
          ].map(([n, title, detail]) => <li key={n}><span className="flow-index">{n}</span><div><strong>{title}</strong><p>{detail}</p></div></li>)}
        </ol>
        <a href="#full-lifecycle">查看完整链路与架构 <ArrowRight size={16} /></a>
        <p className="overview-scope">实验使用模拟资金；外部 KYC、行情供应商和生产容量认证未包含在这些结果中。</p>
      </aside>
    </div>
    <div className="overview-principles">
      <div><ShieldCheck size={19} /><p><strong>资金与恢复</strong><span>重复投递、账本核对与节点接管</span></p></div>
      <div><Layers3 size={19} /><p><strong>团队与交付</strong><span>优先级、协作分工与风险处理示例</span></p></div>
      <div><BookOpen size={19} /><p><strong>实现范围</strong><span>运行结果、教学模型与设计方案分别标注</span></p></div>
    </div>
    <RepresentativeCases />
    <section id="knowledge-map" className="knowledge-map">
      <div className="knowledge-map-heading"><div><p className="overview-eyebrow">TOPICS</p><h2>专题目录</h2></div><a href="#outline">详细索引与实现范围 <ArrowRight size={16} /></a></div>
      <div className="topic-grid">{portfolioTopics.map((topic, index) => <article className={`topic-card${topic.href === '#settlement-optimization' ? ' topic-card-settlement' : ''}`} key={topic.href}>
        <div className="topic-card-top"><span>{String(index + 1).padStart(2, '0')}</span><a href={topic.href} aria-label={`打开${topic.title}`}><ArrowRight size={20} /></a></div>
        <h3><a href={topic.href}>{topic.title}</a></h3><p>{topic.detail}</p>
        <div className="topic-shortcuts">{topic.links.map(([title, href]) => <a href={href} key={title}>{title}</a>)}</div>
      </article>)}</div>
    </section>
  </section>;
}
