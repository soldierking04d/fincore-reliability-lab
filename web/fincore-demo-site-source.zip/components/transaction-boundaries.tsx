'use client';

import { useEffect, useId, useMemo, useState, type ReactNode } from 'react';
import { ArrowRight, BookOpen, Download, RotateCcw } from 'lucide-react';
import { buildOrderCase, buildWorkflowCase } from '@/public/trading-boundaries/model.mjs';
import { existingCoverage, transactionTopics } from '@/lib/transaction-topics';
import { boundaryModules, moduleForHash, type BoundaryModuleId } from '@/lib/transaction-modules';
import { BoundaryExecutionPlayer } from '@/components/boundary-execution-player';

type Check = { name: string; ok: boolean; detail: string };
type Balance = { owner: string; asset: string; available: string; frozen: string; pending: string; total: string };
type Order = { id: string; owner: string; side: string; status: string; settlementStatus: string; quantity: string; filledQuantity: string; settledQuantity: string; canceledQuantity: string; remainingQuantity: string };
type Trade = { id: string; buyer: string; seller: string; quantity: string; quote: string; buyerRole: string; sellerRole: string; status: string };
type Execution = { id: string; tradeId: string; orderId: string; owner: string; side: string; role: string; quantity: string; cumulativeQuantity: string; fee: string; feeAsset: string };
type Snapshot = { step: number; title: string; notes: string[]; checks: Check[]; balances: Balance[]; orders?: Order[]; trades?: Trade[]; executions?: Execution[]; phase?: string; decision?: string; participants?: { id: string; status: string; detail: string }[] };
type Case = { title: string; limitation: string; snapshots: Snapshot[]; maxStep: number };

const scenarios = [
  ['rest', '成交后，C 保留 30'], ['cancel-before-settle', '撤单先于 T3 交割'],
  ['fill-rest', 'D 买走剩余 30'], ['fill-then-cancel', '再成交 10 后撤 20'],
  ['roles-reversed', '到达顺序反转，角色变化'],
] as const;
const workflows = [['retry', '卖方失败 → 恢复缺失分支'], ['compensate', '决定前 → 独立反向流水'], ['two-phase-commit', '2PC 准备 → 决议 → 恢复']] as const;

function DataTable({ headers, rows, empty = '这个步骤还没有产生记录。' }: { headers: string[]; rows: ReactNode[][]; empty?: string }) {
  return <div className="boundary-table" tabIndex={0}><table><thead><tr>{headers.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
    <tbody>{rows.length ? rows.map((row, i) => <tr key={i}>{row.map((cell, j) => <td key={j}>{cell}</td>)}</tr>) : <tr><td colSpan={headers.length}>{empty}</td></tr>}</tbody></table></div>;
}

function Architecture() {
  const arrowId = `boundary-arrow-${useId().replace(/:/g,'')}`;
  const boxes = [
    [20, 112, '用户 / 订单入口', '请求身份 · 资格与预占'], [270, 112, '撮合权威与顺序', 'Order → Trade → 双侧明细'],
    [535, 20, '订单查询投影', '累计成交 / 未成交 / 已撤'], [535, 200, '结算与账务', '冻结消费 / 费用 / 可用化'],
    [800, 20, '用户订单页', 'FILLED ≠ 全部已交割'], [800, 200, '余额与对账', '可用 / 冻结 / 在途 / 水位'],
  ] as const;
  return <figure className="boundary-architecture"><svg viewBox="0 0 1040 330" role="img" aria-label="订单与资金双线架构图：撮合事实分别驱动订单投影和结算账务，订单状态与资产可用分开核验">
    <defs><marker id={arrowId} markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0 L8 4 L0 8 Z" fill="#4075ac" /></marker></defs>
    <g fill="none" stroke="#4075ac" strokeWidth="2" markerEnd={`url(#${arrowId})`}><path d="M230 151H270"/><path d="M480 151H505V59H535"/><path d="M480 151H505V239H535"/><path d="M745 59H800"/><path d="M745 239H800"/></g>
    {boxes.map(([x,y,title,sub]) => <g key={title}><rect x={x} y={y} width="210" height="78" rx="12" fill={y === 200 ? '#eaf6f1' : '#edf4ff'} stroke="#b6cce4"/><text x={x+105} y={y+31} textAnchor="middle" fontSize="17" fill="#16395f" fontWeight="600">{title}</text><text x={x+105} y={y+55} textAnchor="middle" fontSize="12" fill="#496780">{sub}</text></g>)}
    <text x="520" y="314" textAnchor="middle" fontSize="13" fill="#526d86">可靠事件与版本连接两条链路；任何查询进度都不能反过来改写成交事实。</text>
  </svg><figcaption>逻辑服务边界，不代表现网已经拆成独立数据库；虚构资产，不产生实际交易。</figcaption></figure>;
}

/** 客户端按状态机计算并联动表格；不是预设动画，更不会调用资金写接口。 */
function CasePlayer({ workflow = false }: { workflow?: boolean }) {
  const [scenario, setScenario] = useState(workflow ? 'retry' : 'rest');
  const [step, setStep] = useState(0);
  const data = useMemo(() => (workflow ? buildWorkflowCase({ scenario }) : buildOrderCase({ scenario })) as unknown as Case, [scenario, workflow]);
  const current = data.snapshots[Math.min(step, data.snapshots.length - 1)];
  const options = workflow ? workflows : scenarios;
  const prefix = workflow ? 'workflow-case' : 'order-case';
  return <div className="boundary-player" id={prefix}>
    <div className="boundary-player-heading"><div><span className="boundary-label">确定性教学模型 · 本地计算</span><h3>{workflow ? '跨账户中间态与 2PC 对照' : '100 买单与 40 / 40 / 50 卖单'}</h3></div>
      <button type="button" onClick={() => setStep(0)}><RotateCcw size={14}/>重置步骤</button></div>
    <p>{workflow ? '切换恢复或补偿路径，观察参与者状态、未可用资金与全局决定。模型快照只在内存中保存，不是实际持久化恢复。' : '主例：A、B、C 先挂卖单，U 再买 100。价格 10 USDT/ABC；U 初始 1500 USDT。固定教学费率：买方 0.1% ABC，卖方 0.05% USDT；角色反转场景另按逐笔角色费率计算。'}</p>
    <label className="boundary-selector">选择场景<select aria-label={workflow ? '选择一致性场景' : '选择订单场景'} value={scenario} onChange={e => { setScenario(e.target.value); setStep(0); }}>{options.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    <details className="boundary-detail"><summary>展开全部步骤</summary><ol className="boundary-steps" aria-label={workflow ? '一致性步骤' : '订单步骤'}>{data.snapshots.map((snapshot, i) => <li key={i}><button type="button" aria-current={step === i ? 'step' : undefined} onClick={() => setStep(i)}><span>{String(i+1).padStart(2,'0')}</span>{snapshot.title}</button></li>)}</ol></details>
    <div className="boundary-metrics">{(workflow ? [
      ['全局决定', current.decision || 'NONE'], ['收款方可用', `${current.balances.find(b=>b.owner==='SELLER')?.available || '0'} USDT`], ['当前阶段', current.phase || 'INITIAL'],
    ] : [
      ['市场成交', `${current.trades?.length || 0} 笔`], ['C 已成交 / 已撤', `${current.orders?.find(o=>o.id==='C')?.filledQuantity || '0'} / ${current.orders?.find(o=>o.id==='C')?.canceledQuantity || '0'}`], ['U 已到账', `${current.balances.find(b=>b.owner==='U'&&b.asset==='ABC')?.available || '0'} ABC`],
    ]).map(([label,value])=><div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
    <div className="boundary-stage" aria-live="polite"><strong>{step+1} / {data.snapshots.length} · {current.title}</strong><ul>{current.notes.map((note,i) => <li key={i}>{note}</li>)}</ul></div>
    <div className="boundary-controls"><button disabled={step === 0} onClick={() => setStep(v => v-1)}>上一步</button><button disabled={step >= data.snapshots.length-1} onClick={() => setStep(v => v+1)}>下一步 <ArrowRight size={15}/></button><button onClick={() => setStep(data.snapshots.length-1)}>查看最终结果</button></div>
    <details className="boundary-detail"><summary>展开订单、账户明细与校验</summary>
    {workflow ? <><p className="boundary-decision">流程状态：<strong>{current.phase}</strong> · 全局决定：<strong>{current.decision}</strong></p>
      <DataTable headers={['参与者', '状态', '当前含义']} rows={(current.participants || []).map(p => [p.id,p.status,p.detail])}/></> : <>
      <h4>订单执行与交割进度分开</h4><DataTable headers={['订单 / 用户','原始量','已成交','已交割','仍挂','已撤','执行状态 / 结算状态']} rows={(current.orders || []).map(o => [<>{o.id}<small>{o.owner} · {o.side}</small></>,o.quantity,o.filledQuantity,o.settledQuantity,o.remainingQuantity,o.canceledQuantity,<>{o.status}<small>{o.settlementStatus}</small></>])}/>
      <h4>市场成交：一笔成交共享一份事实</h4><DataTable headers={['成交','买方 / 角色','卖方 / 角色','成交 ABC','金额 USDT','交割']} rows={(current.trades || []).map(t => [t.id,`${t.buyer} · ${t.buyerRole}`,`${t.seller} · ${t.sellerRole}`,t.quantity,t.quote,t.status])}/>
      <details className="boundary-detail"><summary>双方成交明细 · {(current.executions || []).length} 条视图记录</summary><p>前三笔撮合产生 3 笔市场成交、6 条参与方明细。当前 Java 的 trade_execution 表每笔成交只有 1 行，这里的双侧明细是教学视图，不是宣称已有 6 行落库。</p><DataTable headers={['成交 / 订单','用户','方向 / 角色','本次数量','本订单累计','本次费用']} rows={(current.executions || []).map(e => [`${e.tradeId} / ${e.orderId}`,e.owner,`${e.side} / ${e.role}`,e.quantity,e.cumulativeQuantity,`${e.fee} ${e.feeAsset}`])}/></details>
    </>}
    <h4>账户资产：余额不是订单状态</h4><DataTable headers={['账户','资产','可用','冻结','待可用 / 过渡','总量']} rows={current.balances.map(b => [b.owner,b.asset,b.available,b.frozen,b.pending,b.total])}/>
    <div className="boundary-checks" aria-label="当前步骤不变量检查">{current.checks.map(c => <div key={c.name} className={c.ok ? 'check-pass' : 'check-fail'}><strong>{c.ok ? 'PASS' : 'FAIL'} · {c.name}</strong><p>{c.detail}</p></div>)}</div>
    </details><p className="boundary-model-note">{data.limitation}</p>
  </div>;
}

export function TransactionBoundaries() {
  const [selected,setSelected] = useState<BoundaryModuleId | null>(null);
  useEffect(()=>{
    // 保留旧链接和重复点击行为：先显示所属模块，再打开细节并定位。
    const reveal = (hash:string) => {
      const module = moduleForHash(hash);
      if (!module && !['#transaction-boundaries','#boundary-coverage'].includes(hash)) return;
      setSelected(module);
      window.requestAnimationFrame(()=>window.requestAnimationFrame(()=>{
        let id:string; try { id=decodeURIComponent(hash.slice(1)); } catch { return; }
        const target=document.getElementById(id);
        if(target instanceof HTMLDetailsElement) target.open=true;
        if(target) {
          const header=document.querySelector('.site-header')?.getBoundingClientRect().height ?? 80;
          window.scrollTo({top:window.scrollY+target.getBoundingClientRect().top-header-24,behavior:'instant'});
        }
      }));
    };
    const onHash=()=>reveal(window.location.hash);
    const onClick=(event:MouseEvent)=>{
      if(event.defaultPrevented || event.button!==0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const anchor=event.target instanceof Element ? event.target.closest('a[href]') : null;
      if(!(anchor instanceof HTMLAnchorElement)) return;
      const url=new URL(anchor.href,window.location.href);
      if(url.origin===window.location.origin && url.pathname===window.location.pathname) reveal(url.hash);
    };
    onHash(); window.addEventListener('hashchange',onHash); document.addEventListener('click',onClick);
    return ()=>{window.removeEventListener('hashchange',onHash);document.removeEventListener('click',onClick);};
  },[]);
  return <section id="transaction-boundaries" className="transaction-boundaries">
    <header className="boundary-intro"><p className="overview-eyebrow">TRADING · PAYMENTS · RECOVERY</p><h2>一笔业务，四个视角。</h2><p>把交易、支付、恢复和对账放在一张地图上。先看整体，再按需要展开数据、代码与实施细节。</p>
      <div className="boundary-links"><a href="#order-case">从一笔订单开始 <ArrowRight size={16}/></a><a href="/trading-boundaries/transaction-boundaries-playbook.md"><BookOpen size={16}/>完整实施手册</a><a href="/trading-boundaries/coverage.md">47 项覆盖清单</a><a href="/trading-boundaries/source.zip"><Download size={16}/>源码与测试</a></div>
    </header>
    <nav id="boundary-coverage" className="boundary-module-grid" aria-label="交易专题四模块">
      {boundaryModules.map((module,index)=><a key={module.id} href={`#boundary-module-${module.id}`} className="boundary-module-card" aria-current={selected===module.id?'location':undefined}><span className="boundary-module-number">0{index+1}</span><h3>{module.title}</h3><p>{module.question}</p><small>{module.outcome}</small><span className="boundary-module-entry">查看演示与细节 <ArrowRight size={15}/></span></a>)}
    </nav>
    <p className="boundary-model-note"><strong>阅读边界：</strong>既有 Java 后端、本地教学模型、外部接入设计分开标注。没有接入真实资金，也没有新增后台金融接口。</p>
    {boundaryModules.map(module=><section key={module.id} id={`boundary-module-${module.id}`} hidden={selected !== module.id} className="boundary-module-panel" aria-label={module.title}>
      <div className="boundary-module-heading"><div><span className="boundary-label">{module.scope}</span><h3>{module.title}</h3><p>{module.outcome}</p></div><a href="#transaction-boundaries">← 返回四模块概览</a></div>
      <ol className="boundary-module-flow" aria-label={`${module.title}流程`}>{module.path.map((step,index)=><li key={step}><span>0{index+1}</span>{step}{index<module.path.length-1&&<ArrowRight size={16} aria-hidden="true"/>}</li>)}</ol>
      {module.id==='orders'&&<><details className="boundary-detail"><summary>查看订单与资金双线架构图</summary><Architecture/></details><CasePlayer/></>}
      {module.id==='execution'&&<BoundaryExecutionPlayer kind="execution"/>}
      {module.id==='recovery'&&<><CasePlayer workflow/><BoundaryExecutionPlayer kind="recovery"/></>}
      {module.id==='assurance'&&<BoundaryExecutionPlayer kind="reconciliation"/>}
      <div className="boundary-links"><a href={`/trading-boundaries/${module.source}`} target="_blank" rel="noreferrer">本模块可运行源码 ↗</a><a href="/trading-boundaries/source.zip">下载全部实验与测试</a></div>
      {module.topics.length>0&&<h4>需要深入时：展开实施说明</h4>}
      {transactionTopics.filter(topic=>(module.topics as readonly string[]).includes(topic.id)).map(topic=><details key={topic.id} className="boundary-topic" id={`boundary-${topic.id}`}><summary><div><strong>{topic.title}</strong><small>{topic.change}</small></div></summary><div className="boundary-topic-body"><p className="boundary-problem">{topic.problem}</p><h4>如何落地</h4><ol>{topic.steps.map(s=><li key={s}>{s}</li>)}</ol><div className="boundary-two-col"><div><h4>失败与恢复</h4><p>{topic.failure}</p></div><div><h4>验收条件</h4><p>{topic.acceptance}</p></div></div><h4>协议与实现要点</h4><pre><code>{topic.code}</code></pre><p className="boundary-warning">{topic.boundary}</p><a href={`https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/${topic.link}`} target="_blank" rel="noreferrer">关联工程说明 ↗</a></div></details>)}
    </section>)}
    <details className="boundary-detail"><summary>架构总览与能力边界</summary><Architecture/><p className="boundary-warning">跨库协议、银行/托管接入、多节点日志复制仍需要外部环境验收。内存演示不代表真实并发原子性、持久化或生产高可用。</p></details>
    <details className="boundary-detail boundary-existing"><summary>继续查看已有工程与管理专项</summary>{existingCoverage.map(([title,href]) => <a key={title} href={href}>{title}<ArrowRight size={15}/></a>)}</details>
    <footer className="boundary-sources">机制核对：<a href="https://www.postgresql.org/docs/current/two-phase.html" target="_blank" rel="noreferrer">PostgreSQL 2PC</a> · <a href="https://kubernetes.io/docs/concepts/storage/persistent-volumes/" target="_blank" rel="noreferrer">Kubernetes 存储</a> · <a href="https://docs.stripe.com/webhooks" target="_blank" rel="noreferrer">Webhook 契约</a>。完整资料与生产验收差距见详细手册。</footer>
  </section>;
}
