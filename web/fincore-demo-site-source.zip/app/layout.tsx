import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] });
const geistMono = Geist_Mono({ variable: '--font-geist-mono', subsets: ['latin'] });

export const metadata: Metadata = {
  metadataBase: new URL('https://fincore-reliability-demo.soldierking04d.chatgpt.site'),
  title: 'FinCore 技术负责人作品集｜交易可靠性、低延迟与 AI 落地',
  description: '3 分钟判断技术负责人岗位匹配，继续验证金融高并发、资金一致性、低延迟 CPU/GPU 判断、数字资产、团队治理、AI 评测和源码证据。',
  openGraph: {
    title: 'FinCore 技术负责人作品集｜结果、代码与治理证据',
    description: '从资金一致性和故障恢复，到低延迟 CPU/NUMA、网络、FPGA/GPU 边界与 54 次 AI 受控评测。',
    type: 'website',
    images: [{ url: '/og.png', width: 1200, height: 630, alt: 'FinCore Reliability Lab 市场暴跌恢复演示' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'FinCore 技术负责人作品集｜结果、代码与治理证据',
    description: '金融与数字资产可靠性、低延迟 CPU/GPU 判断、团队治理和 AI 落地的可验证作品集。',
    images: ['/og.png'],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>{children}</body>
    </html>
  );
}
