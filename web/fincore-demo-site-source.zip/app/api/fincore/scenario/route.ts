const SCENARIO_ENDPOINT = 'https://124.223.164.254/lab/scenarios/market-crash-day';

/**
 * 由站点服务端转发到腾讯云上的 FinCore API。
 *
 * 浏览器只访问当前站点，由服务端通过已验证的 HTTPS IP 证书访问云主机。
 */
export async function POST() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 120_000);

  try {
    const response = await fetch(SCENARIO_ENDPOINT, {
      method: 'POST',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      signal: controller.signal,
    });
    const body = await response.text();
    return new Response(body, {
      status: response.status,
      headers: {
        'content-type': response.headers.get('content-type') ?? 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      },
    });
  } catch (error) {
    const timedOut = error instanceof Error && error.name === 'AbortError';
    return Response.json(
      {
        message: timedOut
          ? '腾讯云场景执行超过 120 秒，请稍后重试。'
          : '腾讯云 FinCore 服务暂时不可达，请使用公网回放。',
      },
      { status: 502 },
    );
  } finally {
    clearTimeout(timeout);
  }
}
