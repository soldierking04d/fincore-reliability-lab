const LIFECYCLE_ENDPOINT = 'https://124.223.164.254/lab/scenarios/trading-lifecycle';

/** 由站点服务端转发腾讯云完整交易链路实验。 */
export async function POST() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60_000);

  try {
    const response = await fetch(LIFECYCLE_ENDPOINT, {
      method: 'POST',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      signal: controller.signal,
    });
    const body = await response.text();
    return new Response(body, {
      status: response.status,
      headers: {
        'content-type': response.headers.get('content-type') ?? 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      },
    });
  } catch (error) {
    const timedOut = error instanceof Error && error.name === 'AbortError';
    return Response.json(
      {
        message: timedOut
          ? '腾讯云完整链路执行超过 60 秒，请稍后重试。'
          : '腾讯云 FinCore 完整链路暂时不可达。',
      },
      { status: 502 },
    );
  } finally {
    clearTimeout(timeout);
  }
}
