import { METRICS, metricQuery, type MetricKey } from '@/lib/live-metrics';

/** Sites 只代理四个固定监控查询；公网 IP 直接使用已有只读 Prometheus 入口。 */
export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get('key');
  if (!key || !Object.hasOwn(METRICS, key)) return Response.json({ message: '不支持的指标' }, { status: 400 });
  try {
    const url = new URL('https://124.223.164.254/prometheus/api/v1/query');
    url.searchParams.set('query', metricQuery(key as MetricKey));
    const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
    return new Response(await response.text(), { status: response.status,
      headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
  } catch {
    return Response.json({ message: '监控暂时不可达，不使用回放值替代' }, { status: 502 });
  }
}
