'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Braces,
  Check,
  CircleDollarSign,
  Cpu,
  Database,
  ExternalLink,
  Gauge,
  GitBranch,
  GitCompareArrows,
  HardDrive,
  Landmark,
  MessageSquare,
  Network,
  Pause,
  Play,
  Radio,
  RefreshCw,
  RotateCcw,
  ServerCog,
  ShieldCheck,
  Target,
  TimerReset,
  TrendingDown,
  TriangleAlert,
  Users,
  Workflow,
  Zap,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DeferredReplayChart } from '@/components/deferred-replay-chart';
import { Switch } from '@/components/ui/switch';
import { LiveRunPanel } from '@/components/live-run-panel';
import { SpotFundsEvidencePanel } from '@/components/spot-funds-evidence';
import { LowLatencyPlaybook } from '@/components/low-latency-playbook';
import { JavaCppMigration } from '@/components/java-cpp-migration';
import { IndustryCases } from '@/components/industry-cases';
import { ExchangeCoverageLab } from '@/components/exchange-coverage-lab';
import { ProjectOutline } from '@/components/project-outline';
import { PortfolioOverview } from '@/components/portfolio-overview';
import { KnowledgeChapter } from '@/components/knowledge-chapter';
import { PerformanceEngineering } from '@/components/performance-engineering';
import { SettlementOptimization } from '@/components/settlement-optimization';
import { TransactionBoundaries } from '@/components/transaction-boundaries';
import { RuntimeSecurity } from '@/components/runtime-security';
import { SecurityIncidents } from '@/components/security-incidents';
import { VisitorAnalytics } from '@/components/visitor-analytics';
import { AiCompanyDelivery } from '@/components/ai-company-delivery';
import { parseLifecycleReport } from '@/lib/scenario-contract';
import { useScenarioRun } from '@/hooks/use-scenario-run';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  performanceDetails,
  performanceSourceUrl,
  type PerformanceDetail,
  type PerformanceDetailKey,
} from '@/lib/performance-details';

type Mode = 'replay' | 'live';
type CodeKey =
  | 'persistence'
  | 'lifecycle'
  | 'pretrade'
  | 'domain'
  | 'concurrency'
  | 'matching'
  | 'outbox'
  | 'settlement'
  | 'compensation'
  | 'workerLease'
  | 'fencing'
  | 'tradeSync'
  | 'reconcile'
  | 'scenario';
type Faults = { burst: boolean; duplicate: boolean; sync: boolean };
type Evidence = {
  runId: string;
  finalStatus: string;
  tradeCount: number;
  uniqueTradeSequences: number;
  duplicateSettlementDeliveries: number;
  ledgerTransactions: number;
  repairedProjections: number;
  quarantinedProjections: number;
  matchingElapsedMs: number;
  observedTradesPerSecond: number;
  endToEndElapsedMs: number;
};

type ArchitectureDomainKey = 'identity' | 'market' | 'riskAccount' | 'admissionMatch' | 'money' | 'recovery';

type ArchitectureDomain = {
  index: string;
  title: string;
  status: string;
  objective: string;
  flow: string[];
  dataStore: string;
  output: string;
  topology: {
    entry: string;
    application: string;
    adapter: string;
    state: string;
    dependency: string;
    event: string;
  };
  concurrency: string;
  volatility: string;
  scaling: string;
  failure: string;
  evidence: string;
};

const architectureDomains: Record<ArchitectureDomainKey, ArchitectureDomain> = {
  identity: {
    index: '01',
    title: '用户、KYC 与权限域',
    status: '状态模型已落地 · 外部供应商待接入',
    objective: '先回答“谁在交易、是否允许交易、权限何时生效”，资格不明确时不把风险继续传给下游。',
    flow: ['注册 / 登录态', '用户主档', 'KYC 审核状态', '交易权限快照'],
    dataStore: 'customer_profile / risk_profile',
    output: '资格快照 + 审计事件',
    topology: { entry: 'TradingLifecycleController', application: 'TradingLifecycleService', adapter: 'TradingLifecycleMapper', state: 'customer_profile / risk_profile', dependency: 'KYC Provider Adapter · TARGET', event: '资格快照 → 盘前风控' },
    concurrency: '读多写少；状态变更使用版本与审计记录，热点读取可以缓存，但数据库仍是最终事实。',
    volatility: '风险事件可把用户切为 SUSPENDED；新的下单立即失败关闭，已经发生的账务继续按原事实结算。',
    scaling: '按 userId 分片；KYC 通过 Provider Adapter 接入，不让供应商字段渗透交易核心。',
    failure: '供应商超时、状态未知、缓存过期都返回不可交易，不使用“先放行、稍后再查”。',
    evidence: 'ACTIVE + VERIFIED 才能进入盘前；KYC_NOT_VERIFIED 只留下拒绝决定，不创建订单。',
  },
  market: {
    index: '02',
    title: '实时行情与价格保护域',
    status: '参考价防线已落地 · 多源聚合为演进目标',
    objective: '把高频行情和低频交易事务拆开：行情允许合并最新值，但绝不能用过期或倒退的快照放行订单。',
    flow: ['多源 Feed', '序列 / 缺口检测', '标准化与异常值过滤', '参考价 / 价格笼子'],
    dataStore: 'market_reference_price',
    output: '版本化参考价 + stale 状态',
    topology: { entry: 'Market Feed / Reference API', application: 'TradingLifecycleService', adapter: 'Quote Normalizer + Mapper', state: 'market_reference_price', dependency: '多源 Feed / 序列检测 · TARGET', event: '参考价 → 价格笼子' },
    concurrency: '按 symbol 分区消费；只保留最新快照，旧 observedAt 不能覆盖新值，避免每个 Tick 都争抢交易库。',
    volatility: '30 秒新鲜度、价格偏离阈值和无保护市价单拒绝共同应对跳价；异常时可按标的暂停准入。',
    scaling: 'Feed、标准化、快照和分发可独立扩容；新增交易所只实现统一 Quote Adapter。',
    failure: '行情缺失、过期、序列跳变或来源分歧时停止新增风险，订单簿和参考价不会互相冒充。',
    evidence: 'MARKET_QUOTE_STALE、PRICE_DEVIATION 和旧行情不可覆盖均有数据库与集成测试证据。',
  },
  riskAccount: {
    index: '03',
    title: '盘前风控与交易账户域',
    status: '额度、余额与幂等决定已落地',
    objective: '在撮合之前一次性完成用户、行情、单笔额度、日累计、账户归属和余额校验，并留下可解释决定。',
    flow: ['幂等键核验', '锁定风险档案', '价格 / 敞口计算', '账户余额与决定'],
    dataStore: 'account / pre_trade_decision',
    output: 'APPROVED / REJECTED',
    topology: { entry: 'TradingLifecycleController', application: 'TradingLifecycleService.place', adapter: 'TradingLifecycleMapper + AccountService', state: 'account / pre_trade_decision', dependency: '用户资格 + 参考行情', event: 'APPROVED → TradingOrderCoordinator' },
    concurrency: '同一用户使用 FOR UPDATE 关闭日累计竞态；userId + clientOrderId 唯一，重试不会重复占额度。',
    volatility: '名义金额以当前参考价和订单参数计算；价格越笼子、余额不足或额度不够都在撮合前截断。',
    scaling: '先按 userId 隔离热点，再把风险规则做成版本化策略；规则计算与账户权威写入保持清晰边界。',
    failure: '任何依赖不可判断就保存稳定 reasonCode；APPROVED 与创建撮合订单处于同一事务。',
    evidence: '10 类拒绝码、冲突重放、并发额度锁和账户资产检查已经进入 TradingLifecycleIntegrationTest。',
  },
  admissionMatch: {
    index: '04',
    title: '有界准入与撮合域',
    status: '单机有界 Lane + 跨实例数据库定序已落地',
    objective: '洪峰到来时守住顺序、内存和尾延迟：同标的串行，不同标的并行，系统宁可明确拒绝也不无限排队。',
    flow: ['入口限流', 'symbol 稳定散列', '4 ×（256 新单 + 32 撤单）', '价格时间优先撮合'],
    dataStore: 'matching_order / trade_execution',
    output: '成交事实 + Outbox',
    topology: { entry: 'TradingOrderCoordinator', application: 'StripedTaskExecutor + MatchingService', adapter: 'MatchingMapper + OutboxMapper', state: 'matching_order / trade_execution', dependency: 'PostgreSQL advisory lock', event: 'matching.events.v1 → Kafka' },
    concurrency: 'Lane 内单线程保持局部顺序；撤单使用保留容量和 8:1 优先批次；跨实例通过 PostgreSQL advisory transaction lock 与版本检查定序。',
    volatility: '价格快速吃穿深度时仍保证数量守恒；额外市价单返回明确终态，不制造负剩余量。',
    scaling: '近期按 symbol 分片并横向增加实例；远期将热点交易对迁到独占分区而不改上游协议。',
    failure: '普通队列满返回 429，但不能挤占撤单保留容量；请求超时不能假定失败，客户端必须查询或使用原幂等键重试。',
    evidence: '60 条成交等于 60 个唯一序列；256 笔普通积压时撤单先完成，普通溢出新单明确拒绝。',
  },
  money: {
    index: '05',
    title: '事件、清算、结算与账本域',
    status: 'Outbox、Kafka、Inbox、Fencing 与平衡账本已落地',
    objective: '把成交事实可靠地变成唯一资金效果；消息可以重复、Worker 可以接管，但钱不能重复变化。',
    flow: ['成交 + Outbox', 'Kafka 分区', 'Epoch Worker', '结算 + 不可变账本'],
    dataStore: 'inbox / balance / ledger_transaction',
    output: '唯一资金效果 + 账本分录',
    topology: { entry: 'SettlementListener', application: 'SettlementService + WorkerLeaseManager', adapter: 'SettlementMapper + LedgerMapper', state: 'inbox / balance / ledger / lease', dependency: 'Kafka partition + Epoch token', event: '结算结果 → 投影 / 对账' },
    concurrency: '按业务键幂等、账户 UUID 排序加锁；Inbox、状态迁移、余额和分录在一个事务中提交。',
    volatility: '行情洪峰只会抬升 Lag，不会绕过账务不变量；消费能力不足时通过积压告警和背压扩容。',
    scaling: '按结算分片增加带 Epoch 的 Worker；事件版本化，新增下游用独立 Consumer Group 解耦。',
    failure: '发布失败由 Outbox 重试，重复投递由 Inbox 去重，失去租约的旧 Worker 在资金事务内部拒写。',
    evidence: '17 次重复结算投递只产生 1 次资金效果；6 笔账本事务全部借贷平衡。',
  },
  recovery: {
    index: '06',
    title: '观测、对账与恢复域',
    status: '指标联动、差异分类与受控修复已落地',
    objective: '系统不能只会报警，还要知道业务结果是否正确，并把恢复边界限制在可重建的派生数据。',
    flow: ['指标 / 日志 / 审计', '权威事实反查', '差异分类', '重建 / 隔离 / 复核'],
    dataStore: 'trade_projection / reconciliation_issue',
    output: 'CLEAN / REBUILT / QUARANTINED',
    topology: { entry: 'ReconciliationController / Scheduler', application: 'ReconciliationService', adapter: 'TradeReliabilityMapper + ReconciliationMapper', state: '权威成交 / 投影 / 差异记录', dependency: 'Prometheus / Grafana / 审计', event: 'CLEAN / REBUILT / QUARANTINED' },
    concurrency: '对账分页、限速运行，不与核心写入争抢连接；修复使用幂等键并记录前后证据。',
    volatility: '高峰时先保护交易和账务，降低非关键扫描频率；恢复后补跑全量核对证明最终收敛。',
    scaling: '按日期、标的和账户分片对账；新增一种投影只需增加 Comparator 与 Repair Adapter。',
    failure: 'MISSING 可重建、MISMATCH 可覆盖派生值、EXTRA 先隔离；权威成交、余额和历史账本禁止修改。',
    evidence: '漏数、错值和幽灵成交被识别为三类差异，2 条修复、1 条隔离，最终再次对账 CLEAN。',
  },
};

type SequenceParticipant = { id: string; label: string; detail: string; tone?: 'cyan' | 'amber' | 'violet' | 'green' | 'neutral' };
type SequenceMessage = { from: string; to: string; label: string; type?: 'sync' | 'async' | 'return' | 'reject' | 'data' };
type SequenceScenario = { index: string; title: string; summary: string; result: string; participants: SequenceParticipant[]; messages: SequenceMessage[] };

const sequenceScenarios: SequenceScenario[] = [
  {
    index: '01',
    title: '正常下单、成交、结算与对账',
    summary: '一笔订单从同步盘前短链路进入撮合，再通过异步事件完成唯一资金效果，最后由对账反向证明结果。',
    result: '1 个盘前决定 · 1 张订单 · 1 条成交 · 1 次资金效果 · 最终 CLEAN',
    participants: [{ id: 'client', label: '客户端', detail: 'clientOrderId', tone: 'neutral' }, { id: 'api', label: 'Trading API', detail: 'Spring Web' }, { id: 'pre', label: '盘前风控', detail: '用户 / 行情 / 账户' }, { id: 'match', label: '撮合', detail: 'Lane + Matching' }, { id: 'event', label: 'Kafka / Worker', detail: 'Outbox + Epoch', tone: 'violet' }, { id: 'money', label: '账本 / 对账', detail: 'Inbox + Ledger', tone: 'green' }],
    messages: [{ from: 'client', to: 'api', label: 'POST /orders + 幂等键' }, { from: 'api', to: 'pre', label: '校验资格、参考价、额度与余额' }, { from: 'pre', to: 'pre', label: '锁风险档案，保存 APPROVED', type: 'data' }, { from: 'pre', to: 'match', label: '按 symbol 进入有界 Lane' }, { from: 'match', to: 'match', label: '成交 + Outbox 同事务', type: 'data' }, { from: 'match', to: 'api', label: '返回订单终态', type: 'return' }, { from: 'api', to: 'client', label: 'FILLED / OPEN', type: 'return' }, { from: 'match', to: 'event', label: 'matching.events.v1', type: 'async' }, { from: 'event', to: 'money', label: '至少一次投递 + Epoch', type: 'async' }, { from: 'money', to: 'money', label: 'Inbox 去重、平衡分录、对账 CLEAN', type: 'data' }],
  },
  {
    index: '02',
    title: '行情暴跌与价格笼子失败关闭',
    summary: '行情快速下跌时先验证序列和新鲜度，再用价格笼子阻止偏离订单；拒绝决定可审计且不会创建撮合订单。',
    result: '旧行情不覆盖 · 越价订单 REJECTED · matching_order 保持 0 条',
    participants: [{ id: 'feed', label: '行情源', detail: 'Tick / Snapshot', tone: 'amber' }, { id: 'quote', label: '参考行情', detail: '版本 + observedAt', tone: 'amber' }, { id: 'client', label: '客户端', detail: '异常价格委托', tone: 'neutral' }, { id: 'api', label: 'Trading API', detail: '受控入口' }, { id: 'pre', label: '盘前风控', detail: '新鲜度 + 价格笼子' }, { id: 'match', label: '撮合', detail: '未被调用' }],
    messages: [{ from: 'feed', to: 'quote', label: '价格 100 → 98，序列递增', type: 'async' }, { from: 'feed', to: 'quote', label: '迟到旧快照 99', type: 'async' }, { from: 'quote', to: 'quote', label: 'observedAt 倒退，拒绝覆盖', type: 'reject' }, { from: 'client', to: 'api', label: 'BUY 2 @ 120' }, { from: 'api', to: 'pre', label: '读取当前参考价 98' }, { from: 'pre', to: 'pre', label: '偏离超过 20%，保存拒绝决定', type: 'reject' }, { from: 'pre', to: 'api', label: 'PRICE_DEVIATION', type: 'reject' }, { from: 'api', to: 'client', label: '明确拒绝，可用原键查询', type: 'return' }, { from: 'pre', to: 'match', label: '不调用撮合', type: 'reject' }],
  },
  {
    index: '03',
    title: '客户端超时后的幂等重试',
    summary: '第一次请求已经提交但响应丢失，客户端使用相同幂等键重试；系统核验原参数并返回原决定和原订单。',
    result: '重试 N 次仍只有 1 个决定、1 张订单和同一结果；偷换参数立即冲突',
    participants: [{ id: 'client', label: '客户端', detail: '相同 clientOrderId', tone: 'neutral' }, { id: 'api', label: 'Trading API', detail: '请求边界' }, { id: 'decision', label: '决定存储', detail: '唯一业务键', tone: 'green' }, { id: 'match', label: '撮合', detail: '幂等载荷核验' }, { id: 'order', label: '订单存储', detail: '原订单终态', tone: 'green' }],
    messages: [{ from: 'client', to: 'api', label: '第一次下单 order-001' }, { from: 'api', to: 'decision', label: '查询历史决定：不存在', type: 'data' }, { from: 'api', to: 'match', label: '批准并创建订单' }, { from: 'match', to: 'order', label: '写入订单 / 成交 / Outbox', type: 'data' }, { from: 'api', to: 'client', label: '响应在网络中丢失', type: 'reject' }, { from: 'client', to: 'api', label: '原 clientOrderId 重试' }, { from: 'api', to: 'decision', label: '命中原决定并核对全部参数', type: 'data' }, { from: 'decision', to: 'order', label: '读取原 orderId' }, { from: 'order', to: 'api', label: '返回原终态', type: 'return' }, { from: 'api', to: 'client', label: '同一订单结果', type: 'return' }],
  },
  {
    index: '04',
    title: '订单洪峰与有界背压',
    summary: '洪峰先经过入口限速，再进入固定容量 Lane；系统保护内存和尾延迟，队满明确返回 429。',
    result: '已接收请求保持同标的顺序；过载请求不静默丢失，携带原幂等键稍后重试',
    participants: [{ id: 'clients', label: '并发客户端', detail: 'Burst Traffic', tone: 'neutral' }, { id: 'nginx', label: 'Nginx', detail: '限速 / 超时' }, { id: 'api', label: 'Java API', detail: '虚拟线程' }, { id: 'lane', label: 'Bounded Lane', detail: '4 × 256' }, { id: 'db', label: '撮合事务', detail: 'symbol 定序', tone: 'green' }],
    messages: [{ from: 'clients', to: 'nginx', label: '瞬时订单洪峰' }, { from: 'nginx', to: 'api', label: '限额内请求' }, { from: 'api', to: 'lane', label: 'symbol 稳定散列' }, { from: 'lane', to: 'lane', label: '普通 256 + 撤单保留 32', type: 'data' }, { from: 'lane', to: 'db', label: '同 symbol 串行执行' }, { from: 'db', to: 'api', label: '已提交订单结果', type: 'return' }, { from: 'lane', to: 'api', label: '普通队列已满 / RejectedExecution', type: 'reject' }, { from: 'api', to: 'clients', label: '429 + 原幂等键重试', type: 'reject' }, { from: 'db', to: 'db', label: '新单 / 撤单队深与拒绝分别上报', type: 'data' }],
  },
  {
    index: '05',
    title: 'Worker 接管、重复投递与 Epoch Fencing',
    summary: '旧 Worker 失去租约后恢复，Kafka 同时重复投递；Epoch 在资金事务内阻止旧节点写入，Inbox 阻止重复资金效果。',
    result: '旧 Epoch 拒写 · 17 次投递只生效 1 次 · 新 Worker 完成结算',
    participants: [{ id: 'kafka', label: 'Kafka', detail: '至少一次投递', tone: 'violet' }, { id: 'wa', label: 'Worker A', detail: '旧 owner / epoch 1' }, { id: 'lease', label: 'Lease / Epoch', detail: '控制面 + 数据面', tone: 'green' }, { id: 'wb', label: 'Worker B', detail: '新 owner / epoch 2' }, { id: 'settle', label: 'Settlement', detail: 'Inbox + 状态机' }, { id: 'ledger', label: 'Ledger', detail: '唯一资金效果', tone: 'green' }],
    messages: [{ from: 'wa', to: 'lease', label: '获取 shard，epoch = 1', type: 'data' }, { from: 'kafka', to: 'wa', label: '第一次投递', type: 'async' }, { from: 'wa', to: 'wa', label: '网络停顿，租约过期', type: 'reject' }, { from: 'wb', to: 'lease', label: '接管 shard，epoch = 2', type: 'data' }, { from: 'kafka', to: 'wa', label: '迟到 / 重复投递', type: 'async' }, { from: 'wa', to: 'settle', label: '携带 epoch 1 写资金' }, { from: 'settle', to: 'lease', label: '事务内核验当前 epoch 2', type: 'data' }, { from: 'settle', to: 'wa', label: 'STALE_EPOCH 拒绝', type: 'reject' }, { from: 'kafka', to: 'wb', label: '重复消息 × 17', type: 'async' }, { from: 'wb', to: 'settle', label: 'epoch 2 处理' }, { from: 'settle', to: 'ledger', label: 'Inbox + 余额 + 分录同事务', type: 'data' }, { from: 'ledger', to: 'ledger', label: '只有 1 次资金效果', type: 'data' }],
  },
  {
    index: '06',
    title: '漏数、错值、幽灵成交的对账修复',
    summary: '对账以权威成交为基准，识别三类差异；只重建派生投影或隔离额外数据，不修改成交、余额和历史账本。',
    result: 'MISSING / MISMATCH 被幂等重建 · EXTRA 被隔离 · 再次对账 CLEAN',
    participants: [{ id: 'truth', label: '权威成交', detail: 'trade_execution', tone: 'green' }, { id: 'projection', label: '查询投影', detail: '可能漏 / 错 / 多' }, { id: 'recon', label: 'Reconciler', detail: '全外连接' }, { id: 'repair', label: 'Repair Worker', detail: '幂等修复' }, { id: 'audit', label: '审计 / 隔离', detail: '不可变证据', tone: 'green' }],
    messages: [{ from: 'projection', to: 'projection', label: '注入 MISSING / MISMATCH / EXTRA', type: 'reject' }, { from: 'recon', to: 'truth', label: '分页读取权威成交', type: 'data' }, { from: 'recon', to: 'projection', label: '读取派生投影', type: 'data' }, { from: 'recon', to: 'recon', label: '全外连接分类三类差异', type: 'data' }, { from: 'recon', to: 'repair', label: 'MISSING / MISMATCH 重建命令', type: 'async' }, { from: 'repair', to: 'truth', label: '只读权威事实', type: 'data' }, { from: 'repair', to: 'projection', label: '幂等重建派生记录', type: 'data' }, { from: 'recon', to: 'audit', label: 'EXTRA 隔离等待复核', type: 'reject' }, { from: 'audit', to: 'recon', label: '记录修复前后证据', type: 'return' }, { from: 'recon', to: 'truth', label: '再次核对', type: 'data' }, { from: 'recon', to: 'audit', label: '最终状态 CLEAN', type: 'return' }],
  },
];

type TelemetryPoint = {
  phase: number;
  time: string;
  event: string;
  price: number;
  orderRate: number;
  totalOrders: number;
  qps: number;
  matchTps: number;
  p95: number;
  cpu: number;
  memory: number;
  heap: number;
  dbActive: number;
  kafkaLag: number;
  outbox: number;
  rejects: number;
  reconDiffs: number;
};

const LAST_PHASE = 8;

const phases = [
  { time: 'READY', title: '系统待命', business: '三档买方流动性就绪', technical: '60 张 Maker 按价格/时间排序' },
  { time: 'T+00s', title: '流量突增', business: '12 路市价卖单同时涌入', technical: '入口 QPS 与订单速率同步抬升' },
  { time: 'T+01s', title: '深度耗尽', business: '三档买盘被全部吃穿', technical: '60 条成交；额外市价单被拒绝' },
  { time: 'T+02s', title: '请求重放', business: '客户端超时后集中重试', technical: '相同请求幂等，篡改请求拒绝' },
  { time: 'T+03s', title: 'Worker 接管', business: '旧节点恢复并尝试迟到写入', technical: 'Epoch 1 拒写，Epoch 2 接管' },
  { time: 'T+04s', title: '消息风暴', business: '同一结算消息投递 17 次', technical: 'Kafka Lag 爬升，Inbox 完成去重' },
  { time: 'T+05s', title: '同步异常', business: '查询端出现漏数、错值、幽灵成交', technical: '识别 MISSING / MISMATCH / EXTRA' },
  { time: 'T+06s', title: '自动修复', business: '重建派生投影并隔离异常数据', technical: 'Backlog、连接池与差异数同步回落' },
  { time: 'T+07s', title: '恢复复市', business: '钱、账、成交重新一致', technical: '再次对账 CLEAN，状态 RECOVERED' },
];

// 固定场景曲线用于把业务阶段与遥测联动起来。实跑结果另行标注，不把曲线冒充生产采样。
const telemetry: TelemetryPoint[] = [
  { phase: 0, time: 'READY', event: '待命', price: 100, orderRate: 0, totalOrders: 60, qps: 28, matchTps: 0, p95: 18, cpu: 12, memory: 31, heap: 26, dbActive: 2, kafkaLag: 0, outbox: 0, rejects: 0, reconDiffs: 0 },
  { phase: 1, time: 'T+00', event: '流量突增', price: 99.72, orderRate: 72, totalOrders: 72, qps: 860, matchTps: 160, p95: 41, cpu: 58, memory: 39, heap: 34, dbActive: 9, kafkaLag: 6, outbox: 18, rejects: 0, reconDiffs: 0 },
  { phase: 2, time: 'T+01', event: '深度耗尽', price: 98, orderRate: 68, totalOrders: 72, qps: 1260, matchTps: 500, p95: 118, cpu: 78, memory: 52, heap: 47, dbActive: 18, kafkaLag: 18, outbox: 60, rejects: 12, reconDiffs: 0 },
  { phase: 3, time: 'T+02', event: '请求重放', price: 98.08, orderRate: 46, totalOrders: 72, qps: 980, matchTps: 340, p95: 92, cpu: 71, memory: 55, heap: 51, dbActive: 15, kafkaLag: 24, outbox: 43, rejects: 12, reconDiffs: 0 },
  { phase: 4, time: 'T+03', event: 'Worker 接管', price: 98.12, orderRate: 21, totalOrders: 72, qps: 610, matchTps: 120, p95: 76, cpu: 62, memory: 54, heap: 48, dbActive: 12, kafkaLag: 39, outbox: 28, rejects: 12, reconDiffs: 0 },
  { phase: 5, time: 'T+04', event: '消息风暴', price: 98.18, orderRate: 12, totalOrders: 72, qps: 720, matchTps: 35, p95: 104, cpu: 68, memory: 61, heap: 57, dbActive: 20, kafkaLag: 86, outbox: 17, rejects: 12, reconDiffs: 0 },
  { phase: 6, time: 'T+05', event: '同步异常', price: 98.2, orderRate: 8, totalOrders: 72, qps: 490, matchTps: 12, p95: 86, cpu: 55, memory: 59, heap: 52, dbActive: 14, kafkaLag: 42, outbox: 8, rejects: 12, reconDiffs: 3 },
  { phase: 7, time: 'T+06', event: '自动修复', price: 98.31, orderRate: 5, totalOrders: 72, qps: 310, matchTps: 5, p95: 48, cpu: 38, memory: 48, heap: 41, dbActive: 7, kafkaLag: 9, outbox: 2, rejects: 12, reconDiffs: 0 },
  { phase: 8, time: 'T+07', event: '恢复', price: 98.45, orderRate: 3, totalOrders: 72, qps: 86, matchTps: 0, p95: 24, cpu: 19, memory: 37, heap: 30, dbActive: 3, kafkaLag: 0, outbox: 0, rejects: 12, reconDiffs: 0 },
];

const replayEvidence: Evidence = {
  runId: '5c960739',
  finalStatus: 'RECOVERED',
  tradeCount: 60,
  uniqueTradeSequences: 60,
  duplicateSettlementDeliveries: 17,
  ledgerTransactions: 6,
  repairedProjections: 2,
  quarantinedProjections: 1,
  matchingElapsedMs: 120,
  observedTradesPerSecond: 500,
  endToEndElapsedMs: 302,
};

const codeSamples: Record<CodeKey, {
  stage: string;
  label: string;
  file: string;
  title: string;
  summary: string;
  invariant: string;
  flow: string[];
  failure: string;
  evidence: string;
  testFile: string;
  points: string[];
  code: string;
}> = {
  persistence: {
    stage: '00 · MYBATIS',
    label: '持久化分层',
    file: 'infrastructure/persistence/mapper/SettlementMapper.java',
    title: 'Spring Boot 管事务，MyBatis Mapper 只负责参数化 SQL',
    summary: 'Controller 与 Kafka Listener 只做协议适配，Application Service 编排金融事务，12 个领域 Mapper 承担 SQL 和 record 映射。生产服务不再直接依赖 JdbcTemplate。',
    invariant: '事务边界留在 Service；SQL 只能使用 #{...} 参数绑定',
    flow: ['Web / Kafka 构造领域命令', 'Service 开启 Spring 事务', '多个 Mapper 共享同一数据库事务', 'PostgreSQL 约束与行锁作为最后防线'],
    failure: 'Mapper 不捕获业务异常、不自行提交；任一 SQL、CAS、序列化或约束失败都会沿调用栈抛出，由 Spring 回滚整个用例。',
    evidence: '架构测试持续禁止生产代码回退到 JdbcTemplate、禁止 ${...} 字符串直替，并保护账本与权威成交不可更新删除。',
    testFile: 'PersistenceArchitectureTest.java',
    points: ['Spring Boot 3.5.16 + MyBatis Starter 3.0.5', '12 个 Mapper 按用户交易、账户、账本、撮合、结算、对账等领域拆分', 'local-cache-scope=statement，金融查询不跨语句复用一级缓存'],
    code: `@MapperScan("dev.fincore.infrastructure.persistence.mapper")
@SpringBootApplication
public class FinCoreApplication { }

public interface SettlementMapper {
    @Insert("""
        INSERT INTO inbox_message(message_id, message_type, payload)
        VALUES (#{messageId}, 'SETTLEMENT_COMMAND', #{payload})
        ON CONFLICT (message_id) DO NOTHING
        """)
    int insertInbox(@Param("messageId") String messageId,
                    @Param("payload") String payload);

    @Update("""
        UPDATE settlement_order
        SET status=#{toStatus}, version=version+1, updated_at=now()
        WHERE business_key=#{businessKey} AND status=#{fromStatus}
        """)
    int transition(...);
}`,
  },
  lifecycle: {
    stage: '00 · CUSTOMER',
    label: '用户与行情',
    file: 'application/TradingLifecycleService.java',
    title: '先确认谁能交易、用哪个账户、参考什么行情',
    summary: '完整入口管理用户状态、KYC、风控档案、交易账户和参考行情。ACTIVE + VERIFIED 只是第一道门，后续仍要检查交易开关、额度、余额和行情年龄。',
    invariant: '用户资格、账户归属和参考行情任一不可判断时，必须停止新增风险',
    flow: ['注册用户并等待 KYC', '配置单笔/日累计风险限额', '为用户建立分资产交易账户', '发布带来源和观察时间的参考行情'],
    failure: '暂停用户、未完成 KYC、关闭交易权限或超过 30 秒的参考行情都会产生明确拒绝原因，不会继续进入撮合。',
    evidence: 'TradingLifecycleIntegrationTest 验证 KYC 未通过和过期行情都保存拒绝决定，matching_order 保持 0 条。',
    testFile: 'TradingLifecycleIntegrationTest.java',
    points: ['用户生命周期与 KYC 状态分开建模', '参考行情旧时间不能覆盖新快照', '买单检查计价资产账户，卖单检查基础资产账户'],
    code: `@Transactional
public TradingOrderResult place(PlaceOrderCommand command) {
    CustomerRow customer = lifecycleMapper.findCustomer(command.userId());
    if (customer == null) {
        return reject(command, null, null, null,
            "USER_NOT_FOUND", "用户不存在");
    }
    if (!"ACTIVE".equals(customer.status())) {
        return reject(command, null, null, null,
            "USER_NOT_ACTIVE", "用户不是可交易状态");
    }
    if (!"VERIFIED".equals(customer.kycStatus())) {
        return reject(command, null, null, null,
            "KYC_NOT_VERIFIED", "KYC 尚未通过");
    }

    RiskProfileRow risk = lifecycleMapper.lockRiskProfile(command.userId());
    MarketQuoteRow quote = lifecycleMapper.findMarketQuote(command.symbol());
    if (quote == null || quote.observedAt()
            .isBefore(Instant.now().minusSeconds(30))) {
        return reject(command, null, null, null,
            "MARKET_QUOTE_STALE", "行情不可用");
    }
    // 继续校验价格、额度、账户与余额，通过后才调用 MatchingService。
}`,
  },
  pretrade: {
    stage: '01 · PRE-TRADE',
    label: '盘前风控',
    file: 'infrastructure/persistence/mapper/TradingLifecycleMapper.java',
    title: '风控决定本身也是需要幂等和审计的业务事实',
    summary: '盘前检查按用户锁住风控档案，再计算价格偏离、单笔/日累计名义金额和所需资产余额。决定以 userId + clientOrderId 唯一保存。',
    invariant: '同一订单只能消耗一次额度；拒绝不能创建订单；重放不能偷换价格或数量',
    flow: ['查询并核验历史决定', 'FOR UPDATE 锁用户风控档案', '计算价格偏离与累计敞口', '保存决定，APPROVED 才进入撮合'],
    failure: '无价格保护的市价单、单笔/累计超限、账户缺失或余额不足全部失败关闭，并返回稳定 reasonCode。',
    evidence: '集成测试证明批准重放只有 1 条盘前决定和 1 张订单；相同幂等键修改价格会被拒绝。',
    testFile: 'TradingLifecycleIntegrationTest.java',
    points: ['FOR UPDATE 关闭并发日限额竞态', '唯一业务键防止重复占用额度', 'APPROVED 与撮合处于同一 Spring 事务，撮合失败一起回滚'],
    code: `@Select("""
    SELECT user_id, trading_enabled,
           max_order_notional, max_daily_notional,
           max_price_deviation, version
    FROM risk_profile
    WHERE user_id=#{userId}
    FOR UPDATE
    """)
RiskProfileRow lockRiskProfile(@Param("userId") String userId);

@Insert("""
    INSERT INTO pre_trade_decision(
        decision_id, user_id, client_order_id, symbol,
        side, order_type, limit_price, quantity,
        reference_price, order_notional, account_id,
        decision, reason_code, reason_detail)
    VALUES (#{decisionId}, #{userId}, #{clientOrderId}, #{symbol},
        #{side}, #{orderType}, #{limitPrice}, #{quantity},
        #{referencePrice}, #{orderNotional}, #{accountId},
        #{decision}, #{reasonCode}, #{reasonDetail})
    """)
int insertDecision(...);`,
  },
  domain: {
    stage: '00 · DOMAIN',
    label: '金额与分录',
    file: 'domain/BalancedJournal.java',
    title: '先在纯领域层证明借贷相等，再允许账本落库',
    summary: '金额统一使用 BigDecimal；每条分录只表达账户、借贷方向和正数金额。BalancedJournal 汇总全部分录，借贷不相等时立即中止事务。',
    invariant: '任何 Ledger Transaction：借方合计 = 贷方合计',
    flow: ['SettlementCommand 校验金额形状', '生成 payer / payee / fee 分录', 'BalancedJournal 汇总借贷双方', '不平衡即抛错，数据库事务回滚'],
    failure: '不使用 float / double，不靠最后修改余额“抹平”误差；不平衡分录不能进入持久化层。',
    evidence: '页面恢复阶段显示 6 ledger tx、0 balance-ledger mismatch。',
    testFile: 'domain/BalancedJournalTest.java',
    points: ['Money 固定 18 位精度并校验资产一致', 'LedgerPosting 金额始终为正，方向单独表达', 'BalancedJournal 是结算与补偿共用的前置不变量'],
    code: `/**
 * 校验一组账本分录的借方总额与贷方总额相等。
 *
 * @param postings 待校验的不可变分录列表
 */
public static void requireBalanced(List<LedgerPosting> postings) {
    BigDecimal debits = postings.stream()
        .filter(p -> p.direction() == LedgerDirection.DEBIT)
        .map(LedgerPosting::amount).reduce(ZERO, BigDecimal::add);
    BigDecimal credits = postings.stream()
        .filter(p -> p.direction() == LedgerDirection.CREDIT)
        .map(LedgerPosting::amount).reduce(ZERO, BigDecimal::add);
    if (debits.compareTo(credits) != 0) {
        throw new IllegalArgumentException(
            "unbalanced journal: debits=" + debits
                + ", credits=" + credits);
    }
}`,
  },
  concurrency: {
    stage: '01 · ADMISSION',
    label: '并发准入',
    file: 'infrastructure/concurrent/StripedTaskExecutor.java',
    title: '按交易对进入有界 Lane：同标的有序，多标的并行',
    summary: '入口不会把每个请求直接推给数据库。同一 symbol 经稳定散列进入同一单平台线程 Lane，默认每条普通新单容量 256、撤单保留容量 32；不同 symbol 可以并行。',
    invariant: '过载必须显式拒绝，不能静默丢单、调用方乱序执行或伪造回滚',
    flow: ['symbol 稳定散列选择 Lane', '普通/撤单双有界容量控制在途量', '8:1 优先批次保持撤单能力', '跨实例仍由 PostgreSQL 事务锁定序'],
    failure: 'Lane 满返回 429；HTTP 等待超过 10 秒返回可重试超时，但不会取消已经开始的资金事务。客户端必须用原 clientOrderId 查询或重试。',
    evidence: '页面 QPS、撮合 TPS、P95、CPU、DB 活跃连接和拒绝数使用同一阶段游标联动；队列指标可在 Grafana 查看。',
    testFile: 'infrastructure/concurrent/StripedTaskExecutorTest.java',
    points: ['PriorityCommandQueue 分隔普通容量与撤单保留容量', '撤单仍由同一平台线程执行且最大连续批次为 8', 'fincore.matching.* 指标分别覆盖新单与撤单队深、执行和拒绝'],
    code: `public <T> CompletableFuture<T> submit(
        String symbol, Callable<T> task) {
    CompletableFuture<T> result = new CompletableFuture<>();
    long submittedAt = System.nanoTime();
    try {
        lanes[laneFor(symbol)].execute(() -> {
            queueWait.record(System.nanoTime() - submittedAt,
                TimeUnit.NANOSECONDS);
            try {
                result.complete(task.call());
            } catch (Exception failure) {
                result.completeExceptionally(failure);
            }
        });
    } catch (RejectedExecutionException failure) {
        rejected.increment();
        throw new ConcurrencyRejectedException(
            "matching queue is full; retry with same idempotency key");
    }
    return result;
}`,
  },
  matching: {
    stage: '01 · MATCH',
    label: '撮合',
    file: 'application/MatchingService.java',
    title: '先锁交易对，再按价格时间优先撮合',
    summary: '同一交易对在数据库事务中串行化；客户端订单号重复时返回原结果，载荷被篡改则直接拒绝。',
    invariant: '订单原始量 = 已成交量 + 剩余量；成交序号全局不重复',
    flow: ['获取交易对事务锁', '核验 clientOrderId 幂等载荷', 'FOR UPDATE 选择最优 Maker', '写成交、审计与 Outbox 后统一提交'],
    failure: '任何 Maker CAS、Taker 更新或事件序列化失败都会回滚整笔撮合；不会留下只有成交、没有事件的半状态。',
    evidence: 'T+01s：60 条成交 = 60 个唯一 trade_sequence；额外市价单安全拒绝。',
    testFile: 'MatchingIntegrationTest.java',
    points: ['pg_advisory_xact_lock 保证同交易对确定性顺序', 'order_sequence / trade_sequence 持久化分配', '成交、订单状态、审计和 Outbox 同事务提交'],
    code: `@Transactional
public MatchingResult place(PlaceOrderCommand command) {
    matchingMapper.lockSymbol(command.symbol());
    Optional<OrderView> replay = Optional.ofNullable(
        matchingMapper.findByClientOrder(
            command.userId(), command.clientOrderId()));
    if (replay.isPresent()) {
        requireSameRequest(command, replay.get());
        duplicates.increment();
        return new MatchingResult(asDuplicate(replay.get(),
            "duplicate client order"), tradesForTaker(replay.get().orderId()));
    }
    long orderSequence = matchingMapper.nextSequence(command.symbol());
    matchingMapper.insertOrder(UUID.randomUUID(), command, orderSequence);
    OrderView maker = command.side() == OrderSide.BUY
        ? matchingMapper.lockBestSell(command.symbol())
        : matchingMapper.lockBestBuy(command.symbol());
    // MatchingMapper + OutboxMapper 共享当前 Spring 事务
}`,
  },
  settlement: {
    stage: '04 · SETTLE',
    label: '结算',
    file: 'application/SettlementService.java',
    title: '一笔数据库事务守住消息、资金和状态',
    summary: '先写 Inbox 去重，再校验 Fencing Token，随后锁账户、验证借贷平衡、写账本、更新余额和 Outbox。任何一步失败都会整体回滚。',
    invariant: '同一消息、同一业务单最多产生一次资金效果',
    flow: ['Inbox 抢占 message_id', '事务内校验 Epoch', '按 UUID 排序锁账户', '账本、余额、SUCCESS、Outbox 原子提交'],
    failure: '余额不足、旧 Epoch、账户资产不一致、CAS 失败都会抛错；SUCCESS 不能被迟到线程覆盖。',
    evidence: 'T+04s：17 次投递只形成 1 次资金效果；最终共 6 个账本交易。',
    testFile: 'SettlementIntegrationTest.java',
    points: ['message_id 与 business_key 两层唯一性', '账户按 UUID 固定排序加锁，降低死锁概率', 'CAS 状态机阻止成功状态被旧线程覆盖'],
    code: `@Transactional
public SettlementOutcome settle(SettlementCommand command,
                                FenceToken fenceToken) {
    if (settlementMapper.insertInbox(
            command.messageId(), toJson(command)) == 0) {
        duplicates.increment();
        return currentOutcomeByMessage(command.messageId());
    }

    // 围栏必须在资金事务内部校验。
    if (fenceToken != null) {
        shardLeases.requireValidFenceForUpdate(fenceToken);
    }
    Map<UUID, LockedAccount> accounts = lockAccounts(command);
    BalancedJournal.requireBalanced(postings);
    UUID transactionId = UUID.randomUUID();
    ledgerMapper.insertTransaction(transactionId,
        command.businessKey(), "SETTLEMENT", command.asset());
    ledgerMapper.insertEntries(transactionId, postings.stream()
        .map(posting -> new LedgerEntryRow(UUID.randomUUID(),
            posting.accountId(), posting.direction().name(), posting.amount()))
        .toList());
    transition(command.businessKey(), SettlementStatus.PROCESSING,
        SettlementStatus.SUCCESS, null);
    outboxMapper.insert(UUID.randomUUID(), command.businessKey(),
        "SETTLEMENT_SUCCEEDED", toJson(Map.of(
            "businessKey", command.businessKey(), "status", "SUCCESS")));
}`,
  },
  compensation: {
    stage: '05 · REVERSE',
    label: '反向补偿',
    file: 'application/CompensationService.java',
    title: '纠错不是修改历史，而是追加一笔可追溯的反向交易',
    summary: '补偿先用原业务键创建唯一补偿单，再锁定原成功结算和相关账户，生成方向相反的平衡分录。原始 SUCCESS 与历史账本始终保留。',
    invariant: '历史账本不可修改；同一原业务单最多生成一笔成功补偿',
    flow: ['按 original_business_key 创建补偿单', '锁定原 SUCCESS 结算', '按 UUID 顺序锁账户', '追加 reverse ledger 与补偿 Outbox'],
    failure: '收款方或费用账户余额不足时补偿失败并回滚；不会把原结算状态改成“从未发生”。',
    evidence: '综合场景连续提交两次补偿，第一次 SUCCESS，第二次 duplicate=true。',
    testFile: 'LabScenarioIntegrationTest.java',
    points: ['补偿业务键拥有数据库唯一约束', '反向分录仍先经过 BalancedJournal', '原交易与补偿交易通过 reversed_business_key 关联'],
    code: `@Transactional
public CompensationOutcome compensate(
        String originalBusinessKey, String reason) {
    String compensationKey = "COMP:" + originalBusinessKey;
    UUID compensationId = UUID.randomUUID();
    int created = compensationMapper.insert(
        compensationId, originalBusinessKey, compensationKey, reason);
    if (created == 0) {
        return current(originalBusinessKey, true);
    }

    CompensationMapper.OriginalSettlementRow originalRow =
        compensationMapper.lockOriginal(originalBusinessKey);
    OriginalSettlement original = new OriginalSettlement(
        originalRow.businessKey(), originalRow.payer(), originalRow.payee(),
        originalRow.feeAccount(), originalRow.asset(),
        originalRow.amount(), originalRow.fee(), originalRow.status());

    // 不修改原 SUCCESS 和历史分录，只新增方向相反的交易。
    List<LedgerPosting> postings = new ArrayList<>();
    postings.add(new LedgerPosting(
        original.payee(), LedgerDirection.DEBIT, original.amount()));
    postings.add(new LedgerPosting(
        original.payer(), LedgerDirection.CREDIT, total));
    BalancedJournal.requireBalanced(postings);

    UUID tx = UUID.randomUUID();
    ledgerMapper.insertTransaction(
        tx, compensationKey, "COMPENSATION", original.asset());
    ledgerMapper.insertEntries(tx, toRows(postings));
    compensationMapper.markSuccess(compensationId);
    outboxMapper.insert(UUID.randomUUID(), originalBusinessKey,
        "SETTLEMENT_COMPENSATED", toJson(Map.of(
            "originalBusinessKey", originalBusinessKey,
            "status", "COMPENSATED")));
}`,
  },
  outbox: {
    stage: '02 · PUBLISH',
    label: 'Outbox',
    file: 'infrastructure/persistence/mapper/OutboxMapper.java',
    title: '先把事件和业务写在一起，再可靠投递 Kafka',
    summary: 'Publisher 每次原子抢占最多 200 条 PENDING 事件，异步并发等待 Kafka Broker 确认，再把成功与失败编号分别批量回写数据库。',
    invariant: '业务事务提交后事件不会静默丢失；失败发布可以安全重试',
    flow: ['业务事务写入 PENDING 事件', 'SKIP LOCKED 抢占最多 200 条', 'Kafka 异步发送并统一等待确认', '成功/失败分别批量回写'],
    failure: 'Publisher 崩溃留下的 PROCESSING 事件会被定时回收；publisher_id 防止其他实例越权确认。',
    evidence: '撮合阶段生成 60 条成交 Outbox；消息风暴后 Backlog 与 Kafka Lag 最终归零。',
    testFile: 'LabScenarioIntegrationTest.java',
    points: ['FOR UPDATE SKIP LOCKED 支持多个 Publisher 并行抢占', '异步发送减少逐条网络等待，数据库状态批量回写', '指数退避 + 0~2 秒确定性抖动避免重试齐射'],
    code: `public interface OutboxMapper {
    @Select("""
        UPDATE outbox_event
        SET status='PROCESSING', claimed_at=now(),
            publisher_id=#{publisherId}
        WHERE event_id IN (
            SELECT event_id FROM outbox_event
            WHERE status='PENDING' AND next_attempt_at<=now()
            ORDER BY created_at LIMIT #{limit}
            FOR UPDATE SKIP LOCKED
        )
        RETURNING event_id AS "eventId",
            aggregate_id AS "aggregateId", event_type AS "eventType", payload
        """)
    List<OutboxEventRow> claimBatch(
        @Param("publisherId") String publisherId,
        @Param("limit") int limit);

    // Publisher 并发发送后调用 markPublishedBatch / releaseForRetryBatch。
}`,
  },
  workerLease: {
    stage: '03 · LEASE CACHE',
    label: 'Worker 续期',
    file: 'application/WorkerLeaseManager.java',
    title: '用短期缓存合并续期写热点，但绝不把缓存当资金凭证',
    summary: '同一分片的并发消息通过 ConcurrentHashMap.compute 合并 Lease 创建或续期；默认 Lease 30 秒、提前 10 秒续期，避免每条 Kafka 消息都写一次数据库。',
    invariant: '缓存只优化控制面；每笔资金事务仍必须在数据库内校验 owner + epoch',
    flow: ['先读取进程内 Lease 快照', '有效期足够则直接生成 FenceToken', '临近到期时 compute 合并续期', '结算事务在 DB 内做最终 Fencing'],
    failure: '围栏失败只删除匹配旧 epoch 的缓存，不能误删已经完成的并发续期；缓存过期最多造成一次额外续期或明确拒绝。',
    evidence: '64 个同分片并发请求的自动测试只触发一次 acquireOrRenew；Grafana 同时展示 hit、renewal 与 invalidation。',
    testFile: 'application/WorkerLeaseManagerTest.java',
    points: ['ConcurrentHashMap.compute 合并同 key 并发刷新', 'compare-and-remove 语义保护新 epoch', '最终资金授权仍来自 PostgreSQL shard_lease 行锁'],
    code: `public FenceToken currentFence(int shardId, String workerId) {
    Lease cached = cache.get(shardId);
    if (reusable(cached, workerId, renewalBoundary())) {
        cacheHits.increment();
        return toFence(cached);
    }
    Lease current = cache.compute(shardId, (key, existing) -> {
        if (reusable(existing, workerId, renewalBoundary())) {
            cacheHits.increment();
            return existing;
        }
        renewals.increment();
        return leases.acquireOrRenew(shardId, workerId, ttl);
    });
    return toFence(current);
}

// 注意：SettlementService 仍会在资金事务内部校验此令牌。
`,
  },
  fencing: {
    stage: '06 · OWNERSHIP',
    label: 'Fencing',
    file: 'application/ShardLeaseService.java',
    title: 'Lease 只负责选主，Epoch 才真正阻止旧节点写入',
    summary: '资金事务内部再次读取 shard_lease，只有 owner、epoch、RUNNING 状态和未过期时间全部匹配才允许继续。',
    invariant: '任何时刻只有当前 owner + 当前 Epoch 能执行资金写入',
    flow: ['旧 Worker 进入 DRAINING', 'Lease 过期后新 Worker 接管', 'Epoch 从 1 递增到 2', '结算事务内再次读取并校验'],
    failure: '入口层检查不能代替数据面校验；旧 Worker 即使网络恢复并继续执行，也会在写钱前被拒绝。',
    evidence: 'T+03s：Worker A / Epoch 1 拒写，Worker B / Epoch 2 完成结算。',
    testFile: 'LabScenarioIntegrationTest.java',
    points: ['接管时 epoch 单调递增', '校验发生在数据面写事务内部', 'DRAINING 或已过期 Worker 即使恢复也无法写钱'],
    code: `public void requireValidFenceForUpdate(FenceToken token) {
    ShardLeaseMapper.LeaseRow row =
        leaseMapper.lockForFenceValidation(token.shardId());
    if (row == null) {
        throw new IllegalStateException(
            "fence rejected: shard lease missing");
    }
    Lease lease = toLease(row);
    if (!lease.ownerId().equals(token.ownerId())
        || lease.epoch() != token.epoch()
        || !"RUNNING".equals(lease.state())
        || !lease.leaseUntil().isAfter(Instant.now())) {
        throw new IllegalStateException(
            "fence rejected: stale or draining worker");
    }
}`,
  },
  tradeSync: {
    stage: '07 · PROJECT',
    label: '成交同步',
    file: 'application/TradeReliabilityService.java',
    title: '事件号去重还不够，还要验证重复事件的内容没有被替换',
    summary: 'trade_sync_inbox 先抢占 event_id，并保存规范化载荷的 SHA-256 指纹；trade_projection 再按 trade_id 去重。两层冲突都会显式失败。',
    invariant: '相同事件可重复到达，但同一事件号或成交号不能对应不同事实',
    flow: ['规范化金额并计算载荷指纹', 'Inbox 按 event_id 去重', '投影按 trade_id 去重', '冲突时逐项核验不可变字段'],
    failure: '重复事件返回 duplicateEvent=true；相同编号携带不同成交、价格或数量时抛错，避免错值静默覆盖。',
    evidence: 'T+05s 的乱序事件正常同步，重复事件被识别，错值投影随后由对账检测。',
    testFile: 'TradeReliabilityIntegrationTest.java',
    points: ['指纹包含交易对、双方订单、价格、数量和序号', 'BigDecimal 先 stripTrailingZeros，避免 scale 造成伪冲突', '投影是派生数据，权威来源始终是 trade_execution'],
    code: `@Transactional
public SyncOutcome apply(TradeSyncCommand command) {
    String payloadHash = fingerprint(command);
    int insertedEvent = tradeMapper.insertInbox(
        command.eventId(), command.tradeId(), payloadHash);
    TradeReliabilityMapper.InboxRow inbox =
        tradeMapper.findInbox(command.eventId());

    if (inbox == null
        || !inbox.tradeId().equals(command.tradeId())
        || !inbox.payloadHash().equals(payloadHash)) {
        throw new IllegalArgumentException(
            "同一事件号携带了冲突成交内容");
    }
    if (insertedEvent == 0) {
        duplicateEvents.increment();
        return new SyncOutcome(command.eventId(),
            command.tradeId(), true, false, inbox.status());
    }
    int projected = tradeMapper.insertProjection(command);
    if (projected == 0) {
        requireSameProjection(command);
    }
    tradeMapper.markInboxProcessed(command.eventId());
}`,
  },
  reconcile: {
    stage: '08 · REPAIR',
    label: '对账修复',
    file: 'infrastructure/persistence/mapper/TradeReliabilityMapper.java',
    title: '用权威成交反查派生投影，只修能重建的数据',
    summary: 'FULL OUTER JOIN 同时找出漏数、错值和幽灵成交；修复前与撮合共享交易对锁，避免误伤正在提交的合法成交。',
    invariant: '修复只能重建派生投影，不能改写权威成交或历史账本',
    flow: ['REPEATABLE READ 冻结对账窗口', 'FULL OUTER JOIN 生成三类差异', 'repair key 抢占修复任务', '重建 MISSING/MISMATCH，隔离 EXTRA'],
    failure: 'EXTRA 不物理删除，保留调查证据；修复完成后必须再次对账，只有 CLEAN 才算闭环。',
    evidence: 'T+05s 发现 1/1/1；T+06s 重建 2、隔离 1；T+07s 差异归零。',
    testFile: 'TradeReliabilityIntegrationTest.java',
    points: ['MISSING / MISMATCH 从 trade_execution 重建', 'EXTRA 只隔离，不删除权威事实', 'repair idempotency key 防止重复修复产生二次影响'],
    code: `@Select("""
SELECT COALESCE(e.trade_id, a.trade_id) AS "tradeId",
       CASE
         WHEN e.trade_id IS NULL THEN 'EXTRA'
         WHEN a.trade_id IS NULL THEN 'MISSING'
         ELSE 'MISMATCH'
       END AS type,
       e.payload AS "expectedPayload", a.payload AS "actualPayload"
FROM expected e
FULL OUTER JOIN actual a ON e.trade_id = a.trade_id
WHERE e.trade_id IS NULL OR a.trade_id IS NULL
   OR e.price IS DISTINCT FROM a.price
   OR e.quantity IS DISTINCT FROM a.quantity
""")
List<DetectedDifferenceRow> findDifferences(
    @Param("symbol") String symbol);`,
  },
  scenario: {
    stage: '09 · PROVE',
    label: '复合实验',
    file: 'application/MarketCrashScenarioService.java',
    title: '场景不是造一张图，而是用数据库事实逐阶段做断言',
    summary: '市场暴跌日服务串联三档深度、并发市价单、重放、流动性耗尽、Worker 接管、17 次重复结算和三类投影污染；任何断言失败都不会返回 RECOVERED。',
    invariant: '报告中的每个 PASS 都必须有数据库计数、唯一性或状态证据',
    flow: ['预置 60 张三档 Maker', '12 路卖单并发吃穿深度', '接管并重复投递结算', '污染投影、修复、再对账 CLEAN'],
    failure: '这是正确性与恢复性实验，不把固定遥测曲线冒充生产 TPS，也不宣称覆盖真实网络分区或硬件灾难。',
    evidence: '页面整条 T+00s—T+07s 时间线与 RECOVERED 证据均由该场景结果映射。',
    testFile: 'LabScenarioIntegrationTest.java',
    points: ['每次运行使用隔离交易对和账户', 'require(...) 失败立即中断，不生成成功报告', '恢复前后 TruthSnapshot 证明权威成交未被修复改写'],
    code: `public synchronized MarketCrashReport runMarketCrashDay() {
    Instant startedAt = Instant.now();
    String runId = UUID.randomUUID().toString().substring(0, 8);
    String symbol = "CRASH" + runId.toUpperCase() + "-USDT";

    seedBuyLiquidity(runId, symbol);
    TrafficOutcome traffic = runSellOff(runId, symbol);
    verifyMatching(symbol, traffic);

    SettlementEvidence settlement =
        runFailoverAndSettlement(runId, symbol, traffic.trades());
    TruthSnapshot truthBefore = truth(symbol);
    RecoveryEvidence recovery =
        injectAndRecover(symbol, runId, traffic.trades());
    TruthSnapshot truthAfter = truth(symbol);

    require(sameTruth(truthBefore, truthAfter),
        "修复修改了权威成交 / repair changed authoritative trades");
    long ledgerMismatches = ledgerMismatchCount(
        settlement.payerId(), settlement.payeeId(), settlement.feeId());
    require(ledgerMismatches == 0,
        "资金余额与账本不一致");
    // 只有上述断言全部通过，最终报告才会返回 RECOVERED。
}`,
  },
};

const codeOrder: CodeKey[] = [
  'persistence',
  'lifecycle',
  'pretrade',
  'domain',
  'concurrency',
  'matching',
  'outbox',
  'workerLease',
  'settlement',
  'compensation',
  'fencing',
  'tradeSync',
  'reconcile',
  'scenario',
];

export default function Home() {
  const [introCopied, setIntroCopied] = useState(false);
  const [mode, setMode] = useState<Mode>('live');
  const [phase, setPhase] = useState(0);
  const [maxPhase, setMaxPhase] = useState(0);
  const [running, setRunning] = useState(false);
  const [faults, setFaults] = useState<Faults>({ burst: true, duplicate: true, sync: true });
  const lifecycleRun = useScenarioRun('lifecycle', parseLifecycleReport);
  const { state: lifecycleState, report: lifecycleEvidence, message: lifecycleMessage } = lifecycleRun;
  const [architectureTab, setArchitectureTab] = useState<ArchitectureDomainKey>('identity');
  const [codeTab, setCodeTab] = useState<CodeKey>('persistence');
  const [selectedPerformance, setSelectedPerformance] = useState<PerformanceDetailKey | null>(null);

  const evidence = replayEvidence;
  const scenarioTelemetry = useMemo(
    () => telemetry.map((point) => ({
      ...point,
      ...(faults.burst
        ? {}
        : {
            price: 100,
            orderRate: 0,
            totalOrders: 60,
            qps: Math.min(point.qps, 80),
            matchTps: 0,
            p95: Math.min(point.p95, 26),
            cpu: Math.min(point.cpu, 24),
            memory: Math.min(point.memory, 38),
            heap: Math.min(point.heap, 32),
            rejects: 0,
          }),
      ...(faults.duplicate
        ? {}
        : {
            kafkaLag: 0,
            outbox: point.phase >= 2 && point.phase <= 4 ? Math.min(point.outbox, 8) : 0,
            dbActive: Math.min(point.dbActive, 6),
          }),
      ...(faults.sync ? {} : { reconDiffs: 0 }),
    })),
    [faults],
  );
  const current = scenarioTelemetry[phase];
  const previous = scenarioTelemetry[Math.max(0, phase - 1)];
  const chartData = scenarioTelemetry.slice(0, phase + 1);
  const selectedCode = codeSamples[codeTab];
  const selectedArchitecture = architectureDomains[architectureTab];
  const performanceDetail = selectedPerformance ? performanceDetails[selectedPerformance] : null;
  const progress = Math.round((phase / LAST_PHASE) * 100);
  const recovered = phase === LAST_PHASE;
  const incident = phase > 0 && phase < LAST_PHASE;
  const burstOccurred = faults.burst && phase >= 2;
  const duplicateOccurred = faults.duplicate && phase >= 5;
  const syncOccurred = faults.sync && phase >= 6;
  const lifecycleData = lifecycleEvidence?.data ?? {
    userId: 'journey-buyer',
    userStatus: 'ACTIVE',
    kycStatus: 'VERIFIED',
    accountAsset: 'USDT',
    accountBalance: 1000,
    symbol: 'BTC-USDT',
    referencePrice: 100,
    quantity: 2,
    orderNotional: 200,
    preTradeDecision: 'APPROVED',
    orderStatus: 'FILLED',
    tradeCount: 1,
    rejectedReasonCode: 'KYC_NOT_VERIFIED',
  };

  useEffect(() => {
    if (!running || phase >= LAST_PHASE) return;
    const timer = window.setTimeout(() => {
      const nextPhase = Math.min(phase + 1, LAST_PHASE);
      setPhase(nextPhase);
      setMaxPhase((value) => Math.max(value, nextPhase));
      if (nextPhase === LAST_PHASE) setRunning(false);
    }, 1250);
    return () => window.clearTimeout(timer);
  }, [phase, running]);

  const checks = useMemo(
    () => [
      [faults.burst ? '60 条唯一成交' : '流量洪峰未注入', phase >= 2],
      [faults.burst ? '额外订单拒绝' : '价格与订单保持基线', phase >= 2],
      ['请求重放幂等', phase >= 3],
      ['旧 Worker 围栏', phase >= 4],
      [faults.duplicate ? '重复结算去重' : '重复消息未注入', phase >= 5],
      [faults.sync ? '三类差异识别' : '同步异常未注入', phase >= 6],
      [faults.sync ? '2 修复 / 1 隔离' : '无需投影修复', phase >= 7],
      ['Kafka Lag 清零', recovered],
      ['资金账本平衡', recovered],
      ['最终对账 CLEAN', recovered],
    ],
    [faults, phase, recovered],
  );

  function reset() {
    setRunning(false);
    setPhase(0);
    setMaxPhase(0);
  }

  function startReplay() {
    setPhase(1);
    setMaxPhase(1);
    setRunning(true);
  }

  async function copyIntroduction() {
    const introduction = 'FinCore Reliability Lab 是可运行、可验证的金融与数字资产可靠性项目，覆盖交易全链路、资金一致性、有界并发、故障恢复、低延迟实验、团队治理与 AI 工程化。源码、架构、测试和测量边界均可查看。项目演示：https://124.223.164.254/';
    try {
      await navigator.clipboard.writeText(introduction);
      setIntroCopied(true);
      window.setTimeout(() => setIntroCopied(false), 2200);
    } catch {
      window.prompt('请复制下面的项目介绍', introduction);
    }
  }

  function runLifecycle() {
    void lifecycleRun.run();
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="site-header sticky top-0 z-50 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1680px] flex-wrap items-center justify-between gap-y-2 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-xl bg-cyan-300 text-[#061018] shadow-[0_0_28px_rgba(103,232,249,.18)]"><Activity className="size-5" /></span>
            <div><p className="text-sm font-semibold tracking-[0.16em] text-white">FINCORE</p><p className="text-[10px] text-slate-500">技术负责人作品集</p></div>
          </div>
          <nav className="portfolio-nav" aria-label="主要内容">
            <a href="#overview">项目综述</a><a href="#knowledge-map">专题目录</a>
            <a href="#settlement-optimization">结算性能</a><a href="#performance-engineering">中间件与热点</a><a href="#management">团队与交付</a>
            <a href="#ai">AI 落地</a><a href="#demo">运行演示</a>
            <a href="https://github.com/soldierking04d/fincore-reliability-lab" target="_blank" rel="noreferrer"><GitBranch className="size-4" /> 源码</a>
          </nav>
        </div>
      </header>

      <PortfolioOverview />
      <KnowledgeChapter number="结算" title="结算性能优化" description="独立专项：资金事务、幂等与过期保护、分段监控、测试与逐笔验账">
        <SettlementOptimization />
      </KnowledgeChapter>
      <KnowledgeChapter number="资金" title="交易、支付与一致性边界" description="逐笔订单数字演示 · 跨账户恢复 · 2PC · 支付渠道 · 稳定币 · 云上存储">
        <TransactionBoundaries />
      </KnowledgeChapter>
      <KnowledgeChapter number="专题" title="中间件与热点账户优化" description="消息与连接预算、热点写入、实施步骤与完整手册">
        <PerformanceEngineering />
      </KnowledgeChapter>
      <KnowledgeChapter number="安全" title="运行时安全与 PHP 漏洞" description="2026 年 10 月公告、修复验收、请求隔离与跨语言对照">
        <RuntimeSecurity />
      </KnowledgeChapter>
      <KnowledgeChapter number="事件" title="钱包安全与第三方供应链" description="Polymarket / Binance 事件：业务影响、权限边界、止血恢复与真实防御测试">
        <SecurityIncidents />
      </KnowledgeChapter>

      <section className="mx-auto max-w-[1680px] scroll-mt-20 px-4 pt-4 pb-4 sm:px-6 lg:px-8">
        <KnowledgeChapter number="作者" title="关于作者" description="技术负责人、研发负责人和金融系统架构方向">
<div id="profile" className="overflow-hidden rounded-2xl border border-cyan-300/12 bg-[linear-gradient(135deg,rgba(15,35,47,.98),rgba(7,16,25,.98)_58%,rgba(16,39,47,.92))]">
          <div className="grid gap-8 p-5 sm:p-7 xl:grid-cols-[1.25fr_.75fr] xl:p-9">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="border border-emerald-300/20 bg-emerald-300/10 text-emerald-300">正在寻找新的工作机会</Badge>
                <span className="font-mono text-[9px] text-emerald-300/70">CODE · DATA · MANAGEMENT · AI · DIGITAL ASSETS</span>
              </div>
              <h2 className="mt-5 max-w-5xl text-3xl font-semibold tracking-[-0.045em] text-white sm:text-4xl xl:text-5xl">技术负责人、研发负责人及金融系统架构方向</h2>
              <p className="mt-4 max-w-4xl text-sm leading-7 text-slate-400">我主要关注交易与清结算系统，也关注团队如何把需求交付到可维护的服务中。FinCore 汇集了相关代码实验、技术取舍和协作方案；实验结果与管理示例分别标注，不代替任职经历。</p>
              <div className="mt-6 flex flex-wrap gap-2">
                <a href="#profile-cases" className="inline-flex items-center gap-2 rounded-lg bg-cyan-300 px-4 py-2.5 text-xs font-semibold text-[#061018] transition hover:bg-cyan-200">查看代表案例 <ArrowRight className="size-3.5" /></a>
                <a href="#demo" className="nav-link inline-flex">运行全链路演练 <Play className="size-3" /></a>
                <button type="button" onClick={copyIntroduction} className="nav-link inline-flex">{introCopied ? <Check className="size-3 text-emerald-300" /> : <Braces className="size-3" />}{introCopied ? '项目介绍已复制' : '复制项目介绍'}</button>
              </div>
            </div>

            <aside className="rounded-xl border border-white/8 bg-black/15 p-4 sm:p-5">
              <p className="panel-kicker">我正在寻找的机会</p>
              <h2 className="mt-2 text-base font-semibold text-white">既能承担核心技术，也能推动团队和业务结果</h2>
              <p className="mt-2 text-[11px] leading-5 text-slate-500">以下是我希望重点沟通的岗位与业务方向。如果你的团队正在解决类似问题，可以通过 GitHub 与我联系。</p>
              <div className="mt-4 space-y-2">
                <ProfileFact label="目标岗位" value="技术负责人 · 研发负责人 · 金融系统架构师" />
                <ProfileFact label="业务方向" value="金融科技 · 支付 · 交易 · 清结算 · 数字资产基础设施" />
                <ProfileFact label="核心价值" value="交易可靠性 + 性能/异构计算判断 + 团队与业务结果" />
                <ProfileFact label="验证方式" value="先看业务结果，再继续核对代码、数据、测试和治理证据" />
              </div>
              <a href="https://github.com/soldierking04d" target="_blank" rel="noreferrer" className="mt-4 flex items-center justify-between rounded-lg border border-cyan-300/15 bg-cyan-300/[0.05] px-3 py-3 text-xs text-cyan-300 transition hover:bg-cyan-300/[0.09] hover:text-cyan-200"><span>查看我的 GitHub 并联系我</span><ExternalLink className="size-3.5" /></a>
            </aside>
          </div>

          <div className="grid border-t border-white/7 sm:grid-cols-2 xl:grid-cols-5">
            <ProfileProof value="17 → 1" label="重复结算" detail="17 次投递只产生 1 次资金效果" />
            <ProfileProof value="60 = 60" label="成交确定性" detail="成交笔数与唯一序列完全一致" />
            <ProfileProof value="54" label="AI 受控评测" detail="3 Agent、多轮、隐藏评分与安全否决" />
            <ProfileProof value="5" label="治理台账" detail="服务、风险、指标、雷达、审计联动" />
            <ProfileProof value="CI" label="构建与检查" detail="结果以对应提交的运行记录为准" />
          </div>
        </div>
</KnowledgeChapter>

        <KnowledgeChapter number="链上" title="区块链与数字资产" description="充值提现、最终性、Reorg、Nonce 与链上链下对账">
<section id="blockchain" className="mt-5 scroll-mt-24 overflow-hidden rounded-2xl border border-violet-300/12 bg-[linear-gradient(145deg,rgba(20,19,46,.72),rgba(7,16,25,.98)_48%,rgba(10,30,38,.88))]">
          <div className="grid gap-6 border-b border-white/7 p-5 sm:p-7 xl:grid-cols-[1.25fr_.75fr] xl:p-8">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="border border-violet-300/20 bg-violet-300/10 text-violet-200">BLOCKCHAIN · DIGITAL ASSET RELIABILITY</Badge>
                <Badge className="border border-amber-300/15 bg-amber-300/[0.07] text-amber-200">确定性状态机已验证 · 主网接入未声明</Badge>
              </div>
              <h2 className="mt-4 max-w-5xl text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">区块链不是换个数据库：我关注链上最终性与链下资金正确性的交界</h2>
              <p className="mt-3 max-w-5xl text-sm leading-7 text-slate-400">数字资产系统最难的不是调用一次 RPC，而是充值遇到 Reorg 不能重复入账、提现超时不能重复签名、旧协调者不能抢占 Nonce 或 UTXO、链上事实与内部账必须持续对平。这里把 FinCore 已验证的可靠性机制映射到这些真实问题，同时明确哪些链专项能力仍要用测试网和安全评审补证。</p>
            </div>
            <aside className="rounded-xl border border-violet-300/10 bg-black/15 p-4">
              <p className="panel-kicker text-violet-200">已验证能力与集成边界</p>
              <div className="mt-3 space-y-2">
                <BlockchainCheck state="已验证" text="幂等、平衡账本、状态机、Fencing 与对账机制" />
                <BlockchainCheck state="已验证" text="充值/提现、Reorg、Nonce 围栏与替换交易状态机" />
                <BlockchainCheck state="待验证" text="真实节点、UTXO、测试网、HSM/MPC 和安全控制" planned />
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/blockchain-digital-asset-reliability.md" target="_blank" rel="noreferrer" className="mt-4 flex items-center justify-between rounded-lg border border-violet-300/15 bg-violet-300/[0.05] px-3 py-3 text-xs text-violet-200 transition hover:bg-violet-300/[0.09]">阅读完整架构与验收路线 <ExternalLink className="size-3.5" /></a>
            </aside>
          </div>

          <div className="grid border-b border-white/7 sm:grid-cols-2 xl:grid-cols-4">
            <ProfileProof value="5" label="可迁移机制" detail="Inbox、Outbox、账本、Fencing、对账" />
            <ProfileProof value="2" label="链模型" detail="EVM 账户/Nonce 与 Bitcoin UTXO" />
            <ProfileProof value="2" label="状态机自动测试" detail="Reorg 调整、Nonce 围栏、未知与替换" />
            <ProfileProof value="0" label="应用持有私钥" detail="目标边界：密钥只在 HSM/MPC/托管签名域" />
          </div>

          <div className="p-5 sm:p-7 xl:p-8">
            <div><p className="panel-kicker">RELIABILITY PRIMITIVES</p><h3 className="mt-2 text-lg font-semibold text-white">现有项目机制如何迁移到数字资产场景</h3><p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">不是从零重写一套“链系统”，而是先复用已经有测试证据的金融可靠性原语，再补齐链特有语义。</p></div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-5">
              <BlockchainMapping from="Inbox 幂等" to="链事件唯一键" detail="chainId + txHash + logIndex / txid + vout" />
              <BlockchainMapping from="Outbox" to="广播意图" detail="超时先查询，避免重复签名或重复提现" />
              <BlockchainMapping from="Epoch Fencing" to="协调者隔离" detail="旧 Worker 不能继续分配 Nonce 或 UTXO" />
              <BlockchainMapping from="平衡账本" to="数字资产内部账" detail="充值、冻结、提现和手续费都有不可变分录" />
              <BlockchainMapping from="对账修复" to="链上链下收敛" detail="只自动修派生投影，资产调整必须授权" />
            </div>

            <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              <BlockchainTopic icon={GitCompareArrows} title="充值确认与 Reorg" status="状态机已验证" description="按事件唯一键和确认数推进；已入账后发生重组，不删除历史流水，而是进入 ADJUSTMENT_REQUIRED 并保留因果链。" tags={['DETECTED → CREDITED', 'REORG', 'adjustment']} />
              <BlockchainTopic icon={Network} title="提现幂等与 Nonce / UTXO" status="EVM 语义已验证" description="提现请求是端到端幂等键；UNKNOWN、Nonce Epoch、广播和替换分别留痕。Bitcoin UTXO 仍属于下一阶段。" tags={['unknown result', 'replacement', 'epoch']} />
              <BlockchainTopic icon={ShieldCheck} title="私钥与签名边界" status="安全目标" description="业务应用和数据库不接触原始私钥；签名前校验网络、资产、地址、金额和费用，规划 HSM/MPC、冷热分层与双人审批。" tags={['HSM / MPC', 'hot / cold', 'dual approval']} />
              <BlockchainTopic icon={Database} title="链上 / 链下四方对账" status="机制可迁移" description="对齐规范链、钱包库存、内部账与客户投影，识别重组、Nonce 空洞、UTXO 冲突和卡住提现并安全收敛。" tags={['MISSING', 'REORGED', 'NONCE_GAP']} />
            </div>

            <div className="mt-5 grid gap-3 lg:grid-cols-2">
              <article className="rounded-xl border border-emerald-300/10 bg-emerald-300/[0.035] p-4 sm:p-5">
                <p className="panel-kicker text-emerald-300">EVIDENCE AVAILABLE · 已有证据</p>
                <h3 className="mt-2 text-base font-semibold text-white">通用资金正确性底座已经可以运行和验证</h3>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {['重复事件只产生一次资金效果', '借贷账本不可变且始终平衡', '旧 Epoch 在资金事务内被拒绝', '漏数、错值和幽灵投影最终 CLEAN'].map((item) => <div key={item} className="flex items-start gap-2 rounded-lg border border-white/6 bg-black/10 p-2.5 text-[10px] leading-5 text-slate-400"><Check className="mt-1 size-3 shrink-0 text-emerald-300" />{item}</div>)}
                </div>
              </article>
              <article className="rounded-xl border border-amber-300/10 bg-amber-300/[0.035] p-4 sm:p-5">
                <p className="panel-kicker text-amber-200">NEXT VALIDATION · 下一步补证</p>
                <h3 className="mt-2 text-base font-semibold text-white">链专项能力必须经过测试网和独立安全验证</h3>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {['EVM / Bitcoin 索引器与重组回放', '多 RPC 分歧与确认策略实验', 'Nonce / UTXO 竞争和交易替换', 'HSM / MPC 签名与密钥生命周期'].map((item) => <div key={item} className="flex items-start gap-2 rounded-lg border border-white/6 bg-black/10 p-2.5 text-[10px] leading-5 text-slate-400"><TimerReset className="mt-1 size-3 shrink-0 text-amber-200" />{item}</div>)}
                </div>
              </article>
            </div>
          </div>
        </section>
</KnowledgeChapter>
      </section>

        <KnowledgeChapter number="行业" title="交易行业的真实问题" description="24 小时市场、流量洪峰与大规模撤单">
<IndustryCases />
</KnowledgeChapter>

        <KnowledgeChapter number="扩展" title="交易所九域能力" description="行情、订单、安全、市场监察、费用与恢复">
<ExchangeCoverageLab />
</KnowledgeChapter>

        <KnowledgeChapter number="运行" title="运行演示与实时监控" description="真实运行和教学回放分开，观察市场冲击、系统负载与恢复">
      <section id="demo" className="mx-auto max-w-[1680px] scroll-mt-20 px-4 py-5 sm:px-6 lg:px-8">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <Button onClick={() => { reset(); setMode('live'); }} variant={mode === 'live' ? 'default' : 'outline'}>真实运行与监控</Button>
          <Button onClick={() => { reset(); setMode('replay'); }} variant={mode === 'replay' ? 'default' : 'outline'}>场景回放 · 教学样本</Button>
          <span className="text-sm text-slate-400">两类数据独立展示，缺数不会自动补成成功。</span>
        </div>
        {mode === 'live' ? <LiveRunPanel /> : <>
        <p className="mb-4 rounded-lg border border-amber-300/20 bg-amber-300/5 p-3 text-sm leading-6 text-amber-200">场景回放：以下曲线、时间轴、检查勾选和样本结果均用于讲解，不是本次服务器实测。请切换“真实运行与监控”取得新报告。</p>
        <div className="mb-4 grid gap-4 xl:grid-cols-[1fr_auto] xl:items-end">
          <div>
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <Badge className="border border-cyan-300/20 bg-cyan-300/10 text-cyan-300">MARKET CRASH DAY</Badge>
              <Badge className={recovered ? 'border border-emerald-300/20 bg-emerald-300/10 text-emerald-300' : incident ? 'border border-rose-300/20 bg-rose-300/10 text-rose-300' : 'border border-white/10 bg-white/5 text-slate-400'}><span className={`size-1.5 rounded-full ${recovered ? 'bg-emerald-300' : incident ? 'animate-pulse bg-rose-300' : 'bg-slate-500'}`} />{recovered ? 'RECOVERED' : incident ? 'P1 INCIDENT' : 'READY'}</Badge>
              <span className="font-mono text-[10px] text-slate-600">RUN {evidence.runId}</span>
            </div>
            <h2 className="text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">市场冲击、系统负载与恢复时间轴</h2>
            <p className="mt-2 max-w-5xl text-sm leading-6 text-slate-400">价格跌穿三档深度时，观察单量与 QPS 如何抬升，CPU、延迟和消息积压如何响应，以及幂等、接管、对账修复如何让所有指标最终收敛。</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {phase > 0 && <><Button variant="outline" size="lg" onClick={() => setRunning((value) => !value)} disabled={recovered} className="h-10 border-white/10 bg-white/5 text-slate-200 hover:bg-white/10">{running ? <Pause /> : <Play />} {running ? '暂停' : '继续'}</Button><Button variant="outline" size="lg" onClick={reset} className="h-10 border-white/10 bg-white/5 text-slate-200 hover:bg-white/10"><RotateCcw /> 重置</Button></>}
            <Button size="lg" onClick={startReplay} disabled={running} className="h-10 bg-cyan-300 px-4 text-[#071019] hover:bg-cyan-200 disabled:opacity-60"><Zap />{phase > 0 ? '重新播放样本' : '播放场景回放'}</Button>
          </div>
        </div>

        <div className="mb-4 overflow-hidden rounded-xl border border-white/8 bg-[#0a151f]">
          <div className="h-1 bg-white/5"><div className="h-full bg-gradient-to-r from-cyan-300 via-amber-300 to-emerald-300 transition-all duration-500" style={{ width: `${progress}%` }} /></div>
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
            <div className="flex min-w-0 items-center gap-3"><span className="shrink-0 font-mono text-xs text-cyan-300">{phases[phase].time}</span><span className="text-sm font-medium text-slate-100">{phases[phase].title}</span><span className="hidden text-xs text-slate-500 md:inline">{phases[phase].business}</span></div>
            <div className="flex items-center gap-3 text-[10px]"><span className="data-source verified"><BadgeCheck className="size-3" /> 历史样本</span><span className="data-source replay"><BarChart3 className="size-3" /> 场景遥测曲线</span><span className="font-mono text-slate-600">{phase}/{LAST_PHASE}</span></div>
          </div>
        </div>

        <section className="mb-4 grid grid-cols-2 gap-2 md:grid-cols-3 xl:grid-cols-6">
          <KpiCard icon={TrendingDown} label="价格指数" value={current.price.toFixed(2)} unit="USDT" delta={phase === 0 ? '基准价' : `${(current.price - 100).toFixed(2)}%`} tone="cyan" source="回放遥测" />
          <KpiCard icon={BarChart3} label="累计订单" value={String(current.totalOrders)} unit="笔" delta={`${current.orderRate} orders/s`} tone="amber" source="60 Maker + 12 Taker" />
          <KpiCard icon={Network} label="API QPS" value={current.qps.toLocaleString()} unit="req/s" delta={metricDelta(current.qps, previous.qps)} tone="cyan" source="回放遥测" />
          <KpiCard icon={Activity} label="撮合吞吐" value={burstOccurred ? String(evidence.observedTradesPerSecond) : String(current.matchTps)} unit="trade/s" delta={burstOccurred ? '样本吞吐' : metricDelta(current.matchTps, previous.matchTps)} tone="violet" source={burstOccurred ? '历史样本' : '回放遥测'} />
          <KpiCard icon={TimerReset} label="P95 延迟" value={String(current.p95)} unit="ms" delta={metricDelta(current.p95, previous.p95)} tone="rose" source="回放遥测" />
          <KpiCard icon={Gauge} label="系统压力" value={current.cpu >= 70 ? 'HIGH' : current.cpu >= 45 ? 'ELEVATED' : 'NORMAL'} unit="" delta={`CPU ${current.cpu}% · Heap ${current.heap}%`} tone={current.cpu >= 70 ? 'rose' : recovered ? 'green' : 'cyan'} source="回放遥测" />
        </section>

        <div className="grid gap-4 xl:grid-cols-2">
          <TelemetryPanel kicker="MARKET / ORDER FLOW" title="价格与订单洪峰" icon={TrendingDown} current={`${current.price.toFixed(2)} USDT`} note="价格轴与订单/秒同阶段推进">
            <DeferredReplayChart kind="market" data={chartData} height={250} />
          </TelemetryPanel>

          <TelemetryPanel kicker="TRAFFIC / LATENCY" title="请求、撮合与响应延迟" icon={Gauge} current={`${current.qps.toLocaleString()} QPS`} note={`撮合峰值 ${evidence.observedTradesPerSecond} trade/s 为历史样本`}>
            <DeferredReplayChart kind="traffic" data={chartData} height={250} />
          </TelemetryPanel>

          <TelemetryPanel kicker="JVM / HOST" title="应用与系统资源" icon={Cpu} current={`CPU ${current.cpu}%`} note={`内存 ${current.memory}% · JVM Heap ${current.heap}%`}>
            <DeferredReplayChart kind="runtime" data={chartData} height={230} />
          </TelemetryPanel>

          <TelemetryPanel kicker="DELIVERY / STORAGE" title="消息积压与数据库压力" icon={Database} current={`${current.kafkaLag} lag`} note={`DB ${current.dbActive}/24 · Outbox ${current.outbox}`}>
            <DeferredReplayChart kind="pipeline" data={chartData} height={230} />
          </TelemetryPanel>
        </div>

        <div className="mt-4 grid gap-4 2xl:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-4">
            <section className="ops-panel scan-grid">
              <div className="panel-heading"><div><p className="panel-kicker">SYSTEM FLOW / LIVE STATE</p><h2>指标变化对应哪一个业务环节</h2></div><Badge variant="outline" className="border-white/10 font-mono text-slate-400">{phases[phase].technical}</Badge></div>
              <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
                <SystemNode icon={Network} label="订单入口" metric={`${current.qps} QPS`} state={phase >= 1 ? 'done' : 'idle'} /><SystemNode icon={Activity} label="撮合引擎" metric={`${burstOccurred ? evidence.tradeCount : 0} trades`} state={phase >= 2 ? 'done' : phase === 1 ? 'active' : 'idle'} /><SystemNode icon={Radio} label="Outbox / Kafka" metric={`${current.kafkaLag} lag`} state={phase >= 6 ? 'done' : phase >= 2 ? 'active' : 'idle'} /><SystemNode icon={ServerCog} label="结算 Worker" metric={phase >= 4 ? 'Epoch 2' : 'Epoch 1'} state={phase >= 5 ? 'done' : phase === 4 ? 'active' : 'idle'} /><SystemNode icon={Landmark} label="资金账本" metric={`${burstOccurred && phase >= 5 ? evidence.ledgerTransactions : 0} tx`} state={phase >= 6 ? 'done' : phase === 5 ? 'active' : 'idle'} /><SystemNode icon={GitCompareArrows} label="对账修复" metric={`${current.reconDiffs} diffs`} state={recovered ? 'done' : phase >= 6 ? 'active' : 'idle'} />
              </div>
            </section>

            <div className="grid gap-4 lg:grid-cols-3">
              <section className="ops-panel"><SmallHeading kicker="ORDER BOOK" title="三档深度与成交结果" /><div className="mt-4 grid grid-cols-3 gap-2">{[{ price: 100, qty: 20 }, { price: 99, qty: 20 }, { price: 98, qty: 20 }].map((level, index) => <div key={level.price} className={`rounded-lg border p-3 text-center transition ${burstOccurred ? 'border-rose-300/12 bg-rose-300/[0.04]' : 'border-emerald-300/10 bg-emerald-300/[0.04]'}`}><p className={`font-mono text-sm ${burstOccurred ? 'text-slate-600 line-through' : 'text-emerald-300'}`}>{level.price}.00</p><p className="mt-1 text-[10px] text-slate-600">{burstOccurred ? 0 : level.qty} / {level.qty} 张</p>{burstOccurred && <p className="mt-1 font-mono text-[9px] text-rose-300">FILLED T+0{index + 1}ms</p>}</div>)}</div><div className="mt-3 grid grid-cols-3 gap-2 text-center"><MiniMetric label="唯一成交" value={burstOccurred ? evidence.uniqueTradeSequences : 0} good={burstOccurred} /><MiniMetric label="拒绝订单" value={current.rejects} warn={current.rejects > 0} /><MiniMetric label="撮合耗时" value={burstOccurred ? `${evidence.matchingElapsedMs}ms` : '—'} /></div></section>

              <section className="ops-panel"><SmallHeading kicker="FENCING / IDEMPOTENCY" title="接管与重复消息控制" /><div className="mt-4 space-y-2"><WorkerRow name="settlement-worker-a" epoch="1" status={phase >= 4 ? 'FENCED' : 'ACTIVE'} state={phase >= 4 ? 'bad' : 'idle'} /><WorkerRow name="settlement-worker-b" epoch="2" status={phase >= 4 ? 'OWNER' : 'STANDBY'} state={phase >= 4 ? 'good' : 'idle'} /></div><div className="mt-3 rounded-lg border border-white/6 bg-black/10 p-3"><div className="flex items-center justify-between text-xs"><span className="text-slate-500">结算消息投递</span><span className="font-mono text-amber-300">{duplicateOccurred ? `${evidence.duplicateSettlementDeliveries}x` : burstOccurred && phase >= 5 ? '1x' : '0x'}</span></div><div className="mt-2 flex items-center justify-between text-xs"><span className="text-slate-500">实际资金效果</span><span className={burstOccurred && phase >= 5 ? 'font-mono text-emerald-300' : 'font-mono text-slate-600'}>{burstOccurred && phase >= 5 ? '1x' : '—'}</span></div></div></section>

              <section className={`ops-panel ${recovered ? 'success-glow' : ''}`}><SmallHeading kicker="RECONCILIATION" title="差异发现与最终收敛" /><div className="mt-4 grid grid-cols-3 gap-2 text-center"><DiffPill label="MISSING" value={syncOccurred && phase === 6 ? 1 : 0} /><DiffPill label="MISMATCH" value={syncOccurred && phase === 6 ? 1 : 0} /><DiffPill label="EXTRA" value={syncOccurred && phase === 6 ? 1 : 0} /></div><div className="mt-3 flex items-center justify-between rounded-lg border border-white/6 bg-black/10 px-3 py-2.5 text-xs"><span className="text-slate-500">最终结论</span><span className={recovered ? 'font-mono text-emerald-300' : incident ? 'font-mono text-amber-300' : 'font-mono text-slate-600'}>{recovered ? 'CLEAN' : syncOccurred ? 'REPAIRING' : phase >= 6 ? 'NO DIFF' : 'WAITING'}</span></div><p className="mt-3 text-[11px] leading-5 text-slate-600">{faults.sync && phase >= 7 ? `${evidence.repairedProjections} 个投影已重建，${evidence.quarantinedProjections} 个幽灵成交已隔离；权威成交与账本未修改。` : faults.sync ? '对账以权威成交为基准，只修复可重建的查询投影。' : '同步异常已关闭，本轮对账没有需要修复或隔离的投影。'}</p></section>
            </div>

            <section className="grid gap-3 rounded-2xl border border-white/8 bg-[#0a151f] p-4 sm:grid-cols-2 lg:grid-cols-4"><Proof icon={Activity} label="唯一成交" value={burstOccurred ? `${evidence.tradeCount} 笔` : '—'} note={faults.burst ? 'trade_sequence 无重复' : '本轮未注入撮合洪峰'} verified={burstOccurred} /><Proof icon={CircleDollarSign} label="资金账本" value={burstOccurred && phase >= 5 ? `${evidence.ledgerTransactions} 笔` : '—'} note="借贷严格平衡" verified={burstOccurred && phase >= 5} /><Proof icon={ShieldCheck} label="权威事实" value={phase >= 7 ? '未修改' : '—'} note="修复仅作用于派生投影" verified={phase >= 7} /><Proof icon={TimerReset} label="样本端到端" value={recovered ? `${evidence.endToEndElapsedMs} ms` : '—'} note="正确性实验结果" verified={recovered} /></section>
          </div>

          <aside className="space-y-4">
            <section className="ops-panel"><div className="panel-heading"><div><p className="panel-kicker">INCIDENT TIMELINE</p><h2>点击已发生阶段可回看</h2></div><span className="font-mono text-xs text-slate-600">{progress}%</span></div><div className="mt-4 max-h-[410px] space-y-1 overflow-auto pr-1">{phases.map((item, index) => <button key={item.time} type="button" disabled={index > maxPhase} onClick={() => { setRunning(false); setPhase(index); }} className={`timeline-row w-full text-left ${index === phase ? 'timeline-active' : index < phase ? 'timeline-done' : ''}`}><span className="timeline-dot">{index < phase || (recovered && index === phase) ? <Check className="size-3" /> : index === phase ? <span className="size-1.5 rounded-full bg-current" /> : null}</span><span className="min-w-0 flex-1"><span className="flex items-center gap-2"><span className="font-mono text-[10px] text-slate-600">{item.time}</span><strong className="text-xs font-medium text-slate-300">{item.title}</strong></span><span className="mt-0.5 block truncate text-[10px] text-slate-600">{item.technical}</span></span><span className="font-mono text-[9px] text-slate-700">{scenarioTelemetry[index].qps}</span></button>)}</div></section>

            <section className="ops-panel"><h2 className="text-sm text-amber-200">回放参数 · 不修改服务器</h2><FaultSwitch label="大流量撮合" detail="价格 / 单量 / QPS 教学联动" checked={faults.burst} disabled={running} onChange={(checked) => setFaults((value) => ({ ...value, burst: checked }))} /><FaultSwitch label="重复结算消息" detail="重复投递回放" checked={faults.duplicate} disabled={running} onChange={(checked) => setFaults((value) => ({ ...value, duplicate: checked }))} /><FaultSwitch label="同步异常" detail="差异与修复回放" checked={faults.sync} disabled={running} onChange={(checked) => setFaults((value) => ({ ...value, sync: checked }))} /></section>

            <section className="ops-panel"><div className="panel-heading"><div><p className="panel-kicker">BUSINESS CHECKS</p><h2>回放中的检查步骤</h2></div><BadgeCheck className="size-4 text-slate-600" /></div><div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1">{checks.map(([label, done]) => <div key={String(label)} className="flex items-center gap-2 py-1.5 text-[11px]"><span className={`grid size-4 place-items-center rounded-full ${done ? 'bg-emerald-300/12 text-emerald-300' : 'bg-white/5 text-slate-700'}`}>{done ? <Check className="size-2.5" /> : <span className="size-1 rounded-full bg-current" />}</span><span className={done ? 'text-slate-300' : 'text-slate-600'}>{label}</span></div>)}</div><div className="mt-3 border-t border-white/6 pt-3"><div className="flex items-end justify-between"><div><p className="text-[10px] text-slate-600">最终业务状态</p><p className={`mt-1 font-mono text-xl font-semibold ${recovered ? 'text-emerald-300' : incident ? 'text-amber-300' : 'text-slate-600'}`}>{recovered ? evidence.finalStatus : incident ? 'CONTAINING' : 'READY'}</p></div><span className={recovered ? 'font-mono text-emerald-300' : 'font-mono text-slate-500'}>{checks.filter(([, done]) => done).length}/10 PASS</span></div></div></section>
          </aside>
        </div>

        <section className="mt-4 grid gap-3 rounded-xl border border-white/8 bg-[#09131c] p-4 lg:grid-cols-[auto_1fr_1fr] lg:items-center"><div className="flex items-center gap-2 text-xs font-medium text-slate-200"><HardDrive className="size-4 text-cyan-300" /> 数据口径</div><p className="text-[11px] leading-5 text-slate-500"><span className="mr-2 font-mono text-emerald-300">历史样本</span>Run {evidence.runId} 的 {evidence.tradeCount} 成交、{evidence.observedTradesPerSecond} trade/s、{evidence.duplicateSettlementDeliveries} 次重复投递、{evidence.ledgerTransactions} 笔账本事务、{evidence.repairedProjections} 修复 / {evidence.quarantinedProjections} 隔离、{evidence.endToEndElapsedMs}ms 端到端结果。</p><p className="text-[11px] leading-5 text-slate-500"><span className="mr-2 font-mono text-amber-300">场景遥测</span>价格、QPS、P95、CPU、内存、JVM Heap、Kafka Lag、Outbox 与连接池是用于解释因果联动的确定性回放曲线，不冒充生产监控采样。</p></section>

        </>}
        </section>
      </KnowledgeChapter>
      <section className="knowledge-library mx-auto max-w-[1680px] px-4 sm:px-6 lg:px-8">
        <KnowledgeChapter number="架构" title="系统架构与完整交易链路" description="总体架构、服务拓扑、领域模型和核心时序图">
<section id="project" className="chapter-section scroll-mt-20">
          <ChapterHeading
            number="01"
            eyebrow="PROJECT EXPLAINER"
            title="这个项目到底解决什么问题？"
            description="FinCore Reliability Lab 将用户与 KYC、盘前风控、交易账户、参考行情、有界下单和撮合接入资金预占、撤单释放、Kafka 交割与账本对账。固定实验使用模拟资金；完整合约强平、外部身份和行情接入、持续容量认证仍是后续边界。"
          />

          <div className="mt-7 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <ProjectPillar icon={Users} index="01" title="交易从用户资格开始" description="用户、KYC、交易权限、账户、额度和参考行情必须先给出明确结果，不能把所有问题都推给撮合。" tags={['ACTIVE + VERIFIED', '盘前决定', '失败关闭']} />
            <ProjectPillar icon={CircleDollarSign} index="02" title="定义不能错的业务结果" description="同一业务请求只能产生一次资金效果；借方合计必须等于贷方合计；权威成交和历史账本不可被修复任务改写。" tags={['唯一资金效果', '借贷平衡', '权威事实不可变']} />
            <ProjectPillar icon={ShieldCheck} index="03" title="把保护机制放进事务边界" description="幂等键、数据库唯一约束、用户风控行锁、CAS 状态机、Outbox、Inbox 与 Epoch Fencing 共同限制并发和重试。" tags={['PostgreSQL 事务', '风控行锁', 'Epoch Fencing']} />
            <ProjectPillar icon={BadgeCheck} index="04" title="用故障实验自动证明" description="项目运行 KYC/行情拒绝、冲突重放、重复消息、Worker 接管、漏数、错值和幽灵成交等复合场景。" tags={['JUnit', 'Testcontainers', '自动对账']} />
          </div>

          <div className="mt-4 flex flex-wrap gap-2 rounded-xl border border-white/7 bg-black/10 p-3">
            {['Java 21', 'Spring Boot 3.5.16', 'MyBatis Starter 3.0.5', 'MyBatis 3.5.19', 'PostgreSQL 16', 'Kafka KRaft', 'Micrometer', 'Prometheus', 'Grafana', 'JUnit 5', 'Testcontainers', 'Docker Compose'].map((item) => <span key={item} className="tech-chip">{item}</span>)}
          </div>

          <section id="system-architecture" className="explain-panel mt-4 scroll-mt-24">
            <div className="flex flex-col gap-4 border-b border-white/7 pb-5 xl:flex-row xl:items-end xl:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2"><Badge className="border border-cyan-300/15 bg-cyan-300/[0.06] text-cyan-300">SYSTEM ARCHITECTURE</Badge><span className="font-mono text-[8px] text-slate-600">TRAFFIC · MARKET · TRADE · MONEY · RECOVERY</span></div>
                <h3 className="mt-3 text-xl font-semibold tracking-[-0.025em] text-white">先看整体：五条通道协同，而不是一条超长同步调用链</h3>
                <p className="mt-2 max-w-5xl text-xs leading-6 text-slate-500">用户资格和盘前决定需要同步给出明确结果；高频行情独立摄入并形成可信快照；撮合只接收已经批准的命令；资金变化通过可靠事件异步推进；观测与对账从权威事实反向证明结果。拆开后，行情洪峰、订单洪峰和结算积压不会互相拖垮。</p>
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/resilient-system-architecture.md" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">阅读完整架构说明 <ExternalLink className="size-3" /></a>
            </div>

            <div className="mt-5 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
              <ResilienceGoal icon={Gauge} title="抗订单洪峰" target="过载有界" detail="入口限速、4 × 256 Lane、队满 429；不无限创建线程，不让排队耗尽内存。" />
              <ResilienceGoal icon={TrendingDown} title="抗行情剧烈波动" target="不确定即停" detail="行情时间单调、30 秒新鲜度、价格笼子、无保护市价单拒绝，异常按标的隔离。" />
              <ResilienceGoal icon={CircleDollarSign} title="抗重复与接管" target="资金只生效一次" detail="Outbox、Inbox、业务唯一键、账户有序锁与 Epoch Fencing 共同守住账务。" />
              <ResilienceGoal icon={Workflow} title="快速扩展业务" target="边界内替换" detail="按领域拆 Mapper、Adapter 和版本化事件；新行情源、新规则、新消费者不改核心账本。" />
            </div>

            <article className="mt-5 overflow-hidden rounded-2xl border border-white/8 bg-[#060e16]">
              <div className="flex flex-col gap-3 border-b border-white/7 px-4 py-4 sm:px-5 lg:flex-row lg:items-center lg:justify-between">
                <div><p className="panel-kicker text-cyan-300">OVERALL ARCHITECTURE · 总架构图</p><h4 className="mt-2 text-base font-semibold text-white">从公网请求到最终对账的完整系统边界</h4></div>
                <div className="flex flex-wrap gap-2 font-mono text-[8px]"><span className="rounded-full border border-emerald-300/15 bg-emerald-300/[0.05] px-2 py-1 text-emerald-300">● 当前已落地</span><span className="rounded-full border border-amber-300/15 bg-amber-300/[0.05] px-2 py-1 text-amber-200">○ 生产演进目标</span></div>
              </div>
              <SystemArchitectureDiagram />
              <div className="grid border-t border-white/7 sm:grid-cols-2 xl:grid-cols-4">
                <ArchitecturePressure label="入口压力" response="限速 + 有界队列" result="内存和尾延迟有上限" />
                <ArchitecturePressure label="行情不确定" response="新鲜度 + 价格笼子" result="停止新增风险" />
                <ArchitecturePressure label="下游变慢" response="Kafka 削峰 + Lag 告警" result="成交事实不丢失" />
                <ArchitecturePressure label="节点接管" response="Lease + Epoch" result="旧节点不能写钱" />
              </div>
            </article>

            <article id="global-service-topology" className="mt-5 overflow-hidden rounded-2xl border border-white/8 bg-[#060e16] scroll-mt-24">
              <div className="flex flex-col gap-3 border-b border-white/7 px-4 py-4 sm:px-5 lg:flex-row lg:items-end lg:justify-between">
                <div><p className="panel-kicker text-violet-300">GLOBAL SERVICE TOPOLOGY · 全局服务拓扑</p><h4 className="mt-2 text-base font-semibold text-white">请求落到哪些实例，事件怎样跨服务，数据和监控部署在哪里</h4><p className="mt-2 max-w-5xl text-xs leading-5 text-slate-500">这张图不再讲业务步骤，而是讲运行拓扑：入口如何分流到 API 副本，热点交易对如何路由到撮合分片，成交如何进入 Kafka 与结算 Worker，PostgreSQL、对账任务和监控如何形成闭环。实线为当前可运行组件，虚线副本和集群为生产横向扩展方式。</p></div>
                <div className="flex shrink-0 flex-wrap gap-2 font-mono text-[8px]"><span className="rounded-full border border-emerald-300/15 bg-emerald-300/[0.05] px-2 py-1 text-emerald-300">CURRENT · 单机演示可运行</span><span className="rounded-full border border-amber-300/15 bg-amber-300/[0.05] px-2 py-1 text-amber-200">TARGET · 副本 / 集群 / 主备</span></div>
              </div>
              <GlobalServiceTopologyDiagram />
            </article>

            <article className="mt-5 overflow-hidden rounded-2xl border border-white/8 bg-black/10">
              <div className="border-b border-white/7 p-4 sm:p-5">
                <p className="panel-kicker text-cyan-300">MODULE ARCHITECTURE · 单模块架构图</p>
                <div className="mt-2 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between"><div><h4 className="text-base font-semibold text-white">再看单体：每个模块如何承压、降级和扩展</h4><p className="mt-2 max-w-4xl text-xs leading-5 text-slate-500">选择模块后可以看到它自己的内部路径。不是把“高并发”作为一句口号，而是分别说明并发控制、行情波动、扩容方法、失败结果和验证证据。</p></div><span className="font-mono text-[8px] text-slate-600">SELECT DOMAIN TO INSPECT</span></div>
                <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-6">
                  {(Object.entries(architectureDomains) as [ArchitectureDomainKey, ArchitectureDomain][]).map(([key, domain]) => <button key={key} type="button" onClick={() => setArchitectureTab(key)} className={`architecture-domain-tab ${architectureTab === key ? 'architecture-domain-tab-active' : ''}`}><span>{domain.index}</span><strong>{domain.title}</strong></button>)}
                </div>
              </div>

              <div className="grid xl:grid-cols-[.9fr_1.1fr]">
                <div className="border-b border-white/7 p-4 sm:p-5 xl:border-r xl:border-b-0">
                  <div className="flex flex-wrap items-center gap-2"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 font-mono text-[9px] text-cyan-300">{selectedArchitecture.index}</span><Badge className="border border-emerald-300/12 bg-emerald-300/[0.05] text-emerald-300">{selectedArchitecture.status}</Badge></div>
                  <h4 className="mt-4 text-lg font-semibold text-white">{selectedArchitecture.title}</h4>
                  <p className="mt-2 text-xs leading-6 text-slate-400">{selectedArchitecture.objective}</p>
                  <ModuleArchitectureDiagram domainKey={architectureTab} domain={selectedArchitecture} />
                  <div className="mt-4 rounded-lg border border-rose-300/12 bg-rose-300/[0.035] p-3"><p className="font-mono text-[8px] text-rose-300">FAILURE CONTRACT</p><p className="mt-2 text-[10px] leading-5 text-rose-100/60">{selectedArchitecture.failure}</p></div>
                </div>
                <div className="grid gap-3 p-4 sm:grid-cols-2 sm:p-5">
                  <ArchitectureDecision icon={Cpu} title="并发与 CPU" text={selectedArchitecture.concurrency} />
                  <ArchitectureDecision icon={TrendingDown} title="行情波动" text={selectedArchitecture.volatility} />
                  <ArchitectureDecision icon={Workflow} title="快速扩展" text={selectedArchitecture.scaling} />
                  <ArchitectureDecision icon={BadgeCheck} title="自动证据" text={selectedArchitecture.evidence} good />
                </div>
              </div>
            </article>

            <article id="service-topology-atlas" className="mt-5 overflow-hidden rounded-2xl border border-white/8 bg-black/10 scroll-mt-24">
              <div className="border-b border-white/7 p-4 sm:p-5"><p className="panel-kicker text-emerald-300">SERVICE TOPOLOGY ATLAS · 六套单服务拓扑</p><h4 className="mt-2 text-base font-semibold text-white">所有服务一次展开：入口、应用服务、适配层、权威存储、外部依赖与事件去向</h4><p className="mt-2 max-w-5xl text-xs leading-5 text-slate-500">上面的可切换图用于深入一个模块；这里把六个服务拓扑全部展开，避免选择一个模块后链路在页面上“消失”。类名与表名对应真实仓库，标记 TARGET 的依赖仍属于生产演进目标。</p></div>
              <div className="grid gap-4 p-4 xl:grid-cols-2 sm:p-5">
                {(Object.entries(architectureDomains) as [ArchitectureDomainKey, ArchitectureDomain][]).map(([key, domain]) => <ServiceTopologyCard key={key} domainKey={key} domain={domain} />)}
              </div>
            </article>

            <article id="core-sequence-diagrams" className="mt-5 overflow-hidden rounded-2xl border border-white/8 bg-[#060e16] scroll-mt-24">
              <div className="flex flex-col gap-3 border-b border-white/7 p-4 sm:p-5 lg:flex-row lg:items-end lg:justify-between"><div><p className="panel-kicker text-amber-200">CORE SEQUENCE DIAGRAMS · 核心场景时序图</p><h4 className="mt-2 text-base font-semibold text-white">从成功路径到复合故障，消息在服务之间怎样真实流动</h4><p className="mt-2 max-w-5xl text-xs leading-5 text-slate-500">六张图全部展开：青色实线是同步调用，紫色是异步消息，绿色虚线是数据库或状态核验，红色表示拒绝和故障。每张图都标出最终业务结果，便于把架构机制和自动测试对应起来。</p></div><a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/resilient-system-architecture.md#核心场景时序图" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">查看 Mermaid 文档版 <ExternalLink className="size-3" /></a></div>
              <div className="grid gap-4 p-4 xl:grid-cols-2 sm:p-5">{sequenceScenarios.map((scenario) => <SequenceScenarioCard key={scenario.index} scenario={scenario} />)}</div>
            </article>
          </section>

          <section id="full-lifecycle" className="explain-panel mt-4 scroll-mt-24">
            <div className="flex flex-col gap-4 border-b border-white/7 pb-5 xl:flex-row xl:items-end xl:justify-between">
              <div><div className="flex flex-wrap items-center gap-2"><Badge className="border border-emerald-300/15 bg-emerald-300/[0.06] text-emerald-300">资金闭环 · V8</Badge><span className="font-mono text-xs text-slate-500">USER → RISK → RESERVE → TRADE → DELIVERY</span></div><h3 className="mt-3 text-xl font-semibold tracking-[-0.025em] text-white">从下单到资产到账，逐笔核对资金去向</h3><p className="mt-2 max-w-4xl text-sm leading-6 text-slate-400">运行一次真实后台实验：通过用户与风控检查、撮合成交、挂单预占、重复撤单，再等待 Kafka Worker 完成双资产交割。只有账本和 4 个模拟资产账户都核对一致才显示成功。</p></div>
              <div className="flex flex-wrap gap-2"><button type="button" onClick={runLifecycle} disabled={lifecycleState === 'running'} className="inline-flex min-h-11 items-center gap-2 rounded-lg bg-cyan-300 px-4 py-2 text-sm font-semibold text-[#061018] transition hover:bg-cyan-200 disabled:opacity-60">{lifecycleState === 'running' ? <RefreshCw className="size-4 animate-spin" /> : <Play className="size-4" />}{lifecycleState === 'running' ? '正在运行并等待交割' : '运行资金全链路实验'}</button><a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/spot-funds-closure.md" target="_blank" rel="noreferrer" className="text-sm text-cyan-300 underline">资金闭环实现说明</a><a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/test/java/dev/fincore/SpotDeliveryKafkaIntegrationTest.java" target="_blank" rel="noreferrer" className="text-sm text-cyan-300 underline">真实 Kafka 验收代码</a></div>
            </div>

            {lifecycleMessage && <div className={`mt-4 rounded-lg border px-3 py-2.5 text-[10px] leading-5 ${lifecycleState === 'success' ? 'border-emerald-300/12 bg-emerald-300/[0.04] text-emerald-200' : (lifecycleState === 'error' || lifecycleState === 'unknown') ? 'border-rose-300/12 bg-rose-300/[0.04] text-rose-200' : 'border-cyan-300/12 bg-cyan-300/[0.04] text-cyan-200'}`}>{lifecycleMessage}</div>}

            <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
              <TradingJourneyNode index="01" icon={Users} title="用户" state="ACTIVE" guard="用户主键 + 生命周期" evidence="userId 唯一" />
              <TradingJourneyNode index="02" icon={BadgeCheck} title="KYC" state="VERIFIED" guard="未通过立即拒绝" evidence="3 个审核状态" />
              <TradingJourneyNode index="03" icon={ShieldCheck} title="风控" state="PASS / REJECT" guard="用户行锁 + 额度" evidence="10 类 reasonCode" />
              <TradingJourneyNode index="04" icon={Landmark} title="交易账户" state="AVAILABLE / HELD" guard="总额覆盖预占与在途" evidence="跨交易对共用预算" />
              <TradingJourneyNode index="05" icon={BarChart3} title="参考行情" state="FRESH ≤ 30s" guard="来源 + 观察时间" evidence="旧快照不覆盖" />
              <TradingJourneyNode index="06" icon={TimerReset} title="盘前决定" state="APPROVED" guard="clientOrderId 幂等" evidence="参数冲突拒绝" />
              <TradingJourneyNode index="07" icon={Gauge} title="有界准入" state="4 × 256" guard="同 symbol 有序" evidence="饱和返回 429" />
              <TradingJourneyNode index="08" icon={GitCompareArrows} title="撮合" state="FILLED / OPEN" guard="价格时间优先" evidence="数量守恒" />
              <TradingJourneyNode index="09" icon={Radio} title="成交事件" state="OUTBOX" guard="与成交同事务" evidence="失败可重试" />
              <TradingJourneyNode index="10" icon={CircleDollarSign} title="双资产交割" state="PENDING → SETTLED" guard="Inbox + Fencing" evidence="两种资产同事务" />
              <TradingJourneyNode index="11" icon={Database} title="不可变账本" state="DEBIT = CREDIT" guard="余额/分录同事务" evidence="历史不可改" />
              <TradingJourneyNode index="12" icon={RefreshCw} title="资金对账" state="CLEAN / FROZEN" guard="账本 + 预占双重重算" evidence="不平冻结待审核" />
            </div>

            <div className="mt-5 grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
              <article className="rounded-xl border border-cyan-300/10 bg-cyan-300/[0.025] p-4 sm:p-5">
                <div className="flex items-start justify-between gap-3"><div><p className="panel-kicker text-cyan-300">{lifecycleEvidence ? '本次后台报告' : '教学样本 · 非本次运行结果'}</p><h4 className="mt-2 text-base font-semibold text-white">一笔 {lifecycleData.symbol} 买单的盘前数据怎样联动</h4></div><Badge className="border border-emerald-300/15 bg-emerald-300/[0.06] text-emerald-300">{lifecycleData.preTradeDecision} → {lifecycleData.orderStatus}</Badge></div>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  <LifecycleData label="用户 / KYC" value={`${lifecycleData.userId} · ${lifecycleData.userStatus} · ${lifecycleData.kycStatus}`} />
                  <LifecycleData label="交易账户" value={`${lifecycleData.accountAsset} 余额 ${Number(lifecycleData.accountBalance).toLocaleString()}`} />
                  <LifecycleData label="参考行情" value={`${lifecycleData.symbol} = ${lifecycleData.referencePrice} · 实验参考价`} />
                  <LifecycleData label="委托" value={`BUY ${lifecycleData.quantity} @ ${lifecycleData.referencePrice} · 名义金额 ${lifecycleData.orderNotional}`} />
                  <LifecycleData label="风控阈值" value="单笔 10,000 · 日累计 20,000 · 偏离 20%" />
                  <LifecycleData label="最终结果" value={`1 决定 · 1 订单 · ${lifecycleData.tradeCount} 成交 · ${lifecycleData.rejectedReasonCode} 拒绝样本`} good />
                </div>
              </article>
              <article className="rounded-xl border border-amber-300/10 bg-amber-300/[0.025] p-4 sm:p-5">
                <p className="panel-kicker text-amber-200">HONEST BOUNDARY</p>
                <h4 className="mt-2 text-base font-semibold text-white">完整链路不等于虚构生产能力</h4>
                <div className="mt-4 space-y-2">
                  <LifecycleBoundary state="已落地" text="用户/KYC 状态、风控档案、交易账户、参考行情、盘前决定与受控下单" />
                  <LifecycleBoundary state="资金闭环" text="限价现货预占、部分成交、撤单释放、真实 Kafka 消费、双资产原子交割及资金对账" />
                  <LifecycleBoundary state="明确边界" text="八位价格与数量、模拟期初资金、无手续费；旧纯撮合订单不自动迁移成资金订单" />
                  <LifecycleBoundary state="待补证" text="真实身份和行情供应商、手续费/充值提现、完整合约强平、多币种风险与生产容量" planned />
                </div>
              </article>
            </div>
            {lifecycleEvidence && <SpotFundsEvidencePanel report={lifecycleEvidence} />}
            <details className="mt-5 rounded-xl border border-white/10 p-4 text-sm text-slate-300">
              <summary className="cursor-pointer text-base font-semibold text-white">代码怎样保证不多扣、不多放、两种资产一起到账？</summary>
              <div className="mt-4 space-y-4 leading-7">
                <p>下单、撮合、预占和成交转在途在同一个数据库事务内提交。所有涉及的付款账户先按 UUID 固定顺序锁定；预占失败会连同订单、成交及事件一起回滚。跨交易对不能重复使用同一份余额。</p>
                <pre className="overflow-x-auto rounded-lg bg-black/25 p-4 text-sm"><code>{`// 已持有相关账户锁；实际成交额不能超过限价预算\nchangeReservation(orderId, -budget, +actual, 0, budget - actual);\n// 预占减少、实际成交转在途，较优价格的差额回到可用\n// 撤单只释放 held；pending 必须留给交割 Worker`}</code></pre>
                <p className="text-slate-500">上方为便于理解的简化伪代码；实际 Java 全部使用 BigDecimal，不使用浮点金额。</p>
                <p>Worker 从数据库读取成交事实，在有效 Epoch 围栏内，用同一个事务完成两笔按资产平衡的账本、四个账户更新、Inbox 和交割终态。最后一步事件写入失败也会全部回滚；重放仍只产生一次资金效果。</p>
                <a className="text-cyan-300 underline" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/application/SpotDeliveryService.java" target="_blank" rel="noreferrer">查看完整 Java 交割实现</a>
              </div>
            </details>
          </section>

          <section className="explain-panel mt-4">
            <div className="flex flex-col gap-3 border-b border-white/7 pb-5 lg:flex-row lg:items-end lg:justify-between">
              <div><p className="panel-kicker">SPRING BOOT + MYBATIS ARCHITECTURE</p><h3 className="mt-2 text-xl font-semibold tracking-[-0.025em] text-white">从接入层到数据库，每一层只承担一种责任</h3></div>
              <p className="max-w-2xl text-xs leading-5 text-slate-500">Spring Boot 负责组件与事务生命周期，Application Service 守住业务不变量，MyBatis Mapper 收拢全部参数化 SQL，PostgreSQL 用唯一约束和锁提供最后防线。</p>
            </div>
            <div className="architecture-grid mt-6">
              <ArchitectureNode index="01" icon={Network} title="协议适配" code="web / messaging" detail="Controller 与 Listener 只解析协议并构造命令" guard="no SQL" />
              <ArchitectureNode index="02" icon={ServerCog} title="事务编排" code="application" detail="Service 统一开启事务、排序加锁和传播失败" guard="@Transactional" />
              <ArchitectureNode index="03" icon={ShieldCheck} title="领域规则" code="domain" detail="BigDecimal、借贷平衡与合法状态迁移" guard="pure Java" />
              <ArchitectureNode index="04" icon={Braces} title="持久化接口" code="12 MyBatis Mappers" detail="按领域收拢参数化 SQL 与 record 映射" guard="#{...} only" />
              <ArchitectureNode index="05" icon={Database} title="事实与约束" code="PostgreSQL 16" detail="唯一键、CAS、行锁和不可变历史" guard="DB is final" />
              <ArchitectureNode index="06" icon={Radio} title="可靠传播" code="Outbox → Kafka" detail="提交后投递、抢占、重试与超时回收" guard="SKIP LOCKED" last />
            </div>
          </section>

          <div className="mt-4 grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
            <section className="explain-panel">
              <p className="panel-kicker">THREE INVARIANTS</p>
              <h3 className="mt-2 text-lg font-semibold text-white">三条不能被任何故障破坏的规则</h3>
              <div className="mt-5 space-y-3">
                <InvariantRow number="I" title="成交事实唯一" description="订单原始量 = 已成交量 + 剩余量；trade_sequence 不重复；相同客户端订单重放不能再生成成交。" proof="60 trades = 60 unique sequences" />
                <InvariantRow number="II" title="资金结果平衡" description="每个 Ledger Transaction 的借方合计必须等于贷方合计；余额更新和账本分录必须一起提交或一起回滚。" proof="6 ledger tx · 0 mismatch" />
                <InvariantRow number="III" title="修复边界受控" description="查询投影可以重建，幽灵投影可以隔离；但权威成交、资金余额和历史账本不能为了让数字好看而被改写。" proof="2 rebuild · 1 quarantine" />
              </div>
            </section>

            <section className="explain-panel">
              <p className="panel-kicker">FAULT → DEFENSE → PROOF</p>
              <h3 className="mt-2 text-lg font-semibold text-white">页面数据从哪里来</h3>
              <div className="mt-5 space-y-1">
                <TraceRow event="12 路并发卖单" action="交易对锁 + 序列" result="60 唯一成交" />
                <TraceRow event="17 次结算投递" action="Inbox + 唯一键" result="1 次资金效果" />
                <TraceRow event="旧 Worker 恢复" action="Epoch 数据面校验" result="旧写入拒绝" />
                <TraceRow event="漏数 / 错值 / 幽灵" action="全外连接对账" result="1 / 1 / 1" />
                <TraceRow event="重复提交修复" action="repair idempotency" result="2 修复 / 1 隔离" />
              </div>
            </section>
          </div>
        </section>
</KnowledgeChapter>

        <KnowledgeChapter number="代码" title="代码实现与资金事务" description="沿源码核对状态机、幂等、Fencing 与不可变账本">
<section id="implementation" className="chapter-section scroll-mt-20">
          <ChapterHeading
            number="02"
            eyebrow="CODE WALKTHROUGH"
            title="从金额模型到恢复闭环，逐层读完整实现"
            description="这里按真实执行顺序拆解 14 个模块，并把用户/KYC、盘前风控、账户行情、Spring Boot 事务、MyBatis Mapper、并发准入和数据库约束放在同一条调用链里；每一层都说明输入如何流转、失败时怎样回滚或重试，以及对应哪一项自动测试。"
          />

          <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <CodeStat value="82" label="生产 Java 源码" detail="接入 / 应用 / 领域 / 基础设施分层" />
            <CodeStat value="12" label="MyBatis Mapper" detail="核心领域 SQL 全部收拢" />
            <CodeStat value="21" label="自动测试类" detail="架构门禁 + 并发 + Testcontainers" />
            <CodeStat value="JDK 21" label="运行时基线" detail="虚拟线程 + G1 / ZGC + JFR" />
          </div>

          <section className="explain-panel mt-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="panel-kicker">END-TO-END CALL CHAIN</p>
                <h3 className="mt-2 text-base font-semibold text-white">一次下单如何从用户资格变成可审计、可恢复的资金结果</h3>
              </div>
              <p className="max-w-2xl text-xs leading-5 text-slate-500">点击任一节点会打开对应真实类。先看 MyBatis 分层、用户与行情、盘前风控，再沿金额、并发准入、撮合、事件、Worker 续期、结算、补偿、Fencing、同步与修复走到最终证明。</p>
            </div>
            <div className="code-flow mt-5">
              {codeOrder.map((key, index) => {
                const item = codeSamples[key];
                return <button key={key} type="button" onClick={() => setCodeTab(key)} className={`code-flow-node ${codeTab === key ? 'code-flow-node-active' : ''}`}><span>{String(index + 1).padStart(2, '0')}</span><strong>{item.label}</strong><small>{item.stage.split(' · ')[1]}</small></button>;
              })}
            </div>
          </section>

          <div className="code-browser mt-4 grid lg:grid-cols-[285px_minmax(0,1fr)]">
            <div className="border-b border-white/7 p-3 lg:border-r lg:border-b-0">
              <p className="px-3 pb-3 font-mono text-[9px] tracking-[0.14em] text-slate-600">SELECT MODULE · 14 FILES</p>
              <div className="grid grid-cols-2 gap-1 sm:grid-cols-3 lg:grid-cols-1">
                {codeOrder.map((key, index) => {
                  const item = codeSamples[key];
                  return <button key={key} type="button" onClick={() => setCodeTab(key)} className={`code-tab ${codeTab === key ? 'code-tab-active' : ''}`}><span className="font-mono text-[9px] text-slate-600">{String(index + 1).padStart(2, '0')}</span><span><strong>{item.label}</strong><small>{item.file.split('/').pop()}</small></span><ArrowRight className="ml-auto size-3.5" /></button>;
                })}
              </div>
            </div>

            <div className="min-w-0">
              <div className="flex flex-col gap-4 border-b border-white/7 px-5 py-5 sm:flex-row sm:items-start sm:justify-between">
                <div><p className="font-mono text-[10px] text-cyan-300">{selectedCode.stage} · {selectedCode.file}</p><h3 className="mt-2 text-lg font-semibold text-white">{selectedCode.title}</h3><p className="mt-2 max-w-3xl text-xs leading-5 text-slate-500">{selectedCode.summary}</p><div className="mt-3 inline-flex rounded-md border border-amber-300/12 bg-amber-300/[0.04] px-2.5 py-1.5 font-mono text-[9px] text-amber-200/75">INVARIANT · {selectedCode.invariant}</div></div>
                <a className="inline-flex shrink-0 items-center gap-1.5 rounded-lg border border-white/8 bg-white/[0.03] px-3 py-2 text-[10px] text-slate-400 transition hover:border-cyan-300/20 hover:text-cyan-300" href={`https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/main/java/dev/fincore/${selectedCode.file}`} target="_blank" rel="noreferrer"><GitBranch className="size-3" /> 查看完整源码 <ExternalLink className="size-3" /></a>
              </div>
              <div className="grid xl:grid-cols-[minmax(0,1.3fr)_minmax(260px,.7fr)]">
                <div className="min-w-0 overflow-x-auto bg-[#060d13]"><div className="code-window-bar"><span className="bg-rose-400/70" /><span className="bg-amber-300/70" /><span className="bg-emerald-300/70" /><em>FinCore / {selectedCode.file.split('/').pop()}</em></div><pre className="code-block"><code>{selectedCode.code}</code></pre></div>
                <div className="border-t border-white/7 p-5 xl:border-t-0 xl:border-l">
                  <p className="panel-kicker">WHY IT MATTERS</p>
                  <div className="mt-4 space-y-3">{selectedCode.points.map((point, index) => <div key={point} className="flex gap-3"><span className="grid size-5 shrink-0 place-items-center rounded-full bg-cyan-300/10 font-mono text-[9px] text-cyan-300">{index + 1}</span><p className="text-[11px] leading-5 text-slate-400">{point}</p></div>)}</div>
                  <div className="mt-5 border-t border-white/7 pt-4"><p className="panel-kicker">EXECUTION FLOW</p><div className="mt-3 space-y-2">{selectedCode.flow.map((step, index) => <div key={step} className="flex items-center gap-2 text-[10px] text-slate-500"><span className="font-mono text-cyan-300/60">{String(index + 1).padStart(2, '0')}</span><span className="h-px w-3 bg-white/10" />{step}</div>)}</div></div>
                  <CodeEvidence title="失败边界" text={selectedCode.failure} tone="rose" />
                  <CodeEvidence title="对应演练数据" text={selectedCode.evidence} tone="green" />
                  <a href={`https://github.com/soldierking04d/fincore-reliability-lab/blob/main/src/test/java/dev/fincore/${selectedCode.testFile}`} target="_blank" rel="noreferrer" className="mt-3 flex items-center justify-between rounded-lg border border-white/7 bg-black/15 p-3 text-[10px] text-slate-500 transition hover:border-cyan-300/15 hover:text-cyan-300"><span><span className="block font-mono text-[8px] text-slate-700">AUTOMATED PROOF</span><strong className="mt-1 block font-normal">{selectedCode.testFile}</strong></span><ExternalLink className="size-3" /></a>
                </div>
              </div>
            </div>
          </div>

          <section className="explain-panel mt-4">
            <div className="grid gap-5 lg:grid-cols-[.75fr_1.25fr] lg:items-start">
              <div><p className="panel-kicker">RUN IT YOURSELF</p><h3 className="mt-2 text-lg font-semibold text-white">从启动到拿到证据，只需要三步</h3><p className="mt-2 text-xs leading-5 text-slate-500">Docker Compose 会启动 FinCore API、PostgreSQL、Kafka、Prometheus 和 Grafana。Lab Profile 才会开放故障注入接口。</p><a href="https://github.com/soldierking04d/fincore-reliability-lab" target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-xs text-cyan-300 hover:text-cyan-200"><GitBranch className="size-3.5" /> 打开 GitHub 项目 <ExternalLink className="size-3" /></a></div>
              <div className="grid gap-3 sm:grid-cols-3">
                <QuickStep number="01" title="启动依赖与服务" command="docker compose up --build" note="自动等待健康并准备实验环境" />
                <QuickStep number="02" title="触发复合场景" command="POST /lab/scenarios/market-crash-day" note="运行撮合、接管、重投和修复" />
                <QuickStep number="03" title="检查自动证据" command="reports/latest-scenario.json" note="每项业务检查都应为 PASS" />
              </div>
            </div>
          </section>
        </section>
</KnowledgeChapter>

        <KnowledgeChapter number="团队" title="团队建设与技术交付" description="人才梯队、产品运营协作、服务责任与风险治理">
<section id="management" className="chapter-section scroll-mt-20">
          <ChapterHeading
            number="03"
            eyebrow="STRATEGY · ENGINEERING · ORGANIZATION · BUSINESS"
            title="团队分工、交付与风险管理"
            description="围绕需求优先级、运营活动和关键岗位备份，说明谁作决定、依据是什么、结果如何检查。以下是结合 FinCore 编写的管理方案示例，不作为真实团队规模、项目业绩或公司实践记录。"
          />

          <section id="management-decisions" className="mt-6 scroll-mt-24">
            <h3 className="text-xl font-semibold">三个决策场景</h3>
            <div className="mt-4 grid gap-4 lg:grid-cols-3">{[
              { title: '需求撞期，先做哪一个？', problem: '功能上线与可靠性修复争用同一组研发人员。', decision: '先处理可能造成资金错误的缺陷；产品缩小首发范围，其他功能按业务损失和依赖排期。', verify: '记录延期范围、责任人和复查时间，下一次评审核对缺陷与交付情况。', file: '05-management-operating-system-playbook.md' },
              { title: '运营要放量，何时可以开始？', problem: '活动目标明确，但峰值假设和系统容量还没有共同口径。', decision: '运营提供流量假设，研发和测试验证目标负载；按阶段放量，预先约定暂停条件和当班决策人。', verify: '核对目标负载下的结算积压、错误率和资金结果；验证未完成时不宣称容量达标。', file: '06-end-to-end-case-study.md' },
              { title: '核心模块只有一人熟悉，怎么交付？', problem: '请假或离职会让排障、评审和发布依赖单个人。', decision: '安排主责与备份共同评审，由备份在隔离环境独立完成恢复演练；培养任务纳入排期。', verify: '检查能否独立定位问题和按预案恢复，再决定是否具备轮值条件。', file: '01-talent-pipeline-playbook.md' },
            ].map(item => <article className="explain-panel" key={item.title}><p className="text-xs text-slate-500">管理方案示例</p><h4 className="mt-2 text-lg font-semibold">{item.title}</h4><p className="mt-3 text-sm leading-6">{item.problem}</p><p className="mt-3 text-sm leading-6"><strong>决策：</strong>{item.decision}</p><p className="mt-3 text-sm leading-6"><strong>检查：</strong>{item.verify}</p><a className="nav-link mt-4 inline-flex" href={`https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/${item.file}`} target="_blank" rel="noreferrer">查看对应方案 <ExternalLink className="size-3" /></a></article>)}</div>
          </section>

          <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <LeadershipDomain icon={Target} index="01" title="战略" count="3 类职责" description="技术战略、架构治理、技术债与长期投资，说明为什么做、放弃什么、何时复查。" tags={['路线图', 'ADR', '技术债', 'Build / Buy']} href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/06-technical-strategy-architecture-governance.md" />
            <LeadershipDomain icon={ShieldCheck} index="02" title="工程" count="4 类职责" description="交付、质量、安全数据与可靠性共同治理，速度不能以资金、客户或合规风险为代价。" tags={['DORA', 'SSDF', 'SLO', 'RTO / RPO']} href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/00-technical-lead-responsibility-map.md" />
            <LeadershipDomain icon={Users} index="03" title="组织" count="3 类职责" description="从岗位规划、招聘和入职，到反馈、绩效、晋升、健康、留任与离职交接。" tags={['1 + 1 + 1', '90 天', '绩效证据', '团队健康']} href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/07-talent-lifecycle-team-health.md" />
            <LeadershipDomain icon={CircleDollarSign} index="04" title="经营" count="3 类职责" description="把产品、客户、成本、供应商与高层决策连接起来，让每项投入都能解释业务价值。" tags={['单位成本', '供应商', '客户升级', '决策请求']} href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/11-finops-vendor-management.md" />
          </div>

          <section className="explain-panel mt-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <p className="panel-kicker">RESPONSIBILITY MAP · 13 BASE + 5 CROSS-DOMAIN</p>
                <h3 className="mt-2 text-lg font-semibold text-white">负责人不必亲自完成所有工作，但必须保证每项结果有人负责</h3>
                <p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">全景手册为每类职责定义了必须回答的问题、最低证据、RACI、决策边界、月度仪表盘和成熟度。已有工程证据与仍需实测的生产化目标明确分开，不把方案写成认证。</p>
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/00-technical-lead-responsibility-map.md" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">打开职责全景 <ExternalLink className="size-3" /></a>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <ManagementProof value="13 + 5" label="职责全景" note="基础责任 + 跨域治理" />
              <ManagementProof value="18 + 18" label="双层内容" note="18 个概要 + 18 份实战手册" />
              <ManagementProof value="RACI" label="责任边界" note="最终负责 / 执行 / 协作 / 知会" />
              <ManagementProof value="L1 → L4" label="成熟度" note="靠人 → 流程 → 证据 → 可持续" />
            </div>
          </section>

          <div className="mt-4">
            <p className="panel-kicker">NEW LEADERSHIP PLAYBOOKS</p>
            <h3 className="mt-2 text-lg font-semibold text-white">管理流程与职责分工</h3>
            <p className="mt-2 text-xs leading-6 text-slate-500">每一项都分为概要与实战两层；概要快速建立共同认识，实战继续给出 FinCore 场景、模板、指标、失败模式和验收标准。</p>
            <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              <LeadershipGuide index="01" title="技术战略与架构治理" detail="年度方向、季度路线、ADR、技术债和 Build / Buy" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/06-technical-strategy-architecture-governance.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/07-technical-strategy-architecture-playbook.md" />
              <LeadershipGuide index="02" title="人才全生命周期" detail="招聘评分卡、90 天入职、绩效、晋升、健康与离职" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/07-talent-lifecycle-team-health.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/08-talent-lifecycle-performance-playbook.md" />
              <LeadershipGuide index="03" title="交付效能与质量" detail="项目组合、DORA、风险分级、发布门禁与延期诊断" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/08-delivery-quality-governance.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/09-delivery-quality-playbook.md" />
              <LeadershipGuide index="04" title="安全合规与数据" detail="威胁模型、RBAC、SBOM、开源许可/IP、数据分级和漏洞响应" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/09-security-compliance-data-governance.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/10-security-compliance-data-playbook.md" />
              <LeadershipGuide index="05" title="SLO、值班与灾备" detail="业务 SLI、错误预算、可行动告警、RTO/RPO 和恢复证明" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/10-slo-disaster-recovery.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/11-slo-disaster-recovery-playbook.md" />
              <LeadershipGuide index="06" title="FinOps 与供应商" detail="预算、AI 单位经济、可持续资源效率、供应商与退出计划" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/11-finops-vendor-management.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/12-finops-vendor-playbook.md" />
              <LeadershipGuide index="07" title="客户支持与高层沟通" detail="客户升级、事故口径、支持边界、反馈聚类和决策请求" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/12-customer-support-executive-communication.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/13-customer-support-executive-playbook.md" />
              <LeadershipGuide index="08" title="平台工程与开发者体验" detail="黄金路径、认知负荷、自助服务、护栏、逃生通道和平台产品指标" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/14-platform-engineering-developer-experience.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/15-platform-developer-experience-playbook.md" />
              <LeadershipGuide index="09" title="数据产品与指标治理" detail="权威源、口径版本、Owner/Steward、质量规则和演示数据边界" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/15-data-product-metric-governance.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/16-data-product-metric-governance-playbook.md" />
              <LeadershipGuide index="10" title="企业技术风险与审计" detail="情景风险、控制目标、证据目录、例外到期和独立验证" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/16-enterprise-technology-risk-audit.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/17-enterprise-technology-risk-audit-playbook.md" />
              <LeadershipGuide index="11" title="技术雷达与创新采用" detail="Adopt / Trial / Assess / Hold、试验门禁、退出条件和复查节奏" overview="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/17-technology-radar-innovation-adoption.md" playbook="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/18-technology-radar-innovation-adoption-playbook.md" />
            </div>
          </div>

          <section className="explain-panel mt-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <p className="panel-kicker">GOVERNANCE OPERATING SYSTEM · MACHINE-READABLE</p>
                <h3 className="mt-2 text-lg font-semibold text-white">服务、风险与指标台账示例</h3>
                <p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">所有台账都使用稳定 ID、具名 Owner、上次/下次复查日期和明确限制。CI 会检查服务依赖、风险评分、指标权威级别、技术退出条件、控制证据和跨文件引用；“已证明”必须指向仓库里真实存在的文件。</p>
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/tree/main/governance" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">打开治理数据目录 <ExternalLink className="size-3" /></a>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
              <GovernanceRegistryCard icon={Network} index="01" count="5" title="服务目录" detail="Owner、Deputy、依赖、SLO 与运行手册" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/governance/services.yaml" />
              <GovernanceRegistryCard icon={TriangleAlert} index="02" count="7" title="风险登记" detail="情景、概率×影响、处置、到期和限制" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/governance/risks.yaml" />
              <GovernanceRegistryCard icon={BarChart3} index="03" count="8" title="指标目录" detail="定义、权威源、质量规则与 demoOnly" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/governance/metrics.yaml" />
              <GovernanceRegistryCard icon={GitCompareArrows} index="04" count="11" title="技术雷达" detail="采用、试验、评估、暂停与退出条件" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/governance/technology-radar.yaml" />
              <GovernanceRegistryCard icon={BadgeCheck} index="05" count="8" title="审计证据" detail="控制目标、方法、证据、频率和限制" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/governance/audit-evidence.yaml" />
            </div>

            <div className="mt-5 grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
              <div className="rounded-xl border border-white/7 bg-black/10 p-4">
                <p className="panel-kicker">ONE TRACE · SERVICE → RISK → METRIC → TECHNOLOGY → CONTROL</p>
                <div className="mt-3 space-y-1">
                  <GovernanceTraceRow type="SERVICE" id="fincore-api" title="交易与结算服务" state="Owner + Deputy" />
                  <GovernanceTraceRow type="RISK" id="RISK-004" title="演示回放与真实指标混淆" state="12 / 25" />
                  <GovernanceTraceRow type="METRIC" id="api_qps · v1" title="网站回放 API QPS" state="demoOnly" />
                  <GovernanceTraceRow type="RADAR" id="TECH-001" title="Java 21 虚拟线程" state="ADOPT" />
                  <GovernanceTraceRow type="CONTROL" id="CTRL-DEMO-001" title="回放与真实证据可见区分" state="DEMONSTRATED" />
                </div>
              </div>
              <div className="rounded-xl border border-amber-300/10 bg-amber-300/[0.025] p-4">
                <p className="panel-kicker text-amber-300">TRUTH BOUNDARY</p>
                <h4 className="mt-2 text-sm font-medium text-white">证明过什么，也要明确还没有证明什么</h4>
                <div className="mt-4 space-y-3 text-[11px] leading-5 text-slate-500">
                  <p><span className="mr-2 font-mono text-emerald-300">DEMONSTRATED</span>当前代码、测试、报告和台账结构可以在仓库中复核。</p>
                  <p><span className="mr-2 font-mono text-amber-300">PLANNED</span>认证授权、生产灾备、供应链签名和 AI 业务用例仍需目标环境证据。</p>
                  <p><span className="mr-2 font-mono text-rose-300">NOT CERTIFIED</span>机器校验不等于监管认证、独立审计或生产容量承诺。</p>
                </div>
                <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/scripts/verify-governance.sh" target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-2 text-[10px] text-cyan-300">查看自动门禁 <ExternalLink className="size-3" /></a>
              </div>
            </div>
          </section>

          <div className="mt-8">
            <p className="panel-kicker">TEAM FOUNDATION</p>
            <h3 className="mt-2 text-lg font-semibold text-white">团队协作与产品运营</h3>
          </div>
          <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <ManagementPillar
              icon={Users}
              index="01"
              title="团队梯队建设"
              summary="关键领域采用 1 + 1 + 1：主责、备份、成长者。接班能力用演练结果证明，不以听过分享代替能够独立接管。"
              evidence="8 人团队 · 4 个关键域 · 每域有备份"
              href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/01-team-talent-pipeline.md"
            />
            <ManagementPillar
              icon={Workflow}
              index="02"
              title="团队能力提升"
              summary="学习必须经过理解、应用、验证、沉淀四步。改进项进入真实代码、监控或预案，并由自动测试和复盘结论验收。"
              evidence="学习 → 应用 → 验证 → 沉淀"
              href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/02-team-capability-growth.md"
            />
            <ManagementPillar
              icon={MessageSquare}
              index="03"
              title="跨部门沟通"
              summary="技术、产品、运营围绕同一个业务影响、同一组指标和同一份决策记录协作，减少各说各话与口头承诺。"
              evidence="共同目标 · 共同指标 · 决策留痕"
              href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/03-cross-functional-communication.md"
            />
            <ManagementPillar
              icon={Target}
              index="04"
              title="贴合产品与运营"
              summary="把活动目标翻译成订单峰值、QPS、容量、灰度与止损条件；业务结果和系统安全从需求阶段一起设计。"
              evidence="业务目标 → 容量 → 灰度 → 验收"
              href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/04-product-operations-alignment.md"
            />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-[1.12fr_.88fr]">
            <section id="management-case" className="explain-panel scroll-mt-24">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="panel-kicker">协作演练方案 · 非任职业绩</p>
                  <h3 className="mt-2 text-lg font-semibold text-white">一次运营放量如何变成可控的跨部门交付</h3>
                  <p className="mt-2 max-w-3xl text-xs leading-6 text-slate-500">以 FinCore 模块设计一次运营放量演练。人员、活动规模和时间线为方案假设；资金测试可单独核验，但不能据此推导真实活动容量或故障恢复时间。</p>
                </div>
                <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/06-end-to-end-case-study.md" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">打开完整案例 <ExternalLink className="size-3" /></a>
              </div>
              <div className="mt-5 space-y-1">
                <ManagementCaseRow time="活动准备" owner="运营 + 产品" decision="确定目标流量、分档放量比例和每档观察时间" proof="记录假设与暂停条件" />
                <ManagementCaseRow time="上线前" owner="技术 + 测试" decision="按目标订单峰值压测撮合、结算与对账链路" proof="核对实际容量结果" />
                <ManagementCaseRow time="故障演练" owner="当班备份" decision="观察积压告警，演练 Worker 接管与旧 epoch 拒写" proof="记录实际恢复时间" />
                <ManagementCaseRow time="恢复核验" owner="联合指挥" decision="检查重复投递、资金流水与对账结果" proof="按报告决定是否继续放量" />
                <ManagementCaseRow time="次日复盘" owner="团队共同" decision="行动项进入测试、监控、预案和培养计划" proof="责任与期限明确" />
              </div>
              <div className="mt-5 grid gap-3 sm:grid-cols-3">
                <ManagementProof value="1 + 1 + 1" label="关键域人员梯队" note="主责 / 备份 / 成长者" />
                <ManagementProof value="17 → 1" label="重复结算控制" note="业务效果只发生一次" />
                <ManagementProof value="待实测" label="活动容量与恢复时间" note="需在目标环境完成演练" />
              </div>
            </section>

            <section className="explain-panel">
              <p className="panel-kicker">TEAM PLAYBOOKS</p>
              <h3 className="mt-2 text-lg font-semibold text-white">团队协作手册</h3>
              <p className="mt-2 text-xs leading-6 text-slate-500">每份概要都保留了问题、原则和结果；详细层继续给出角色分工、会议机制、模板、反例、验收标准和 FinCore 场景。下面所有条目都可点击查看。</p>
              <div className="mt-5 space-y-2">
                <ManagementGuide index="01" title="梯队建设实战手册" detail="关键岗位地图、接管认证与人员风险看板" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/01-talent-pipeline-playbook.md" />
                <ManagementGuide index="02" title="能力提升闭环" detail="训练选题、任务设计、验收与知识复用" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/02-team-capability-growth-playbook.md" />
                <ManagementGuide index="03" title="跨部门案例库" detail="需求冲突、上线争议、故障与数据口径处理" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/03-cross-functional-casebook.md" />
                <ManagementGuide index="04" title="产品运营交付手册" detail="活动目标如何落到容量、灰度、止损和复盘" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/04-product-operations-delivery-playbook.md" />
                <ManagementGuide index="05" title="管理运行机制" detail="周会、风险台账、决策记录与月度复盘" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/05-management-operating-system-playbook.md" />
                <ManagementGuide index="06" title="端到端真实案例" detail="从运营放量到故障接管、资金核验和改进闭环" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/06-end-to-end-case-study.md" />
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/tree/main/docs/management" target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-xs text-cyan-300 transition hover:text-cyan-200">浏览技术负责人文档总目录 <ArrowRight className="size-3.5" /></a>
            </section>
          </div>
        </section>
</KnowledgeChapter>

        <KnowledgeChapter number="AI" title="AI 研发落地" description="理解代码、内部需求实现、缺陷修复与人工验收">
<section id="ai" className="chapter-section scroll-mt-20">
          <ChapterHeading
            number="04"
            eyebrow="AI DELIVERY · EVALS · GUARDRAILS"
            title="把 AI 编程助手落到公司：读代码、做需求、修缺陷"
            description="借鉴 Cursor 的研发工作方式，以 Claude Code 或 Codex 承接读代码、改代码、跑测试的执行过程。公司统一维护上下文、任务合同、验收和评审，工具可以替换，交付标准不变。"
          />
          <AiCompanyDelivery />

          <details id="ai-evaluations" className="mt-7 scroll-mt-24 rounded-2xl border border-white/10 p-5">
          <summary className="cursor-pointer py-2 text-lg font-medium text-cyan-200">已有 Coding Agent 真实评测与 AI 治理登记</summary>

          <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
            <ManagementProof value="54" label="受控评测运行" note="3 Agent · 多轮隔离执行" />
            <ManagementProof value="8" label="金融可靠性任务" note="基础 5 项 + 高阶 3 项" />
            <ManagementProof value="3" label="Coding Agents" note="Codex / Claude / Antigravity" />
            <ManagementProof value="2" label="安全否决" note="结果可用也不能越过资金边界" />
            <ManagementProof value="5" label="治理上下文" note="模型 / 价值 / 门禁 / 工具 / 退出" />
            <ManagementProof value="0" label="AI 自主资金写入" note="默认拒绝 · 人工审批 · 可回退" />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-[1.15fr_.85fr]">
            <section className="explain-panel">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="panel-kicker">LANDED · CODING AGENT BENCHMARK</p>
                  <h3 className="mt-2 text-lg font-semibold text-white">已经落地：用金融不变量评价 AI，而不是只看代码能不能编译</h3>
                  <p className="mt-2 max-w-3xl text-xs leading-6 text-slate-500">54 次运行覆盖幂等、并发、Outbox、Worker 接管、Epoch Fencing、对账与自动修复。下表把三轮稳定性与高阶挑战分开，所有结果都可追溯到公开报告。</p>
                </div>
                <a href="https://fincore-agent-benchmark.soldierking04d.chatgpt.site" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">打开评测网站 <ExternalLink className="size-3" /></a>
              </div>
              <div className="mt-5 overflow-hidden rounded-xl border border-white/7">
                <div className="hidden grid-cols-[1.1fr_repeat(4,1fr)] gap-3 border-b border-white/7 bg-white/[0.025] px-4 py-3 font-mono text-[8px] text-slate-600 sm:grid"><span>AGENT</span><span>三轮通过</span><span>高阶得分</span><span>隐藏测试</span><span>安全否决</span></div>
                <AiAgentRow agent="Codex" repeat="12 / 15" advanced="290 / 300" hidden="17 / 17" veto="0" best />
                <AiAgentRow agent="Claude" repeat="11 / 15" advanced="195 / 300" hidden="15 / 17" veto="1" />
                <AiAgentRow agent="Antigravity" repeat="10 / 15" advanced="175 / 300" hidden="10 / 17" veto="1" />
              </div>
              <p className="mt-3 text-[10px] leading-5 text-slate-600">三轮通过数来自 FC-001～FC-005；高阶得分、隐藏测试与安全否决来自 FC-006～FC-008，两组数据口径不混算。高阶竞态测试还暴露了“普通测试全绿、权威事务边界仍可能错误”的盲区。</p>
            </section>

            <section className="explain-panel">
              <p className="panel-kicker">CONTROLLED DELIVERY PIPELINE</p>
              <h3 className="mt-2 text-lg font-semibold text-white">每个 AI 能力先过六道门，再谈上线</h3>
              <div className="mt-5 space-y-2">
                <AiFlowStep index="01" title="用例与价值登记" detail="记录 Owner、人工基线、目标结果、单位成本和退出责任" />
                <AiFlowStep index="02" title="模型与数据上下文" detail="固定模型/提示/检索/工具版本、驻留、保留和训练用途" />
                <AiFlowStep index="03" title="隔离评测" detail="验收集、隐藏样本、最低阈值、业务质量与成本延迟同时验证" />
                <AiFlowStep index="04" title="安全否决" detail="资金、账本、权威成交、泄露或越权动作一票否决" />
                <AiFlowStep index="05" title="人工批准与关闭" detail="高风险结论由授权人确认，用例 Owner 可独立关闭 AI 路径" />
                <AiFlowStep index="06" title="复查、失效与回退" detail="门禁到期自动失败；影子、辅助、受限执行逐级放开" />
              </div>
            </section>
          </div>

          <section className="explain-panel mt-4">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <p className="panel-kicker">USE-CASE PORTFOLIO · 1 LANDED + 4 PLANNED</p>
                <h3 className="mt-2 text-lg font-semibold text-white">先解决高频、可评价、可回退的问题</h3>
                <p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">每张卡片都连接机器可读登记。已落地与规划中状态明确分开，避免“做过演示”被误认为“进入生产”。</p>
              </div>
              <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/ai/use-cases.json" target="_blank" rel="noreferrer" className="nav-link inline-flex shrink-0">查看用例登记 <ExternalLink className="size-3" /></a>
            </div>
            <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
              <AiUseCaseCard index="01" title="Coding Agent 评测" status="已落地" authority="隔离候选代码" outcome="用金融可靠性证据选择模型与工作流" href="https://github.com/soldierking04d/fincore-reliability-lab/tree/main/reports/evaluations" />
              <AiUseCaseCard index="02" title="事故诊断副驾" status="规划中" authority="只读建议" outcome="聚合告警、日志和变更，给出处置证据" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/14-ai-engineering-adoption-playbook.md" />
              <AiUseCaseCard index="03" title="对账差异解释" status="规划中" authority="只读建议" outcome="解释 MISSING、MISMATCH、EXTRA 及证据链" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/14-ai-engineering-adoption-playbook.md" />
              <AiUseCaseCard index="04" title="支持响应摘要" status="规划中" authority="仅生成草稿" outcome="把客户问题关联到运行证据与已知影响" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/14-ai-engineering-adoption-playbook.md" />
              <AiUseCaseCard index="05" title="容量成本建议" status="规划中" authority="只读建议" outcome="结合 QPS、延迟、CPU、堆和成本给出方案" href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/14-ai-engineering-adoption-playbook.md" />
            </div>
          </section>

          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <section className="explain-panel border-emerald-300/10">
              <p className="panel-kicker text-emerald-300">AI MAY</p>
              <h3 className="mt-2 text-base font-semibold text-white">可以检索、解释、建议和生成隔离候选</h3>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {['检索运行手册并引用来源', '聚合指标、日志、告警与变更', '解释异常并给出置信度', '生成等待评审的代码或回复草稿'].map((item) => <AiBoundary key={item} allowed>{item}</AiBoundary>)}
              </div>
            </section>
            <section className="explain-panel border-rose-300/10">
              <p className="panel-kicker text-rose-300">AI MUST NEVER</p>
              <h3 className="mt-2 text-base font-semibold text-white">不能越过资金、事实和发布权限</h3>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {['修改余额、账本、权威订单或成交', '批准补偿、核销或资金修复', '自动合并代码、发布或扩大权限', '无证据宣布根因、恢复或客户结论'].map((item) => <AiBoundary key={item}>{item}</AiBoundary>)}
              </div>
            </section>
          </div>

          <section className="explain-panel mt-4">
            <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-center">
              <div><p className="panel-kicker">DOCUMENTATION + MACHINE GATE</p><h3 className="mt-2 text-lg font-semibold text-white">概要讲方向，实战手册解决问题，机器登记和 CI 守住底线</h3><p className="mt-2 max-w-4xl text-xs leading-6 text-slate-500">登记会检查模型上下文、价值基线、最低阈值、复查与失效日期、允许工具、禁止范围、关闭责任、法务/隐私、安全评审和公开证据。planned 可以明确写“进入影子前完成”，landed 不能保留占位值；团队私自把敏感数据接入个人 AI 服务会作为影子 AI 风险处置。</p><div className="mt-3 flex flex-wrap gap-1.5">{['modelContext', 'valueBaseline', 'releaseGate', 'toolAccess', 'governance'].map((field) => <span key={field} className="tech-chip">{field}</span>)}</div></div>
              <div className="flex flex-wrap gap-2 lg:max-w-md lg:justify-end">
                <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/13-ai-engineering-adoption.md" target="_blank" rel="noreferrer" className="nav-link">AI 落地概要 <ExternalLink className="size-3" /></a>
                <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/management/detailed/14-ai-engineering-adoption-playbook.md" target="_blank" rel="noreferrer" className="nav-link">AI 实战手册 <ExternalLink className="size-3" /></a>
                <a href="https://github.com/soldierking04d/fincore-reliability-lab/tree/main/ai" target="_blank" rel="noreferrer" className="nav-link">治理与校验 <ExternalLink className="size-3" /></a>
              </div>
            </div>
          </section>
          </details>
        </section>
</KnowledgeChapter>

        <KnowledgeChapter number="延迟" title="低延迟与 CPU / GPU 判断" description="热点路径、NUMA、网络与异构计算的使用边界">
<LowLatencyPlaybook />
</KnowledgeChapter>
        <KnowledgeChapter number="选型" title="Java → C++ 交易改造" description="跨语言实验、架构权衡、迁移与回退">
<JavaCppMigration />
</KnowledgeChapter>

        <KnowledgeChapter number="并发" title="高并发、线程与 JVM" description="有界准入、连接池、GC、JFR 与运行指标">
<section id="performance" className="chapter-section scroll-mt-20">
          <ChapterHeading
            number="06"
            eyebrow="CONCURRENCY · CPU · JVM"
            title="从入口限流到 GC 诊断，性能优化已经进入真实运行链路"
            description="这不是一张只讲概念的架构图：线程模型、队列容量、连接池、Kafka 批量参数、Outbox 发布、CPU 热点、G1/ZGC 参数、JFR 和 Prometheus 指标都已写进项目，并由配置门禁与自动测试保护。"
          />

          <div className="mt-7 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <RuntimeCard icon={Network} title="Web / 短 I/O" value="Java 21 虚拟线程" detail="降低阻塞式请求的线程占用；监控 pinned 事件，不让虚拟线程掩盖锁竞争。" tag="spring.threads.virtual.enabled" onClick={() => setSelectedPerformance('virtual-threads')} />
            <RuntimeCard icon={Zap} title="撮合与撤单" value="4 Lane × (256 + 32)" detail="普通新单 256、撤单保留 32；同 symbol 串行，撤单优先但不抢占事务。" tag="PriorityCommandQueue" onClick={() => setSelectedPerformance('matching-lanes')} />
            <RuntimeCard icon={Radio} title="Kafka 结算" value="min(4, CPU)" detail="显式平台线程并限制并发数，避免虚拟线程 pinning 破坏消费者轮询稳定性。" tag="max.poll.records=50" onClick={() => setSelectedPerformance('kafka-consumers')} />
            <RuntimeCard icon={Database} title="PostgreSQL" value="Hikari 12 固定连接" detail="1.5 秒获取超时；连接池是数据库并发预算，不随请求线程数无限扩大。" tag="maximum-pool-size=12" onClick={() => setSelectedPerformance('hikari-pool')} />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-[1.15fr_.85fr]">
            <section className="explain-panel">
              <p className="panel-kicker">BOUNDED CONCURRENCY</p>
              <h3 className="mt-2 text-lg font-semibold text-white">一条写请求怎样穿过四层并发保护</h3>
              <div className="mt-5 space-y-1">
                <TuningRow index="01" title="Tomcat 接入" setting="4096 connections / accept 256" effect="先限制 socket 积压，避免无上限堆积请求。" onClick={() => setSelectedPerformance('tomcat-admission')} />
                <TuningRow index="02" title="交易对 Lane" setting="4 × bounded 256" effect="削平同标的锁竞争，并保留价格/时间顺序。" onClick={() => setSelectedPerformance('symbol-lane')} />
                <TuningRow index="03" title="数据库事务" setting="advisory lock + row lock" effect="跨实例仍以 PostgreSQL 为最终串行化边界。" onClick={() => setSelectedPerformance('database-locks')} />
                <TuningRow index="04" title="异步传播" setting="Outbox batch 200" effect="并发等待 Broker ack，成功/失败编号分别批量回写。" onClick={() => setSelectedPerformance('outbox-batch')} />
              </div>
            </section>

            <section className="explain-panel">
              <p className="panel-kicker">OVERLOAD CONTRACT</p>
              <h3 className="mt-2 text-lg font-semibold text-white">系统忙时，结果必须明确</h3>
              <div className="mt-5 space-y-3 text-[11px] leading-5 text-slate-500">
                <PerformanceTextButton tone="rose" title="429 · Lane 已满" onClick={() => setSelectedPerformance('overload-429')}>任务没有入队，调用方保留原 clientOrderId 重试；不会 CallerRuns 破坏顺序，也不会静默丢单。</PerformanceTextButton>
                <PerformanceTextButton tone="amber" title="503 · 等待或 Kafka 确认超时" onClick={() => setSelectedPerformance('overload-503')}>返回 retryable 错误，绝不把 Broker 未确认伪装成已接受。撮合超时也不强制取消已经开始的事务。</PerformanceTextButton>
                <PerformanceTextButton tone="green" title="幂等重试" onClick={() => setSelectedPerformance('idempotent-retry')}>同一 clientOrderId、messageId、businessKey 和 repair key 由数据库唯一约束兜底。</PerformanceTextButton>
              </div>
            </section>
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <section className="explain-panel">
              <p className="panel-kicker">CPU HOT PATH</p>
              <h3 className="mt-2 text-base font-semibold text-white">减少锁竞争与短命对象</h3>
              <div className="mt-4 space-y-2">
                <TraceRow event="UUID 锁排序" action="直接比较 128-bit" result="不创建 UUID 字符串" onClick={() => setSelectedPerformance('uuid-ordering')} />
                <TraceRow event="账本写入" action="MyBatis foreach" result="整组分录 1 次 SQL" onClick={() => setSelectedPerformance('ledger-batch')} />
                <TraceRow event="Outbox 发布" action="异步 send + 批量状态" result="减少网络/DB 往返" onClick={() => setSelectedPerformance('outbox-publish')} />
                <TraceRow event="Lease 续期" action="ConcurrentHashMap.compute" result="64 并发合并为 1 次续期" onClick={() => setSelectedPerformance('lease-coalescing')} />
              </div>
            </section>

            <button type="button" onClick={() => setSelectedPerformance('g1')} className="explain-panel performance-panel-button text-left">
              <p className="panel-kicker">DEFAULT · G1</p>
              <h3 className="mt-2 text-base font-semibold text-white">中小堆的生产基线</h3>
              <p className="mt-3 text-xs leading-5 text-slate-500">容器内初始堆 25%、最大堆 65%，为线程栈、直接内存、Metaspace、JFR 与操作系统缓存保留空间。目标停顿 200ms，并启用并行引用处理和字符串去重。</p>
              <div className="mt-4 grid grid-cols-2 gap-2"><MiniMetric label="MAX HEAP" value="65% RAM" /><MiniMetric label="PAUSE GOAL" value="200 ms" /><MiniMetric label="GC LOG" value="5 × 20 MB" /><MiniMetric label="JFR" value="6h / 256M" /></div>
              <p className="mt-4 flex items-center justify-between font-mono text-[9px] text-cyan-300/70"><span>FINCORE_GC=g1 · config/jvm/g1.options</span><span>查看详情 →</span></p>
            </button>

            <button type="button" onClick={() => setSelectedPerformance('zgc')} className="explain-panel performance-panel-button text-left">
              <p className="panel-kicker">ALTERNATIVE · ZGC</p>
              <h3 className="mt-2 text-base font-semibold text-white">低停顿备选，不是默认答案</h3>
              <p className="mt-3 text-xs leading-5 text-slate-500">只有真实流量证明 G1 停顿不达标、且容器有足够 CPU 与内存余量时，才切换 Generational ZGC。相同的 65% 堆边界、OOM dump、GC 日志与 JFR 仍保留。</p>
              <div className="mt-4 rounded-lg border border-amber-300/12 bg-amber-300/[0.04] p-3 text-[11px] leading-5 text-amber-100/65">选择 GC 前先看分配速率、live set、p99 GC pause、CPU 与容器 OOM；不能只凭“ZGC 更新”就替换 G1。</div>
              <p className="mt-4 flex items-center justify-between font-mono text-[9px] text-violet-300/70"><span>FINCORE_GC=zgc · config/jvm/zgc.options</span><span>查看详情 →</span></p>
            </button>
          </div>

          <section className="explain-panel mt-4">
            <div className="grid gap-6 xl:grid-cols-[.9fr_1.1fr]">
              <div>
                <p className="panel-kicker">OBSERVABILITY</p>
                <h3 className="mt-2 text-lg font-semibold text-white">要同时看业务吞吐、排队和运行时</h3>
                <p className="mt-3 text-xs leading-5 text-slate-500">页面上价格、单量、QPS、TPS、P95、CPU、Heap、DB 活跃连接、Kafka Lag 和 Outbox Backlog 已按同一场景阶段联动。Grafana 再补上下面这些真实 Micrometer 指标。</p>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  {['fincore_matching_queue_depth_total', 'fincore_matching_queue_rejected_total', 'jvm_threads_virtual_pinned_seconds_count', 'fincore_settlement_consumer_inflight', 'hikaricp_connections_pending', 'jvm_gc_pause_seconds_bucket'].map((metric) => <span key={metric} className="rounded-md border border-white/7 bg-black/15 px-2.5 py-2 font-mono text-[9px] text-slate-500">{metric}</span>)}
                </div>
                <button type="button" onClick={() => setSelectedPerformance('observability')} className="performance-detail-link mt-4">查看监控指标详情 <ArrowRight className="size-3" /></button>
              </div>
              <div>
                <p className="panel-kicker">REPRODUCIBLE LOAD</p>
              <h3 className="mt-2 text-lg font-semibold text-white">固定到达率压测与结果采集</h3>
                <p className="mt-3 text-xs leading-5 text-slate-500">k6 同时注入结算 150 QPS、热点撮合 100 QPS、市场查询 100 QPS，并输出 JSON、Actuator 指标、GC 日志和 JFR。最终吞吐与延迟必须在目标虚拟机上实跑后才算有效数据。</p>
                <div className="mt-4 rounded-xl border border-cyan-300/12 bg-[#060d13] p-4 font-mono text-[10px] text-cyan-200">./scripts/performance/run-performance-lab.sh</div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" onClick={() => setSelectedPerformance('load-test')} className="nav-link">查看压测设计详情 <ArrowRight className="size-3" /></button>
                  <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/docs/high-concurrency-jvm-tuning.md" target="_blank" rel="noreferrer" className="nav-link">阅读完整调优讲解 <ExternalLink className="size-3" /></a>
                  <a href="https://github.com/soldierking04d/fincore-reliability-lab/blob/main/benchmarks/mixed-workload.js" target="_blank" rel="noreferrer" className="nav-link">查看 k6 负载 <ExternalLink className="size-3" /></a>
                </div>
              </div>
            </div>
          </section>
        </section>
</KnowledgeChapter>

        <KnowledgeChapter number="索引" title="详细索引与实现范围" description="与首页相同的专题入口，附业务阶段、实现范围和参考资料">
          <ProjectOutline />
        </KnowledgeChapter>

        <Sheet open={selectedPerformance !== null} onOpenChange={(open) => { if (!open) setSelectedPerformance(null); }}>
          <SheetContent className="w-full border-white/10 bg-[#071019] p-0 sm:max-w-3xl">
            {performanceDetail && <PerformanceDetailContent detail={performanceDetail} />}
          </SheetContent>
        </Sheet>

        <footer className="flex flex-col gap-2 py-8 text-[11px] leading-5 text-slate-600 sm:flex-row sm:items-center sm:justify-between"><p>先运行监控演练，再沿完整业务链和真实代码向下追踪每一个结果。</p><p className="font-mono">user → kyc → risk → account → market → match → settle → ledger → reconcile</p></footer>
        <VisitorAnalytics />
      </section>
    </main>
  );
}

function metricDelta(value: number, previous: number) { if (value === previous) return '—'; return `${value > previous ? '↑' : '↓'} ${Math.abs(value - previous).toLocaleString()}`; }

function AiAgentRow({ agent, repeat, advanced, hidden, veto, best = false }: { agent: string; repeat: string; advanced: string; hidden: string; veto: string; best?: boolean }) {
  return <div className={`grid gap-2 border-b border-white/6 px-4 py-3 last:border-0 sm:grid-cols-[1.1fr_repeat(4,1fr)] sm:items-center ${best ? 'bg-emerald-300/[0.035]' : 'bg-black/10'}`}><div className="flex items-center justify-between gap-3"><strong className="text-xs font-medium text-slate-200">{agent}</strong>{best && <span className="rounded-md bg-emerald-300/10 px-2 py-1 font-mono text-[8px] text-emerald-300">LEADING</span>}</div><AiAgentMetric label="三轮通过" value={repeat} /><AiAgentMetric label="高阶得分" value={advanced} /><AiAgentMetric label="隐藏测试" value={hidden} /><AiAgentMetric label="安全否决" value={veto} warn={veto !== '0'} /></div>;
}

function AiAgentMetric({ label, value, warn = false }: { label: string; value: string; warn?: boolean }) {
  return <div className="flex items-center justify-between gap-3 sm:block"><span className="font-mono text-[8px] text-slate-700 sm:hidden">{label}</span><span className={`font-mono text-[10px] ${warn ? 'text-rose-300' : 'text-slate-300'}`}>{value}</span></div>;
}

function AiFlowStep({ index, title, detail }: { index: string; title: string; detail: string }) {
  return <div className="grid grid-cols-[30px_100px_1fr] items-center gap-3 rounded-lg border border-white/6 bg-black/10 p-2.5"><span className="grid size-6 place-items-center rounded-md bg-cyan-300/10 font-mono text-[8px] text-cyan-300">{index}</span><strong className="text-[10px] font-medium text-slate-300">{title}</strong><span className="text-[10px] leading-5 text-slate-600">{detail}</span></div>;
}

function AiUseCaseCard({ index, title, status, authority, outcome, href }: { index: string; title: string; status: '已落地' | '规划中'; authority: string; outcome: string; href: string }) {
  const landed = status === '已落地';
  return <a href={href} target="_blank" rel="noreferrer" className="explain-panel performance-panel-button block text-left"><div className="flex items-center justify-between gap-3"><span className="font-mono text-[9px] text-cyan-300/70">{index}</span><span className={`rounded-md px-2 py-1 font-mono text-[8px] ${landed ? 'bg-emerald-300/10 text-emerald-300' : 'bg-amber-300/[0.08] text-amber-200'}`}>{status}</span></div><h4 className="mt-4 text-sm font-medium text-slate-100">{title}</h4><p className="mt-2 min-h-15 text-[11px] leading-5 text-slate-500">{outcome}</p><div className="mt-4 flex items-center justify-between gap-2 border-t border-white/7 pt-3"><span className="font-mono text-[8px] text-violet-300/70">{authority}</span><ExternalLink className="size-3.5 shrink-0 text-cyan-300/60" /></div></a>;
}

function AiBoundary({ allowed = false, children }: { allowed?: boolean; children: React.ReactNode }) {
  return <div className={`flex items-start gap-2.5 rounded-lg border p-3 text-[10px] leading-5 ${allowed ? 'border-emerald-300/10 bg-emerald-300/[0.035] text-emerald-100/60' : 'border-rose-300/10 bg-rose-300/[0.035] text-rose-100/60'}`}><span className={`mt-0.5 grid size-4 shrink-0 place-items-center rounded-full ${allowed ? 'bg-emerald-300/10 text-emerald-300' : 'bg-rose-300/10 text-rose-300'}`}>{allowed ? <Check className="size-2.5" /> : <TriangleAlert className="size-2.5" />}</span><span>{children}</span></div>;
}

function RuntimeCard({ icon: Icon, title, value, detail, tag, onClick }: { icon: typeof Activity; title: string; value: string; detail: string; tag: string; onClick: () => void }) { return <button type="button" onClick={onClick} className="explain-panel performance-panel-button text-left"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-cyan-300/10 text-cyan-300"><Icon className="size-4.5" /></span><span className="font-mono text-[8px] text-slate-700">RUNTIME</span></div><p className="mt-4 text-[10px] text-slate-600">{title}</p><h3 className="mt-1 font-mono text-base font-medium text-white">{value}</h3><p className="mt-3 text-[11px] leading-5 text-slate-500">{detail}</p><p className="mt-3 flex items-center justify-between font-mono text-[8px] text-cyan-300/60"><span>{tag}</span><span>查看实现详情 →</span></p></button>; }

function TuningRow({ index, title, setting, effect, onClick }: { index: string; title: string; setting: string; effect: string; onClick: () => void }) { return <button type="button" onClick={onClick} className="performance-row grid w-full gap-2 rounded-xl border border-white/6 bg-black/10 p-3 text-left sm:grid-cols-[34px_140px_190px_1fr_auto] sm:items-center"><span className="font-mono text-[9px] text-cyan-300/60">{index}</span><strong className="text-xs font-medium text-slate-200">{title}</strong><span className="font-mono text-[9px] text-amber-200/70">{setting}</span><span className="text-[10px] leading-5 text-slate-600">{effect}</span><ArrowRight className="size-3.5 text-cyan-300/60" /></button>; }

function PerformanceTextButton({ tone, title, onClick, children }: { tone: 'rose' | 'amber' | 'green'; title: string; onClick: () => void; children: React.ReactNode }) {
  const tones = {
    rose: 'border-rose-300/12 bg-rose-300/[0.04] text-rose-200',
    amber: 'border-amber-300/12 bg-amber-300/[0.04] text-amber-200',
    green: 'border-emerald-300/12 bg-emerald-300/[0.04] text-emerald-200',
  };
  return <button type="button" onClick={onClick} className={`performance-row w-full rounded-lg border p-3 text-left ${tones[tone]}`}><span className="flex items-center justify-between gap-3"><strong>{title}</strong><ArrowRight className="size-3.5 shrink-0" /></span><span className="mt-1 block text-slate-500">{children}</span></button>;
}

function PerformanceDetailContent({ detail }: { detail: PerformanceDetail }) {
  return <div className="flex h-full flex-col overflow-hidden">
    <SheetHeader className="border-b border-white/8 px-5 py-5 sm:px-7">
      <p className="font-mono text-[10px] tracking-[0.16em] text-cyan-300">{detail.eyebrow}</p>
      <SheetTitle className="mt-2 pr-10 text-xl font-semibold tracking-[-0.025em] text-white sm:text-2xl">{detail.title}</SheetTitle>
      <SheetDescription className="mt-2 max-w-2xl text-xs leading-6 text-slate-400">{detail.summary}</SheetDescription>
    </SheetHeader>
    <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-7">
      <div className="grid gap-5 lg:grid-cols-2">
        <DetailList title="实际落地配置" items={detail.configurations} tone="cyan" />
        <DetailList title="执行链" items={detail.flow} tone="amber" ordered />
      </div>
      <section className="mt-5 overflow-hidden rounded-xl border border-white/8 bg-[#050b10]">
        <div className="flex items-center justify-between border-b border-white/7 px-4 py-3"><p className="panel-kicker">KEY IMPLEMENTATION</p><span className="font-mono text-[9px] text-slate-600">{detail.sourceLabel}</span></div>
        <pre className="max-h-[330px] overflow-auto p-4 font-mono text-[10px] leading-6 text-slate-300"><code>{detail.code}</code></pre>
      </section>
      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <DetailList title="应该盯住的指标" items={detail.metrics} tone="violet" mono />
        <DetailList title="怎么验证" items={detail.verification} tone="green" ordered />
      </div>
      <section className="mt-5 rounded-xl border border-rose-300/12 bg-rose-300/[0.035] p-4"><p className="panel-kicker text-rose-300">FAILURE MODE</p><p className="mt-2 text-xs leading-6 text-rose-100/65">{detail.failure}</p></section>
      <a href={performanceSourceUrl(detail)} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 rounded-lg border border-cyan-300/15 bg-cyan-300/[0.05] px-4 py-3 text-xs font-medium text-cyan-300 transition hover:border-cyan-300/30 hover:bg-cyan-300/[0.08]">打开 {detail.sourceLabel} 完整源码 <ExternalLink className="size-3.5" /></a>
    </div>
  </div>;
}

function DetailList({ title, items, tone, ordered = false, mono = false }: { title: string; items: string[]; tone: 'cyan' | 'amber' | 'violet' | 'green'; ordered?: boolean; mono?: boolean }) {
  const toneClass = { cyan: 'bg-cyan-300/10 text-cyan-300', amber: 'bg-amber-300/10 text-amber-300', violet: 'bg-violet-300/10 text-violet-300', green: 'bg-emerald-300/10 text-emerald-300' }[tone];
  return <section><p className="panel-kicker">{title}</p><div className="mt-3 space-y-2">{items.map((item, index) => <div key={item} className="flex items-start gap-2.5 rounded-lg border border-white/6 bg-white/[0.02] p-2.5"><span className={`grid size-5 shrink-0 place-items-center rounded-full font-mono text-[8px] ${toneClass}`}>{ordered ? index + 1 : <Check className="size-2.5" />}</span><p className={`${mono ? 'font-mono text-[10px]' : 'text-[11px]'} leading-5 text-slate-400`}>{item}</p></div>)}</div></section>;
}

function KpiCard({ icon: Icon, label, value, unit, delta: change, tone, source }: { icon: typeof Activity; label: string; value: string; unit: string; delta: string; tone: 'cyan' | 'amber' | 'violet' | 'rose' | 'green'; source: string }) {
  const tones = { cyan: 'text-cyan-300 bg-cyan-300/10', amber: 'text-amber-300 bg-amber-300/10', violet: 'text-violet-300 bg-violet-300/10', rose: 'text-rose-300 bg-rose-300/10', green: 'text-emerald-300 bg-emerald-300/10' };
  return <article className="telemetry-kpi"><div className="flex items-center justify-between"><span className={`grid size-7 place-items-center rounded-lg ${tones[tone]}`}><Icon className="size-3.5" /></span><span className="font-mono text-[9px] text-slate-600">{source}</span></div><p className="mt-3 text-[10px] text-slate-500">{label}</p><div className="mt-1 flex items-baseline gap-1.5"><strong className="font-mono text-xl font-medium tracking-[-0.03em] text-white xl:text-2xl">{value}</strong><span className="font-mono text-[9px] text-slate-600">{unit}</span></div><p className={`mt-1 font-mono text-[10px] ${change.includes('↑') ? 'text-rose-300' : change.includes('↓') ? 'text-emerald-300' : 'text-slate-600'}`}>{change}</p></article>;
}

function TelemetryPanel({ kicker, title, icon: Icon, current, note, children }: { kicker: string; title: string; icon: typeof Activity; current: string; note: string; children: React.ReactNode }) { return <section className="ops-panel"><div className="panel-heading"><div><p className="panel-kicker">{kicker}</p><h2>{title}</h2></div><div className="text-right"><div className="flex items-center justify-end gap-1.5 font-mono text-xs text-cyan-300"><Icon className="size-3.5" /> {current}</div><p className="mt-1 text-[9px] text-slate-600">{note}</p></div></div><div className="mt-2">{children}</div></section>; }

function SystemNode({ icon: Icon, label, metric, state }: { icon: typeof Activity; label: string; metric: string; state: 'idle' | 'active' | 'done' }) { return <div className={`system-node ${state === 'active' ? 'system-node-active' : state === 'done' ? 'system-node-done' : ''}`}><div className="flex items-center justify-between"><span className="grid size-8 place-items-center rounded-lg bg-white/5"><Icon className="size-4" /></span>{state === 'done' ? <Check className="size-3.5 text-emerald-300" /> : state === 'active' ? <Radio className="size-3.5 animate-pulse text-cyan-300" /> : <ArrowRight className="size-3.5 text-slate-700" />}</div><p className="mt-3 text-xs font-medium text-slate-300">{label}</p><p className="mt-1 font-mono text-[10px] text-slate-600">{metric}</p></div>; }

function SmallHeading({ kicker, title }: { kicker: string; title: string }) { return <div><p className="panel-kicker">{kicker}</p><h2 className="mt-1 text-sm font-medium text-slate-100">{title}</h2></div>; }
function MiniMetric({ label, value, good = false, warn = false }: { label: string; value: string | number; good?: boolean; warn?: boolean }) { return <div className="rounded-lg border border-white/6 bg-black/10 p-2"><p className="text-[9px] text-slate-600">{label}</p><p className={`mt-1 font-mono text-sm ${good ? 'text-emerald-300' : warn ? 'text-rose-300' : 'text-slate-300'}`}>{value}</p></div>; }
function WorkerRow({ name, epoch, status, state }: { name: string; epoch: string; status: string; state: 'idle' | 'good' | 'bad' }) { return <div className={`flex items-center justify-between rounded-lg border px-3 py-2.5 text-xs ${state === 'good' ? 'border-emerald-300/15 bg-emerald-300/[0.05]' : state === 'bad' ? 'border-rose-300/15 bg-rose-300/[0.05]' : 'border-white/6 bg-black/10'}`}><div><p className="font-mono text-[10px] text-slate-600">{name}</p><p className="mt-1 text-slate-300">Epoch {epoch}</p></div><span className={`font-mono text-[10px] ${state === 'good' ? 'text-emerald-300' : state === 'bad' ? 'text-rose-300' : 'text-slate-600'}`}>{state !== 'idle' && (state === 'good' ? <Check className="mr-1 inline size-3" /> : <TriangleAlert className="mr-1 inline size-3" />)}{status}</span></div>; }
function DiffPill({ label, value }: { label: string; value: number }) { return <div className="rounded-lg border border-white/6 bg-black/10 p-2"><p className="font-mono text-[8px] text-slate-600">{label}</p><p className={`mt-2 font-mono text-lg ${value > 0 ? 'text-rose-300' : 'text-emerald-300'}`}>{value}</p></div>; }
function FaultSwitch({ label, detail, checked, disabled, onChange }: { label: string; detail: string; checked: boolean; disabled: boolean; onChange: (checked: boolean) => void }) { return <div className="flex items-center justify-between gap-3 border-b border-white/6 py-2.5 last:border-0"><div><p className="text-xs text-slate-300">{label}</p><p className="mt-0.5 text-[10px] text-slate-600">{detail}</p></div><Switch checked={checked} disabled={disabled} onCheckedChange={onChange} className="data-checked:bg-cyan-300" /></div>; }
function Proof({ icon: Icon, label, value, note, verified }: { icon: typeof Activity; label: string; value: string; note: string; verified: boolean }) { return <div className="flex items-start gap-3 rounded-xl border border-white/6 bg-black/10 p-3"><span className={`grid size-8 shrink-0 place-items-center rounded-lg ${verified ? 'bg-emerald-300/10 text-emerald-300' : 'bg-white/5 text-slate-600'}`}><Icon className="size-4" /></span><div><div className="flex items-center gap-1.5"><p className="text-[10px] text-slate-600">{label}</p>{verified && <BadgeCheck className="size-3 text-emerald-300" />}</div><p className="mt-1 font-mono text-sm text-slate-200">{value}</p><p className="mt-1 text-[10px] text-slate-600">{note}</p></div></div>; }

function ProfileFact({ label, value }: { label: string; value: string }) {
  return <div className="grid gap-1 rounded-lg border border-white/6 bg-black/10 px-3 py-2.5 sm:grid-cols-[70px_1fr] sm:items-center"><span className="font-mono text-[8px] text-slate-600">{label}</span><strong className="text-[10px] font-medium leading-5 text-slate-300">{value}</strong></div>;
}

function ProfileProof({ value, label, detail }: { value: string; label: string; detail: string }) {
  return <article className="border-b border-white/7 p-4 last:border-b-0 xl:border-r xl:border-b-0 xl:last:border-r-0"><strong className="font-mono text-xl font-medium text-cyan-300">{value}</strong><p className="mt-2 text-xs font-medium text-white">{label}</p><p className="mt-1 text-[9px] leading-4 text-slate-600">{detail}</p></article>;
}

function ProfileCase({ index, title, problem, result, evidence, href }: { index: string; title: string; problem: string; result: string; evidence: string; href: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className="explain-panel performance-panel-button block text-left"><div className="flex items-center justify-between"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 font-mono text-[9px] text-cyan-300">{index}</span><Badge className="border border-emerald-300/15 bg-emerald-300/[0.06] text-[8px] text-emerald-300">VERIFIABLE</Badge></div><h3 className="mt-4 text-sm font-semibold text-white">{title}</h3><p className="mt-3 text-[10px] leading-5 text-slate-600">{problem}</p><p className="mt-3 border-l-2 border-emerald-300/30 pl-3 text-[11px] leading-5 text-emerald-100/70">{result}</p><div className="mt-4 flex items-center justify-between gap-3 border-t border-white/7 pt-3"><span className="font-mono text-[8px] text-cyan-300/70">{evidence}</span><ExternalLink className="size-3.5 shrink-0 text-cyan-300/70" /></div></a>;
}

function BlockchainCheck({ state, text, planned = false }: { state: string; text: string; planned?: boolean }) {
  return <div className="grid grid-cols-[52px_1fr] gap-2 rounded-lg border border-white/6 bg-black/10 p-2.5"><span className={`font-mono text-[8px] ${planned ? 'text-amber-200' : 'text-emerald-300'}`}>{state}</span><span className="text-[10px] leading-5 text-slate-400">{text}</span></div>;
}

function BlockchainMapping({ from, to, detail }: { from: string; to: string; detail: string }) {
  return <article className="rounded-xl border border-white/7 bg-black/10 p-3"><div className="flex items-center gap-2 font-mono text-[9px]"><span className="text-cyan-300">{from}</span><ArrowRight className="size-3 text-slate-700" /><span className="text-violet-200">{to}</span></div><p className="mt-2 text-[9px] leading-4 text-slate-600">{detail}</p></article>;
}

function BlockchainTopic({ icon: Icon, title, status, description, tags }: { icon: typeof Activity; title: string; status: string; description: string; tags: string[] }) {
  return <article className="explain-panel"><div className="flex items-center justify-between gap-3"><span className="grid size-9 place-items-center rounded-xl bg-violet-300/10 text-violet-200"><Icon className="size-4.5" /></span><span className="rounded-md border border-violet-300/10 bg-violet-300/[0.06] px-2 py-1 font-mono text-[8px] text-violet-200">{status}</span></div><h3 className="mt-4 text-sm font-semibold text-white">{title}</h3><p className="mt-2 min-h-24 text-[11px] leading-5 text-slate-500">{description}</p><div className="mt-3 flex flex-wrap gap-1.5">{tags.map((tag) => <span key={tag} className="tech-chip">{tag}</span>)}</div></article>;
}

function ChapterHeading({ number, eyebrow, title, description }: { number: string; eyebrow: string; title: string; description: string }) {
  return <div className="grid gap-5 lg:grid-cols-[110px_1fr] lg:items-start"><div className="chapter-number">{number}</div><div><p className="panel-kicker text-cyan-300">{eyebrow}</p><h2 className="mt-2 text-2xl font-semibold tracking-[-0.035em] text-white sm:text-3xl">{title}</h2><p className="mt-3 max-w-5xl text-sm leading-7 text-slate-400">{description}</p></div></div>;
}

function ResilienceGoal({ icon: Icon, title, target, detail }: { icon: typeof Activity; title: string; target: string; detail: string }) {
  return <article className="rounded-xl border border-white/7 bg-black/10 p-3.5"><div className="flex items-center justify-between gap-2"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Icon className="size-4" /></span><span className="rounded-md bg-emerald-300/[0.06] px-2 py-1 font-mono text-[8px] text-emerald-300/80">{target}</span></div><h4 className="mt-3 text-xs font-semibold text-white">{title}</h4><p className="mt-2 text-[10px] leading-5 text-slate-500">{detail}</p></article>;
}

function ArchitectureSvgNode({ x, y, width = 190, height = 68, title, detail, tone = 'cyan', target = false }: { x: number; y: number; width?: number; height?: number; title: string; detail: string; tone?: 'cyan' | 'amber' | 'violet' | 'green' | 'neutral' | 'rose'; target?: boolean }) {
  return <g className={`architecture-svg-node architecture-svg-node-${tone} ${target ? 'architecture-svg-node-target' : ''}`}><rect x={x} y={y} width={width} height={height} rx="10" /><circle cx={x + 15} cy={y + 17} r="4" /><text className="architecture-svg-title" x={x + 27} y={y + 22}>{title}</text><text className="architecture-svg-detail" x={x + 15} y={y + 46}>{detail}</text>{target && <text className="architecture-svg-target" x={x + width - 12} y={y + 17} textAnchor="end">TARGET</text>}</g>;
}

function SystemArchitectureDiagram() {
  return <div className="architecture-svg-scroll" aria-label="FinCore 整体系统架构图">
    <svg className="system-architecture-svg" viewBox="0 0 1580 930" aria-labelledby="system-architecture-title system-architecture-desc">
      <title id="system-architecture-title">FinCore 从用户、行情、交易到资金与恢复的整体架构</title>
      <desc id="system-architecture-desc">实线表示同步调用，紫色线表示异步事件，绿色虚线表示数据和观测链路；图中区分外部系统、接入适配、交易核心、事件资金域和权威数据与恢复域。</desc>
      <defs>
        <marker id="architecture-arrow-sync" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker>
        <marker id="architecture-arrow-market" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-market" /></marker>
        <marker id="architecture-arrow-async" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-async" /></marker>
        <marker id="architecture-arrow-data" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-data" /></marker>
      </defs>

      <rect className="architecture-zone" x="20" y="55" width="180" height="515" rx="16" />
      <rect className="architecture-zone" x="225" y="55" width="245" height="515" rx="16" />
      <rect className="architecture-zone architecture-zone-core" x="500" y="55" width="650" height="515" rx="16" />
      <rect className="architecture-zone architecture-zone-async" x="500" y="610" width="650" height="280" rx="16" />
      <rect className="architecture-zone architecture-zone-data" x="1180" y="55" width="375" height="835" rx="16" />

      <text className="architecture-zone-title" x="42" y="87">EXTERNAL · 外部参与方</text>
      <text className="architecture-zone-title" x="247" y="87">EDGE · 接入与适配</text>
      <text className="architecture-zone-title" x="522" y="87">SYNC CORE · 同步交易核心</text>
      <text className="architecture-zone-title" x="522" y="642">ASYNC MONEY · 事件与资金处理</text>
      <text className="architecture-zone-title" x="1202" y="87">STATE &amp; RECOVERY · 权威状态与恢复</text>

      <ArchitectureSvgNode x={40} y={120} width={140} title="用户客户端" detail="下单 / 查询 / 重试" tone="neutral" />
      <ArchitectureSvgNode x={40} y={225} width={140} title="运营后台" detail="配置 / 暂停 / 复核" tone="neutral" />
      <ArchitectureSvgNode x={40} y={330} width={140} title="KYC 供应商" detail="身份 / 审核 / 回调" tone="amber" target />
      <ArchitectureSvgNode x={40} y={435} width={140} title="多源行情" detail="交易所 A / B / C" tone="amber" target />

      <ArchitectureSvgNode x={250} y={120} width={195} title="TLS / Nginx" detail="限速 · 超时 · 429" />
      <ArchitectureSvgNode x={250} y={225} width={195} title="Spring Web API" detail="虚拟线程 · 协议适配" />
      <ArchitectureSvgNode x={250} y={330} width={195} title="KYC Adapter" detail="统一审核状态" tone="amber" target />
      <ArchitectureSvgNode x={250} y={435} width={195} title="Market Gateway" detail="序列 · 缺口 · 标准化" tone="amber" target />

      <ArchitectureSvgNode x={535} y={120} width={225} title="用户 / KYC / 权限" detail="ACTIVE + VERIFIED" />
      <ArchitectureSvgNode x={870} y={120} width={225} title="风控档案 / 交易账户" detail="额度 · 资产 · 余额 · 行锁" />
      <ArchitectureSvgNode x={535} y={275} width={225} title="参考行情服务" detail="来源 · observedAt · 版本" tone="amber" />
      <ArchitectureSvgNode x={870} y={275} width={225} title="盘前决定" detail="价格笼子 · 敞口 · 幂等" />
      <ArchitectureSvgNode x={535} y={430} width={225} title="有界准入 Lane" detail="symbol 散列 · 4 × 256" />
      <ArchitectureSvgNode x={870} y={430} width={225} title="撮合分片" detail="价格时间 · 数量守恒" />

      <ArchitectureSvgNode x={535} y={680} width={175} title="Outbox Relay" detail="抢占 · 发布 · 重试" tone="violet" />
      <ArchitectureSvgNode x={740} y={680} width={175} title="Kafka" detail="分区 · 至少一次" tone="violet" />
      <ArchitectureSvgNode x={945} y={680} width={175} title="Fenced Worker" detail="Lease + Epoch" tone="violet" />
      <ArchitectureSvgNode x={635} y={800} width={205} title="清算 / 结算" detail="Inbox · 状态机 · 有序锁" tone="violet" />
      <ArchitectureSvgNode x={875} y={800} width={205} title="不可变账本" detail="余额同事务 · 借贷平衡" tone="green" />

      <g className="architecture-database-node"><rect x="1215" y="120" width="305" height="180" rx="14" /><ellipse cx="1367.5" cy="145" rx="125" ry="17" /><text className="architecture-svg-title" x="1367.5" y="151" textAnchor="middle">PostgreSQL 16 · 权威事实</text><text className="architecture-svg-detail" x="1242" y="190">用户 / 风控 / 账户 / 参考行情</text><text className="architecture-svg-detail" x="1242" y="220">订单 / 成交 / Inbox / Outbox</text><text className="architecture-svg-detail" x="1242" y="250">余额 / 账本 / 状态审计 / Epoch</text><text className="architecture-svg-proof" x="1242" y="278">唯一键 · 行锁 · CAS · 不可变历史</text></g>
      <ArchitectureSvgNode x={1215} y={355} width={305} height={84} title="Prometheus / Grafana" detail="QPS · P95 · CPU · GC · Lag" tone="green" />
      <ArchitectureSvgNode x={1215} y={500} width={305} height={84} title="自动对账" detail="成交 × 投影 × 余额 × 账本" tone="green" />
      <ArchitectureSvgNode x={1215} y={645} width={305} height={84} title="差异分类" detail="MISSING · MISMATCH · EXTRA" tone="green" />
      <ArchitectureSvgNode x={1215} y={790} width={305} height={84} title="受控恢复" detail="重建 · 隔离 · 再次 CLEAN" tone="green" />

      <g className="architecture-svg-edges architecture-svg-edges-sync">
        <path d="M180 154 H250" /><path d="M347 188 V225" /><path d="M445 259 H485 V154 H535" />
        <path d="M180 259 H250" /><path d="M445 259 H485" />
        <path d="M180 364 H250" /><path d="M445 364 H490 V170 H535" />
        <path d="M760 154 H870" /><path d="M647 188 V275" />
        <path d="M760 309 H870" /><path d="M982 188 V275" />
        <path d="M982 343 V382 H647 V430" /><path d="M760 464 H870" />
      </g>
      <g className="architecture-svg-edges architecture-svg-edges-market"><path d="M180 469 H250" /><path d="M445 469 H490 V309 H535" /></g>
      <g className="architecture-svg-edges architecture-svg-edges-async"><path d="M982 498 V600 H622 V680" /><path d="M710 714 H740" /><path d="M915 714 H945" /><path d="M1032 748 V770 H738 V800" /><path d="M840 834 H875" /></g>
      <g className="architecture-svg-edges architecture-svg-edges-data"><path d="M1095 154 H1160 V180 H1215" /><path d="M1095 309 H1160 V200 H1215" /><path d="M1095 464 H1160 V230 H1215" /><path d="M1080 834 H1160 V265 H1215" /><path d="M1368 300 V355" /><path d="M1368 439 V500" /><path d="M1368 584 V645" /><path d="M1368 729 V790" /><path d="M1215 832 H1160 V280 H1215" /></g>

      <g className="architecture-edge-labels"><text x="475" y="142">HTTPS / JSON</text><text x="465" y="457">QUOTE STREAM</text><text x="705" y="592">成交 + Outbox 同事务</text><text x="1125" y="820">SQL TX</text></g>

      <g className="architecture-legend" transform="translate(40 905)"><line x1="0" y1="0" x2="34" y2="0" className="legend-sync" /><text x="43" y="4">同步调用</text><line x1="160" y1="0" x2="194" y2="0" className="legend-async" /><text x="203" y="4">异步事件</text><line x1="320" y1="0" x2="354" y2="0" className="legend-data" /><text x="363" y="4">数据 / 观测 / 恢复</text><rect x="540" y="-9" width="28" height="18" rx="4" className="legend-target" /><text x="577" y="4">虚线节点为生产演进目标</text></g>
    </svg>
  </div>;
}

function GlobalServiceTopologyDiagram() {
  return <div className="architecture-svg-scroll" aria-label="FinCore 全局服务部署与调用拓扑图"><svg className="global-topology-svg" viewBox="0 0 1580 820" aria-labelledby="global-topology-title global-topology-desc"><title id="global-topology-title">FinCore 全局服务拓扑</title><desc id="global-topology-desc">公网流量经过 Caddy 与 Nginx 进入 API 副本，再按交易对路由到撮合分片；成交由 Outbox 进入 Kafka 和带 Epoch 的结算 Worker，最终写入 PostgreSQL。Prometheus、Grafana 与对账任务形成观测恢复闭环。</desc><defs><marker id="topology-arrow-sync" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker><marker id="topology-arrow-async" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-async" /></marker><marker id="topology-arrow-data" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-data" /></marker></defs>
    <rect className="architecture-zone" x="20" y="55" width="420" height="700" rx="16" /><rect className="architecture-zone architecture-zone-core" x="470" y="55" width="655" height="700" rx="16" /><rect className="architecture-zone architecture-zone-data" x="1155" y="55" width="400" height="700" rx="16" />
    <text className="architecture-zone-title" x="42" y="87">PUBLIC &amp; EDGE · 公网与接入层</text><text className="architecture-zone-title" x="492" y="87">COMPUTE PLANE · 应用、撮合与 Worker</text><text className="architecture-zone-title" x="1177" y="87">DATA &amp; CONTROL PLANE · 数据与控制面</text>
    <ArchitectureSvgNode x={45} y={120} width={150} title="Web / App" detail="HTTPS · 幂等请求" tone="neutral" /><ArchitectureSvgNode x={45} y={230} width={150} title="运营 / 管理" detail="权限配置 · 复核" tone="neutral" /><ArchitectureSvgNode x={45} y={340} width={150} title="行情供应商" detail="多源 Tick / Snapshot" tone="amber" target /><ArchitectureSvgNode x={45} y={450} width={150} title="KYC 供应商" detail="审核回调" tone="amber" target />
    <ArchitectureSvgNode x={245} y={120} width={170} title="Caddy / TLS" detail="443 · 证书终止" /><ArchitectureSvgNode x={245} y={230} width={170} title="Nginx" detail="路由 · 限速 · 超时" /><ArchitectureSvgNode x={245} y={340} width={170} title="Market Adapter" detail="标准化 · 缺口检测" tone="amber" target /><ArchitectureSvgNode x={245} y={450} width={170} title="KYC Adapter" detail="供应商状态映射" tone="amber" target />
    <ArchitectureSvgNode x={500} y={120} width={175} title="API Replica A" detail="Spring Boot · Java 21" /><ArchitectureSvgNode x={710} y={120} width={175} title="API Replica B" detail="无状态横向扩容" target /><ArchitectureSvgNode x={920} y={120} width={175} title="API Replica N" detail="无状态横向扩容" target />
    <ArchitectureSvgNode x={710} y={245} width={175} title="Symbol Router" detail="一致路由 · 热点识别" target /><ArchitectureSvgNode x={500} y={355} width={175} title="Match Shard 0" detail="Lane 0..3 · 当前" /><ArchitectureSvgNode x={710} y={355} width={175} title="Match Shard 1" detail="热点标的独占" target /><ArchitectureSvgNode x={920} y={355} width={175} title="Match Shard N" detail="按 symbol 扩容" target />
    <ArchitectureSvgNode x={500} y={485} width={175} title="Outbox Publisher" detail="claim · retry · timeout" tone="violet" /><ArchitectureSvgNode x={710} y={485} width={175} title="Kafka KRaft" detail="演示 1 / 生产 3+" tone="violet" /><ArchitectureSvgNode x={920} y={485} width={175} title="Settlement Worker" detail="partition · Lease · Epoch" tone="violet" />
    <ArchitectureSvgNode x={610} y={620} width={205} title="Settlement Service" detail="Inbox · 有序账户锁" tone="violet" /><ArchitectureSvgNode x={850} y={620} width={205} title="Reconciliation Worker" detail="分页 · 限速 · 可重跑" tone="green" />
    <g className="architecture-database-node"><rect x="1190" y="120" width="160" height="155" rx="14" /><ellipse cx="1270" cy="142" rx="62" ry="14" /><text className="architecture-svg-title" x="1270" y="148" textAnchor="middle">PG Primary</text><text className="architecture-svg-detail" x="1270" y="185" textAnchor="middle">权威写入</text><text className="architecture-svg-detail" x="1270" y="210" textAnchor="middle">唯一键 / 行锁 / CAS</text><text className="architecture-svg-proof" x="1270" y="245" textAnchor="middle">CURRENT</text></g><g className="architecture-database-node architecture-svg-node-target"><rect x="1370" y="120" width="150" height="155" rx="14" /><ellipse cx="1445" cy="142" rx="58" ry="14" /><text className="architecture-svg-title" x="1445" y="148" textAnchor="middle">Standby / Read</text><text className="architecture-svg-detail" x="1445" y="185" textAnchor="middle">主备 + 只读副本</text><text className="architecture-svg-detail" x="1445" y="210" textAnchor="middle">查询 / 对账卸载</text><text className="architecture-svg-target" x="1445" y="245" textAnchor="middle">TARGET</text></g>
    <ArchitectureSvgNode x={1190} y={345} width={160} height={82} title="Prometheus" detail="指标采集 · 告警规则" tone="green" /><ArchitectureSvgNode x={1370} y={345} width={150} height={82} title="Grafana" detail="业务 + JVM 看板" tone="green" /><ArchitectureSvgNode x={1190} y={505} width={160} height={82} title="Flyway / CI" detail="迁移 · 门禁 · 回归" tone="green" /><ArchitectureSvgNode x={1370} y={505} width={150} height={82} title="审计与告警" detail="差异 · 隔离 · 复核" tone="green" /><ArchitectureSvgNode x={1280} y={640} width={195} height={82} title="容量与恢复控制" detail="扩容 · 降级 · CLEAN" tone="green" />
    <g className="topology-edges topology-sync"><path d="M195 154 H245" /><path d="M330 188 V230" /><path d="M415 264 H465 V154 H500" /><path d="M415 264 H465 V154 H710" /><path d="M415 264 H465 V154 H920" /><path d="M195 264 H245" /><path d="M195 374 H245" /><path d="M415 374 H465 V185 H710" /><path d="M195 484 H245" /><path d="M415 484 H465 V185 H500" /><path d="M587 188 V230 H797 V245" /><path d="M797 313 V335 H587 V355" /><path d="M797 313 V355" /><path d="M797 313 V335 H1007 V355" /></g>
    <g className="topology-edges topology-async"><path d="M587 423 V485" /><path d="M797 423 V485" /><path d="M1007 423 V485" /><path d="M675 519 H710" /><path d="M885 519 H920" /><path d="M1007 553 V590 H712 V620" /></g>
    <g className="topology-edges topology-data"><path d="M675 154 H1145 V180 H1190" /><path d="M1095 389 H1145 V205 H1190" /><path d="M815 654 H1145 V235 H1190" /><path d="M1190 230 H1145 V654 H1055" /><path d="M1350 195 H1370" /><path d="M1270 275 V345" /><path d="M1350 386 H1370" /><path d="M1190 546 H1135 V386 H1190" /><path d="M1450 587 V640" /><path d="M1290 587 V620 H1280" /></g>
    <g className="architecture-edge-labels"><text x="430" y="141">LOAD BALANCE</text><text x="680" y="326">ROUTE BY SYMBOL</text><text x="678" y="475">MATCHING EVENTS</text><text x="1110" y="218">SQL TX</text><text x="1120" y="375">METRICS</text></g><g className="architecture-legend" transform="translate(45 785)"><line x1="0" y1="0" x2="34" y2="0" className="legend-sync" /><text x="43" y="4">调用 / 路由</text><line x1="160" y1="0" x2="194" y2="0" className="legend-async" /><text x="203" y="4">事件 / 消费</text><line x1="320" y1="0" x2="354" y2="0" className="legend-data" /><text x="363" y="4">SQL / 指标 / 控制</text><rect x="540" y="-9" width="28" height="18" rx="4" className="legend-target" /><text x="577" y="4">虚线节点为生产扩容拓扑</text></g>
  </svg></div>;
}

function ServiceTopologyCard({ domainKey, domain }: { domainKey: ArchitectureDomainKey; domain: ArchitectureDomain }) {
  return <article className="service-topology-card"><div className="flex items-start justify-between gap-3"><div><p className="font-mono text-[8px] text-cyan-300">SERVICE {domain.index}</p><h5 className="mt-2 text-sm font-semibold text-white">{domain.title}</h5></div><span className="rounded-md border border-white/7 bg-white/[0.025] px-2 py-1 font-mono text-[7px] text-slate-500">{domainKey.toUpperCase()}</span></div><ServiceTopologyDiagram domainKey={domainKey} domain={domain} /><p className="mt-3 border-t border-white/6 pt-3 text-[10px] leading-5 text-slate-500"><span className="mr-2 font-mono text-emerald-300/75">OUTPUT</span>{domain.topology.event}</p></article>;
}

function ServiceTopologyDiagram({ domainKey, domain }: { domainKey: ArchitectureDomainKey; domain: ArchitectureDomain }) {
  const markerId=`service-topology-${domainKey}`;
  const split=(value:string, fallback:string)=>{ const pieces=value.split(' + '); return { title:pieces[0], detail:pieces.length>1?`+ ${pieces.slice(1).join(' + ')}`:fallback }; };
  const app=split(domain.topology.application,'Application Service');
  const adapter=split(domain.topology.adapter,'Mapper / Adapter');
  return <div className="service-topology-svg-scroll mt-4"><svg className="service-topology-svg" viewBox="0 0 820 330" aria-label={`${domain.title}服务拓扑`}><defs><marker id={markerId} markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker></defs><text className="module-svg-caption" x="24" y="28">INBOUND → APPLICATION → PORT / ADAPTER → STATE</text><ArchitectureSvgNode x={25} y={115} width={170} height={72} title={domain.topology.entry} detail="Controller / Listener / Scheduler" tone="neutral" /><ArchitectureSvgNode x={225} y={115} width={170} height={72} title={app.title} detail={app.detail} /><ArchitectureSvgNode x={425} y={115} width={170} height={72} title={adapter.title} detail={adapter.detail} /><g className="module-database-node"><rect x="625" y="115" width="170" height="72" rx="12" /><ellipse cx="710" cy="129" rx="65" ry="11" /><text className="architecture-svg-title" x="710" y="137" textAnchor="middle">PostgreSQL 状态</text><text className="service-topology-store" x="710" y="165" textAnchor="middle">{domain.topology.state}</text></g><path className="service-topology-arrow" markerEnd={`url(#${markerId})`} d="M195 151 H222" /><path className="service-topology-arrow" markerEnd={`url(#${markerId})`} d="M395 151 H422" /><path className="service-topology-arrow" markerEnd={`url(#${markerId})`} d="M595 151 H622" /><g className="service-dependency-node"><rect x="225" y="230" width="370" height="62" rx="11" /><text className="architecture-svg-title" x="410" y="254" textAnchor="middle">DEPENDENCY / GUARD</text><text className="architecture-svg-detail" x="410" y="276" textAnchor="middle">{domain.topology.dependency}</text></g><path className="service-dependency-arrow" d="M310 187 V230" /><path className="service-dependency-arrow" d="M510 187 V230" /><path className="service-event-arrow" d="M710 187 V261 H598" /><text className="module-svg-caption" x="795" y="28" textAnchor="end">{domain.topology.event}</text></svg></div>;
}

function SequenceScenarioCard({ scenario }: { scenario: SequenceScenario }) {
  return <article className="sequence-scenario-card"><div className="flex items-start gap-3"><span className="grid size-8 shrink-0 place-items-center rounded-lg bg-amber-300/10 font-mono text-[8px] text-amber-200">{scenario.index}</span><div><h5 className="text-sm font-semibold text-white">{scenario.title}</h5><p className="mt-2 text-[10px] leading-5 text-slate-500">{scenario.summary}</p></div></div><SequenceDiagram scenario={scenario} /><div className="mt-3 rounded-lg border border-emerald-300/10 bg-emerald-300/[0.035] px-3 py-2.5"><p className="font-mono text-[8px] text-emerald-300">FINAL BUSINESS RESULT</p><p className="mt-1 text-[10px] leading-5 text-emerald-100/65">{scenario.result}</p></div></article>;
}

function SequenceDiagram({ scenario }: { scenario: SequenceScenario }) {
  const width=1040;
  const top=105;
  const messageGap=42;
  const height=top+scenario.messages.length*messageGap+56;
  const left=72;
  const right=width-72;
  const participantGap=(right-left)/(scenario.participants.length-1);
  const xById=new Map(scenario.participants.map((participant,index)=>[participant.id,left+index*participantGap]));
  const marker=(type:SequenceMessage['type']='sync')=>`sequence-${scenario.index}-${type}`;
  const colorClass=(type:SequenceMessage['type']='sync')=>`sequence-message-${type}`;
  return <div className="sequence-svg-scroll mt-4"><svg className="sequence-svg" viewBox={`0 0 ${width} ${height}`} aria-label={`${scenario.title}时序图`}><defs>{(['sync','async','return','reject','data'] as const).map(type=><marker key={type} id={marker(type)} markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className={`sequence-marker-${type}`} /></marker>)}</defs>{scenario.participants.map((participant,index)=>{ const x=left+index*participantGap; return <g key={participant.id}><rect className={`sequence-participant sequence-participant-${participant.tone??'cyan'}`} x={x-62} y="20" width="124" height="54" rx="9" /><text className="sequence-participant-title" x={x} y="42" textAnchor="middle">{participant.label}</text><text className="sequence-participant-detail" x={x} y="60" textAnchor="middle">{participant.detail}</text><line className="sequence-lifeline" x1={x} y1="74" x2={x} y2={height-22} /></g>; })}{scenario.messages.map((message,index)=>{ const fromX=xById.get(message.from)??left; const toX=xById.get(message.to)??right; const y=top+index*messageGap; const type=message.type??'sync'; if(fromX===toX){ return <g key={`${index}-${message.label}`} className={colorClass(type)}><path className="sequence-message-line" markerEnd={`url(#${marker(type)})`} d={`M${fromX} ${y} h42 v20 h-40`} /><text className="sequence-message-label" x={fromX+47} y={y+6}>{message.label}</text></g>; } const mid=(fromX+toX)/2; return <g key={`${index}-${message.label}`} className={colorClass(type)}><line className="sequence-message-line" markerEnd={`url(#${marker(type)})`} x1={fromX} y1={y} x2={toX} y2={y} /><text className="sequence-message-label" x={mid} y={y-8} textAnchor="middle">{message.label}</text></g>; })}</svg></div>;
}

function ModuleArchitectureDiagram({ domainKey, domain }: { domainKey: ArchitectureDomainKey; domain: ArchitectureDomain }) {
  const markerId = `module-arrow-${domainKey}`;
  return <div className="module-svg-scroll mt-5"><svg className="module-architecture-svg" viewBox="0 0 840 320" aria-label={`${domain.title}模块架构图`}><defs><marker id={markerId} markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" className="architecture-marker-sync" /></marker></defs><text className="module-svg-caption" x="22" y="28">INPUT</text><path className="module-svg-arrow" markerEnd={`url(#${markerId})`} d="M20 126 H52" />{domain.flow.map((step, index) => { const x = 55 + index * 190; return <g key={step}><ArchitectureSvgNode x={x} y={92} width={155} height={70} title={step} detail={`STEP ${String(index + 1).padStart(2, '0')}`} />{index < domain.flow.length - 1 && <path className="module-svg-arrow" markerEnd={`url(#${markerId})`} d={`M${x + 155} 127 H${x + 186}`} />}</g>; })}<path className="module-svg-data-arrow" d="M323 162 V218" /><path className="module-svg-data-arrow" d="M513 162 V218" /><g className="module-database-node"><rect x="260" y="218" width="330" height="70" rx="12" /><ellipse cx="425" cy="232" rx="130" ry="12" /><text className="architecture-svg-title" x="425" y="238" textAnchor="middle">权威状态 / 审计落点</text><text className="architecture-svg-detail" x="425" y="267" textAnchor="middle">{domain.dataStore}</text></g><path className="module-svg-reject-arrow" d="M702 162 V210 H760" /><g className="module-reject-node"><rect x="650" y="218" width="165" height="70" rx="12" /><text className="architecture-svg-title" x="732" y="244" textAnchor="middle">明确失败</text><text className="architecture-svg-detail" x="732" y="268" textAnchor="middle">拒绝 / 重试 / 隔离</text></g><text className="module-svg-caption" x="815" y="28" textAnchor="end">OUTPUT · {domain.output}</text></svg></div>;
}

function ArchitecturePressure({ label, response, result }: { label: string; response: string; result: string }) {
  return <div className="border-b border-white/7 p-3 last:border-b-0 sm:odd:border-r xl:border-r xl:border-b-0 xl:last:border-r-0"><p className="font-mono text-[8px] text-slate-600">{label}</p><div className="mt-2 flex items-center gap-2 text-[9px]"><span className="text-cyan-300/70">{response}</span><ArrowRight className="size-3 shrink-0 text-slate-700" /><span className="text-emerald-300/75">{result}</span></div></div>;
}

function ArchitectureDecision({ icon: Icon, title, text, good = false }: { icon: typeof Activity; title: string; text: string; good?: boolean }) {
  return <article className={`rounded-xl border p-3.5 ${good ? 'border-emerald-300/12 bg-emerald-300/[0.035]' : 'border-white/7 bg-black/10'}`}><div className="flex items-center gap-2"><span className={`grid size-7 place-items-center rounded-lg ${good ? 'bg-emerald-300/10 text-emerald-300' : 'bg-cyan-300/10 text-cyan-300'}`}><Icon className="size-3.5" /></span><h5 className="text-[11px] font-medium text-slate-200">{title}</h5></div><p className="mt-3 text-[10px] leading-5 text-slate-500">{text}</p></article>;
}

function ProjectPillar({ icon: Icon, index, title, description, tags }: { icon: typeof Activity; index: string; title: string; description: string; tags: string[] }) {
  return <article className="explain-panel"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-cyan-300/10 text-cyan-300"><Icon className="size-4.5" /></span><span className="font-mono text-[10px] text-slate-700">{index}</span></div><h3 className="mt-5 text-base font-medium text-white">{title}</h3><p className="mt-2 min-h-15 text-xs leading-5 text-slate-500">{description}</p><div className="mt-4 flex flex-wrap gap-1.5">{tags.map((tag) => <span key={tag} className="rounded-md border border-white/7 bg-black/15 px-2 py-1 font-mono text-[9px] text-slate-500">{tag}</span>)}</div></article>;
}

function TradingJourneyNode({ index, icon: Icon, title, state, guard, evidence }: { index: string; icon: typeof Activity; title: string; state: string; guard: string; evidence: string }) {
  return <article className="relative overflow-hidden rounded-xl border border-white/7 bg-black/10 p-3"><div className="flex items-center justify-between"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Icon className="size-4" /></span><span className="font-mono text-[8px] text-slate-700">{index}</span></div><h4 className="mt-3 text-xs font-semibold text-white">{title}</h4><p className="mt-1 font-mono text-[9px] text-emerald-300/80">{state}</p><p className="mt-2 text-[9px] leading-4 text-slate-600">{guard}</p><p className="mt-2 border-t border-white/6 pt-2 font-mono text-[8px] text-cyan-300/50">{evidence}</p></article>;
}

function LifecycleData({ label, value, good = false }: { label: string; value: string; good?: boolean }) {
  return <div className="rounded-lg border border-white/6 bg-black/10 p-2.5"><p className="font-mono text-[8px] text-slate-700">{label}</p><p className={`mt-1 text-[10px] leading-5 ${good ? 'text-emerald-300' : 'text-slate-400'}`}>{value}</p></div>;
}

function LifecycleBoundary({ state, text, planned = false }: { state: string; text: string; planned?: boolean }) {
  return <div className="grid grid-cols-[48px_1fr] gap-2 rounded-lg border border-white/6 bg-black/10 p-2.5"><span className={`font-mono text-[8px] ${planned ? 'text-amber-200' : 'text-emerald-300'}`}>{state}</span><span className="text-[10px] leading-5 text-slate-500">{text}</span></div>;
}

function ManagementPillar({ icon: Icon, index, title, summary, evidence, href }: { icon: typeof Activity; index: string; title: string; summary: string; evidence: string; href: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className="explain-panel performance-panel-button block text-left"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-cyan-300/10 text-cyan-300"><Icon className="size-4.5" /></span><span className="font-mono text-[10px] text-slate-700">{index}</span></div><h3 className="mt-5 text-base font-medium text-white">{title}</h3><p className="mt-2 min-h-20 text-xs leading-5 text-slate-500">{summary}</p><div className="mt-4 flex items-center justify-between gap-3 border-t border-white/7 pt-3"><span className="font-mono text-[9px] text-emerald-300/70">{evidence}</span><ExternalLink className="size-3.5 shrink-0 text-cyan-300/70" /></div></a>;
}

function LeadershipDomain({ icon: Icon, index, title, count, description, tags, href }: { icon: typeof Activity; index: string; title: string; count: string; description: string; tags: string[]; href: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className="explain-panel performance-panel-button block text-left"><div className="flex items-center justify-between"><span className="grid size-9 place-items-center rounded-xl bg-cyan-300/10 text-cyan-300"><Icon className="size-4.5" /></span><span className="font-mono text-[10px] text-slate-700">{index}</span></div><div className="mt-5 flex items-baseline justify-between gap-3"><h3 className="text-base font-medium text-white">{title}</h3><span className="font-mono text-[9px] text-amber-200/70">{count}</span></div><p className="mt-2 min-h-20 text-xs leading-5 text-slate-500">{description}</p><div className="mt-4 flex flex-wrap gap-1.5">{tags.map((tag) => <span key={tag} className="rounded-md border border-white/7 bg-black/15 px-2 py-1 font-mono text-[9px] text-slate-500">{tag}</span>)}</div><span className="mt-4 flex items-center justify-between border-t border-white/7 pt-3 font-mono text-[9px] text-cyan-300/70">查看对应职责 <ExternalLink className="size-3.5" /></span></a>;
}

function LeadershipGuide({ index, title, detail, overview, playbook }: { index: string; title: string; detail: string; overview: string; playbook: string }) {
  return <article className="explain-panel"><div className="flex items-start justify-between gap-3"><span className="grid size-7 shrink-0 place-items-center rounded-lg bg-cyan-300/10 font-mono text-[9px] text-cyan-300">{index}</span><span className="font-mono text-[8px] text-slate-700">OVERVIEW + PLAYBOOK</span></div><h4 className="mt-4 text-sm font-medium text-slate-100">{title}</h4><p className="mt-2 min-h-12 text-[11px] leading-5 text-slate-500">{detail}</p><div className="mt-4 grid grid-cols-2 gap-2"><a href={overview} target="_blank" rel="noreferrer" className="nav-link flex justify-center">阅读概要 <ExternalLink className="size-3" /></a><a href={playbook} target="_blank" rel="noreferrer" className="nav-link flex justify-center">查看实战 <ExternalLink className="size-3" /></a></div></article>;
}

function GovernanceRegistryCard({ icon: Icon, index, count, title, detail, href }: { icon: typeof Activity; index: string; count: string; title: string; detail: string; href: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className="performance-panel-button rounded-xl border border-white/7 bg-black/10 p-4 text-left"><div className="flex items-center justify-between"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Icon className="size-4" /></span><span className="font-mono text-[9px] text-slate-700">{index}</span></div><div className="mt-4 flex items-end justify-between"><h4 className="text-xs font-medium text-slate-200">{title}</h4><strong className="font-mono text-xl font-medium text-cyan-300">{count}</strong></div><p className="mt-2 min-h-10 text-[10px] leading-5 text-slate-600">{detail}</p><span className="mt-3 flex items-center justify-between border-t border-white/6 pt-3 font-mono text-[8px] text-emerald-300/70">VALIDATED REGISTRY <ExternalLink className="size-3" /></span></a>;
}

function GovernanceTraceRow({ type, id, title, state }: { type: string; id: string; title: string; state: string }) {
  return <div className="grid gap-2 rounded-lg border border-white/6 bg-black/10 px-3 py-2.5 sm:grid-cols-[70px_130px_1fr_auto] sm:items-center"><span className="font-mono text-[8px] text-cyan-300/70">{type}</span><span className="font-mono text-[9px] text-slate-400">{id}</span><span className="text-[10px] text-slate-500">{title}</span><span className="w-fit rounded-md bg-emerald-300/[0.06] px-2 py-1 font-mono text-[8px] text-emerald-300/80">{state}</span></div>;
}

function ManagementCaseRow({ time, owner, decision, proof }: { time: string; owner: string; decision: string; proof: string }) {
  return <div className="grid gap-2 rounded-xl border border-white/6 bg-black/10 p-3 sm:grid-cols-[70px_110px_1fr_auto] sm:items-center"><span className="font-mono text-[9px] text-cyan-300">{time}</span><strong className="text-[10px] font-medium text-slate-300">{owner}</strong><span className="text-[10px] leading-5 text-slate-500">{decision}</span><span className="w-fit rounded-md bg-emerald-300/[0.06] px-2 py-1 font-mono text-[9px] text-emerald-300/80">{proof}</span></div>;
}

function ManagementProof({ value, label, note }: { value: string; label: string; note: string }) {
  return <article className="rounded-xl border border-cyan-300/10 bg-cyan-300/[0.035] p-3"><strong className="font-mono text-xl font-medium text-cyan-300">{value}</strong><p className="mt-2 text-xs font-medium text-slate-300">{label}</p><p className="mt-1 text-[9px] text-slate-600">{note}</p></article>;
}

function ManagementGuide({ index, title, detail, href }: { index: string; title: string; detail: string; href: string }) {
  return <a href={href} target="_blank" rel="noreferrer" className="performance-row grid gap-2 rounded-xl border border-white/6 bg-black/10 p-3 sm:grid-cols-[28px_1fr_auto] sm:items-center"><span className="font-mono text-[9px] text-cyan-300/60">{index}</span><span><strong className="block text-xs font-medium text-slate-200">{title}</strong><small className="mt-1 block text-[10px] leading-4 text-slate-600">{detail}</small></span><ExternalLink className="size-3.5 text-cyan-300/60" /></a>;
}

function ArchitectureNode({ index, icon: Icon, title, code, detail, guard, last = false }: { index: string; icon: typeof Activity; title: string; code: string; detail: string; guard: string; last?: boolean }) {
  return <article className="architecture-node"><div className="flex items-center justify-between"><span className="grid size-8 place-items-center rounded-lg bg-cyan-300/10 text-cyan-300"><Icon className="size-4" /></span><span className="font-mono text-[9px] text-slate-700">{index}</span></div><h4 className="mt-4 text-sm font-medium text-slate-100">{title}</h4><p className="mt-1 font-mono text-[9px] text-cyan-300/70">{code}</p><p className="mt-3 text-[11px] leading-5 text-slate-500">{detail}</p><div className="mt-3 rounded-md border border-white/6 bg-black/15 px-2 py-1.5 font-mono text-[9px] text-emerald-300/70">{guard}</div>{!last && <ArrowRight className="architecture-arrow size-4" />}</article>;
}

function InvariantRow({ number, title, description, proof }: { number: string; title: string; description: string; proof: string }) {
  return <article className="grid gap-3 rounded-xl border border-white/6 bg-black/10 p-3 sm:grid-cols-[36px_1fr_auto] sm:items-center"><span className="grid size-8 place-items-center rounded-lg bg-white/5 font-mono text-xs text-cyan-300">{number}</span><div><h4 className="text-xs font-medium text-slate-200">{title}</h4><p className="mt-1 text-[11px] leading-5 text-slate-600">{description}</p></div><span className="w-fit rounded-md bg-emerald-300/[0.06] px-2 py-1 font-mono text-[9px] text-emerald-300">{proof}</span></article>;
}

function TraceRow({ event, action, result, onClick }: { event: string; action: string; result: string; onClick?: () => void }) {
  const content = <><span className="text-slate-400">{event}</span><ArrowRight className="size-3 text-slate-700" /><span className="text-cyan-300/70">{action}</span><ArrowRight className="size-3 text-slate-700" /><span className="text-right font-mono text-emerald-300/80">{result}</span></>;
  return onClick
    ? <button type="button" onClick={onClick} className="performance-row grid w-full grid-cols-[1fr_18px_1fr_18px_1fr] items-center gap-1 rounded-lg px-2 py-2.5 text-left text-[10px] odd:bg-white/[0.02]">{content}</button>
    : <div className="grid grid-cols-[1fr_18px_1fr_18px_1fr] items-center gap-1 rounded-lg px-2 py-2.5 text-[10px] odd:bg-white/[0.02]">{content}</div>;
}

function QuickStep({ number, title, command, note }: { number: string; title: string; command: string; note: string }) {
  return <article className="rounded-xl border border-white/7 bg-black/15 p-4"><span className="font-mono text-[9px] text-cyan-300">STEP {number}</span><h4 className="mt-3 text-xs font-medium text-slate-200">{title}</h4><code className="mt-3 block overflow-x-auto rounded-md bg-[#060d13] px-2.5 py-2 font-mono text-[9px] text-amber-200/80">{command}</code><p className="mt-3 text-[10px] leading-4 text-slate-600">{note}</p></article>;
}

function CodeStat({ value, label, detail }: { value: string; label: string; detail: string }) {
  return <article className="rounded-xl border border-white/7 bg-black/10 p-4"><div className="flex items-baseline justify-between gap-3"><strong className="font-mono text-2xl font-medium text-cyan-300">{value}</strong><span className="text-xs font-medium text-slate-300">{label}</span></div><p className="mt-2 text-[10px] leading-4 text-slate-600">{detail}</p></article>;
}

function CodeEvidence({ title, text, tone }: { title: string; text: string; tone: 'rose' | 'green' }) {
  const style = tone === 'rose'
    ? 'border-rose-300/12 bg-rose-300/[0.035] text-rose-100/60'
    : 'border-emerald-300/12 bg-emerald-300/[0.04] text-emerald-100/60';
  return <div className={`mt-3 rounded-lg border p-3 ${style}`}><p className={`font-mono text-[8px] ${tone === 'rose' ? 'text-rose-300' : 'text-emerald-300'}`}>{title.toUpperCase()}</p><p className="mt-2 text-[10px] leading-5">{text}</p></div>;
}
