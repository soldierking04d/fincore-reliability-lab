import { mkdir, copyFile, readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { verifyPublicRoots } from './verify-public-content.mjs';

const source = new URL('../../fincore-reliability-lab/experiments/runtime-security/', import.meta.url);
const output = new URL('../public/runtime-security/', import.meta.url);
await mkdir(output, { recursive: true });
const files = ['php-policy.mjs', 'php-policy.test.mjs', 'assess.mjs', 'inventory.example.json', 'ThreadLocalIsolationDemo.java', 'verify.mjs', 'README.md',
  'runtime-guards.mjs', 'runtime-guards.test.mjs', 'context_isolation.py', 'request_lifetime.cpp', 'release-gates.mjs', 'release-gates.test.mjs', 'casebook.json'];
for (const file of files) await copyFile(new URL(file, source), new URL(file, output));
// 下载副本使用同目录链接，避免离开原仓库后手册链接失效。
const readme = (await readFile(new URL('README.md', output), 'utf8')).replace('../../docs/security/php-runtime-2026-10.md', 'php-runtime-2026-10.md');
await writeFile(new URL('README.md', output), readme);
await copyFile(new URL('../../fincore-reliability-lab/docs/security/php-runtime-2026-10.md', import.meta.url), new URL('php-runtime-2026-10.md', output));
const evidence = JSON.parse(execFileSync(process.execPath, [fileURLToPath(new URL('verify.mjs', output))], { encoding: 'utf8' }));
await writeFile(new URL('evidence.json', output), JSON.stringify(evidence, null, 2) + '\n');
await verifyPublicRoots([fileURLToPath(output)]);
const archive = execFileSync('zip', ['-q', '-', ...files, 'php-runtime-2026-10.md', 'evidence.json'], { cwd: fileURLToPath(output), maxBuffer: 4 * 1024 * 1024 });
await writeFile(new URL('source.zip', output), archive);
console.log(JSON.stringify({ ruleTests: evidence.ruleTests, guardTests: evidence.guardTests, releaseGateTests: evidence.releaseGateTests,
  cliExitCodes: evidence.cliExitCodes, java: evidence.java.passed, python: evidence.python.tests, cpp: evidence.cpp.safeChecks, asanDetected: evidence.cpp.asanDetected, decoding: evidence.decoding, assets: evidence.exampleAssets.length }));
