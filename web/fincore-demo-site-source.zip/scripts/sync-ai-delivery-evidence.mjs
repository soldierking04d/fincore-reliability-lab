import { writeFile,mkdir,readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { buildPublicEvidence } from '../../fincore-reliability-lab/ai/developer-adoption/live-lab/public-evidence.mjs';

const evidence=await buildPublicEvidence();
const text=JSON.stringify(evidence,null,2)+'\n';
if (/\/Users\/|PRIVATE KEY|X-Lab-Token|connectionIp|UserKnownHostsFile|localhost:4400|127\.0\.0\.1:4400/.test(text)) throw Error('公开证据包含私有运行配置');
const publicDir=new URL('../public/ai-delivery/',import.meta.url);
await mkdir(publicDir,{recursive:true});
await writeFile(new URL('evidence.json',publicDir),text);
await writeFile(new URL('../../fincore-reliability-lab/ai/developer-adoption/live-lab/public-evidence.json',import.meta.url),text);
const primary=evidence.runs[0];
for(const [name,source] of [['TicketQuery.before.java',primary.beforeSource],['TicketQuery.candidate.java',primary.candidateSource]])await writeFile(new URL(name,publicDir),source);
const workshop=new URL('../../fincore-reliability-lab/ai/developer-adoption/workshop/',import.meta.url);
for(const name of ['QueryProbe.java','cases.json'])await writeFile(new URL(name,publicDir),await readFile(new URL('tests/'+name,workshop)));
console.log(JSON.stringify({target:fileURLToPath(publicDir),runs:evidence.runs.length,modelCalls:primary.calls.length,tests:`${primary.before.passed}→${primary.after.passed}/12`}));
