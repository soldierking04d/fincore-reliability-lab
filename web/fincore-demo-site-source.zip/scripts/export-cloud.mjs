import { cp, mkdir, readFile, writeFile, access, rm } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { verifyPublicRoots } from './verify-public-content.mjs';

// 腾讯云没有 Sites Worker：从同一生产产物导出首页，API 在源代码中按部署目标适配。
// 禁止抓开发服务器页面，禁止修改压缩 JS；缺少任一引用资源就停止打包。
const origin = process.argv[2] ?? 'http://127.0.0.1:8787';
const target = path.resolve(process.argv[3] ?? 'outputs/cloud-web');
const outputRoot = path.resolve('outputs');
const relativeTarget = path.relative(outputRoot, target);
if (!relativeTarget || relativeTarget.startsWith('..') || path.isAbsolute(relativeTarget)) {
  throw new Error('导出目录必须是项目 outputs 下的独立子目录');
}
await access('dist/server/index.js');
// `worker:` 直接调用已构建的生产 Worker，避免导出过程依赖开发服务器或文件监听器。
const response = origin === 'worker:'
  ? await (await import(pathToFileURL(path.resolve('dist/server/index.js')))).default.fetch(
      new Request('https://fincore-export.invalid/'), {}, { waitUntil() {}, passThroughOnException() {} })
  : await fetch(origin, { signal: AbortSignal.timeout(15_000) });
if (!response.ok) throw new Error(`生产首页不可用：${response.status}`);
const html = await response.text();
if (!html.includes('FINCORE') || html.includes('/@vite/client')) throw new Error('只能导出 FinCore 生产首页');
const assets = [...html.matchAll(/(?:src|href)="(\/_next\/[^"?#]+)[^"]*"/g)].map(m => m[1]);
if (!assets.some(asset => asset.endsWith('.js'))) throw new Error('缺少生产脚本');
for (const asset of assets) await access(path.join('dist/client', asset));
// 从空目录生成，避免发行包夹带旧构建的内容寻址资源。
await rm(target, { recursive: true, force: true });
await mkdir(target, { recursive: true });
await cp('dist/client/_next', path.join(target, '_next'), { recursive: true });
for (const asset of ['favicon.svg', 'og.png']) await cp(`dist/client/${asset}`, path.join(target, asset));
// 页面中的实施手册、任务合同、验证证据与工具包也是发行制品，不能只上传脚本和图片。
await cp('dist/client/ai-developer', path.join(target, 'ai-developer'), { recursive: true });
await cp('dist/client/ai-delivery', path.join(target, 'ai-delivery'), { recursive: true });
await cp('dist/client/performance', path.join(target, 'performance'), { recursive: true });
await cp('dist/client/trading-boundaries', path.join(target, 'trading-boundaries'), { recursive: true });
await cp('dist/client/runtime-security', path.join(target, 'runtime-security'), { recursive: true });
for (const asset of ['php-policy.mjs', 'php-policy.test.mjs', 'assess.mjs', 'inventory.example.json', 'ThreadLocalIsolationDemo.java', 'verify.mjs', 'README.md', 'php-runtime-2026-10.md', 'evidence.json', 'source.zip',
  'runtime-guards.mjs', 'runtime-guards.test.mjs', 'context_isolation.py', 'request_lifetime.cpp', 'release-gates.mjs', 'release-gates.test.mjs', 'casebook.json']) {
  await access(path.join(target, 'runtime-security', asset));
}
for (const asset of ['model.mjs', 'model.test.mjs', 'execution-model.mjs', 'execution-model.test.mjs', 'recovery-model.mjs', 'recovery-model.test.mjs', 'run.mjs', 'README.md', 'source.zip',
  'transaction-boundaries-playbook.md', 'coverage.md', 'evidence.json']) {
  await access(path.join(target, 'trading-boundaries', asset));
}
for (const asset of ['README.md', 'middleware-optimization-playbook.md', 'hot-account-optimization-playbook.md',
  'settlement-performance-playbook.md', 'VERIFICATION.md', 'tool-guide.md', 'settlement-comparison.mjs',
  'settlement-comparison.test.mjs', 'compose.isolated.yml', '01-audit-role.sql', 'settlement-completion.md',
  'settlement-database-audit.mjs', 'settlement-database-audit.test.mjs', 'settlement-source.zip', 'settlement-evidence.json']) {
  await access(path.join(target, 'performance', asset));
}
for (const asset of ['kit.zip', 'company-playbook.md', 'evidence.json',
  'tasks/understand.md', 'tasks/implement.md', 'tasks/repair.md']) {
  await access(path.join(target, 'ai-developer', asset));
}
await writeFile(path.join(target, 'index.html'), html);
for (const asset of ['evidence.json','TicketQuery.before.java','TicketQuery.candidate.java','QueryProbe.java','cases.json']) {
  await access(path.join(target,'ai-delivery',asset));
}
await verifyPublicRoots([target]);
const manifest = JSON.parse(await readFile('.openai/hosting.json', 'utf8'));
console.log(`已导出 ${assets.length} 个首页资源引用，来源 Site ${manifest.project_id}`);
