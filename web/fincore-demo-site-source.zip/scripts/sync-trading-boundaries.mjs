import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { posix } from 'node:path';
import { verifyPublicRoots } from './verify-public-content.mjs';

// 仅复制明确列出的公开源码，不带出其他工作区或个人材料。站点和下载共用同一模型。
const repo = new URL('../../fincore-reliability-lab/', import.meta.url);
const output = new URL('../public/trading-boundaries/', import.meta.url);
await mkdir(output, { recursive: true });
const sourceFiles = ['model.mjs', 'model.test.mjs', 'execution-model.mjs', 'execution-model.test.mjs', 'recovery-model.mjs', 'recovery-model.test.mjs', 'run.mjs', 'README.md'];
for (const name of sourceFiles) {
  await copyFile(new URL(`experiments/funds-boundaries/${name}`, repo), new URL(name, output));
}
for (const [source, target] of [['transaction-boundaries-playbook.md', 'transaction-boundaries-playbook.md'], ['transaction-boundaries-coverage.md', 'coverage.md']]) {
  const markdown = await readFile(new URL(`docs/${source}`, repo), 'utf8');
  // 下载目录不包含整座代码仓库，把仓库内的相对引用指向公开源码。
  const portable = markdown.replace(/(\]\()([^\s)]+)(\))/g, (match, before, href, after) => {
    if (/^(?:[a-z]+:|\/|#)/i.test(href)) return match;
    const [path, fragment] = href.split('#');
    const resolved = posix.normalize(posix.join('docs', path));
    if(resolved.startsWith('experiments/funds-boundaries/') && sourceFiles.includes(posix.basename(resolved))) return `${before}${posix.basename(resolved)}${fragment ? `#${fragment}` : ''}${after}`;
    const url = `https://github.com/soldierking04d/fincore-reliability-lab/blob/main/${resolved.split('/').map(encodeURIComponent).join('/')}${fragment ? `#${fragment}` : ''}`;
    return `${before}${url}${after}`;
  });
  await writeFile(new URL(target, output), portable);
}
const report = JSON.parse(execFileSync(process.execPath, [fileURLToPath(new URL('run.mjs', output))], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 }));
if (report.passed !== true) throw new Error('教学模型检查未通过，不生成展示证据');
const modelSha256 = createHash('sha256').update(await readFile(new URL('model.mjs', output))).digest('hex');
const sourceSha256 = Object.fromEntries(await Promise.all(['model.mjs','execution-model.mjs','recovery-model.mjs'].map(async name=>[name,createHash('sha256').update(await readFile(new URL(name,output))).digest('hex')])));
await writeFile(new URL('evidence.json', output), JSON.stringify({ generatedAt: new Date().toISOString(), modelSha256, sourceSha256, ...report }, null, 2) + '\n');
await verifyPublicRoots([fileURLToPath(output)]);
// zip - 写出新归档到 stdout，不把旧压缩包中的已删除文件带回来。
const archive = execFileSync('zip', ['-q', '-', ...sourceFiles, 'transaction-boundaries-playbook.md', 'coverage.md', 'evidence.json'], { cwd: fileURLToPath(output), maxBuffer: 4 * 1024 * 1024 });
await writeFile(new URL('source.zip', output), archive);
console.log(JSON.stringify({ cases: report.summary.length, snapshots: report.summary.reduce((sum, c) => sum + c.snapshots, 0), passed: true, modelSha256 }));
