import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

// 只检查会被浏览器或站点服务交付的内容；个人准备材料必须保存在仓库外。
// 测试用例和规则定义自身不属于发布资源，不能被拿来豁免真实页面。
const privateCopy = /面试|追问|备考|面经|答题卡|终面速记|回答(?:话术|模板|结构)|(?:60|90)\s*秒(?:回答|自我介绍)|先讲本质|再讲架构|最后讲运营|\binterview(?:s|ing)?\b/iu;
const privatePath = /(?:interview|interview-prep|private-notes|personal-preparation|面试|备考)/iu;
const textExtensions = new Set(['.ts', '.tsx', '.js', '.mjs', '.cjs', '.json', '.html', '.md', '.txt', '.svg', '.css', '.map']);

export function publicContentViolation(file, content) {
  if (privatePath.test(file)) return 'private-material-path';
  if (privateCopy.test(content)) return 'private-preparation-copy';
  return null;
}

export async function verifyPublicRoots(roots) {
  const failures = [];
  let checked = 0;
  async function visit(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const file = path.join(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error(`发布内容检查不接受符号链接：${file}`);
      if (entry.isDirectory()) await visit(file);
      else if (entry.isFile() && textExtensions.has(path.extname(file))) {
        checked += 1;
        const reason = publicContentViolation(file, await readFile(file, 'utf8'));
        if (reason) failures.push({ file, reason });
      }
    }
  }
  for (const root of roots) await visit(root);
  if (failures.length) {
    // 只报告位置，不把待移除原文重复输出到公开日志。
    throw new Error(`公开内容检查失败：\n${failures.map(({file, reason}) => `${file}: ${reason}`).join('\n')}`);
  }
  if (checked === 0) throw new Error('公开内容检查没有读取任何文本，拒绝空检查通过');
  return checked;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const roots = ['app', 'components', 'lib', 'hooks', 'public'];
  if (process.argv.includes('--built')) roots.push('dist/client', 'dist/server');
  const checked = await verifyPublicRoots(roots);
  console.log(`Public delivery content gate passed: ${checked} text files.`);
}
